from pathlib import Path
from datetime import datetime
import shutil
import re

ROOT = Path(__file__).resolve().parent

PHP_FILE = ROOT / "index.php"
JS_FILE = ROOT / "app" / "assets" / "index.js"

BACKUP_DIR = (
    ROOT
    / "app"
    / "data"
    / "local_avatar_patch"
    / datetime.now().strftime("%Y%m%d_%H%M%S")
)

php = PHP_FILE.read_text(encoding="utf-8")
js = JS_FILE.read_text(encoding="utf-8")

php_new = php
js_new = js


# ============================================================
# index.php：加入 COC
# ============================================================

if "coc dylan" in php_new:
    print("✓ COC：已经存在")
else:
    pattern = r"(\$names\s*=\s*explode\(\s*'\s*',\s*')dylan\b"

    php_new, count = re.subn(
        pattern,
        r"\1coc dylan",
        php_new,
        count=1
    )

    if count != 1:
        raise SystemExit(
            "错误：找不到 avatar_styles() 的官方样式列表，未修改。"
        )

    print("+ COC：已加入")


# ============================================================
# index.php：头像改成本地
# ============================================================

local_php = """function avatar_remote_url(string $style, string $seed): string
{
    $style = preg_replace('/[^a-z0-9_-]/i', '', $style);
    $seed = (string)max(1, min(48, (int)$seed));
    return '/app/avatars/' . $style . '_' . $seed . '.svg';
}"""

if "return '/app/avatars/' . $style . '_' . $seed . '.svg';" in php_new:
    print("✓ PHP：头像 URL 已经是本地")
else:
    pattern = (
        r"function\s+avatar_remote_url\s*"
        r"\(\s*string\s+\$style\s*,\s*string\s+\$seed\s*\)"
        r"\s*:\s*string\s*\{.*?\}"
    )

    php_new, count = re.subn(
        pattern,
        lambda _: local_php,
        php_new,
        count=1,
        flags=re.S
    )

    if count != 1:
        raise SystemExit(
            "错误：找不到 avatar_remote_url()，未修改。"
        )

    print("+ PHP：头像 URL 已切换为本地")


# ============================================================
# index.js：头像改成本地
# ============================================================

local_js = """function avatarRemoteUrl(style, seed) {
    return "/app/avatars/"
        + encodeURIComponent(style)
        + "_"
        + encodeURIComponent(seed)
        + ".svg";
}"""

if 'return "/app/avatars/"' in js_new:
    print("✓ JS：头像 URL 已经是本地")
else:
    pattern = (
        r"function\s+avatarRemoteUrl\s*"
        r"\(\s*style\s*,\s*seed\s*\)\s*\{.*?\}"
    )

    js_new, count = re.subn(
        pattern,
        lambda _: local_js,
        js_new,
        count=1,
        flags=re.S
    )

    if count != 1:
        raise SystemExit(
            "错误：找不到 avatarRemoteUrl()，未修改。"
        )

    print("+ JS：头像 URL 已切换为本地")


# ============================================================
# 没有变化
# ============================================================

if php_new == php and js_new == js:
    print()
    print("没有需要修改的内容。")
    raise SystemExit(0)


# ============================================================
# 备份
# ============================================================

BACKUP_DIR.mkdir(parents=True, exist_ok=True)

shutil.copy2(
    PHP_FILE,
    BACKUP_DIR / "index.php"
)

shutil.copy2(
    JS_FILE,
    BACKUP_DIR / "index.js"
)

print()
print("备份：")
print(BACKUP_DIR)


# ============================================================
# 写入
# ============================================================

PHP_FILE.write_text(
    php_new,
    encoding="utf-8"
)

JS_FILE.write_text(
    js_new,
    encoding="utf-8"
)

print("✓ index.php 已修改")
print("✓ app/assets/index.js 已修改")

print()
print("========================================")
print(" 补丁完成")
print("========================================")