<?php
if (!defined('APP_ROOT')) exit;

function md_video_config(): array
{
    $raw = plugin_config('md_video', []);
    return [
        'max_size_mb' => min(100, max(1, (int)($raw['max_size_mb'] ?? 50))),
        'allowed_exts' => $raw['allowed_exts'] ?? ['mp4', 'webm', 'ogg'],
    ];
}

function md_video_install(array $plugin): void
{
    plugin_save_config('md_video', [
        'max_size_mb' => 50,
        'allowed_exts' => ['mp4', 'webm', 'ogg'],
    ]);
}

function md_video_css(): string
{
    return '
.md-video-wrap{max-width:100%;margin:10px 0;border-radius:var(--radius-sm);overflow:hidden;background:var(--inverse)}
.md-video-wrap video{display:block;width:100%;max-height:480px;border-radius:var(--radius-sm)}
';
}

function md_video_js(): string
{
    return '
(function(){
    const VIDEO_MARK = "![video](";
    
    function md_video_insert(textarea, text) {
        const s = textarea.selectionStart, e = textarea.selectionEnd;
        const before = textarea.value.substring(0, s);
        const after = textarea.value.substring(e);
        const prefix = before && !before.endsWith("\\n") ? "\\n" : "";
        const suffix = after && !after.startsWith("\\n") ? "\\n" : "";
        textarea.value = before + prefix + text + suffix + after;
        const pos = s + prefix.length + text.length + suffix.length;
        textarea.selectionStart = textarea.selectionEnd = pos;
        textarea.dispatchEvent(new Event("input", {bubbles: true}));
    }
    
    function md_video_isVideo(file) {
        return file && file.type && file.type.startsWith("video/");
    }
    
    function md_video_upload(file, textarea) {
        const form = textarea.closest("form");
        const csrf = form?.querySelector("input[name=_csrf]")?.value || "";
        const fd = new FormData();
        fd.append("video", file);
        fd.append("_csrf", csrf);
        
        const toast = document.getElementById("toast");
        if (toast) { toast.textContent = "视频上传中…"; toast.hidden = false; }
        
        fetch("' . h(route_url('md_video_upload')) . '", {
            method: "POST",
            body: fd,
            headers: {"X-Requested-With": "XMLHttpRequest"}
        })
        .then(r => r.json())
        .then(data => {
            if (toast) toast.hidden = true;
            if (data.ok && data.url) {
                md_video_insert(textarea, VIDEO_MARK + data.url + ")");
                if (typeof showToast === "function") showToast("视频已插入");
            } else {
                if (typeof showToast === "function") showToast(data.message || "上传失败");
            }
        })
        .catch(() => {
            if (toast) toast.hidden = true;
            if (typeof showToast === "function") showToast("上传失败");
        });
    }
    
    document.addEventListener("paste", function(e) {
        const t = e.target.closest("textarea[name=body]");
        if (!t) return;
        const items = e.clipboardData?.items;
        if (!items) return;
        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            if (item.kind === "file" && md_video_isVideo(item.getAsFile())) {
                e.preventDefault();
                md_video_upload(item.getAsFile(), t);
                return;
            }
        }
    });

    document.addEventListener("dragover", function(e) {
        const t = e.target.closest("textarea[name=body]");
        if (!t) return;
        const hasFiles = e.dataTransfer?.types?.includes("Files");
        if (!hasFiles) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
    }, true);

    document.addEventListener("drop", function(e) {
        const t = e.target.closest("textarea[name=body]");
        if (!t) return;
        const files = e.dataTransfer?.files;
        if (!files || files.length === 0) return;
        const file = files[0];
        if (md_video_isVideo(file)) {
            e.preventDefault();
            e.stopPropagation();
            md_video_upload(file, t);
            if (typeof showToast === "function") {
                showToast("视频上传中...");
            }
        }
    }, true);
})();
';
}

function md_video_markdown_before(string $text, array $ctx): string
{
    return preg_replace_callback('/!\\[video\\]\\(([^)]+)\\)/i', static function (array $m): string {
        $url = trim($m[1]);
        if ($url === '') return $m[0];
        return "\x1BMD_VIDEO:" . base64_encode($url) . "\x1B";
    }, $text) ?? $text;
}

function md_video_markdown_after(string $html, array $ctx): string
{
    return preg_replace_callback('/\x1BMD_VIDEO:([A-Za-z0-9+\/=]+)\x1B/', static function (array $m): string {
        $url = base64_decode($m[1]);
        if ($url === false || $url === '') return '';
        return '<div class="md-video-wrap"><video src="' . h($url) . '" controls preload="metadata" playsinline></video></div>';
    }, $html) ?? $html;
}

function md_video_route_upload(array $plugin): void
{
    require_post();
    need_speak();
    
    $config = md_video_config();
    $file = $_FILES['video'] ?? null;
    
    if (!$file || (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        json_response(['ok' => 0, 'message' => '请选择视频文件']);
    }
    
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($file['tmp_name']);
    $ext = match ($mime) {
        'video/webm' => 'webm',
        'video/ogg', 'video/ogv' => 'ogg',
        default => 'mp4',
    };
    
    if (!in_array($ext, $config['allowed_exts'], true)) {
        json_response(['ok' => 0, 'message' => '仅支持 ' . implode(', ', $config['allowed_exts']) . ' 格式的视频']);
    }
    
    $maxBytes = $config['max_size_mb'] * 1024 * 1024;
    if ((int)($file['size'] ?? 0) > $maxBytes) {
        json_response(['ok' => 0, 'message' => '视频大小超过 ' . $config['max_size_mb'] . 'MB 限制']);
    }
    
    $hash = hash_file('sha256', $file['tmp_name']);
    $dir = UPLOAD_DIR . '/' . upload_hash_dir($hash);
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        json_response(['ok' => 0, 'message' => '保存目录创建失败']);
    }
    
    $filename = 'md_video_' . substr($hash, 0, 16) . '.' . $ext;
    $path = $dir . '/' . $filename;
    
    if (!move_uploaded_file($file['tmp_name'], $path)) {
        json_response(['ok' => 0, 'message' => '文件保存失败']);
    }
    
    $url = app_url(str_replace(APP_ROOT . '/', '', $path));
    json_response(['ok' => 1, 'url' => $url]);
}

function md_video_admin_page(array $plugin): string
{
    $config = md_video_config();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals(csrf_token(), (string)($_POST['_csrf'] ?? ''))) {
            err('请求已过期');
        }
        $max_size_mb = min(100, max(1, (int)($_POST['max_size_mb'] ?? 50)));
        $allowed_exts = [];
        foreach (['mp4', 'webm', 'ogg'] as $ext) {
            if (isset($_POST['ext_' . $ext])) {
                $allowed_exts[] = $ext;
            }
        }
        if (empty($allowed_exts)) {
            err('至少选择一种视频格式');
        }
        plugin_save_config('md_video', [
            'max_size_mb' => $max_size_mb,
            'allowed_exts' => $allowed_exts,
        ]);
        set_flash('设置已保存');
        go(admin_url(['tab' => 'md_video']));
    }

    $form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'md_video'])) . '">'
        . form_token()
        . '<label class="grid"><span>最大上传大小 (MB)</span><input type="number" name="max_size_mb" value="' . (int)$config['max_size_mb'] . '" min="1" max="100"></label>'
        . '<div class="grid"><span>允许的视频格式</span><div style="display:flex;gap:12px;flex-wrap:wrap;">';
    foreach (['mp4', 'webm', 'ogg'] as $ext) {
        $checked = in_array($ext, $config['allowed_exts'], true) ? ' checked' : '';
        $form .= '<label><input type="checkbox" name="ext_' . $ext . '" value="1"' . $checked . '> ' . strtoupper($ext) . '</label>';
    }
    $form .= '</div></div>'
        . '<button>保存设置</button></form>';

    return '<div class="admin-list-panel plugin-manage-panel">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>视频 MD 语法设置</strong><span>配置视频上传大小和允许的格式</span></div>', '')
        . '<div class="plugin-panel-body">' . $form . '</div></div>';
}

return [
    'id' => 'md_video',
    'name' => '视频 MD 语法与粘贴上传',
    'version' => '1.1.0',
    'description' => '在帖子中插入视频并支持粘贴与拖拽上传，增加了 ![video](视频地址) 自定义 MD 语法嵌入视频。',
    'author' => 'banming',
    'assets' => ['css' => 'md_video_css', 'js' => 'md_video_js'],
    'hooks' => [
        'markdown.before' => 'md_video_markdown_before',
        'markdown.after' => 'md_video_markdown_after',
    ],
    'routes' => [
        'md_video_upload' => 'md_video_route_upload',
    ],
    'admin_tabs' => [
        'md_video' => 'md_video_admin_page',
    ],
    'install' => 'md_video_install',
];