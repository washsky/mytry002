<?php
if (!defined('APP_ROOT')) exit;

// ============ 聊天室 1.6.4 ============
// SSE 实时消息 + POST 发送。当前版本以测试环境为目标，保留后续切换 WebSocket 的接口边界。

const CHAT_DEFAULT_ROOM_KEY = 'lobby';
const CHAT_DEFAULT_ROOM_NAME = '大厅';
const CHAT_DEFAULT_ROOM_DESC = '大家随便聊，欢迎来到聊天室。';
const CHAT_MAX_MESSAGE_LENGTH = 4000;
const CHAT_SSE_TICK = 1;
const CHAT_SSE_KEEPALIVE = 15;
const CHAT_PRESENCE_INTERVAL = 10;
const CHAT_PRESENCE_TTL = 45;
const CHAT_HISTORY_PAGE_SIZE = 40;
const CHAT_PLUGIN_VERSION = '1.6.27';
const CHAT_PRIVATE_HISTORY_PAGE_SIZE = 40;
const CHAT_SCHEMA_VERSION = '1.6.0';
const CHAT_PRIVATE_PRESENCE_BASE = 1000000000;

/* =========================================================
 * 1. 插件配置与界面文案
 * ========================================================= */

function chat_default_ui(): array
{
    return [
        'menu_label' => '聊天室',
        'page_title' => '聊天室',
        'page_subtitle' => '实时交流，想到什么就聊什么。',
        'new_room_label' => '新建聊天室',
        'manage_label' => '管理聊天室',
        'send_label' => '发送',
        'input_placeholder' => '输入消息……',
        'empty_rooms' => '暂无聊天室。',
        'empty_messages' => '还没有消息，来发第一条吧。',
        'login_to_chat' => '登录后即可发言。',
        'delete_label' => '删除',
        'disable_label' => '已关闭',
        'online_suffix' => '人活跃',
    ];
}

function chat_ui(array $plugin): array
{
    $config = plugin_config((string)($plugin['id'] ?? 'forum_chat_room'), []);
    $defaults = chat_default_ui();
    $saved = is_array($config['ui'] ?? null) ? $config['ui'] : [];
    $ui = [];
    foreach ($defaults as $key => $value) {
        $candidate = trim((string)($saved[$key] ?? ''));
        $ui[$key] = $candidate !== '' ? cut($candidate, 300) : $value;
    }
    return $ui;
}

function chat_default_config(): array
{
    return [
        'ui' => chat_default_ui(),
        'sse' => [
            'max_lifetime' => 120,
            'close_on_timeout' => 1,
            'keepalive' => 15,
            'poll_interval' => 2,
            'batch_limit' => 100,
            'initial_limit' => 30,
            'reconnect_delay' => 1500,
            'allow_guest' => 0,
        ],
        'presence' => [
            'enabled' => 1,
            'ttl' => 45,
            'interval' => 10,
        ],
    ];
}

function chat_config(): array
{
    $saved = plugin_config('forum_chat_room', []);
    $defaults = chat_default_config();
    $sse = is_array($saved['sse'] ?? null) ? $saved['sse'] : [];
    $presence = is_array($saved['presence'] ?? null) ? $saved['presence'] : [];
    return [
        'sse' => [
            'max_lifetime' => max(15, min(1800, (int)($sse['max_lifetime'] ?? $defaults['sse']['max_lifetime']))),
            'close_on_timeout' => !empty($sse['close_on_timeout']) ? 1 : 0,
            'keepalive' => max(5, min(120, (int)($sse['keepalive'] ?? $defaults['sse']['keepalive']))),
            'poll_interval' => max(1, min(30, (int)($sse['poll_interval'] ?? $defaults['sse']['poll_interval']))),
            'batch_limit' => max(10, min(200, (int)($sse['batch_limit'] ?? $defaults['sse']['batch_limit']))),
            'initial_limit' => max(10, min(100, (int)($sse['initial_limit'] ?? $defaults['sse']['initial_limit']))),
            'reconnect_delay' => max(250, min(30000, (int)($sse['reconnect_delay'] ?? $defaults['sse']['reconnect_delay']))),
            'allow_guest' => !empty($sse['allow_guest']) ? 1 : 0,
        ],
        'presence' => [
            'enabled' => array_key_exists('enabled', $presence) ? (!empty($presence['enabled']) ? 1 : 0) : $defaults['presence']['enabled'],
            'ttl' => max(15, min(600, (int)($presence['ttl'] ?? $defaults['presence']['ttl']))),
            'interval' => max(5, min(60, (int)($presence['interval'] ?? $defaults['presence']['interval']))),
        ],
        'ui' => is_array($saved['ui'] ?? null) ? $saved['ui'] : $defaults['ui'],
    ];
}

function chat_ensure_schema(): void
{
    static $ready = false;
    if ($ready) return;
    $ready = true;
    if (!function_exists('app_db_table_exists') || !function_exists('db')) return;
    $t = app_db_types();

    app_db_create_table('plugin_chat_private_conversations',
        "id {$t['id']},user_low_id {$t['uint']} NOT NULL,user_high_id {$t['uint']} NOT NULL,created_at {$t['uint']} NOT NULL,updated_at {$t['uint']} NOT NULL,last_message_id {$t['uint']} NOT NULL DEFAULT 0,UNIQUE(user_low_id,user_high_id)"
    );
    app_db_ensure_columns('plugin_chat_private_conversations', [
        'user_low_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'user_high_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'created_at' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'updated_at' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'last_message_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
    ]);
    app_db_create_index('plugin_chat_private_conv_low_idx', 'plugin_chat_private_conversations(user_low_id,updated_at)');
    app_db_create_index('plugin_chat_private_conv_high_idx', 'plugin_chat_private_conversations(user_high_id,updated_at)');

    app_db_create_table('plugin_chat_private_messages',
        "id {$t['id']},conversation_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,body {$t['text']} NOT NULL,created_at {$t['uint']} NOT NULL,deleted_at {$t['uint']} NOT NULL DEFAULT 0"
    );
    app_db_ensure_columns('plugin_chat_private_messages', [
        'conversation_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'user_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'body' => $t['text'] . ' NOT NULL',
        'created_at' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'deleted_at' => $t['uint'] . ' NOT NULL DEFAULT 0',
    ]);
    app_db_create_index('plugin_chat_private_messages_conv_idx', 'plugin_chat_private_messages(conversation_id,id)');
    app_db_create_index('plugin_chat_private_messages_user_idx', 'plugin_chat_private_messages(user_id,id)');

    app_db_create_table('plugin_chat_private_file_references',
        "id {$t['id']},attachment_id {$t['uint']} NOT NULL,message_id {$t['uint']} NOT NULL,conversation_id {$t['uint']} NOT NULL,created_at {$t['uint']} NOT NULL,UNIQUE(attachment_id,message_id)"
    );
    app_db_ensure_columns('plugin_chat_private_file_references', [
        'attachment_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'message_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'conversation_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'created_at' => $t['uint'] . ' NOT NULL DEFAULT 0',
    ]);
    app_db_create_index('plugin_chat_private_file_refs_attachment_idx', 'plugin_chat_private_file_references(attachment_id,created_at,message_id)');
    app_db_create_index('plugin_chat_private_file_refs_message_idx', 'plugin_chat_private_file_references(message_id)');
    app_db_create_index('plugin_chat_private_file_refs_conversation_idx', 'plugin_chat_private_file_references(conversation_id,message_id)');
    if (!app_db_index_exists(db(), db_driver(), 'plugin_chat_private_conv_pair_unique_idx', 'plugin_chat_private_conversations')) {
        try { db()->exec('CREATE UNIQUE INDEX plugin_chat_private_conv_pair_unique_idx ON plugin_chat_private_conversations(user_low_id,user_high_id)'); } catch (Throwable $e) { /* 旧库存在重复会话时不阻断聊天室页面，创建函数会回读已有会话。 */ }
    }

    app_db_create_table('plugin_chat_private_reads',
        "id {$t['id']},conversation_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,last_read_message_id {$t['uint']} NOT NULL DEFAULT 0,updated_at {$t['uint']} NOT NULL,UNIQUE(conversation_id,user_id)"
    );
    app_db_ensure_columns('plugin_chat_private_reads', [
        'conversation_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'user_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'last_read_message_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
        'updated_at' => $t['uint'] . ' NOT NULL DEFAULT 0',
    ]);
    app_db_create_index('plugin_chat_private_reads_conv_user_idx', 'plugin_chat_private_reads(conversation_id,user_id)');

    if (setting('plugin_chat_schema_version', '') !== CHAT_SCHEMA_VERSION) {
        save_settings_values(['plugin_chat_schema_version' => CHAT_SCHEMA_VERSION]);
    }
}


function chat_install(array $plugin): void
{
    $t = app_db_types();
    app_db_create_table('plugin_chat_rooms',
        "id {$t['id']},room_key {$t['key']} NOT NULL UNIQUE,name {$t['string']} NOT NULL,description {$t['text']} NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,sort {$t['uint']} NOT NULL DEFAULT 10,created_at {$t['uint']} NOT NULL,updated_at {$t['uint']} NOT NULL"
    );
    app_db_create_index('plugin_chat_rooms_sort_idx', 'plugin_chat_rooms(sort)');

    app_db_create_table('plugin_chat_messages',
        "id {$t['id']},room_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,body {$t['text']} NOT NULL,created_at {$t['uint']} NOT NULL,deleted_at {$t['uint']} NOT NULL DEFAULT 0"
    );
    app_db_create_index('plugin_chat_messages_room_id_idx', 'plugin_chat_messages(room_id,id)');
    app_db_create_index('plugin_chat_messages_user_id_idx', 'plugin_chat_messages(user_id,id)');

    app_db_create_table('plugin_chat_file_references',
        "id {$t['id']},attachment_id {$t['uint']} NOT NULL,message_id {$t['uint']} NOT NULL,room_id {$t['uint']} NOT NULL,created_at {$t['uint']} NOT NULL,UNIQUE(attachment_id,message_id)"
    );
    app_db_create_index('plugin_chat_file_references_attachment_idx', 'plugin_chat_file_references(attachment_id,created_at,message_id)');
    app_db_create_index('plugin_chat_file_references_message_idx', 'plugin_chat_file_references(message_id)');

    // 聊天插件只扫描并建立自己的历史引用，绝不写入 user_files 的引用索引。
    if (setting('plugin_chat_file_reference_schema', '') !== '1.0') {
        chat_file_references_rebuild_all();
        save_settings_values(['plugin_chat_file_reference_schema' => '1.0']);
    }

    app_db_create_table('plugin_chat_reads',
        "id {$t['id']},room_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,last_read_message_id {$t['uint']} NOT NULL DEFAULT 0,updated_at {$t['uint']} NOT NULL,UNIQUE(room_id,user_id)"
    );
    app_db_create_index('plugin_chat_reads_room_user_idx', 'plugin_chat_reads(room_id,user_id)');

    app_db_create_table('plugin_chat_presence',
        "id {$t['id']},room_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,last_seen_at {$t['uint']} NOT NULL,UNIQUE(room_id,user_id)"
    );
    app_db_create_index('plugin_chat_presence_room_user_idx', 'plugin_chat_presence(room_id,user_id)');
    app_db_create_index('plugin_chat_presence_room_seen_idx', 'plugin_chat_presence(room_id,last_seen_at)');

    $count = (int)val('SELECT COUNT(*) FROM plugin_chat_rooms');
    if ($count === 0) {
        $now = now();
        app_db_insert_ignore('plugin_chat_rooms', [
            'room_key' => CHAT_DEFAULT_ROOM_KEY,
            'name' => CHAT_DEFAULT_ROOM_NAME,
            'description' => CHAT_DEFAULT_ROOM_DESC,
            'enabled' => 1,
            'sort' => 10,
            'created_at' => $now,
            'updated_at' => $now,
        ], ['room_key']);
    }
    chat_ensure_schema();
}


function chat_uninstall(array $plugin): void
{
    app_db_drop_index('plugin_chat_presence_room_seen_idx', 'plugin_chat_presence');
    app_db_drop_index('plugin_chat_presence_room_user_idx', 'plugin_chat_presence');
    app_db_drop_table('plugin_chat_presence');
    app_db_drop_index('plugin_chat_reads_room_user_idx', 'plugin_chat_reads');
    app_db_drop_table('plugin_chat_reads');
    app_db_drop_index('plugin_chat_file_references_message_idx', 'plugin_chat_file_references');
    app_db_drop_index('plugin_chat_file_references_attachment_idx', 'plugin_chat_file_references');
    app_db_drop_table('plugin_chat_file_references');
    app_db_drop_index('plugin_chat_messages_user_id_idx', 'plugin_chat_messages');
    app_db_drop_index('plugin_chat_messages_room_id_idx', 'plugin_chat_messages');
    app_db_drop_table('plugin_chat_messages');
    app_db_drop_index('plugin_chat_private_reads_conv_user_idx', 'plugin_chat_private_reads');
    app_db_drop_table('plugin_chat_private_reads');
    app_db_drop_index('plugin_chat_private_file_refs_conversation_idx', 'plugin_chat_private_file_references');
    app_db_drop_index('plugin_chat_private_file_refs_message_idx', 'plugin_chat_private_file_references');
    app_db_drop_index('plugin_chat_private_file_refs_attachment_idx', 'plugin_chat_private_file_references');
    app_db_drop_table('plugin_chat_private_file_references');
    app_db_drop_index('plugin_chat_private_messages_user_idx', 'plugin_chat_private_messages');
    app_db_drop_index('plugin_chat_private_messages_conv_idx', 'plugin_chat_private_messages');
    app_db_drop_table('plugin_chat_private_messages');
    app_db_drop_index('plugin_chat_private_conv_pair_unique_idx', 'plugin_chat_private_conversations');
    app_db_drop_index('plugin_chat_private_conv_high_idx', 'plugin_chat_private_conversations');
    app_db_drop_index('plugin_chat_private_conv_low_idx', 'plugin_chat_private_conversations');
    app_db_drop_table('plugin_chat_private_conversations');
    app_db_drop_index('plugin_chat_rooms_sort_idx', 'plugin_chat_rooms');
    app_db_drop_table('plugin_chat_rooms');
}

/* =========================================================
 * 2. 房间与消息数据层
 * ========================================================= */

function chat_rooms(bool $include_disabled = false): array
{
    $sql = 'SELECT id,room_key,name,description,enabled,sort FROM plugin_chat_rooms';
    if (!$include_disabled) $sql .= ' WHERE enabled=1';
    $sql .= ' ORDER BY sort ASC,name ASC,id ASC';
    return q($sql)->fetchAll();
}

function chat_find_room(int $room_id): ?array
{
    if ($room_id < 1) return null;
    $row = row('plugin_chat_rooms', 'id', $room_id);
    if (!$row) return null;
    return $row;
}

function chat_find_default_room(): ?array
{
    $row = q('SELECT id,room_key,name,description,enabled,sort FROM plugin_chat_rooms WHERE enabled=1 ORDER BY sort ASC,name ASC,id ASC LIMIT 1')->fetch();
    return $row ?: null;
}

function chat_clean_body(string $body): string
{
    return cut(trim($body), CHAT_MAX_MESSAGE_LENGTH);
}

function chat_user_map(array $rows): array
{
    return rows_by_ids('app_users', array_column($rows, 'user_id'), 'id,username,avatar_style,avatar_seed,group_id,points,is_banned,is_muted');
}

function chat_message_rows(int $room_id, int $after_id = 0, int $limit = 50): array
{
    $limit = max(1, min(100, $limit));
    if ($after_id > 0) {
        $rows = q("SELECT id,room_id,user_id,body,created_at,deleted_at FROM plugin_chat_messages WHERE room_id=? AND id>? ORDER BY id ASC LIMIT {$limit}", [$room_id, $after_id])->fetchAll();
    } else {
        $rows = q("SELECT id,room_id,user_id,body,created_at,deleted_at FROM plugin_chat_messages WHERE room_id=? ORDER BY id DESC LIMIT {$limit}", [$room_id])->fetchAll();
        $rows = array_reverse($rows);
    }
    if (!$rows) return [];
    $users = chat_user_map($rows);
    foreach ($rows as &$row) {
        $uid = (int)($row['user_id'] ?? 0);
        $u = $users[$uid] ?? user_summary_defaults('用户删除');
        $row['username'] = (string)($u['username'] ?? '用户删除');
        $row['avatar_style'] = (string)($u['avatar_style'] ?? '');
        $row['avatar_seed'] = (string)($u['avatar_seed'] ?? '');
        $row['deleted'] = !empty($row['deleted_at']);
    }
    unset($row);
    return $rows;
}

function chat_message_payload(array $row): array
{
    $deleted = !empty($row['deleted_at']);
    return [
        'id' => (int)$row['id'],
        'room_id' => (int)$row['room_id'],
        'user_id' => (int)$row['user_id'],
        'username' => (string)($row['username'] ?? '用户删除'),
        'avatar_style' => (string)($row['avatar_style'] ?? ''),
        'avatar_seed' => (string)($row['avatar_seed'] ?? ''),
        'profile_url' => $row['user_id'] ? chat_user_profile_url((int)$row['user_id']) : '#',
        'avatar_html' => $row['user_id'] ? '<span class="chat-avatar-inner" data-chat-avatar-user="' . (int)$row['user_id'] . '">' . avatar_tag((int)$row['user_id'], (string)($row['username'] ?? '用户删除'), (string)($row['avatar_style'] ?? ''), '', (string)($row['avatar_seed'] ?? '')) . '</span>' : '',
        'body' => $deleted ? '' : (string)$row['body'],
        'html' => $deleted ? '<div class="chat-deleted-message">这条消息已删除</div>' : '<div class="post-content chat-message-content">' . markdown_html((string)$row['body']) . '</div>',
        'created_at' => (int)$row['created_at'],
        'time' => human_time((int)$row['created_at']),
        'deleted' => $deleted,
        'mine' => uid() > 0 && (int)$row['user_id'] === uid(),
    ];
}

function chat_message_payloads(array $rows): array
{
    if (!$rows) return [];
    $attachment_map = chat_attachment_payloads($rows);
    $out = [];
    foreach ($rows as $row) {
        $payload = chat_message_payload($row);
        $payload['attachments'] = $attachment_map[(int)$row['id']] ?? [];
        $out[] = $payload;
    }
    return $out;
}

function chat_update_global_presence(int $user_id): void
{
    if ($user_id < 1 || !chat_config()['presence']['enabled']) return;
    // room_id=0 代表“整个聊天插件在线”，同时覆盖公共聊天室与个人聊天室。
    // 不主动写离线，依靠 TTL 自然过期，避免用户开多个聊天页时一个页面退出把另一个页面误判为离线。
    app_db_upsert('plugin_chat_presence', [
        'room_id' => 0,
        'user_id' => $user_id,
        'last_seen_at' => now(),
    ], ['room_id', 'user_id']);
}

function chat_update_presence(int $room_id, int $user_id): void
{
    if ($room_id < 1 || $user_id < 1 || !chat_config()['presence']['enabled']) return;
    app_db_upsert('plugin_chat_presence', [
        'room_id' => $room_id,
        'user_id' => $user_id,
        'last_seen_at' => now(),
    ], ['room_id', 'user_id']);
    chat_update_global_presence($user_id);
}

function chat_presence_endpoint(): void
{
    require_post();
    need_login();
    $room_id = max(0, (int)($_POST['room_id'] ?? 0));
    $room = chat_find_room($room_id);
    if (!$room || empty($room['enabled'])) {
        http_response_code(404);
        json_response(['ok' => 0, 'error' => '聊天室不存在或已关闭']);
    }
    if (!chat_config()['presence']['enabled']) {
        json_response(['ok' => 1, 'online' => 0]);
    }
    $action = (string)($_POST['action'] ?? 'online');
    if ($action === 'offline') {
        // 公共聊天室自己的房间记录可以立即离线；全局聊天 Presence 不主动清除，依靠 TTL 过期。
        // 这样用户同时打开公共/个人聊天室时，一个页面退出不会误伤另一个页面的在线状态。
        $ttl = (int)chat_config()['presence']['ttl'];
        q('UPDATE plugin_chat_presence SET last_seen_at=? WHERE room_id=? AND user_id=?', [now() - $ttl - 1, $room_id, uid()]);
        json_response(['ok' => 1, 'online' => chat_global_online_count()]);
    }
    chat_update_presence($room_id, uid());
    json_response(['ok' => 1, 'online' => chat_global_online_count()]);
}

function chat_global_online_count(): int
{
    if (!chat_config()['presence']['enabled']) return 0;
    return (int)val('SELECT COUNT(*) FROM plugin_chat_presence WHERE room_id=0 AND last_seen_at>?', [now() - chat_config()['presence']['ttl']]);
}

function chat_online_count(int $room_id): int
{
    // 为兼容旧调用保留参数；从 1.6.27 起公共聊天室显示“整个聊天插件在线人数”。
    return chat_global_online_count();
}

function chat_mark_read(int $room_id, int $message_id): void
{
    if ($room_id < 1 || uid() < 1 || $message_id < 1) return;
    $exists = (int)val('SELECT COUNT(*) FROM plugin_chat_reads WHERE room_id=? AND user_id=?', [$room_id, uid()]);
    if ($exists) {
        q('UPDATE plugin_chat_reads SET last_read_message_id=?,updated_at=? WHERE room_id=? AND user_id=?', [$message_id, now(), $room_id, uid()]);
    } else {
        app_db_insert_ignore('plugin_chat_reads', [
            'room_id' => $room_id,
            'user_id' => uid(),
            'last_read_message_id' => $message_id,
            'updated_at' => now(),
        ], ['room_id', 'user_id']);
    }
}

function chat_unread_count(int $room_id): int
{
    if (uid() < 1) return 0;
    $last = (int)val('SELECT last_read_message_id FROM plugin_chat_reads WHERE room_id=? AND user_id=? LIMIT 1', [$room_id, uid()]);
    return (int)val('SELECT COUNT(*) FROM plugin_chat_messages WHERE room_id=? AND id>? AND deleted_at=0', [$room_id, $last]);
}

function chat_unread_counts(array $room_ids): array
{
    $room_ids = array_values(array_unique(array_filter(array_map('intval', $room_ids), static fn($id) => $id > 0)));
    if (uid() < 1 || !$room_ids) return [];
    $placeholders = implode(',', array_fill(0, count($room_ids), '?'));
    $rows = q(
        "SELECT r.id AS room_id, COUNT(m.id) AS unread
         FROM plugin_chat_rooms r
         LEFT JOIN plugin_chat_reads rd ON rd.room_id=r.id AND rd.user_id=?
         LEFT JOIN plugin_chat_messages m ON m.room_id=r.id AND m.id>COALESCE(rd.last_read_message_id,0) AND m.deleted_at=0
         WHERE r.id IN ({$placeholders})
         GROUP BY r.id",
        array_merge([uid()], $room_ids)
    )->fetchAll();
    $out = array_fill_keys($room_ids, 0);
    foreach ($rows as $row) $out[(int)$row['room_id']] = (int)$row['unread'];
    return $out;
}


/* =========================================================
 * 3. 个人聊天室数据层
 * ========================================================= */

function chat_private_pair(int $a, int $b): array
{
    $a = max(0, $a); $b = max(0, $b);
    return $a < $b ? [$a, $b] : [$b, $a];
}

function chat_private_find(int $conversation_id): ?array
{
    if ($conversation_id < 1) return null;
    $row = row('plugin_chat_private_conversations', 'id', $conversation_id);
    return $row ?: null;
}

function chat_private_allowed(array $conversation): bool
{
    $me_id = uid();
    if ($me_id < 1) return false;
    return (int)$conversation['user_low_id'] === $me_id || (int)$conversation['user_high_id'] === $me_id;
}

function chat_private_get_or_create(int $a, int $b): ?array
{
    [$low, $high] = chat_private_pair($a, $b);
    if ($low < 1 || $high < 1 || $low === $high) return null;
    $select = static function () use ($low, $high): ?array {
        $row = one('SELECT id,user_low_id,user_high_id,created_at,updated_at,last_message_id FROM plugin_chat_private_conversations WHERE user_low_id=? AND user_high_id=? LIMIT 1', [$low, $high]);
        return is_array($row) ? $row : null;
    };
    $row = $select();
    if ($row) return $row;
    $now = now();
    try {
        app_db_insert_ignore('plugin_chat_private_conversations', [
            'user_low_id' => $low,
            'user_high_id' => $high,
            'created_at' => $now,
            'updated_at' => $now,
            'last_message_id' => 0,
        ], ['user_low_id', 'user_high_id']);
    } catch (Throwable $e) {
        $row = $select();
        if ($row) return $row;
        return null;
    }
    return $select();
}

function chat_private_other_id(array $conversation, int $user_id = 0): int
{
    $user_id = $user_id > 0 ? $user_id : uid();
    if ((int)$conversation['user_low_id'] === $user_id) return (int)$conversation['user_high_id'];
    if ((int)$conversation['user_high_id'] === $user_id) return (int)$conversation['user_low_id'];
    return 0;
}

function chat_private_presence_room_id(int $conversation_id): int
{
    if ($conversation_id < 1) return 0;
    // 复用插件已有 Presence 表，不新增数据库表；高位区间与公共聊天室 room_id 分开。
    return CHAT_PRIVATE_PRESENCE_BASE + $conversation_id;
}

function chat_private_update_presence(int $conversation_id, int $user_id): void
{
    $presence_room_id = chat_private_presence_room_id($conversation_id);
    if ($presence_room_id < 1 || $user_id < 1 || !chat_config()['presence']['enabled']) return;
    app_db_upsert('plugin_chat_presence', [
        'room_id' => $presence_room_id,
        'user_id' => $user_id,
        'last_seen_at' => now(),
    ], ['room_id', 'user_id']);
    chat_update_global_presence($user_id);
}

function chat_private_online(int $conversation_id, int $user_id): bool
{
    if ($user_id < 1 || !chat_config()['presence']['enabled']) return false;
    // 私聊对象是否在线，统一按“是否正在使用聊天插件”判断，而不是要求对方正好打开同一个私聊会话。
    return (int)val(
        'SELECT COUNT(*) FROM plugin_chat_presence WHERE room_id=0 AND user_id=? AND last_seen_at>?',
        [$user_id, now() - chat_config()['presence']['ttl']]
    ) > 0;
}

function chat_private_presence_endpoint(): void
{
    require_post();
    need_login();
    $conversation_id = max(0, (int)($_POST['conversation_id'] ?? 0));
    $conversation = chat_private_find($conversation_id);
    if (!$conversation || !chat_private_allowed($conversation)) {
        json_response(['ok' => 0, 'error' => '无权访问该私聊']);
    }
    $me_id = uid();
    $other_id = chat_private_other_id($conversation, $me_id);
    $action = (string)($_POST['action'] ?? 'online');
    if ($action === 'offline') {
        $presence_room_id = chat_private_presence_room_id($conversation_id);
        if ($presence_room_id > 0) {
            $ttl = (int)chat_config()['presence']['ttl'];
            q('UPDATE plugin_chat_presence SET last_seen_at=? WHERE room_id=? AND user_id=?', [now() - $ttl - 1, $presence_room_id, $me_id]);
        }
        // 全局 Presence 不主动离线，避免同时存在的公共/其他私聊页面互相覆盖。
    } else {
        chat_private_update_presence($conversation_id, $me_id);
    }
    json_response([
        'ok' => 1,
        'self_online' => $action !== 'offline',
        'other_online' => $other_id > 0 ? chat_private_online($conversation_id, $other_id) : false,
    ]);
}

function chat_private_user(int $user_id): ?array
{
    if ($user_id < 1) return null;
    $row = one('SELECT id,username,avatar_style,avatar_seed,group_id,points,bio,is_banned,is_muted FROM app_users WHERE id=?', [$user_id]);
    return $row ?: null;
}

function chat_user_profile_url(int $user_id): string
{
    if ($user_id < 1) return '#';
    // 聊天插件中的“个人信息”明确指向论坛用户页；不使用聊天内部页面。
    return index_url(['a' => 'user', 'id' => $user_id]);
}

function chat_private_user_payload(array $user): array
{
    $id = (int)$user['id'];
    $name = (string)($user['username'] ?? '用户');
    return [
        'id' => $id,
        'username' => $name,
        'avatar_style' => (string)($user['avatar_style'] ?? ''),
        'avatar_seed' => (string)($user['avatar_seed'] ?? ''),
        'avatar_html' => avatar_tag($id, $name, (string)($user['avatar_style'] ?? ''), '', (string)($user['avatar_seed'] ?? '')),
        'profile_url' => chat_user_profile_url($id),
        'bio' => cut(trim((string)($user['bio'] ?? '')), 300),
        'points' => (int)($user['points'] ?? 0),
    ];
}

function chat_private_message_rows(int $conversation_id, int $after_id = 0, int $limit = 50): array
{
    $limit = max(1, min(200, $limit));
    if ($after_id > 0) {
        $rows = q("SELECT id,conversation_id,user_id,body,created_at,deleted_at FROM plugin_chat_private_messages WHERE conversation_id=? AND id>? ORDER BY id ASC LIMIT {$limit}", [$conversation_id, $after_id])->fetchAll();
    } else {
        $rows = q("SELECT id,conversation_id,user_id,body,created_at,deleted_at FROM plugin_chat_private_messages WHERE conversation_id=? ORDER BY id DESC LIMIT {$limit}", [$conversation_id])->fetchAll();
        $rows = array_reverse($rows);
    }
    if (!$rows) return [];
    $users = rows_by_ids('app_users', array_column($rows, 'user_id'), 'id,username,avatar_style,avatar_seed,group_id,points,bio,is_banned,is_muted');
    foreach ($rows as &$row) {
        $u = $users[(int)$row['user_id']] ?? user_summary_defaults('用户删除');
        $row['username'] = (string)($u['username'] ?? '用户删除');
        $row['avatar_style'] = (string)($u['avatar_style'] ?? '');
        $row['avatar_seed'] = (string)($u['avatar_seed'] ?? '');
    }
    unset($row);
    return $rows;
}

function chat_private_message_payload(array $row): array
{
    $deleted = !empty($row['deleted_at']);
    return [
        'id' => (int)$row['id'],
        'conversation_id' => (int)$row['conversation_id'],
        'user_id' => (int)$row['user_id'],
        'username' => (string)($row['username'] ?? '用户删除'),
        'avatar_style' => (string)($row['avatar_style'] ?? ''),
        'avatar_seed' => (string)($row['avatar_seed'] ?? ''),
        'avatar_html' => $row['user_id'] ? avatar_tag((int)$row['user_id'], (string)($row['username'] ?? '用户删除'), (string)($row['avatar_style'] ?? ''), '', (string)($row['avatar_seed'] ?? '')) : '',
        'profile_url' => $row['user_id'] ? chat_user_profile_url((int)$row['user_id']) : '#',
        'body' => $deleted ? '' : (string)$row['body'],
        'html' => $deleted ? '<div class="chat-deleted-message">这条消息已删除</div>' : '<div class="post-content chat-message-content">' . markdown_html((string)$row['body']) . '</div>',
        'created_at' => (int)$row['created_at'],
        'time' => human_time((int)$row['created_at']),
        'deleted' => $deleted,
        'mine' => uid() > 0 && (int)$row['user_id'] === uid(),
    ];
}

function chat_private_attachment_payloads(array $rows): array
{
    if (!$rows || uid() < 1 || !app_db_table_exists(db(), db_driver(), 'plugin_chat_private_file_references')) return [];
    $ids = array_values(array_unique(array_filter(array_map(static fn($row) => (int)($row['id'] ?? 0), $rows), static fn($id) => $id > 0)));
    if (!$ids) return [];
    $marks = sql_marks(count($ids));
    $refs = q('SELECT attachment_id,message_id FROM plugin_chat_private_file_references WHERE message_id IN (' . $marks . ') ORDER BY message_id ASC,id ASC', $ids)->fetchAll();
    $attachment_ids = array_values(array_unique(array_filter(array_map(static fn($r) => (int)($r['attachment_id'] ?? 0), $refs), static fn($id) => $id > 0)));
    if (!$attachment_ids) return [];
    $marks2 = sql_marks(count($attachment_ids));
    $files = q('SELECT id,user_id,hash,file_name,original_name,ext,mime,size,is_image,created_at FROM app_attachments WHERE user_id=? AND id IN (' . $marks2 . ')', array_merge([uid()], $attachment_ids))->fetchAll();
    $file_map = [];
    foreach ($files as $file) {
        $id = (int)$file['id'];
        $external = chat_user_files_file_get($id);
        if ($external) $file_map[$id] = ['id'=>$id,'name'=>(string)($external['original_name'] ?? $external['name'] ?? $file['original_name'] ?? $file['file_name'] ?? '附件'),'size'=>(int)($external['size'] ?? $file['size'] ?? 0),'is_image'=>!empty($external['is_image'] ?? $file['is_image'])];
    }
    $out = [];
    foreach ($refs as $ref) { $mid=(int)$ref['message_id']; $aid=(int)$ref['attachment_id']; if(isset($file_map[$aid])) $out[$mid][]=$file_map[$aid]; }
    return $out;
}

function chat_private_register_attachment_references(array $attachments, int $message_id, int $conversation_id): array
{
    if (!$attachments || $message_id < 1 || $conversation_id < 1) return ['ok'=>true,'registered'=>0,'attachment_ids'=>[]];
    if (!app_db_table_exists(db(), db_driver(), 'plugin_chat_private_file_references')) return ['ok'=>false,'registered'=>0,'attachment_ids'=>[],'reason'=>'private_reference_index_unavailable'];
    $ids=[]; foreach($attachments as $file){$id=(int)($file['id']??0);if($id>0)$ids[$id]=true;} $ids=array_keys($ids); $registered=0;
    foreach($ids as $attachment_id){try{app_db_insert_ignore('plugin_chat_private_file_references',['attachment_id'=>$attachment_id,'message_id'=>$message_id,'conversation_id'=>$conversation_id,'created_at'=>now()],['attachment_id','message_id']);$registered++;}catch(Throwable $e){}}
    return ['ok'=>true,'registered'=>$registered,'attachment_ids'=>$ids];
}

function chat_private_message_payloads(array $rows): array
{
    if (!$rows) return [];
    $attachment_map=chat_private_attachment_payloads($rows); $out=[];
    foreach($rows as $row){$payload=chat_private_message_payload($row);$payload['attachments']=$attachment_map[(int)$row['id']]??[];$out[]=$payload;}
    return $out;
}

function chat_private_mark_read(int $conversation_id, int $message_id): void
{
    if ($conversation_id < 1 || uid() < 1 || $message_id < 1) return;
    app_db_upsert('plugin_chat_private_reads', [
        'conversation_id' => $conversation_id,
        'user_id' => uid(),
        'last_read_message_id' => $message_id,
        'updated_at' => now(),
    ], ['conversation_id', 'user_id']);
}

function chat_private_unread_count(int $conversation_id, int $user_id = 0): int
{
    $user_id = $user_id > 0 ? $user_id : uid();
    if ($conversation_id < 1 || $user_id < 1) return 0;
    $last = (int)val('SELECT last_read_message_id FROM plugin_chat_private_reads WHERE conversation_id=? AND user_id=? LIMIT 1', [$conversation_id, $user_id]);
    return (int)val('SELECT COUNT(*) FROM plugin_chat_private_messages WHERE conversation_id=? AND id>? AND user_id<>? AND deleted_at=0', [$conversation_id, $last, $user_id]);
}

function chat_private_conversations(int $user_id = 0): array
{
    $user_id = $user_id > 0 ? $user_id : uid();
    if ($user_id < 1) return [];
    $rows = q('SELECT c.id,c.user_low_id,c.user_high_id,c.created_at,c.updated_at,c.last_message_id, SUM(CASE WHEN m.id>COALESCE(r.last_read_message_id,0) AND m.user_id<>? AND m.deleted_at=0 THEN 1 ELSE 0 END) AS unread FROM plugin_chat_private_conversations c LEFT JOIN plugin_chat_private_reads r ON r.conversation_id=c.id AND r.user_id=? LEFT JOIN plugin_chat_private_messages m ON m.conversation_id=c.id WHERE c.user_low_id=? OR c.user_high_id=? GROUP BY c.id,c.user_low_id,c.user_high_id,c.created_at,c.updated_at,c.last_message_id ORDER BY c.updated_at DESC,c.id DESC LIMIT 100', [$user_id,$user_id,$user_id,$user_id])->fetchAll();
    if (!$rows) return [];
    $other_ids = [];
    foreach ($rows as $row) $other_ids[] = chat_private_other_id($row, $user_id);
    $users = rows_by_ids('app_users', $other_ids, 'id,username,avatar_style,avatar_seed,group_id,points,bio,is_banned,is_muted');
    foreach ($rows as &$row) {
        $other_id = chat_private_other_id($row, $user_id);
        $row['other'] = $users[$other_id] ?? null;
        $row['unread'] = (int)($row['unread'] ?? 0);
    }
    unset($row);
    return $rows;
}

function chat_private_admin_stats(): array
{
    return [
        'conversations' => (int)val('SELECT COUNT(*) FROM plugin_chat_private_conversations'),
        'messages' => (int)val('SELECT COUNT(*) FROM plugin_chat_private_messages'),
        'active_24h' => (int)val('SELECT COUNT(*) FROM plugin_chat_private_conversations WHERE updated_at>?', [now() - 86400]),
    ];
}

/* =========================================================
 * 3. 外部能力：依赖检测与适配层
 *
 * 聊天室本体不依赖任何附件插件才能运行。
 * - attachment_upload：提供聊天输入区的上传控件
 * - user_files：提供“我的文件”、file.get / file.recent / file.can_use / file.use
 *
 * 两个插件均由聊天插件通过公开 Hook / 核心插件运行时信息接入，
 * 不直接调用对方插件内部函数。
 * ========================================================= */

function chat_external_plugin_enabled(string $plugin_id): bool
{
    $plugin_id = trim($plugin_id);
    if ($plugin_id === '') return false;
    $plugin = plugins()[$plugin_id] ?? null;
    return is_array($plugin) && plugin_enabled($plugin);
}

function chat_attachment_upload_available(): bool
{
    return chat_external_plugin_enabled('attachment_upload');
}

function chat_user_files_available(): bool
{
    static $available = null;
    if ($available !== null) return $available;
    if (!chat_external_plugin_enabled('user_files')) return $available = false;

    // capabilities 是服务能力描述，不带 ok 字段；通过 service/api_version/operations 判断。
    // 这里必须与 user_files.api 的真实返回结构一致，否则已安装 user_files 也会被误判为不可用。
    $result = chat_user_files_api('api.capabilities');
    $operations = is_array($result['operations'] ?? null) ? $result['operations'] : [];
    return $available = (string)($result['service'] ?? '') === 'user_files'
        && (string)($result['api_version'] ?? '') !== ''
        && in_array('file.recent', $operations, true);
}

function chat_attachment_tools_enabled(): bool
{
    return chat_attachment_upload_available() || chat_user_files_available();
}

function chat_core_attachment_get(int $attachment_id, int $owner_id = 0): ?array
{
    if ($attachment_id < 1) return null;
    $sql = 'SELECT id,user_id,hash,file_name,original_name,ext,mime,size,is_image,created_at FROM app_attachments WHERE id=?';
    $params = [$attachment_id];
    if ($owner_id > 0) {
        $sql .= ' AND user_id=?';
        $params[] = $owner_id;
    }
    $row = one($sql, $params);
    return is_array($row) ? $row : null;
}

function chat_attachment_hashes(string $body): array
{
    if ($body === '') return [];
    preg_match_all('/(?<![a-f0-9])([a-f0-9]{64})(?:\.[a-z0-9]{1,25})?(?![a-f0-9])/i', $body, $matches);
    if (empty($matches[1]) || !is_array($matches[1])) return [];
    $hashes = [];
    foreach ($matches[1] as $hash) {
        $hash = strtolower(trim((string)$hash));
        if (preg_match('/^[a-f0-9]{64}$/', $hash) === 1) $hashes[$hash] = true;
    }
    return array_keys($hashes);
}

/**
 * 调用 user_files 2.7.x 的公开服务 API。
 * 这里使用 Hook 获取返回值，不使用 fire()。
 */
function chat_user_files_api(string $op, array $params = []): array
{
    if (!function_exists('hook')) return ['ok' => false, 'reason' => 'hook_unavailable'];
    $ctx = array_merge(['op' => strtolower(trim($op))], $params);
    $result = hook('user_files.api', null, $ctx);
    return is_array($result) ? $result : ['ok' => false, 'reason' => 'invalid_response'];
}

function chat_user_files_file_get(int $attachment_id): ?array
{
    if ($attachment_id < 1) return null;
    if (!chat_user_files_available()) return chat_core_attachment_get($attachment_id, uid());

    $result = chat_user_files_api('file.get', ['attachment_id' => $attachment_id]);
    if (empty($result['ok']) || !is_array($result['file'] ?? null)) return null;
    return $result['file'];
}

function chat_user_files_file_can_use(int $attachment_id): bool
{
    if ($attachment_id < 1) return false;
    if (!chat_user_files_available()) {
        return chat_core_attachment_get($attachment_id, uid()) !== null;
    }

    $result = chat_user_files_api('file.can_use', ['attachment_id' => $attachment_id]);
    return !empty($result['ok']) && (int)($result['attachment_id'] ?? 0) === $attachment_id;
}

/**
 * 将真正随聊天消息发送出去的文件标记为最近使用。
 * 只有消息保存成功后才调用，因此单纯打开“我的文件”或复制链接不会刷新最近日期。
 */
function chat_user_files_file_use(int $attachment_id): array
{
    if ($attachment_id < 1) return ['ok' => false, 'reason' => 'invalid_attachment'];
    if (!chat_user_files_available()) return ['ok' => false, 'reason' => 'user_files_unavailable'];
    $result = chat_user_files_api('file.use', ['attachment_id' => $attachment_id]);
    return is_array($result) ? $result : ['ok' => false, 'reason' => 'invalid_response'];
}

/**
 * 通过 user_files 2.7.x 的公开 API 获取当前用户最近文件。
 * 这个函数专门用于验证 file.recent 的外部服务契约，不直接查询 user_files 内部表。
 */
function chat_user_files_file_recent(int $limit = 5, bool $include_pinned = true): array
{
    if (uid() < 1) return ['ok' => false, 'files' => [], 'folders' => [], 'reason' => 'not_logged_in'];
    if (!chat_user_files_available()) return ['ok' => false, 'files' => [], 'folders' => [], 'reason' => 'user_files_unavailable'];
    $limit = max(1, min(20, $limit));
    $result = chat_user_files_api('file.recent', [
        'limit' => $limit,
        'include_pinned' => $include_pinned,
        'user_id' => uid(),
    ]);
    if (!is_array($result) || empty($result['ok'])) {
        return ['ok' => false, 'files' => [], 'folders' => [], 'reason' => (string)($result['reason'] ?? 'api_failed')];
    }
    return [
        'ok' => true,
        'files' => is_array($result['files'] ?? null) ? $result['files'] : [],
        'folders' => is_array($result['folders'] ?? null) ? $result['folders'] : [],
    ];
}

function chat_user_files_recent_html(array $recent): string
{
    if (empty($recent['ok'])) {
        return '<div class="chat-recent-files-status">最近文件 API 暂不可用</div>';
    }

    $files = is_array($recent['files'] ?? null) ? $recent['files'] : [];
    $folders = is_array($recent['folders'] ?? null) ? $recent['folders'] : [];
    $html = '<section class="chat-recent-files" data-chat-user-files-recent="1">'
        . '<div class="chat-recent-files-head"><strong>我的文件</strong><span>user_files API · file.recent</span></div>';

    if (!$files) {
        $html .= '<div class="chat-recent-files-empty">暂无最近文件</div>';
    } else {
        $html .= '<div class="chat-recent-files-list">';
        foreach ($files as $file) {
            if (!is_array($file)) continue;
            $id = (int)($file['attachment_id'] ?? $file['id'] ?? 0);
            $name = trim((string)($file['name'] ?? $file['original_name'] ?? $file['file_name'] ?? '文件'));
            $markdown = trim((string)($file['markdown'] ?? ''));
            $size = (int)($file['size'] ?? 0);
            $size_label = $size > 0 ? ($size >= 1048576 ? number_format($size / 1048576, 1) . ' MB' : number_format(max(1, $size / 1024), 1) . ' KB') : '';
            $copy = $markdown !== ''
                ? '<button type="button" class="chat-recent-file-copy" data-chat-copy-insert-link data-copy-text="' . h($markdown) . '">复制插入链接</button>'
                : '<span class="chat-recent-file-unavailable">暂无插入链接</span>';
            $html .= '<div class="chat-recent-file"><span class="chat-recent-file-name" title="' . h($name) . '">' . h($name) . '</span>'
                . '<span class="chat-recent-file-meta">#' . $id . ($size_label !== '' ? ' · ' . h($size_label) : '') . '</span>'
                . $copy
                . '</div>';
        }
        $html .= '</div>';
    }

    if ($folders) {
        $html .= '<div class="chat-recent-files-folders">已包含 ' . count($folders) . ' 个置顶文件夹中的文件</div>';
    }
    $html .= '<div class="chat-recent-files-footer"><a href="' . h(route_url('user_files')) . '" target="_blank" rel="noopener">打开我的文件</a></div>';
    return $html . '</section>';
}

function chat_attachment_map(array $rows): array
{
    $hashes = chat_attachment_hashes(implode("\n", array_map(static fn(array $row): string => (string)($row['body'] ?? ''), $rows)));
    if (!$hashes || uid() < 1) return [];

    // hash 仅用于兼容聊天室现有正文格式；拿到 attachment_id 后，文件对象统一交给 user_files API。
    $marks = sql_marks(count($hashes));
    $found = q(
        'SELECT id,hash FROM app_attachments WHERE user_id=? AND hash IN (' . $marks . ')',
        array_merge([uid()], $hashes)
    )->fetchAll();

    $map = [];
    foreach ($found as $row) {
        $attachment_id = (int)($row['id'] ?? 0);
        $hash = strtolower((string)($row['hash'] ?? ''));
        if ($attachment_id < 1 || $hash === '') continue;
        $file = chat_user_files_file_get($attachment_id);
        if (!$file) continue;
        $map[$hash] = $file;
    }
    return $map;
}

/**
 * 解析当前消息作者实际拥有的附件引用。
 * attachment_id 的发现仍兼容聊天室原有正文 hash 格式；文件对象交给 user_files API。
 */
function chat_attachment_reference_rows(string $body, int $owner_id): array
{
    if ($owner_id < 1) return [];
    $hashes = chat_attachment_hashes($body);
    if (!$hashes) return [];
    $marks = sql_marks(count($hashes));
    $found = q(
        'SELECT id,user_id,hash FROM app_attachments WHERE user_id=? AND hash IN (' . $marks . ')',
        array_merge([$owner_id], $hashes)
    )->fetchAll();

    $out = [];
    foreach ($found as $row) {
        $attachment_id = (int)($row['id'] ?? 0);
        if ($attachment_id < 1 || !chat_user_files_file_can_use($attachment_id)) continue;
        $out[] = ['id' => $attachment_id];
    }
    return $out;
}

/**
 * 聊天插件自行维护“聊天消息 → 附件”的外部引用。
 * user_files 只提供文件能力，不保存也不扫描 chat 的引用关系。
 */
function chat_register_attachment_references(array $attachments, int $message_id, int $room_id, int $actor_id, string $room_name = ''): array
{
    if (!$attachments || $message_id < 1) return ['ok' => true, 'registered' => 0, 'skipped' => true];
    if (!app_db_table_exists(db(), db_driver(), 'plugin_chat_file_references')) {
        return ['ok' => false, 'reason' => 'chat_reference_index_unavailable'];
    }

    $ids = [];
    foreach ($attachments as $file) {
        $id = (int)($file['id'] ?? 0);
        if ($id > 0) $ids[$id] = true;
    }
    $ids = array_keys($ids);
    if (!$ids) return ['ok' => true, 'registered' => 0, 'skipped' => true];

    $now = now();
    $registered = 0;
    foreach ($ids as $attachment_id) {
        app_db_upsert('plugin_chat_file_references', [
            'attachment_id' => $attachment_id,
            'message_id' => $message_id,
            'room_id' => $room_id,
            'created_at' => $now,
        ], ['attachment_id', 'message_id']);
        $registered++;
    }
    return ['ok' => true, 'registered' => $registered, 'attachment_ids' => $ids];
}

function chat_unregister_attachment_references(int $message_id, int $actor_id = 0): array
{
    if ($message_id < 1) return ['ok' => true, 'removed' => 0, 'skipped' => true];
    if (!app_db_table_exists(db(), db_driver(), 'plugin_chat_file_references')) {
        return ['ok' => false, 'reason' => 'chat_reference_index_unavailable'];
    }
    $removed = (int)val('SELECT COUNT(*) FROM plugin_chat_file_references WHERE message_id=?', [$message_id]);
    q('DELETE FROM plugin_chat_file_references WHERE message_id=?', [$message_id]);
    return ['ok' => true, 'removed' => $removed];
}

function chat_file_references_rebuild_all(): void
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_chat_file_references')) return;

    // 仅清理 chat 自己的关系表；不会触碰 user_files 或论坛引用。
    q('DELETE FROM plugin_chat_file_references');
    $cursor = 0;
    $limit = 200;

    while (true) {
        $rows = q(
            "SELECT id,room_id,user_id,body,created_at FROM plugin_chat_messages WHERE id>? ORDER BY id ASC LIMIT {$limit}",
            [$cursor]
        )->fetchAll();
        if (!$rows) break;

        $hashes = [];
        foreach ($rows as $row) {
            foreach (chat_attachment_hashes((string)($row['body'] ?? '')) as $hash) $hashes[$hash] = true;
        }

        $files_by_owner_hash = [];
        if ($hashes) {
            $hash_list = array_keys($hashes);
            $marks = sql_marks(count($hash_list));
            $files = q(
                'SELECT id,user_id,hash FROM app_attachments WHERE hash IN (' . $marks . ')',
                $hash_list
            )->fetchAll();
            foreach ($files as $file) {
                $key = (int)$file['user_id'] . ':' . strtolower((string)$file['hash']);
                $files_by_owner_hash[$key][] = (int)$file['id'];
            }
        }

        foreach ($rows as $row) {
            $message_id = (int)$row['id'];
            $owner_id = (int)$row['user_id'];
            foreach (chat_attachment_hashes((string)($row['body'] ?? '')) as $hash) {
                $key = $owner_id . ':' . strtolower($hash);
                foreach (($files_by_owner_hash[$key] ?? []) as $attachment_id) {
                    app_db_insert_ignore('plugin_chat_file_references', [
                        'attachment_id' => $attachment_id,
                        'message_id' => $message_id,
                        'room_id' => (int)$row['room_id'],
                        'created_at' => (int)$row['created_at'],
                    ], ['attachment_id', 'message_id']);
                }
            }
            $cursor = $message_id;
        }
    }
}

/* =========================================================
 * 4. 聊天室外部附件引用索引
 * ========================================================= */

function chat_file_reference_count(int $attachment_id): int
{
    if ($attachment_id < 1 || !app_db_table_exists(db(), db_driver(), 'plugin_chat_file_references')) return 0;
    return (int)val('SELECT COUNT(*) FROM plugin_chat_file_references WHERE attachment_id=?', [$attachment_id]);
}

function chat_user_files_reference_tab(mixed $value, array $ctx): mixed
{
    $tabs = is_array($value) ? $value : [];
    $attachment_id = (int)($ctx['attachment_id'] ?? 0);
    $admin_mode = !empty($ctx['admin_mode']);
    $count = chat_file_reference_count($attachment_id);
    if ($attachment_id < 1 || $count < 1) return $tabs;

    $tabs['chat'] = [
        'label' => '聊天室引用 (' . $count . ')',
        'href' => route_url('chat', ['do' => 'file_references', 'id' => $attachment_id]),
        'provider_id' => 'chat',
    ];
    return $tabs;
}

function chat_file_references_page(): never
{
    need_login();
    $attachment_id = max(0, (int)($_GET['id'] ?? 0));
    if ($attachment_id < 1) err('文件不存在', 404);

    $file = chat_user_files_file_get($attachment_id);
    if (!$file) err('文件不存在', 404);
    if ((int)($file['owner_id'] ?? 0) !== uid() && !can_access_admin()) err('文件不存在或无权查看', 404);

    $rows = q(
        'SELECT r.message_id,r.room_id,r.created_at,m.body,m.deleted_at,rm.name AS room_name
         FROM plugin_chat_file_references r
         INNER JOIN plugin_chat_messages m ON m.id=r.message_id
         LEFT JOIN plugin_chat_rooms rm ON rm.id=r.room_id
         WHERE r.attachment_id=?
         ORDER BY r.message_id DESC',
        [$attachment_id]
    )->fetchAll();

    $name = trim((string)($file['original_name'] ?? '')) ?: (string)($file['file_name'] ?? '附件');
    $html = '<div class="chat-file-reference-page">' .
        '<div class="chat-file-reference-head"><a href="' . h(route_url('user_files')) . '">返回我的文件</a><strong>' . h($name) . '</strong></div>' .
        '<div class="chat-file-reference-summary"><strong>' . count($rows) . '</strong> 个聊天室引用</div>' .
        '<div class="chat-file-reference-list">';

    foreach ($rows as $row) {
        $message_id = (int)$row['message_id'];
        $room_name = trim((string)($row['room_name'] ?? '')) ?: '聊天室';
        $body = trim((string)($row['body'] ?? ''));
        if (mb_strlen($body, 'UTF-8') > 180) $body = mb_substr($body, 0, 180, 'UTF-8') . '…';
        $state = !empty($row['deleted_at']) ? '消息已删除' : $body;
        $html .= '<article class="chat-file-reference-item"><div class="chat-file-reference-icon">聊</div><div class="chat-file-reference-main"><strong>' . h($room_name) . '</strong><span>聊天室消息 #' . h((string)$message_id) . ' · ' . h(date('Y-m-d H:i', (int)$row['created_at'])) . '</span><p>' . h($state) . '</p></div></article>';
    }
    if (!$rows) $html .= '<div class="chat-file-reference-empty">暂无聊天室引用。</div>';
    $html .= '</div></div>';

    page('聊天室引用', shell_html($html, sidebar_stack_html([sidebar_user_card_html(null, true)])));
    exit;
}

function chat_attachment_payloads(array $rows): array
{
    $map = chat_attachment_map($rows);
    $out = [];
    foreach ($rows as $row) {
        $hashes = chat_attachment_hashes((string)($row['body'] ?? ''));
        $attachments = [];
        foreach ($hashes as $hash) {
            if (!isset($map[$hash])) continue;
            $file = $map[$hash];
            $attachments[] = [
                'id' => (int)$file['id'],
                'name' => (string)($file['original_name'] ?? $file['file_name'] ?? '附件'),
                'size' => (int)($file['size'] ?? 0),
                'is_image' => !empty($file['is_image']),
            ];
        }
        $out[(int)$row['id']] = $attachments;
    }
    return $out;
}

/* =========================================================
 * 5. 路由与请求处理
 * ========================================================= */

function chat_save_message(): void
{
    require_post();
    need_speak();

    $room_id = max(0, (int)($_POST['room_id'] ?? 0));
    $room = chat_find_room($room_id);
    if (!$room || empty($room['enabled'])) json_response(['ok' => 0, 'error' => '聊天室不存在或已关闭']);

    $body = chat_clean_body((string)($_POST['body'] ?? ''));
    if ($body === '') json_response(['ok' => 0, 'error' => '消息不能为空']);
    if (mb_strlen($body, 'UTF-8') > CHAT_MAX_MESSAGE_LENGTH) json_response(['ok' => 0, 'error' => '消息太长']);

    // 采用简单的用户级发送间隔限制：1 秒 1 条。
    $last = (int)val('SELECT created_at FROM plugin_chat_messages WHERE room_id=? AND user_id=? AND deleted_at=0 ORDER BY id DESC LIMIT 1', [$room_id, uid()]);
    if ($last > 0 && now() - $last < 1 && !is_super_user()) json_response(['ok' => 0, 'error' => '发送太快，请稍后再试']);

    $created = now();
    $attachment_refs = chat_attachment_reference_rows($body, uid());
    q('INSERT INTO plugin_chat_messages(room_id,user_id,body,created_at,deleted_at) VALUES(?,?,?,?,0)', [$room_id, uid(), $body, $created]);
    $message_id = (int)app_db_last_insert_id('plugin_chat_messages');
    if ($message_id < 1) $message_id = (int)val('SELECT id FROM plugin_chat_messages WHERE room_id=? AND user_id=? AND created_at=? ORDER BY id DESC LIMIT 1', [$room_id, uid(), $created]);
    if ($message_id < 1) json_response(['ok' => 0, 'error' => '消息保存失败']);

    $attachment_reference = chat_register_attachment_references($attachment_refs, $message_id, $room_id, uid(), (string)($room['name'] ?? '聊天室'));

    // user_files 2.7.13 的 file.use 是“最近使用”语义：只有消息已经成功保存，
    // 且正文实际包含该用户可使用的附件时，才刷新对应 attachment 的最近日期。
    // 聊天插件维护自己的外部引用表，因此这里不能改用 user_files 的 reference.register。
    $attachment_usage = [];
    foreach (($attachment_reference['attachment_ids'] ?? []) as $attachment_id) {
        $attachment_id = (int)$attachment_id;
        if ($attachment_id < 1) continue;
        $attachment_usage[$attachment_id] = chat_user_files_file_use($attachment_id);
    }

    chat_update_presence($room_id, uid());
    $rows = chat_message_rows($room_id, $message_id - 1, 2);
    $message = null;
    foreach ($rows as $row) if ((int)$row['id'] === $message_id) { $message = chat_message_payload($row); break; }
    json_response([
        'ok' => 1,
        'message' => $message,
        'last_id' => $message_id,
        'attachment_reference' => $attachment_reference,
        'attachment_usage' => $attachment_usage,
    ]);
}

function chat_delete_message(): void
{
    require_post();
    need_login();
    $message_id = max(0, (int)($_POST['message_id'] ?? 0));
    $row = $message_id > 0 ? row('plugin_chat_messages', 'id', $message_id) : null;
    if (!$row) json_response(['ok' => 0, 'error' => '消息不存在']);
    if (!can_manage() && (int)$row['user_id'] !== uid()) json_response(['ok' => 0, 'error' => '无权限']);
    q('UPDATE plugin_chat_messages SET deleted_at=? WHERE id=?', [now(), $message_id]);
    $attachment_reference = chat_unregister_attachment_references($message_id, uid());
    json_response(['ok' => 1, 'message_id' => $message_id, 'attachment_reference' => $attachment_reference]);
}

function chat_stream(): never
{
    $room_id = max(0, (int)($_GET['room'] ?? 0));
    $room = chat_find_room($room_id);
    if (!$room || empty($room['enabled'])) {
        http_response_code(404); header('Content-Type: text/plain; charset=utf-8'); echo '聊天室不存在或已关闭'; exit;
    }
    $cfg = chat_config();
    if (uid() < 1 && empty($cfg['sse']['allow_guest'])) {
        http_response_code(403); header('Content-Type: text/plain; charset=utf-8'); echo '请登录后连接聊天室'; exit;
    }
    if (function_exists('set_time_limit')) @set_time_limit(0);
    @ini_set('output_buffering', 'off'); @ini_set('zlib.output_compression', '0');
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-store, must-revalidate'); header('Pragma: no-cache'); header('Expires: 0');
    header('X-Accel-Buffering: no'); header('Connection: keep-alive');
    while (ob_get_level() > 0) @ob_end_flush();
    $last_id = max(0, (int)($_GET['after'] ?? 0));
    if ($last_id < 1 && ctype_digit(trim((string)($_SERVER['HTTP_LAST_EVENT_ID'] ?? '')))) $last_id = (int)$_SERVER['HTTP_LAST_EVENT_ID'];
    $started = microtime(true); $last_keepalive = $started;
    $last_deleted_at = now() - 1; $last_deleted_id = 0;
    echo ": chat-sse connected\n\n"; @flush();
    if ($last_id < 1) {
        foreach (chat_message_rows($room_id, 0, $cfg['sse']['initial_limit']) as $row) {
            $payload = chat_message_payload($row);
            echo 'id: ' . (int)$payload['id'] . "\n" . "event: message\n" . 'data: ' . json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE) . "\n\n";
            $last_id = max($last_id, (int)$payload['id']);
        }
        @flush();
    }
    while (!connection_aborted()) {
        $now_float = microtime(true); $now_int = now();
        $rows = chat_message_rows($room_id, $last_id, $cfg['sse']['batch_limit']);
        foreach ($rows as $row) {
            $payload = chat_message_payload($row);
            echo 'id: ' . (int)$payload['id'] . "\n" . "event: message\n" . 'data: ' . json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE) . "\n\n";
            $last_id = max($last_id, (int)$payload['id']);
        }
        $deleted_rows = q("SELECT id,room_id,user_id,deleted_at FROM plugin_chat_messages WHERE room_id=? AND deleted_at>? AND (deleted_at>? OR (deleted_at=? AND id>?)) ORDER BY deleted_at ASC,id ASC LIMIT {$cfg['sse']['batch_limit']}", [$room_id,$last_deleted_at,$last_deleted_at,$last_deleted_at,$last_deleted_id])->fetchAll();
        foreach ($deleted_rows as $r) {
            $last_deleted_at=(int)$r['deleted_at']; $last_deleted_id=(int)$r['id'];
            echo "event: delete\n" . 'data: ' . json_encode(['id'=>(int)$r['id'],'room_id'=>(int)$r['room_id'],'deleted_at'=>$last_deleted_at], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) . "\n\n";
        }
        if ($now_float - $last_keepalive >= $cfg['sse']['keepalive']) { echo ': keepalive ' . $now_int . "\n\n"; $last_keepalive=$now_float; }
        if ($cfg['sse']['max_lifetime'] > 0 && $now_float - $started >= $cfg['sse']['max_lifetime']) {
            echo "event: server_close\n" . 'data: ' . json_encode(['reason'=>'max_lifetime','last_id'=>$last_id,'reconnect_delay'=>$cfg['sse']['reconnect_delay']], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) . "\n\n"; @flush();
            if ($cfg['sse']['close_on_timeout']) break;
            $started = $now_float;
        }
        @flush(); sleep($cfg['sse']['poll_interval']);
    }
    exit;
}

function chat_private_stream(): never
{
    need_login();
    $conversation_id = max(0, (int)($_GET['conversation'] ?? 0));
    $conversation = chat_private_find($conversation_id);
    if (!$conversation || !chat_private_allowed($conversation)) { http_response_code(403); header('Content-Type: text/plain; charset=utf-8'); echo '无权访问该私聊'; exit; }
    $cfg = chat_config();
    if (function_exists('set_time_limit')) @set_time_limit(0);
    @ini_set('output_buffering','off'); @ini_set('zlib.output_compression','0');
    header('Content-Type: text/event-stream; charset=utf-8'); header('Cache-Control: no-cache, no-store, must-revalidate'); header('Pragma: no-cache'); header('Expires: 0'); header('X-Accel-Buffering: no'); header('Connection: keep-alive');
    while (ob_get_level()>0) @ob_end_flush();
    $last_id=max(0,(int)($_GET['after']??0));
    if ($last_id<1 && ctype_digit(trim((string)($_SERVER['HTTP_LAST_EVENT_ID']??'')))) $last_id=(int)$_SERVER['HTTP_LAST_EVENT_ID'];
    $started=microtime(true); $last_keepalive=$started; echo ": chat-private-sse connected\n\n"; @flush();
    if ($last_id<1) foreach(chat_private_message_rows($conversation_id,0,$cfg['sse']['initial_limit']) as $row){$p=chat_private_message_payload($row);echo 'id: '.(int)$p['id']."\n"."event: message\n".'data: '.json_encode($p,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)."\n\n";$last_id=max($last_id,(int)$p['id']);}
    @flush();
    while(!connection_aborted()){
        $now_float=microtime(true); $now_int=now();
        foreach(chat_private_message_rows($conversation_id,$last_id,$cfg['sse']['batch_limit']) as $row){$p=chat_private_message_payload($row);echo 'id: '.(int)$p['id']."\n"."event: message\n".'data: '.json_encode($p,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)."\n\n";$last_id=max($last_id,(int)$p['id']);}
        if($now_float-$last_keepalive >= $cfg['sse']['keepalive']){echo ': keepalive '.$now_int."\n\n";$last_keepalive=$now_float;}
        if($cfg['sse']['max_lifetime']>0 && $now_float-$started >= $cfg['sse']['max_lifetime']){echo "event: server_close\n".'data: '.json_encode(['reason'=>'max_lifetime','last_id'=>$last_id,'reconnect_delay'=>$cfg['sse']['reconnect_delay']],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n\n";@flush();if($cfg['sse']['close_on_timeout'])break;$started=$now_float;}
        @flush();sleep($cfg['sse']['poll_interval']);
    }
    exit;
}


function chat_private_send(): void
{
    require_post();
    need_login();

    $conversation_id = max(0, (int)($_POST['conversation_id'] ?? 0));
    if ($conversation_id < 1) json_response(['ok' => 0, 'error' => '私聊会话不存在']);

    $conversation = chat_private_find($conversation_id);
    if (!$conversation || !chat_private_allowed($conversation)) {
        json_response(['ok' => 0, 'error' => '无权访问该私聊']);
    }

    $body = chat_clean_body((string)($_POST['body'] ?? ''));
    if ($body === '') json_response(['ok' => 0, 'error' => '消息不能为空']);
    if (mb_strlen($body, 'UTF-8') > CHAT_MAX_MESSAGE_LENGTH) json_response(['ok' => 0, 'error' => '消息太长']);

    $attachment_refs = chat_attachment_reference_rows($body, uid());
    $created = now();
    $last = (int)val(
        'SELECT created_at FROM plugin_chat_private_messages WHERE conversation_id=? AND user_id=? AND deleted_at=0 ORDER BY id DESC LIMIT 1',
        [$conversation_id, uid()]
    );
    if ($last > 0 && $created - $last < 1 && !is_super_user()) {
        json_response(['ok' => 0, 'error' => '发送太快，请稍后再试']);
    }

    try {
        q(
            'INSERT INTO plugin_chat_private_messages(conversation_id,user_id,body,created_at,deleted_at) VALUES(?,?,?,?,0)',
            [$conversation_id, uid(), $body, $created]
        );
        $message_id = (int)app_db_last_insert_id('plugin_chat_private_messages');
        if ($message_id < 1) {
            $message_id = (int)val(
                'SELECT id FROM plugin_chat_private_messages WHERE conversation_id=? AND user_id=? AND created_at=? ORDER BY id DESC LIMIT 1',
                [$conversation_id, uid(), $created]
            );
        }
        if ($message_id < 1) json_response(['ok' => 0, 'error' => '消息保存失败']);

        q(
            'UPDATE plugin_chat_private_conversations SET updated_at=?,last_message_id=? WHERE id=?',
            [$created, $message_id, $conversation_id]
        );
        chat_update_global_presence(uid());

        $attachment_reference = chat_private_register_attachment_references($attachment_refs, $message_id, $conversation_id);
        $attachment_usage = [];
        foreach (($attachment_reference['attachment_ids'] ?? []) as $attachment_id) {
            $attachment_id = (int)$attachment_id;
            if ($attachment_id > 0) $attachment_usage[$attachment_id] = chat_user_files_file_use($attachment_id);
        }

        $rows = chat_private_message_rows($conversation_id, $message_id - 1, 2);
        $message = null;
        foreach ($rows as $row) {
            if ((int)$row['id'] === $message_id) {
                $message = chat_private_message_payload($row);
                break;
            }
        }
        if (!$message) json_response(['ok' => 0, 'error' => '消息已保存，但读取消息失败']);

        json_response(['ok' => 1, 'message' => $message, 'last_id' => $message_id, 'attachment_reference' => $attachment_reference, 'attachment_usage' => $attachment_usage]);
    } catch (Throwable $e) {
        // 不把数据库内部错误直接暴露给用户；返回稳定 JSON，避免前端因 HTML/空响应再次崩溃。
        json_response(['ok' => 0, 'error' => '私聊消息保存失败，请检查插件数据库表是否已完成升级']);
    }
}


function chat_private_open(): void
{
    require_post(); need_login();
    $target=max(0,(int)($_GET['user']??$_POST['user']??0));
    if($target<1 || $target===uid()) { if(ajax_request()) json_response(['ok'=>0,'error'=>'不能和自己私聊']); err('不能和自己私聊'); }
    $user=chat_private_user($target);
    if(!$user || !empty($user['is_banned'])) { if(ajax_request()) json_response(['ok'=>0,'error'=>'用户不存在']); err('用户不存在'); }
    try {
        $conversation=chat_private_get_or_create(uid(),$target);
        if(!$conversation || (int)($conversation['id']??0)<1) throw new RuntimeException('conversation_create_failed');
        $redirect=route_url('chat',['do'=>'private','conversation'=>(int)$conversation['id']]);
        if(ajax_request()) json_response(['ok'=>1,'redirect'=>$redirect]);
        go($redirect);
    } catch(Throwable $e) {
        if(ajax_request()) json_response(['ok'=>0,'error'=>'个人聊天室创建失败，请检查私聊数据库表结构']);
        err('个人聊天室创建失败，请检查私聊数据库表结构');
    }
}

function chat_private_history(): void
{
    need_login();
    $conversation_id=max(0,(int)($_GET['conversation']??0));$conversation=chat_private_find($conversation_id);
    if(!$conversation || !chat_private_allowed($conversation))json_response(['ok'=>0,'error'=>'无权访问该私聊']);
    $before=max(0,(int)($_GET['before']??0));$limit=CHAT_PRIVATE_HISTORY_PAGE_SIZE;
    if($before>0){$rows=q("SELECT id,conversation_id,user_id,body,created_at,deleted_at FROM plugin_chat_private_messages WHERE conversation_id=? AND id<? ORDER BY id DESC LIMIT {$limit}",[$conversation_id,$before])->fetchAll();$rows=array_reverse($rows);}else{$rows=chat_private_message_rows($conversation_id,0,$limit);}
    $messages=chat_private_message_payloads($rows);$oldest=$messages?(int)$messages[0]['id']:0;$has_more=$oldest>0&&(int)val('SELECT COUNT(*) FROM plugin_chat_private_messages WHERE conversation_id=? AND id<?',[$conversation_id,$oldest])>0;
    json_response(['ok'=>1,'messages'=>$messages,'oldest_id'=>$oldest,'has_more'=>$has_more]);
}

function chat_private_read(): void
{
    require_post(); need_login();
    $conversation_id=max(0,(int)($_POST['conversation_id']??0));$conversation=chat_private_find($conversation_id);
    if(!$conversation || !chat_private_allowed($conversation))json_response(['ok'=>0,'error'=>'无权访问该私聊']);
    chat_private_mark_read($conversation_id,max(0,(int)($_POST['message_id']??0))); json_response(['ok'=>1]);
}

function chat_private_delete(): void
{
    require_post(); need_login();
    $message_id=max(0,(int)($_POST['message_id']??0));$row=$message_id>0?row('plugin_chat_private_messages','id',$message_id):null;
    if(!$row)json_response(['ok'=>0,'error'=>'消息不存在']);$conversation=chat_private_find((int)$row['conversation_id']);
    if(!$conversation || !chat_private_allowed($conversation))json_response(['ok'=>0,'error'=>'无权限']);
    if(!can_manage() && (int)$row['user_id']!==uid())json_response(['ok'=>0,'error'=>'无权限']);
    q('UPDATE plugin_chat_private_messages SET deleted_at=? WHERE id=?',[now(),$message_id]);json_response(['ok'=>1,'message_id'=>$message_id]);
}

function chat_private_user_card(): void
{
    need_login();
    $target=max(0,(int)($_GET['user']??0));
    if($target<1 || $target===uid())json_response(['ok'=>0,'error'=>'用户不存在']);$user=chat_private_user($target);
    if(!$user || !empty($user['is_banned']))json_response(['ok'=>0,'error'=>'用户不存在']);
    json_response(['ok'=>1,'user'=>chat_private_user_payload($user),'private_url'=>route_url('chat',['do'=>'private_open','user'=>$target])]);
}

function chat_manage_save_settings(): void
{
    require_post(); need_admin();
    $cfg=chat_config();
    $cfg['sse']['max_lifetime']=max(15,min(1800,(int)($_POST['max_lifetime']??$cfg['sse']['max_lifetime'])));
    $cfg['sse']['close_on_timeout']=!empty($_POST['close_on_timeout'])?1:0;
    $cfg['sse']['keepalive']=max(5,min(120,(int)($_POST['keepalive']??$cfg['sse']['keepalive'])));
    $cfg['sse']['poll_interval']=max(1,min(30,(int)($_POST['poll_interval']??$cfg['sse']['poll_interval'])));
    $cfg['sse']['batch_limit']=max(10,min(200,(int)($_POST['batch_limit']??$cfg['sse']['batch_limit'])));
    $cfg['sse']['initial_limit']=max(10,min(100,(int)($_POST['initial_limit']??$cfg['sse']['initial_limit'])));
    $cfg['sse']['reconnect_delay']=max(250,min(30000,(int)($_POST['reconnect_delay']??$cfg['sse']['reconnect_delay'])));
    $cfg['sse']['allow_guest']=!empty($_POST['allow_guest'])?1:0;
    $cfg['presence']['enabled']=!empty($_POST['presence_enabled'])?1:0;
    $cfg['presence']['ttl']=max(15,min(600,(int)($_POST['presence_ttl']??$cfg['presence']['ttl'])));
    $cfg['presence']['interval']=max(5,min(60,(int)($_POST['presence_interval']??$cfg['presence']['interval'])));
    if ($cfg['presence']['interval'] >= $cfg['presence']['ttl']) { $cfg['presence']['interval'] = max(5, (int)floor($cfg['presence']['ttl'] / 2)); }
    plugin_save_config('forum_chat_room',$cfg); set_flash('聊天室 SSE 与性能设置已保存'); go(admin_url(['tab'=>'chat_sse']));
}

function chat_admin_tabs(string $active): string
{
    $items=[
        'chat_manage'=>['label'=>'公共聊天室','href'=>admin_url(['tab'=>'chat_manage'])],
        'chat_private'=>['label'=>'个人聊天室','href'=>admin_url(['tab'=>'chat_private'])],
        'chat_sse'=>['label'=>'SSE 与性能','href'=>admin_url(['tab'=>'chat_sse'])],
    ];
    return tab_bar_html($items,$active,'chat-admin-tabs','chat.admin.tabs');
}

function chat_admin_manage_page(array $plugin): string
{
    need_manage();
    $room_id=max(0,(int)($_GET['id']??0));$editing=$room_id>0?chat_find_room($room_id):null;if($room_id>0&&!$editing)err('聊天室不存在');
    $rooms=chat_rooms(true);$rows='';foreach($rooms as $room){$rows.='<article class="chat-room-admin-card"><div><strong>'.h((string)$room['name']).'</strong><p>'.h((string)$room['description']).'</p></div><div class="chat-room-admin-actions"><span class="chat-room-status">'.(!empty($room['enabled'])?'启用':'关闭').'</span><a href="'.h(admin_url(['tab'=>'chat_manage','id'=>(int)$room['id']])).'">编辑</a></div></article>';}
    if($rows==='')$rows='<p class="chat-muted">暂无聊天室。</p>';
    $name=$editing?(string)$editing['name']:'';$description=$editing?(string)$editing['description']:'';$sort=$editing?(int)$editing['sort']:10;$enabled=!$editing||!empty($editing['enabled']);
    return chat_admin_tabs('chat_manage').'<section class="admin-list-panel chat-admin-panel"><div class="plugin-panel-body"><div class="chat-manage-grid"><section class="chat-panel chat-room-form"><h2>'.($editing?'编辑聊天室':'新建聊天室').'</h2><form method="post" action="'.h(route_url('chat',['do'=>'manage_save'])).'">'.form_token().hidden_inputs(['chat_action'=>'save_room','room_id'=>$room_id]).'<label class="grid"><span>名称</span><input type="text" name="name" maxlength="120" value="'.h($name).'" required></label><label class="grid"><span>简介</span><textarea name="description" maxlength="500" rows="4">'.h($description).'</textarea></label><label class="grid"><span>排序</span><input type="number" name="sort" min="0" max="999999" value="'.$sort.'"></label><label class="chat-check"><input type="checkbox" name="enabled" value="1"'.($enabled?' checked':'').'> <span>启用聊天室</span></label><div class="chat-form-actions"><button type="submit">保存</button></div></form></section><section class="chat-panel"><h2>聊天室列表</h2>'.$rows.'</section></div></div></section>';
}

function chat_admin_private_page(array $plugin): string
{
    need_admin();$stats=chat_private_admin_stats();
    return chat_admin_tabs('chat_private').'<section class="admin-list-panel chat-admin-panel"><div class="plugin-panel-body"><div class="chat-admin-stats"><div><strong>'.$stats['conversations'].'</strong><span>私聊会话</span></div><div><strong>'.$stats['messages'].'</strong><span>私聊消息</span></div><div><strong>'.$stats['active_24h'].'</strong><span>24小时活跃会话</span></div></div><p class="chat-muted">个人聊天室由用户在聊天界面点击头像后发起。后台不会把私聊内容暴露给非管理员，也不会把私聊转换为论坛全局私信。</p></div></section>';
}

function chat_admin_sse_page(array $plugin): string
{
    need_admin();$cfg=chat_config();$s=$cfg['sse'];$p=$cfg['presence'];
    return chat_admin_tabs('chat_sse').'<section class="admin-list-panel chat-admin-panel"><div class="plugin-panel-body"><form method="post" action="'.h(route_url('chat',['do'=>'manage_save'])).'">'.form_token().hidden_inputs(['chat_action'=>'save_settings']).'<div class="chat-settings-grid"><label class="grid"><span>SSE 单次最长连接（秒）</span><input type="number" name="max_lifetime" min="15" max="1800" value="'.$s['max_lifetime'].'"><small>到时间服务器发送 server_close，客户端保存游标后自动重连。</small></label><label class="chat-check"><input type="checkbox" name="close_on_timeout" value="1"'.($s['close_on_timeout']?' checked':'').'> <span>达到最长连接时间后主动断开</span></label><label class="grid"><span>SSE 保活间隔（秒）</span><input type="number" name="keepalive" min="5" max="120" value="'.$s['keepalive'].'"></label><label class="grid"><span>服务器轮询间隔（秒）</span><input type="number" name="poll_interval" min="1" max="30" value="'.$s['poll_interval'].'"><small>越小越实时，但每个在线 SSE 连接的数据库轮询压力越大；后台标签页会主动暂停 SSE。建议 2～5 秒。</small></label><label class="grid"><span>单次增量消息上限</span><input type="number" name="batch_limit" min="10" max="200" value="'.$s['batch_limit'].'"></label><label class="grid"><span>首次连接历史消息数</span><input type="number" name="initial_limit" min="10" max="100" value="'.$s['initial_limit'].'"></label><label class="grid"><span>客户端自动重连等待（毫秒）</span><input type="number" name="reconnect_delay" min="250" max="30000" value="'.$s['reconnect_delay'].'"></label><label class="chat-check"><input type="checkbox" name="allow_guest" value="1"'.($s['allow_guest']?' checked':'').'> <span>允许游客建立公共聊天室 SSE 连接</span></label><label class="chat-check"><input type="checkbox" name="presence_enabled" value="1"'.($p['enabled']?' checked':'').'> <span>启用公共聊天室在线人数</span></label><label class="grid"><span>在线状态过期时间（秒）</span><input type="number" name="presence_ttl" min="15" max="600" value="'.$p['ttl'].'"><small>用户异常断线后最多等待这段时间才自动离线。</small></label><label class="grid"><span>在线心跳间隔（秒）</span><input type="number" name="presence_interval" min="5" max="60" value="'.$p['interval'].'"><small>越小人数变化越及时，但登录用户产生的 Presence 请求越多。建议 10～15 秒。</small></label></div><div class="chat-form-actions"><button type="submit">保存 SSE 设置</button></div></form></div></section>';
}

function chat_manage_save_room(): void
{
    require_post();
    if ((string)($_POST['chat_action'] ?? '') === 'save_settings') { need_admin(); chat_manage_save_settings(); return; }
    need_manage();
    $room_id = max(0, (int)($_POST['room_id'] ?? 0));
    $action = (string)($_POST['chat_action'] ?? 'save');
    if ($action === 'delete') {
        $room = chat_find_room($room_id);
        if (!$room) err('聊天室不存在');
        $message_count = (int)val('SELECT COUNT(*) FROM plugin_chat_messages WHERE room_id=?', [$room_id]);
        if ($message_count > 0) err('聊天室已有消息，请先停用，不建议删除历史数据');
        q('DELETE FROM plugin_chat_presence WHERE room_id=?', [$room_id]);
        q('DELETE FROM plugin_chat_reads WHERE room_id=?', [$room_id]);
        q('DELETE FROM plugin_chat_rooms WHERE id=?', [$room_id]);
        set_flash('聊天室已删除');
        go(route_url('chat', ['do' => 'manage']));
    }

    $name = cut(trim((string)($_POST['name'] ?? '')), 120);
    $description = cut(trim((string)($_POST['description'] ?? '')), 500);
    $sort = max(0, (int)($_POST['sort'] ?? 10));
    $enabled = !empty($_POST['enabled']) ? 1 : 0;
    if ($name === '') err('请输入聊天室名称');

    $now = now();
    if ($room_id > 0) {
        if (!chat_find_room($room_id)) err('聊天室不存在');
        q('UPDATE plugin_chat_rooms SET name=?,description=?,enabled=?,sort=?,updated_at=? WHERE id=?', [$name, $description, $enabled, $sort, $now, $room_id]);
    } else {
        $key = 'room_' . time() . '_' . random_int(100, 999);
        app_db_insert_ignore('plugin_chat_rooms', [
            'room_key' => $key,
            'name' => $name,
            'description' => $description,
            'enabled' => $enabled,
            'sort' => $sort,
            'created_at' => $now,
            'updated_at' => $now,
        ], ['room_key']);
    }
    set_flash('聊天室已保存');
    go(route_url('chat', ['do' => 'manage']));
}

function chat_manage_page(): void
{
    need_manage();
    $room_id = max(0, (int)($_GET['id'] ?? 0));
    $editing = $room_id > 0 ? chat_find_room($room_id) : null;
    if ($room_id > 0 && !$editing) err('聊天室不存在');

    $rooms = chat_rooms(true);
    $ui = chat_ui(['id' => 'chat']);
    $rows = '';
    foreach ($rooms as $room) {
        $rows .= '<article class="chat-room-admin-card"><div><strong>' . h((string)$room['name']) . '</strong><p>' . h((string)$room['description']) . '</p></div><div class="chat-room-admin-actions"><span class="chat-room-status">' . (!empty($room['enabled']) ? '启用' : '关闭') . '</span><a href="' . h(route_url('chat', ['do' => 'manage', 'id' => (int)$room['id']])) . '">编辑</a></div></article>';
    }
    if ($rows === '') $rows = '<p class="chat-muted">暂无聊天室。</p>';

    $name = $editing ? (string)$editing['name'] : '';
    $description = $editing ? (string)$editing['description'] : '';
    $sort = $editing ? (int)$editing['sort'] : 10;
    $enabled = !$editing || !empty($editing['enabled']);
    $body = '<div class="chat-page chat-manage-page">'
        . '<div class="chat-page-head"><div><h1>' . h($ui['manage_label']) . '</h1><p>创建、排序、启用或停用聊天室。</p></div><a class="chat-back-link" href="' . h(route_url('chat')) . '">返回聊天室</a></div>'
        . '<div class="chat-manage-grid"><section class="chat-panel chat-room-form"><h2>' . ($editing ? '编辑聊天室' : '新建聊天室') . '</h2>'
        . '<form method="post" action="' . h(route_url('chat', ['do' => 'manage_save'])) . '">' . form_token() . hidden_inputs(['room_id' => $room_id])
        . '<label class="grid"><span>名称</span><input type="text" name="name" maxlength="120" value="' . h($name) . '" required></label>'
        . '<label class="grid"><span>简介</span><textarea name="description" maxlength="500" rows="4">' . h($description) . '</textarea></label>'
        . '<label class="grid"><span>排序</span><input type="number" name="sort" min="0" max="999999" value="' . $sort . '"></label>'
        . '<label class="chat-check"><input type="checkbox" name="enabled" value="1"' . ($enabled ? ' checked' : '') . '> <span>启用聊天室</span></label>'
        . '<div class="chat-form-actions"><button type="submit">保存</button>'
        . ($editing ? '<button class="chat-danger-button" type="submit" name="chat_action" value="delete" data-confirm="确认删除这个没有消息的聊天室吗？">删除</button>' : '')
        . '</div></form></section><section><div class="chat-panel"><h2>聊天室列表</h2>' . $rows . '</div></section></div></div>';
    page($ui['manage_label'], shell_html($body, sidebar_stack_html([sidebar_user_card_html(null, true)])));
}

function chat_history_endpoint(): void
{
    $room_id = max(0, (int)($_GET['room'] ?? $_POST['room'] ?? 0));
    $before_id = max(0, (int)($_GET['before'] ?? $_POST['before'] ?? 0));
    $room = chat_find_room($room_id);
    if (!$room || empty($room['enabled'])) json_response(['ok' => 0, 'error' => '聊天室不存在或已关闭']);
    $limit = CHAT_HISTORY_PAGE_SIZE;
    if ($before_id > 0) {
        $rows = q(
            "SELECT id,room_id,user_id,body,created_at,deleted_at
             FROM plugin_chat_messages WHERE room_id=? AND id<?
             ORDER BY id DESC LIMIT {$limit}",
            [$room_id, $before_id]
        )->fetchAll();
        $rows = array_reverse($rows);
    } else {
        $rows = chat_message_rows($room_id, 0, $limit);
    }
    $messages = chat_message_payloads($rows);
    $oldest_id = $messages ? (int)$messages[0]['id'] : 0;
    $has_more = $oldest_id > 0 && (int)val('SELECT COUNT(*) FROM plugin_chat_messages WHERE room_id=? AND id<?', [$room_id, $oldest_id]) > 0;
    json_response(['ok' => 1, 'messages' => $messages, 'oldest_id' => $oldest_id, 'has_more' => $has_more]);
}

function chat_mark_read_endpoint(): void
{
    require_post();
    need_login();
    $room_id = max(0, (int)($_POST['room_id'] ?? 0));
    $message_id = max(0, (int)($_POST['message_id'] ?? 0));
    chat_mark_read($room_id, $message_id);
    json_response(['ok' => 1]);
}

/* =========================================================
 * 6. 页面渲染
 * ========================================================= */

function chat_page(array $plugin): void
{
    $do = (string)($_GET['do'] ?? $_POST['do'] ?? '');
    if ($do === 'stream') { chat_stream(); return; }
    if ($do === 'private_stream') { chat_private_stream(); return; }
    if ($do === 'private_send') { chat_private_send(); return; }
    if ($do === 'private_open') { chat_private_open(); return; }
    if ($do === 'private_history') { chat_private_history(); return; }
    if ($do === 'private_read') { chat_private_read(); return; }
    if ($do === 'private_delete') { chat_private_delete(); return; }
    if ($do === 'private_user') { chat_private_user_card(); return; }
    if ($do === 'private_presence') { chat_private_presence_endpoint(); return; }
    if ($do === 'send') { chat_save_message(); return; }
    if ($do === 'delete') { chat_delete_message(); return; }
    if ($do === 'read') { chat_mark_read_endpoint(); return; }
    if ($do === 'presence') { chat_presence_endpoint(); return; }
    if ($do === 'history') { chat_history_endpoint(); return; }
    if ($do === 'file_references') { chat_file_references_page(); return; }
    if ($do === 'private') { chat_private_page($plugin); return; }
    if ($do === 'manage_save') { chat_manage_save_room(); return; }
    if ($do === 'manage') { chat_manage_page(); return; }

    $rooms = chat_rooms(false);
    if (!$rooms) {
        $body = '<div class="chat-page"><div class="chat-panel chat-empty-room"><h1>聊天室</h1><p>暂无可用聊天室。</p></div></div>';
        page('聊天室', shell_html($body, sidebar_stack_html([sidebar_user_card_html(null, true)])));
        return;
    }

    $room_id = max(0, (int)($_GET['room'] ?? 0));
    if ($room_id < 1) $room_id = (int)$rooms[0]['id'];
    $room = chat_find_room($room_id);
    if (!$room || empty($room['enabled'])) {
        $room = $rooms[0];
        $room_id = (int)$room['id'];
    }
    if (uid() > 0 && chat_config()['presence']['enabled']) {
        chat_update_presence($room_id, uid());
    }

    $ui = chat_ui($plugin);
    $csrf = csrf_token();
    $stream_url = route_url('chat', ['do' => 'stream', 'room' => $room_id]);
    $send_url = route_url('chat', ['do' => 'send']);
    $read_url = route_url('chat', ['do' => 'read']);
    $history_url = route_url('chat', ['do' => 'history']);
    $delete_url = route_url('chat', ['do' => 'delete']);
    $room_links = '';
    $unread_counts = chat_unread_counts(array_column($rooms, 'id'));
    foreach ($rooms as $r) {
        $active = (int)$r['id'] === $room_id;
        $unread = (int)($unread_counts[(int)$r['id']] ?? 0);
        $room_links .= '<a class="chat-room-link' . ($active ? ' is-active' : '') . '" href="' . h(route_url('chat', ['room' => (int)$r['id']])) . '">'
            . '<span class="chat-room-link-main"><strong>' . h((string)$r['name']) . '</strong><small>' . h((string)$r['description']) . '</small></span>'
            . ($unread > 0 ? '<span class="chat-unread-badge">' . min(99, $unread) . '</span>' : '')
            . '</a>';
    }

    $initial = chat_message_payloads(chat_message_rows($room_id, 0, 30));
    $initial_json = json_encode($initial, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE);
    $me_json = json_encode(['id' => uid(), 'username' => (string)(me()['username'] ?? '')], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $can_manage_attr = can_manage() ? '1' : '0';
    $logged_attr = uid() > 0 ? '1' : '0';

    $manage = can_manage() ? '<a class="chat-manage-link" href="' . h(route_url('chat', ['do' => 'manage'])) . '">' . h($ui['manage_label']) . '</a>' : '';
    $private_links='';
    if(uid()>0){ foreach(chat_private_conversations() as $conv){ $other=$conv['other']??null; if(!is_array($other)) continue; $other_id=(int)$other['id']; $other_name=(string)$other['username']; $private_links.='<a class="chat-private-link" href="'.h(route_url('chat',['do'=>'private','conversation'=>(int)$conv['id']])).'"><span class="chat-private-avatar">'.avatar_tag($other_id,$other_name,(string)($other['avatar_style']??''),'',(string)($other['avatar_seed']??'')).'</span><span class="chat-private-name">'.h($other_name).'</span>'.((int)$conv['unread']>0?'<span class="chat-unread-badge">'.min(99,(int)$conv['unread']).'</span>':'').'</a>'; } }
    $private_section='<div class="chat-private-section"><div class="chat-private-head"><strong>个人聊天室</strong></div>'.($private_links!==''?$private_links:'<div class="chat-private-empty">点击聊天头像，可发起私聊。</div>').'</div>';
    $room_nav = '<aside class="chat-room-list"><div class="chat-room-list-head"><strong>聊天室</strong>' . ($manage !== '' ? $manage : '') . '</div>' . $room_links . $private_section . '</aside>';

    // 恢复旧版聊天室顶部的 mobile-forum-strip；保持论坛首页的移动端版块导航。
    $body = '<div class="mobile-forum-strip"><a class="mobile-forum-link" href="' . h(route_url('home')) . '">全部</a>';
    foreach (forums_cache() as $forum) {
        $body .= '<a class="mobile-forum-link" href="' . h(route_url('forum', ['id' => (int)($forum['id'] ?? 0)])) . '">' . h((string)($forum['name'] ?? '')) . '</a>';
    }
    $body .= '<a class="mobile-forum-link chat-mobile-forum-link" href="' . h(route_url('chat')) . '">' . h($ui['menu_label']) . '</a></div><nav class="chat-mobile-switch" data-chat-mobile-switch="1"></nav>';

    /* ---------------------------------------------------------
     * 附件工具区：只在外部能力实际存在时渲染。
     * 聊天室没有附件插件时，输入区完全不显示空壳工具栏。
     * --------------------------------------------------------- */
    $uploader = '';
    $recent_files_html = '';
    $has_attachment_upload = false;
    $has_user_files = false;

    if (uid() > 0) {
        $has_attachment_upload = chat_attachment_upload_available();
        $has_user_files = chat_user_files_available();

        if ($has_attachment_upload) {
            $uploader = (string)hook('attachment.uploader', '', ['page' => 'chat', 'muted' => false]);
            if ($uploader !== '') {
                $uploader = str_replace(
                    'bbs1_attachment_upload_history_v1_' . uid(),
                    'bbs1_attachment_upload_history_v1_chat_' . uid(),
                    $uploader
                );
            }
        }

        if ($has_user_files) {
            $recent = chat_user_files_file_recent(10, true);
            $recent_files_html = chat_user_files_recent_html($recent);
        }
    }

    $attachment_tool_buttons = '';
    $attachment_tool_panels = '';
    if ($has_attachment_upload && $uploader !== '') {
        $attachment_tool_buttons .= '<button type="button" class="chat-attachment-toggle" data-chat-attachment-toggle aria-expanded="false">附件</button>';
        $attachment_tool_panels .= '<div class="chat-attachment-panel is-hidden" data-chat-attachment-panel>' . $uploader . '</div>';
    }
    if ($has_user_files && $recent_files_html !== '') {
        $attachment_tool_buttons .= '<button type="button" class="chat-attachment-toggle" data-chat-user-files-toggle aria-expanded="false">我的文件</button>';
        $attachment_tool_panels .= '<div class="chat-attachment-panel chat-user-files-panel is-hidden" data-chat-user-files-panel>' . $recent_files_html . '</div>';
    }

    $attachment_tools = ($attachment_tool_buttons !== '' && chat_attachment_tools_enabled())
        ? '<div class="chat-attachment-tools" data-chat-attachment-tools="1">' . $attachment_tool_buttons . '</div>' . $attachment_tool_panels
        : '';

    $body .= '<div class="chat-page" data-chat-app="1" data-room-id="' . $room_id . '" data-stream-url="' . h($stream_url) . '" data-send-url="' . h($send_url) . '" data-read-url="' . h($read_url) . '" data-history-url="' . h($history_url) . '" data-delete-url="' . h($delete_url) . '" data-presence-url="' . h(route_url('chat', ['do' => 'presence'])) . '" data-presence-interval="' . (int)chat_config()['presence']['interval'] . '" data-private-user-url="' . h(route_url('chat',['do'=>'private_user'])) . '" data-private-open-base="' . h(route_url('chat',['do'=>'private_open'])) . '" data-private-page-url="' . h(route_url('chat',['do'=>'private'])) . '" data-chat-profile-base="' . h(index_url(['a'=>'user'])) . '" data-sse-reconnect-delay="' . (int)chat_config()['sse']['reconnect_delay'] . '" data-csrf="' . h($csrf) . '" data-logged-in="' . $logged_attr . '" data-can-manage="' . $can_manage_attr . '" data-me="' . h((string)$me_json) . '" data-initial="' . h((string)$initial_json) . '">'
        . '<div class="chat-layout">' . $room_nav
        . '<section class="chat-panel chat-main">'
        . '<header class="chat-main-head"><div class="chat-main-title"><h1>' . h((string)$room['name']) . '</h1><p>' . h((string)$room['description']) . '</p></div><div class="chat-main-meta"><span class="chat-connection-dot" data-chat-connection></span><span data-chat-online>' . chat_online_count($room_id) . ' ' . h($ui['online_suffix']) . '</span></div></header>'
        . '<div class="chat-scroll" data-chat-scroll aria-live="polite"><div class="chat-messages" data-chat-messages></div><div class="chat-new-marker is-hidden" data-chat-new>新消息</div></div>'
        . '<div class="chat-composer-wrap">'
        . (uid() > 0 ? '<form class="chat-composer" data-chat-form>' . form_token() . $attachment_tools . '<div class="chat-composer-row"><textarea name="body" maxlength="' . CHAT_MAX_MESSAGE_LENGTH . '" rows="1" placeholder="' . h($ui['input_placeholder']) . '" data-chat-input></textarea><button type="submit" data-chat-send>' . h($ui['send_label']) . '</button></div></form>' : '<div class="chat-login-hint">' . h($ui['login_to_chat']) . ' <a href="' . h(route_url('login')) . '">登录</a></div>')
        . '<div class="chat-composer-status" data-chat-status></div></div>'
        . '</section></div></div>';

    page($ui['page_title'], shell_html($body, sidebar_stack_html([sidebar_user_card_html(null, true)])));
}


function chat_private_page(array $plugin): void
{
    need_login();
    $conversation_id=max(0,(int)($_GET['conversation']??0));
    $conversation=$conversation_id>0?chat_private_find($conversation_id):null;
    if ($conversation_id > 0 && (!$conversation || !chat_private_allowed($conversation))) err('私聊不存在或无权访问');
    if ($conversation_id < 1) {
        $convs=chat_private_conversations();
        $links='';
        foreach($convs as $c){$u=$c['other']??null;if(!is_array($u))continue;$links.='<a class="chat-private-link" href="'.h(route_url('chat',['do'=>'private','conversation'=>(int)$c['id']])).'"><span class="chat-private-avatar">'.avatar_tag((int)$u['id'],(string)$u['username'],(string)($u['avatar_style']??''),'',(string)($u['avatar_seed']??'')).'</span><span class="chat-private-name">'.h((string)$u['username']).'</span>'.((int)$c['unread']>0?'<span class="chat-unread-badge">'.min(99,(int)$c['unread']).'</span>':'').'</a>';}
        $body='<div class="mobile-forum-strip"><a class="mobile-forum-link" href="'.h(route_url('home')).'">全部</a>'; foreach(forums_cache() as $forum){ $body.='<a class="mobile-forum-link" href="'.h(route_url('forum',['id'=>(int)($forum['id']??0)])).'">'.h((string)($forum['name']??'')).'</a>'; } $body.='<a class="mobile-forum-link chat-mobile-forum-link" href="'.h(route_url('chat')).'">'.h($ui['menu_label']).'</a></div><div class="chat-page chat-private-page chat-private-index" data-chat-private-index="1"><nav class="chat-mobile-switch" data-chat-mobile-switch="1"></nav><div class="chat-private-index-card"><h1>个人聊天室</h1><p>这里只显示你已经建立的双向私聊。你可以在公共聊天室点击用户头像，再选择“私信TA”。</p><div class="chat-private-index-list">'.($links!==''?$links:'<div class="chat-private-empty">暂无私聊。</div>').'</div><a class="chat-back-link" href="'.h(route_url('chat')).'">返回公共聊天室</a></div></div>';
        page('个人聊天室',shell_html($body,sidebar_stack_html([sidebar_user_card_html(null,true)])));
        return;
    }
    $other=chat_private_user(chat_private_other_id($conversation)); if(!$other) err('对方用户不存在');
    if (chat_config()['presence']['enabled']) chat_update_global_presence(uid());
    $other_payload=chat_private_user_payload($other); $initial=chat_private_message_payloads(chat_private_message_rows($conversation_id,0,30));
    $csrf=csrf_token();$initial_json=json_encode($initial,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_INVALID_UTF8_SUBSTITUTE);
    $convs=chat_private_conversations();$links='';foreach($convs as $c){$u=$c['other']??null;if(!is_array($u))continue;$active=(int)$c['id']===$conversation_id;$links.='<a class="chat-private-link'.($active?' is-active':'').'" href="'.h(route_url('chat',['do'=>'private','conversation'=>(int)$c['id']])).'"><span class="chat-private-avatar">'.avatar_tag((int)$u['id'],(string)$u['username'],(string)($u['avatar_style']??''),'',(string)($u['avatar_seed']??'')).'</span><span class="chat-private-name">'.h((string)$u['username']).'</span>'.((int)$c['unread']>0?'<span class="chat-unread-badge">'.min(99,(int)$c['unread']).'</span>':'').'</a>';}

    // 私聊与公共聊天室使用同一套附件能力：上传、我的文件、正文插入链接均可用。
    $private_uploader=''; $private_recent_html='';
    if (uid() > 0) {
        if (chat_attachment_upload_available()) {
            $private_uploader=(string)hook('attachment.uploader','',['page'=>'chat','muted'=>false]);
            if ($private_uploader !== '') {
                $private_uploader=str_replace('bbs1_attachment_upload_history_v1_'.uid(),'bbs1_attachment_upload_history_v1_chat_private_'.uid(),$private_uploader);
            }
        }
        if (chat_user_files_available()) {
            $private_recent_html=chat_user_files_recent_html(chat_user_files_file_recent(10,true));
        }
    }
    $private_attachment_buttons=''; $private_attachment_panels='';
    if ($private_uploader !== '') {
        $private_attachment_buttons.='<button type="button" class="chat-attachment-toggle" data-chat-private-attachment-toggle aria-expanded="false">附件</button>';
        $private_attachment_panels.='<div class="chat-attachment-panel is-hidden" data-chat-private-attachment-panel>'.$private_uploader.'</div>';
    }
    if ($private_recent_html !== '') {
        $private_attachment_buttons.='<button type="button" class="chat-attachment-toggle" data-chat-private-files-toggle aria-expanded="false">我的文件</button>';
        $private_attachment_panels.='<div class="chat-attachment-panel chat-user-files-panel is-hidden" data-chat-private-files-panel>'.$private_recent_html.'</div>';
    }
    $private_attachment_tools=$private_attachment_buttons!==''?'<div class="chat-attachment-tools" data-chat-private-attachment-tools="1">'.$private_attachment_buttons.'</div>'.$private_attachment_panels:'';
    $private_open_base=route_url('chat',['do'=>'private_open']);
    $body='<div class="mobile-forum-strip"><a class="mobile-forum-link" href="'.h(route_url('home')).'">全部</a>'; foreach(forums_cache() as $forum){ $body.='<a class="mobile-forum-link" href="'.h(route_url('forum',['id'=>(int)($forum['id']??0)])).'">'.h((string)($forum['name']??'')).'</a>'; } $body.='<a class="mobile-forum-link chat-mobile-forum-link" href="'.h(route_url('chat')).'">'.h($ui['menu_label']).'</a></div><div class="chat-page chat-private-page" data-chat-private-app="1" data-conversation-id="'.$conversation_id.'" data-private-stream-url="'.h(route_url('chat',['do'=>'private_stream','conversation'=>$conversation_id])).'" data-private-send-url="'.h(route_url('chat',['do'=>'private_send'])).'" data-private-read-url="'.h(route_url('chat',['do'=>'private_read'])).'" data-private-delete-url="'.h(route_url('chat',['do'=>'private_delete'])).'" data-private-user-url="'.h(route_url('chat',['do'=>'private_user'])).'" data-private-presence-url="'.h(route_url('chat',['do'=>'private_presence'])).'" data-presence-interval="'.(int)chat_config()['presence']['interval'].'" data-private-open-base="'.h($private_open_base).'" data-chat-profile-base="'.h(index_url(['a'=>'user'])).'" data-csrf="'.h($csrf).'" data-initial="'.h((string)$initial_json).'" data-sse-reconnect-delay="'.(int)chat_config()['sse']['reconnect_delay'].'"><nav class="chat-mobile-switch" data-chat-mobile-switch="1"></nav><div class="chat-layout"><aside class="chat-room-list"><div class="chat-room-list-head"><strong>个人聊天室</strong><a class="chat-back-link" href="'.h(route_url('chat')).'">公共聊天室</a></div>'.($links!==''?$links:'<div class="chat-private-empty">暂无私聊</div>').'</aside><section class="chat-panel chat-main"><header class="chat-main-head"><div class="chat-main-title"><h1>'.h((string)$other_payload['username']).'</h1><p>仅你和对方可见的个人聊天室</p></div><div class="chat-main-meta chat-private-status-meta"><span class="chat-private-status-item"><span class="chat-connection-dot" data-chat-private-connection></span><span data-chat-private-self-status>我：连接中</span></span><span class="chat-private-status-item"><span class="chat-connection-dot" data-chat-private-other-connection></span><span data-chat-private-other-status>对方：检测中</span></span></div></header><div class="chat-scroll" data-chat-private-scroll aria-live="polite"><div class="chat-messages" data-chat-private-messages></div><div class="chat-new-marker is-hidden" data-chat-private-new>新消息</div></div><div class="chat-composer-wrap"><form class="chat-composer" data-chat-private-form>'.form_token().$private_attachment_tools.'<div class="chat-composer-row"><textarea name="body" maxlength="'.CHAT_MAX_MESSAGE_LENGTH.'" rows="1" placeholder="输入私聊消息……" data-chat-private-input></textarea><button type="submit" data-chat-private-send>发送</button></div></form><div class="chat-composer-status" data-chat-private-status></div></div></section></div></div>';
    page('个人聊天室',shell_html($body,sidebar_stack_html([sidebar_user_card_html(null,true)])));
}

function chat_top_menu($links, array $ctx): array
{
    $links = is_array($links) ? $links : [];
    $ui = chat_ui(['id' => 'chat']);
    $links[] = ['text' => $ui['menu_label'], 'url' => route_url('chat')];
    return $links;
}

function chat_top_menu_enabled(): bool
{
    // 聊天室 manifest 的真实插件 ID 是 forum_chat_room。
    // 旧代码读取 plugins()['chat']，会导致论坛/版块页面上的
    // page.before_render 补回逻辑被直接短路；聊天室自己的页面
    // 因为是直接输出 mobile-forum-strip，所以表面上看起来正常。
    $all = plugins();
    $plugin = $all['forum_chat_room'] ?? ($all['chat'] ?? null);
    return is_array($plugin) && plugin_entry_enabled($plugin, 'top_menu');
}

function chat_page_before_render($value, array $ctx): string
{
    $html = (string)$value;
    if (!chat_top_menu_enabled() || $html === '' || strpos($html, 'mobile-forum-strip') === false) return $html;
    $ui = chat_ui(['id' => 'chat']);
    if (strpos($html, 'chat-mobile-forum-link') !== false) return $html;
    $link = '<a class="mobile-forum-link chat-mobile-forum-link" href="' . h(route_url('chat')) . '">' . h($ui['menu_label']) . '</a>';
    $pattern = '~(<div class="mobile-forum-strip">.*?)(</div>)~s';
    $updated = preg_replace($pattern, '$1' . $link . '$2', $html, 1);
    return is_string($updated) ? $updated : $html;
}

/* =========================================================
 * 7. 前端资源
 * ========================================================= */

function chat_js(): string
{
    return strtr(<<<'JS'
(function () {
    'use strict';

    function chatMenuRotation() {
        var selector = [
            '[data-slot~="top.menu_links"] a[href*="/chat"]',
            '[data-slot~="top.menu_links"] a[href*="?route=chat"]',
            '.mobile-menu-links a[href*="/chat"]',
            '.mobile-menu-links a[href*="?route=chat"]',
            '.mobile-forum-strip a.chat-mobile-forum-link'
        ].join(',');

        var links = document.querySelectorAll(selector);
        for (var i = 0; i < links.length; i++) {
            var link = links[i];
            if (link.getAttribute('data-chat-menu-rotation') === '1') continue;
            link.setAttribute('data-chat-menu-rotation', '1');

            (function (target) {
                var labels = ['💬 聊天室', '🟢 在线聊天'];
                var index = 0;
                var timer = null;

                function lockWidth() {
                    if (!target || !labels.length || !document.body) return;
                    var maxWidth = 0;
                    var probe = target.cloneNode(false);
                    probe.removeAttribute('data-chat-menu-rotation');
                    probe.style.position = 'fixed';
                    probe.style.left = '-100000px';
                    probe.style.top = '0';
                    probe.style.visibility = 'hidden';
                    probe.style.width = 'auto';
                    probe.style.minWidth = '0';
                    probe.style.maxWidth = 'none';
                    probe.style.display = 'inline-flex';
                    probe.style.whiteSpace = 'nowrap';
                    document.body.appendChild(probe);
                    for (var i = 0; i < labels.length; i++) {
                        probe.textContent = labels[i];
                        maxWidth = Math.max(maxWidth, Math.ceil(probe.getBoundingClientRect().width));
                    }
                    probe.remove();
                    if (maxWidth > 0) target.style.setProperty('--chat-menu-width', maxWidth + 'px');
                }

                function rotate() {
                    if (!target || !target.isConnected) {
                        if (timer) window.clearInterval(timer);
                        return;
                    }

                    var label = target.querySelector('.chat-menu-label');
                    if (!label) {
                        label = document.createElement('span');
                        label.className = 'chat-menu-label';
                        label.textContent = target.textContent.trim() || labels[index];
                        target.textContent = '';
                        target.appendChild(label);
                    }
                    label.classList.add('chat-menu-label-rotate-out');

                    window.setTimeout(function () {
                        if (!target || !target.isConnected || !label) return;
                        index = (index + 1) % labels.length;
                        label.textContent = labels[index];
                        label.classList.remove('chat-menu-label-rotate-out');
                        label.classList.add('chat-menu-label-rotate-in');

                        window.setTimeout(function () {
                            if (label) label.classList.remove('chat-menu-label-rotate-in');
                        }, 220);
                    }, 120);
                }

                var initialLabel = target.querySelector('.chat-menu-label');
                if (!initialLabel) {
                    initialLabel = document.createElement('span');
                    initialLabel.className = 'chat-menu-label';
                    initialLabel.textContent = target.textContent.trim() || labels[0];
                    target.textContent = '';
                    target.appendChild(initialLabel);
                } else if (!initialLabel.textContent.trim()) {
                    initialLabel.textContent = labels[0];
                }
                lockWidth();
                timer = window.setInterval(rotate, 4000);

                target.addEventListener('mouseenter', function () {
                    if (timer) window.clearInterval(timer);
                    timer = null;
                });
            }(link));
        }
    }

    chatMenuRotation();

    function chatSetupMobileSwitch() {
        var nav = document.querySelector('[data-chat-mobile-switch="1"]');
        if (!nav || nav.getAttribute('data-chat-mobile-ready') === '1') return;
        nav.setAttribute('data-chat-mobile-ready','1');
        var isPrivate = !!document.querySelector('[data-chat-private-app="1"]');
        var publicLink = null;
        if (isPrivate) {
            var back = document.querySelector('.chat-back-link');
            publicLink = back ? back.getAttribute('href') : null;
        } else {
            var activeRoom = document.querySelector('.chat-room-link.is-active') || document.querySelector('.chat-room-link');
            publicLink = activeRoom ? activeRoom.getAttribute('href') : null;
        }
        var privateLink = null;
        if (!isPrivate) {
            var privateLinkElement = document.querySelector('.chat-private-link');
            privateLink = privateLinkElement ? privateLinkElement.getAttribute('href') : null;
            if (!privateLink) {
                var base = document.querySelector('[data-private-open-base]');
                if (base) privateLink = base.getAttribute('data-private-page-url') || null;
            }
        } else {
            privateLink = window.location.href;
        }
        nav.innerHTML = (publicLink ? '<a class="' + (!isPrivate ? 'is-active' : '') + '" href="' + escAttr(publicLink) + '">公共聊天室</a>' : '') + (privateLink ? '<a class="' + (isPrivate ? 'is-active' : '') + '" href="' + escAttr(privateLink) + '">个人聊天室</a>' : '');
    }
    function escAttr(value) { var div=document.createElement('div'); div.textContent=value==null?'':String(value); return div.innerHTML.replace(/"/g,'&quot;'); }

    var observer = new MutationObserver(function () {
        chatMenuRotation();
    });
    if (document.body) observer.observe(document.body, {childList: true, subtree: true});

    var app = document.querySelector('[data-chat-app="1"]');
    if (!app) { chatSetupMobileSwitch(); return; }

    chatSetupMobileSwitch();

    var roomId = Number(app.getAttribute('data-room-id') || 0);
    var streamUrl = app.getAttribute('data-stream-url') || '';
    var sendUrl = app.getAttribute('data-send-url') || '';
    var readUrl = app.getAttribute('data-read-url') || '';
    var historyUrl = app.getAttribute('data-history-url') || '';
    var deleteUrl = app.getAttribute('data-delete-url') || '';
    var presenceUrl = app.getAttribute('data-presence-url') || '';
    var privateOpenBase = app.getAttribute('data-private-open-base') || '';
    var csrf = app.getAttribute('data-csrf') || '';
    var loggedIn = app.getAttribute('data-logged-in') === '1';
    var canManage = app.getAttribute('data-can-manage') === '1';
    var messages = app.querySelector('[data-chat-messages]');
    var scroll = app.querySelector('[data-chat-scroll]');
    var form = app.querySelector('[data-chat-form]');
    var input = app.querySelector('[data-chat-input]');
    var sendButton = app.querySelector('[data-chat-send]');
    var status = app.querySelector('[data-chat-status]');
    var attachmentToggle = app.querySelector('[data-chat-attachment-toggle]');
    var attachmentPanel = app.querySelector('[data-chat-attachment-panel]');
    var userFilesToggle = app.querySelector('[data-chat-user-files-toggle]');
    var userFilesPanel = app.querySelector('[data-chat-user-files-panel]');
    var connection = app.querySelector('[data-chat-connection]');
    var online = app.querySelector('[data-chat-online]');
    var newMarker = app.querySelector('[data-chat-new]');
    var lastId = 0;
    var lastDeletedAt = 0;
    var lastDeletedId = 0;
    var source = null;
    var reconnectTimer = null;
    var pendingReadTimer = null;
    var loadingHistory = false;
    var hasMoreHistory = true;
    var user = {};

    try { user = JSON.parse(app.getAttribute('data-me') || '{}'); } catch (e) { user = {}; }

    function esc(s) {
        var div = document.createElement('div');
        div.textContent = s == null ? '' : String(s);
        return div.innerHTML;
    }

    function isNearBottom() {
        return scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 100;
    }

    function scrollBottom(force) {
        if (force || isNearBottom()) scroll.scrollTop = scroll.scrollHeight;
    }

    function insertText(field, text) {
        if (!field || !text) return;
        var start = typeof field.selectionStart === 'number' ? field.selectionStart : field.value.length;
        var end = typeof field.selectionEnd === 'number' ? field.selectionEnd : start;
        var prefix = start > 0 && !field.value.slice(0, start).endsWith('\n') ? '\n' : '';
        var suffix = end < field.value.length && !field.value.slice(end).startsWith('\n') ? '\n' : '';
        field.setRangeText(prefix + text + suffix, start, end, 'end');
        field.dispatchEvent(new Event('input', {bubbles: true}));
        field.focus();
    }

    function togglePanel(panel, button, show) {
        if (!panel) return;
        panel.classList.toggle('is-hidden', !show);
        if (button) button.setAttribute('aria-expanded', show ? 'true' : 'false');
    }

    function copyText(text, button) {
        if (!text) return;
        var done = function () {
            if (!button) return;
            var old = button.textContent;
            button.textContent = '已复制';
            window.setTimeout(function () { if (button && button.isConnected) button.textContent = old; }, 1200);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done).catch(function () {
                var field = document.createElement('textarea');
                field.value = text;
                field.style.position = 'fixed';
                field.style.left = '-10000px';
                document.body.appendChild(field);
                field.focus();
                field.select();
                try { document.execCommand('copy'); done(); } catch (e) {}
                field.remove();
            });
            return;
        }
        var field = document.createElement('textarea');
        field.value = text;
        field.style.position = 'fixed';
        field.style.left = '-10000px';
        document.body.appendChild(field);
        field.focus();
        field.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        field.remove();
    }

    function messageHtml(m) {
        var mine = m.mine || (user.id && Number(m.user_id) === Number(user.id));
        var cls = 'chat-message' + (mine ? ' is-mine' : '') + (m.deleted ? ' is-deleted' : '');
        var profile = m.profile_url || '#';
        var avatar = '<button type="button" class="chat-avatar chat-avatar-button" data-chat-avatar-user="' + Number(m.user_id || 0) + '" data-chat-avatar-profile="' + esc(profile) + '" aria-label="查看用户">' + (m.avatar_html || esc((m.username || '?').slice(0, 1).toUpperCase())) + '</button>';
        var author = '<a class="chat-author" href="' + esc(profile) + '">' + esc(m.username || '用户删除') + '</a>';
        var op = (!m.deleted && (mine || canManage)) ? '<button type="button" class="chat-message-delete" data-chat-delete="' + Number(m.id) + '">删除</button>' : '';
        return '<article class="' + cls + '" id="chat-message-' + Number(m.id) + '" data-message-id="' + Number(m.id) + '">' + avatar + '<div class="chat-message-body"><div class="chat-message-head">' + author + '<time>' + esc(m.time || '') + '</time>' + op + '</div>' + (m.html || '') + '</div></article>';
    }

    function appendMessage(m, forceScroll) {
        if (!m || !m.id) return;
        if (messages.querySelector('[data-message-id="' + Number(m.id) + '"]')) return;
        var wasBottom = isNearBottom();
        messages.insertAdjacentHTML('beforeend', messageHtml(m));
        lastId = Math.max(lastId, Number(m.id));
        if (forceScroll || wasBottom) scrollBottom(true);
        else if (newMarker) newMarker.classList.remove('is-hidden');
        scheduleRead();
    }

    function renderInitial(list) {
        messages.innerHTML = '';
        (Array.isArray(list) ? list : []).forEach(function (m) {
            messages.insertAdjacentHTML('beforeend', messageHtml(m));
            lastId = Math.max(lastId, Number(m.id || 0));
        });
        scrollBottom(true);
        scheduleRead();
    }

    function setConnected(ok) {
        if (connection) connection.classList.toggle('is-online', ok);
        if (status) status.textContent = ok ? '' : '正在重新连接……';
    }

    function closeStream() {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
        if (source) {
            try { source.close(); } catch (e) {}
            source = null;
        }
        setConnected(false);
    }

    function scheduleReconnect(delay) {
        if (document.visibilityState === 'hidden') return;
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(function () {
            reconnectTimer = null;
            connect();
        }, Math.max(250, Number(delay) || 1500));
    }

    function connect() {
        if (document.visibilityState === 'hidden') return;
        if (!window.EventSource || !streamUrl) {
            if (status) status.textContent = '当前浏览器不支持实时连接。';
            return;
        }
        if (source) return;
        var url = streamUrl + (streamUrl.indexOf('?') >= 0 ? '&' : '?') + 'after=' + encodeURIComponent(lastId);
        source = new EventSource(url, {withCredentials: true});
        source.addEventListener('open', function () { setConnected(true); });
        source.addEventListener('message', function (event) {
            try { appendMessage(JSON.parse(event.data), false); } catch (e) {}
        });
        source.addEventListener('delete', function (event) {
            try {
                var data = JSON.parse(event.data || '{}');
                var id = Number(data.id || 0);
                if (!id) return;
                var item = messages.querySelector('[data-message-id="' + id + '"]');
                if (!item) return;
                item.classList.add('is-deleted');
                var content = item.querySelector('.chat-message-content');
                if (content) content.outerHTML = '<div class="chat-deleted-message">这条消息已删除</div>';
                var button = item.querySelector('[data-chat-delete]');
                if (button) button.remove();
            } catch (e) {}
        });
        source.addEventListener('server_close', function (event) {
            var data = {};
            try { data = JSON.parse(event.data || '{}'); } catch (e) {}
            lastId = Math.max(lastId, Number(data.last_id || 0));
            var delay = Number(data.reconnect_delay || 1500);
            closeStream();
            scheduleReconnect(delay);
        });
        source.onerror = function () {
            setConnected(false);
            if (source) {
                try { source.close(); } catch (e) {}
                source = null;
            }
            scheduleReconnect(Number(app.getAttribute('data-sse-reconnect-delay') || 1500));
        };
    }

    function post(url, data) {
        var body = new URLSearchParams();
        body.set('_csrf', csrf);
        Object.keys(data || {}).forEach(function (key) { body.set(key, data[key]); });
        return fetch(url, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest'}, body: body.toString()}).then(function (response) {
            return response.json();
        });
    }

    var presenceTimer = null;
    var presenceInFlight = false;
    var presenceStarted = false;

    function updatePresence() {
        if (!loggedIn || !presenceUrl || !roomId || presenceInFlight || document.visibilityState === 'hidden') return;
        presenceInFlight = true;
        post(presenceUrl, {room_id: roomId, action: 'online'}).then(function (data) {
            if (online && data && typeof data.online !== 'undefined') online.textContent = Number(data.online || 0) + ' 人活跃';
        }).catch(function () {}).finally(function () {
            presenceInFlight = false;
        });
    }

    function markPresenceOffline() {
        if (!loggedIn || !presenceUrl || !roomId) return;
        var body = new URLSearchParams();
        body.set('_csrf', csrf);
        body.set('room_id', roomId);
        body.set('action', 'offline');
        if (navigator.sendBeacon) {
            try {
                navigator.sendBeacon(presenceUrl, body);
                return;
            } catch (e) {}
        }
        fetch(presenceUrl, {method: 'POST', credentials: 'same-origin', keepalive: true, headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest'}, body: body.toString()}).catch(function () {});
    }

    function startPresence() {
        if (!loggedIn || !presenceUrl || !roomId || presenceStarted) return;
        presenceStarted = true;
        updatePresence();
        if (presenceTimer) clearInterval(presenceTimer);
        var presenceSeconds = Number(app.getAttribute('data-presence-interval') || 10);
        if (!isFinite(presenceSeconds) || presenceSeconds < 5) presenceSeconds = 10;
        presenceTimer = setInterval(updatePresence, presenceSeconds * 1000);
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'visible') {
                updatePresence();
                connect();
            } else if (document.visibilityState === 'hidden') {
                markPresenceOffline();
                closeStream();
            }
        });
        window.addEventListener('pagehide', function () {
            markPresenceOffline();
            closeStream();
        });
        window.addEventListener('pageshow', function () {
            updatePresence();
            connect();
        });
    }

    function scheduleRead() {
        if (!loggedIn || !lastId || !isNearBottom()) return;
        clearTimeout(pendingReadTimer);
        pendingReadTimer = setTimeout(function () {
            if (!isNearBottom()) return;
            post(readUrl, {room_id: roomId, message_id: lastId}).catch(function () {});
        }, 350);
    }

    function prependMessages(list) {
        if (!Array.isArray(list) || !list.length) return;
        var previousHeight = scroll.scrollHeight;
        var previousTop = scroll.scrollTop;
        var holder = document.createElement('div');
        for (var i = 0; i < list.length; i++) {
            var item = list[i];
            if (!item || !item.id || messages.querySelector('[data-message-id="' + Number(item.id) + '"]')) continue;
            holder.insertAdjacentHTML('beforeend', messageHtml(item));
        }
        while (holder.lastChild) messages.insertBefore(holder.lastChild, messages.firstChild);
        scroll.scrollTop = scroll.scrollHeight - previousHeight + previousTop;
    }

    function loadHistory() {
        if (!historyUrl || loadingHistory || !hasMoreHistory) return;
        var first = messages.querySelector('[data-message-id]');
        var before = first ? Number(first.getAttribute('data-message-id') || 0) : lastId;
        if (!before) return;
        loadingHistory = true;
        if (status) status.textContent = '正在加载更早消息……';
        var url = historyUrl + (historyUrl.indexOf('?') >= 0 ? '&' : '?') + 'room=' + encodeURIComponent(roomId) + '&before=' + encodeURIComponent(before);
        fetch(url, {credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}})
            .then(function (response) { return response.json(); })
            .then(function (data) {
                if (!data || !data.ok) throw new Error((data && data.error) || '历史消息加载失败');
                prependMessages(data.messages || []);
                hasMoreHistory = !!data.has_more;
                if (status) status.textContent = hasMoreHistory ? '' : '已经到最早的消息了';
            })
            .catch(function (error) { if (status) status.textContent = error.message || '历史消息加载失败'; })
            .finally(function () { loadingHistory = false; });
    }

    if (form && input) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            if (sendButton.disabled) return;
            if (window.bbs1AttachmentUpload && typeof window.bbs1AttachmentUpload.isUploading === 'function' && window.bbs1AttachmentUpload.isUploading(form)) {
                if (status) status.textContent = '附件仍在上传，请稍候……';
                return;
            }
            if (window.bbs1AttachmentUpload && typeof window.bbs1AttachmentUpload.beforeSubmit === 'function') {
                window.bbs1AttachmentUpload.beforeSubmit(form);
            }
            var body = input.value.trim();
            if (!body) return;
            sendButton.disabled = true;
            if (status) status.textContent = '发送中……';
            post(sendUrl, {room_id: roomId, body: body}).then(function (data) {
                if (!data || !data.ok) throw new Error((data && data.error) || '发送失败');
                input.value = '';
                input.style.height = 'auto';
                appendMessage(data.message, true);
                if (status) status.textContent = '';
                var key = 'bbs1_attachment_upload_history_v1_chat_' + (user.id || 0);
                try { if (key && Number(user.id) > 0) localStorage.removeItem(key); } catch (e) {}
                if (attachmentPanel) attachmentPanel.classList.add('is-hidden');
                if (attachmentToggle) attachmentToggle.setAttribute('aria-expanded', 'false');
            }).catch(function (error) {
                if (status) status.textContent = error.message || '发送失败';
            }).finally(function () { sendButton.disabled = false; });
        });
        input.addEventListener('input', function () {
            input.style.height = 'auto';
            input.style.height = Math.min(input.scrollHeight, 140) + 'px';
        });
        input.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
                event.preventDefault();
                form.requestSubmit();
            }
        });
    }

    messages.addEventListener('click', function (event) {
        var button = event.target.closest('[data-chat-delete]');
        if (!button) return;
        var id = Number(button.getAttribute('data-chat-delete') || 0);
        if (!id || !window.confirm('确认删除这条消息吗？')) return;
        button.disabled = true;
        post(deleteUrl, {message_id: id}).then(function (data) {
            if (!data || !data.ok) throw new Error((data && data.error) || '删除失败');
            var item = messages.querySelector('[data-message-id="' + id + '"]');
            if (item) {
                item.classList.add('is-deleted');
                var content = item.querySelector('.chat-message-content');
                if (content) content.outerHTML = '<div class="chat-deleted-message">这条消息已删除</div>';
                button.remove();
            }
        }).catch(function (error) {
            button.disabled = false;
            if (status) status.textContent = error.message || '删除失败';
        });
    });

    if (attachmentToggle) {
        attachmentToggle.addEventListener('click', function () {
            var show = attachmentPanel && attachmentPanel.classList.contains('is-hidden');
            togglePanel(attachmentPanel, attachmentToggle, show);
            if (show) togglePanel(userFilesPanel, userFilesToggle, false);
        });
    }
    if (userFilesToggle) {
        userFilesToggle.addEventListener('click', function () {
            var show = userFilesPanel && userFilesPanel.classList.contains('is-hidden');
            togglePanel(userFilesPanel, userFilesToggle, show);
            if (show) togglePanel(attachmentPanel, attachmentToggle, false);
        });
    }
    app.addEventListener('click', function (event) {
        var button = event.target.closest('[data-chat-copy-insert-link]');
        if (!button) return;
        event.preventDefault();
        copyText(button.getAttribute('data-copy-text') || '', button);
    });
    scroll.addEventListener('scroll', function () {
        if (isNearBottom() && newMarker) newMarker.classList.add('is-hidden');
        if (scroll.scrollTop < 100) loadHistory();
        scheduleRead();
    });
    if (newMarker) newMarker.addEventListener('click', function () { scrollBottom(true); newMarker.classList.add('is-hidden'); });

    // 移动端聊天室是一个完整的视口应用：页面本身不滚动，只允许消息区滚动。
    // 同时锁定 html/body，避免聊天内容把整个论坛页面一起撑出滚动条。
    function setChatPageScrollLock(enabled) {
        var root = document.documentElement;
        var body = document.body;
        if (!root || !body) return;
        if (enabled) {
            root.classList.add('chat-active-page');
            body.classList.add('chat-active-page');
        } else {
            root.classList.remove('chat-active-page');
            body.classList.remove('chat-active-page');
        }
    }
    setChatPageScrollLock(true);

    function syncChatViewport() {
        var page = app;
        if (!page) return;
        var rect = page.getBoundingClientRect();
        var top = Math.max(0, rect.top);
        // 只在聊天室移动端布局下计算可视高度；优先使用 innerHeight，避免
        // visualViewport 在地址栏/窗口滚动变化时把聊天室高度重新算大。
        var viewport = window.innerHeight;
        var height = Math.max(320, viewport - top);
        page.style.setProperty('--chat-viewport-height', height + 'px');
        page.style.height = height + 'px';
    }

    function syncChatScrollMode() {
        setChatPageScrollLock(window.matchMedia && window.matchMedia('(max-width: 860px)').matches);
    }
    syncChatViewport();
    syncChatScrollMode();

    // 移动端输入区固定在浏览器窗口底部时，消息区需要预留它的实际高度。
    // 用 ResizeObserver 跟随 textarea 自动增高、附件工具/状态提示等变化，避免消息被输入区遮住。
    function syncChatComposerHeight() {
        if (!app || !(window.matchMedia && window.matchMedia('(max-width: 860px)').matches)) return;
        var composer = app.querySelector('.chat-composer-wrap');
        if (!composer) return;
        var height = Math.ceil(composer.getBoundingClientRect().height);
        if (height > 0) app.style.setProperty('--chat-composer-height', height + 'px');
    }
    syncChatComposerHeight();
    if (window.ResizeObserver) {
        var chatComposerObserver = new ResizeObserver(syncChatComposerHeight);
        var chatComposer = app.querySelector('.chat-composer-wrap');
        if (chatComposer) chatComposerObserver.observe(chatComposer);
    }
    window.addEventListener('resize', syncChatComposerHeight);
    window.addEventListener('orientationchange', function () { setTimeout(syncChatComposerHeight, 50); });
    window.addEventListener('resize', syncChatViewport);
    window.addEventListener('resize', syncChatScrollMode);
    // 不监听 visualViewport.scroll：聊天室禁止页面滚动，避免浏览器 UI/地址栏变化
    // 被误判为页面滚动后重新放大 chat-page 高度。

    var initial = [];
    // 初始消息由页面内联数据提供，避免首次打开聊天室再等待一个 SSE 周期。
    try { initial = JSON.parse(app.getAttribute('data-initial') || '[]'); } catch (e) { initial = []; }
    renderInitial(initial);
    startPresence();
    connect();

    /* 头像菜单仅绑定当前 .chat-page，不修改论坛全局头像行为。 */
    var chatAvatarMenu = null;
    function closeChatAvatarMenu() {
        if (chatAvatarMenu) { chatAvatarMenu.remove(); chatAvatarMenu = null; }
    }
    function showChatAvatarMenu(button, clickEvent) {
        closeChatAvatarMenu();
        var userId = Number(button.getAttribute('data-chat-avatar-user') || 0);
        var profileUrl = button.getAttribute('data-chat-avatar-profile') || ''; if (!profileUrl) { var base = app.getAttribute('data-chat-profile-base') || ''; if (base) profileUrl = base + (base.indexOf('?') >= 0 ? '&' : '?') + 'id=' + encodeURIComponent(userId); }
        if (!userId) return;
        var menu = document.createElement('div');
        menu.className = 'chat-avatar-action-menu chat-public-avatar-action-menu';
        menu.innerHTML = '<a href="' + esc(profileUrl) + '" class="chat-avatar-action-item">个人信息</a><button type="button" class="chat-avatar-action-item" data-chat-avatar-private>私信TA</button>';
        document.body.appendChild(menu);
        chatAvatarMenu = menu;
        /* 公共聊天室菜单必须依据头像的真实视口坐标定位。若按钮的布局坐标暂时为 0，则退回点击坐标，避免菜单落到左上角。 */
        menu.style.position = 'fixed';
        var rect = button.getBoundingClientRect();
        var hasRect = rect && rect.width > 0 && rect.height > 0 && isFinite(rect.left) && isFinite(rect.top);
        var anchorX = hasRect ? rect.right : ((clickEvent && isFinite(clickEvent.clientX)) ? clickEvent.clientX : 12);
        var anchorY = hasRect ? rect.top : ((clickEvent && isFinite(clickEvent.clientY)) ? clickEvent.clientY : 12);
        var anchorLeft = hasRect ? rect.left : anchorX;
        var anchorBottom = hasRect ? rect.bottom : anchorY + 1;
        var gap = 8;
        var menuWidth = menu.offsetWidth || 136;
        var menuHeight = menu.offsetHeight || 80;
        var left = anchorX + gap;
        if (left + menuWidth > window.innerWidth - 8) left = anchorLeft - menuWidth - gap;
        left = Math.max(8, Math.min(left, Math.max(8, window.innerWidth - menuWidth - 8)));
        var top = anchorY;
        if (top + menuHeight > window.innerHeight - 8) top = anchorBottom - menuHeight;
        top = Math.max(8, Math.min(top, Math.max(8, window.innerHeight - menuHeight - 8)));
        menu.classList.toggle('is-left', left < anchorLeft);
        menu.style.left = Math.round(left) + 'px';
        menu.style.top = Math.round(top) + 'px';
        var privateButton = menu.querySelector('[data-chat-avatar-private]');
        if (privateButton) privateButton.addEventListener('click', function () {
            post(privateOpenBase, {user:userId}).then(function(r){ window.location.href = r.redirect; }).catch(function(e){
                closeChatAvatarMenu();
                if (status) status.textContent = e.message || '私聊创建失败';
            });
        });
        window.setTimeout(function(){
            document.addEventListener('click', function outside(ev){
                if (!chatAvatarMenu || chatAvatarMenu.contains(ev.target) || button.contains(ev.target)) return;
                closeChatAvatarMenu();
                document.removeEventListener('click', outside);
            }, {once:true});
        }, 0);
    }
    app.addEventListener('click', function(event){
        var avatarButton = event.target.closest('[data-chat-avatar-user]');
        if (avatarButton && app.contains(avatarButton)) {
            event.preventDefault(); event.stopPropagation(); showChatAvatarMenu(avatarButton, event);
        }
    });
    window.addEventListener('resize', closeChatAvatarMenu);
    window.addEventListener('scroll', closeChatAvatarMenu, true);
}());
JS
    , []) . "\n" . chat_private_runtime_js();
}

function chat_private_runtime_js(): string
{
    return <<<'JS'
(function(){
'use strict';
var app=document.querySelector('[data-chat-private-app=\"1\"]');
if(!app)return;
var messages=app.querySelector('[data-chat-private-messages]'),scroll=app.querySelector('[data-chat-private-scroll]'),form=app.querySelector('[data-chat-private-form]'),input=app.querySelector('[data-chat-private-input]'),send=app.querySelector('[data-chat-private-send]'),status=app.querySelector('[data-chat-private-status]'),dot=app.querySelector('[data-chat-private-connection]'),selfStatus=app.querySelector('[data-chat-private-self-status]'),otherDot=app.querySelector('[data-chat-private-other-connection]'),otherStatus=app.querySelector('[data-chat-private-other-status]'),newMarker=app.querySelector('[data-chat-private-new]');
var streamUrl=app.getAttribute('data-private-stream-url')||'',sendUrl=app.getAttribute('data-private-send-url')||'',readUrl=app.getAttribute('data-private-read-url')||'',deleteUrl=app.getAttribute('data-private-delete-url')||'',presenceUrl=app.getAttribute('data-private-presence-url')||'',csrf=app.getAttribute('data-csrf')||'',conversationId=Number(app.getAttribute('data-conversation-id')||0),lastId=0,source=null,reconnectTimer=null,presenceTimer=null,presenceStarted=false,loading=false;
function esc(s){return String(s==null?'':s).replace(/[&<>\"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c];});}
function nearBottom(){return scroll.scrollHeight-scroll.scrollTop-scroll.clientHeight<80;}
function bottom(){scroll.scrollTop=scroll.scrollHeight;}

// 个人聊天室也使用公共聊天室相同的“视口锁定 + composer 实际高度让位”机制。
// 关键点：个人页自己的运行时必须单独测量 composer，因为公共聊天室运行时不会接管它。
function setPrivatePageScrollLock(enabled){
    var root=document.documentElement,body=document.body;
    if(!root||!body)return;
    if(enabled){root.classList.add('chat-active-page');body.classList.add('chat-active-page');}
    else{root.classList.remove('chat-active-page');body.classList.remove('chat-active-page');}
}
function syncPrivateViewport(){
    if(!(window.matchMedia&&window.matchMedia('(max-width:860px)').matches))return;
    var rect=app.getBoundingClientRect();
    var top=Math.max(0,rect.top);
    var height=Math.max(320,window.innerHeight-top);
    app.style.setProperty('--chat-viewport-height',height+'px');
    app.style.height=height+'px';
}
function syncPrivateComposerHeight(keepBottom){
    if(!(window.matchMedia&&window.matchMedia('(max-width:860px)').matches))return;
    var composer=app.querySelector('.chat-composer-wrap');
    if(!composer||!scroll)return;
    var wasNear=nearBottom();
    var height=Math.ceil(composer.getBoundingClientRect().height);
    if(height>0)app.style.setProperty('--chat-composer-height',height+'px');
    // composer 增高（例如附件工具栏出现）后，如果原本就在底部，立即把滚动位置跟到新的底部。
    // 如果用户正在看历史消息，则不强行跳到底部。
    if(keepBottom!==false&&wasNear)requestAnimationFrame(bottom);
}
setPrivatePageScrollLock(true);
syncPrivateViewport();
syncPrivateComposerHeight(false);
if(window.ResizeObserver){
    var privateComposerObserver=new ResizeObserver(function(){syncPrivateComposerHeight(true);});
    var privateComposer=app.querySelector('.chat-composer-wrap');
    if(privateComposer)privateComposerObserver.observe(privateComposer);
}
window.addEventListener('resize',syncPrivateViewport);
window.addEventListener('resize',function(){syncPrivateComposerHeight(true);});
window.addEventListener('orientationchange',function(){setTimeout(function(){syncPrivateViewport();syncPrivateComposerHeight(true);},50);});
function html(m){var mine=!!m.mine;var a='<button type=\"button\" class=\"chat-avatar chat-avatar-button\" data-chat-avatar-user=\"'+Number(m.user_id||0)+'\">'+(m.avatar_html||esc((m.username||'?').slice(0,1)))+'</button>';var op=(!m.deleted&&(mine))?'<button type=\"button\" class=\"chat-message-delete\" data-chat-private-delete=\"'+Number(m.id)+'\">删除</button>':'';return '<article class=\"chat-message'+(mine?' is-mine':'')+'\" data-message-id=\"'+Number(m.id)+'\">'+a+'<div class=\"chat-message-body\"><div class=\"chat-message-head\"><span class=\"chat-author\">'+esc(m.username||'用户')+'</span><time>'+esc(m.time||'')+'</time>'+op+'</div>'+(m.html||'')+'</div></article>'; }
function append(m,force){if(!m||!m.id||messages.querySelector('[data-message-id=\"'+Number(m.id)+'\"]'))return;var was=nearBottom();messages.insertAdjacentHTML('beforeend',html(m));lastId=Math.max(lastId,Number(m.id));if(force||was)bottom();else if(newMarker)newMarker.classList.remove('is-hidden');}
function render(list){messages.innerHTML='';(Array.isArray(list)?list:[]).forEach(function(m){append(m,false);});bottom();}
function post(url,data){var body=new URLSearchParams();Object.keys(data||{}).forEach(function(k){body.set(k,data[k]);});body.set('_csrf',csrf);return fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest'},body:body.toString()}).then(function(r){return r.text().then(function(text){var x=null;try{x=JSON.parse(text);}catch(e){throw new Error('服务器返回异常，请检查插件数据库或 PHP 错误日志');}if(!r.ok||!x||!x.ok)throw new Error((x&&x.error)||'请求失败');return x;});});}
function read(){if(lastId)post(readUrl,{conversation_id:conversationId,message_id:lastId}).catch(function(){});}
function setSelfStatus(online,label){if(dot)dot.classList.toggle('is-online',!!online);if(selfStatus)selfStatus.textContent='我：'+(label|| (online?'已连接':'未连接'));}
function setOtherStatus(online,label){if(otherDot)otherDot.classList.toggle('is-online',!!online);if(otherStatus)otherStatus.textContent='对方：'+(label|| (online?'在线':'离线'));}
function updatePrivatePresence(action){if(!presenceUrl||!conversationId)return Promise.resolve();return post(presenceUrl,{conversation_id:conversationId,action:action||'online'}).then(function(d){setOtherStatus(!!d.other_online);}).catch(function(){if(action!=='offline')setOtherStatus(false,'暂不可用');});}
function startPrivatePresence(){if(presenceStarted||!presenceUrl||!conversationId)return;presenceStarted=true;updatePrivatePresence('online');var seconds=Number(app.getAttribute('data-presence-interval')||10);if(!isFinite(seconds)||seconds<5)seconds=10;presenceTimer=setInterval(function(){if(document.hidden)return;updatePrivatePresence('online');},seconds*1000);}
function stopPrivatePresence(){presenceStarted=false;if(presenceTimer){clearInterval(presenceTimer);presenceTimer=null;}if(!presenceUrl||!conversationId)return;var body=new URLSearchParams();body.set('conversation_id',String(conversationId));body.set('action','offline');body.set('_csrf',csrf);try{if(navigator.sendBeacon)navigator.sendBeacon(presenceUrl,body);else fetch(presenceUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString(),keepalive:true}).catch(function(){});}catch(e){}}
function connect(){if(document.hidden)return;if(source)return;var sep=streamUrl.indexOf('?')>=0?'&':'?';source=new EventSource(streamUrl+sep+'after='+encodeURIComponent(lastId),{withCredentials:true});source.addEventListener('open',function(){setSelfStatus(true,'已连接');});source.addEventListener('message',function(e){try{append(JSON.parse(e.data),false);read();}catch(x){}});source.addEventListener('server_close',function(e){var d={};try{d=JSON.parse(e.data||'{}');}catch(x){};lastId=Math.max(lastId,Number(d.last_id||0));if(source)source.close();source=null;setSelfStatus(false,'准备重连');var delay=Number(d.reconnect_delay||1500);clearTimeout(reconnectTimer);reconnectTimer=setTimeout(connect,delay);});source.onerror=function(){setSelfStatus(false,'连接断开');if(source)source.close();source=null;clearTimeout(reconnectTimer);reconnectTimer=setTimeout(connect,Number(app.getAttribute('data-sse-reconnect-delay')||1500));};}
if(form)form.addEventListener('submit',function(e){e.preventDefault();var body=(input.value||'').trim();if(!body||!send||send.disabled)return;send.disabled=true;post(sendUrl,{conversation_id:conversationId,body:body}).then(function(d){input.value='';if(d.message)append(d.message,true);read();}).catch(function(e){if(status)status.textContent=e.message||'发送失败';}).finally(function(){send.disabled=false;input.focus();});});
if(input)input.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();if(form)form.requestSubmit();}});
function showPrivateAvatarMenu(button){
    var old=document.querySelector('.chat-avatar-action-menu'); if(old) old.remove();
    var userId=Number(button.getAttribute('data-chat-avatar-user')||0); if(!userId)return;
    var profileBase=app.getAttribute('data-chat-profile-base')||'';
    var profileUrl=profileBase?profileBase+(profileBase.indexOf('?')>=0?'&':'?')+'id='+encodeURIComponent(userId):'#';
    var menu=document.createElement('div'); menu.className='chat-avatar-action-menu chat-private-avatar-action-menu';
    /* 个人聊天室中只保留“个人信息”，不再提供对当前私聊对象再次私信。 */
    menu.innerHTML='<a href="'+esc(profileUrl)+'" class="chat-avatar-action-item">个人信息</a>';
    document.body.appendChild(menu);
    menu.style.position='fixed';
    var rect=button.getBoundingClientRect(), gap=8, menuWidth=menu.offsetWidth, menuHeight=menu.offsetHeight;
    var left=rect.right+gap;
    if(left+menuWidth>window.innerWidth-8)left=rect.left-menuWidth-gap;
    left=Math.max(8,Math.min(left,window.innerWidth-menuWidth-8));
    var top=rect.top;
    if(top+menuHeight>window.innerHeight-8)top=rect.bottom-menuHeight;
    top=Math.max(8,Math.min(top,window.innerHeight-menuHeight-8));
    menu.style.left=Math.round(left)+'px'; menu.style.top=Math.round(top)+'px';
    window.setTimeout(function(){document.addEventListener('click',function outside(ev){if(menu.contains(ev.target)||button.contains(ev.target))return;menu.remove();document.removeEventListener('click',outside);},{once:true});},0);
}
app.addEventListener('click',function(event){
    var avatarButton=event.target.closest('[data-chat-avatar-user]');
    if(avatarButton && app.contains(avatarButton)){
        event.preventDefault(); event.stopPropagation(); showPrivateAvatarMenu(avatarButton);
    }
});
function togglePanel(button,panel){var show=panel.classList.contains('is-hidden');panel.classList.toggle('is-hidden',!show);button.setAttribute('aria-expanded',show?'true':'false');}
var pa=app.querySelector('[data-chat-private-attachment-toggle]'),pap=app.querySelector('[data-chat-private-attachment-panel]');
if(pa&&pap)pa.addEventListener('click',function(){togglePanel(pa,pap);});
var pf=app.querySelector('[data-chat-private-files-toggle]'),pfp=app.querySelector('[data-chat-private-files-panel]');
if(pf&&pfp)pf.addEventListener('click',function(){togglePanel(pf,pfp);});
if(newMarker)newMarker.addEventListener('click',function(){bottom();newMarker.classList.add('is-hidden');});
var initial=[];try{initial=JSON.parse(app.getAttribute('data-initial')||'[]');}catch(e){}render(initial);read();startPrivatePresence();connect();
if(document.addEventListener){document.addEventListener('visibilitychange',function(){if(document.hidden){stopPrivatePresence();if(source){source.close();source=null;}setSelfStatus(false,'后台暂停');}else{startPrivatePresence();connect();}});}
window.addEventListener('pagehide',function(){stopPrivatePresence();if(source){source.close();source=null;}});
window.addEventListener('pageshow',function(){startPrivatePresence();connect();});
}());
JS;
}

function chat_css(): string
{
    return <<<'CSS'
.chat-recent-files{margin:0}.chat-recent-files-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;color:var(--text)}.chat-recent-files-head span{font-size:11px;opacity:.55}.chat-recent-files-list{display:flex;flex-direction:column;gap:6px}.chat-recent-file{display:grid;grid-template-columns:minmax(0,1fr) auto auto;align-items:center;gap:8px;padding:7px 8px;border:1px solid var(--line);border-radius:8px}.chat-recent-file-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-recent-file-meta{font-size:11px;opacity:.55;white-space:nowrap}.chat-recent-file-copy{border:1px solid var(--line);background:var(--bg,var(--panel));color:var(--brand-hover);border-radius:7px;padding:5px 7px;font:inherit;font-size:11px;cursor:pointer;white-space:nowrap}.chat-recent-file-unavailable{font-size:11px;opacity:.55;white-space:nowrap}.chat-recent-files-empty,.chat-recent-files-status,.chat-recent-files-folders{font-size:12px;opacity:.65;padding:6px 2px}.chat-recent-files-folders{border-top:1px solid var(--line);margin-top:8px;padding-top:8px}.chat-recent-files-footer{margin-top:8px;padding-top:8px;border-top:1px solid var(--line);font-size:12px}.chat-recent-files-footer a{color:var(--brand-hover);text-decoration:none}.chat-menu-link{display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;min-width:var(--chat-menu-width,0px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.chat-menu-label{display:inline-block;white-space:nowrap}.chat-menu-label-rotate-out{opacity:0;transform:translateY(-4px);transition:opacity .12s ease,transform .12s ease}.chat-menu-label-rotate-in{animation:chat-menu-label-rotate-in .22s ease}@keyframes chat-menu-label-rotate-in{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}.chat-page{max-width:1180px;margin:0 auto;padding:var(--space-lg,16px);box-sizing:border-box;height:var(--chat-viewport-height,calc(100vh - var(--chat-page-offset, 0px)));min-height:0;display:flex;flex-direction:column;overflow:hidden}.chat-layout{display:grid;grid-template-columns:280px minmax(0,1fr);gap:var(--space-md,14px);flex:1;min-height:0;overflow:hidden}.chat-room-list,.chat-panel{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);min-width:0;min-height:0}.chat-room-list{padding:10px;overflow-y:auto}.chat-room-list-head{display:flex;align-items:center;justify-content:space-between;padding:8px 8px 12px;color:var(--text)}.chat-room-list-head strong{font-size:var(--font-size-lg)}.chat-manage-link,.chat-back-link,.chat-room-admin-actions a{font-size:var(--font-size-sm);font-weight:600;color:var(--brand-hover);text-decoration:none}.chat-room-link{display:flex;align-items:center;gap:10px;padding:11px 10px;border-radius:calc(var(--radius) - 2px);color:var(--text);text-decoration:none;margin-bottom:3px}.chat-room-link:hover,.chat-room-link.is-active{background:var(--bg-soft,var(--line));}.chat-room-link-main{min-width:0;display:flex;flex-direction:column;gap:3px;flex:1}.chat-room-link-main strong{font-size:var(--font-size-sm);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-room-link-main small{color:var(--text-muted);font-size:var(--font-size-xs);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-unread-badge{min-width:20px;padding:2px 6px;border-radius:999px;background:var(--brand);color:var(--brand-contrast,#fff);font-size:var(--font-size-xxs);text-align:center}.chat-main{display:flex;flex-direction:column;overflow:hidden}.chat-main-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 18px;border-bottom:1px solid var(--line)}.chat-main-title{min-width:0}.chat-main-title h1{margin:0;color:var(--text);font-size:var(--font-size-xl)}.chat-main-title p{margin:4px 0 0;color:var(--text-muted);font-size:var(--font-size-sm);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-main-meta{display:flex;align-items:center;justify-content:flex-end;gap:7px;min-width:86px;white-space:nowrap;color:var(--text-muted);font-size:var(--font-size-xs)}.chat-private-status-meta{gap:10px;flex-wrap:wrap}.chat-private-status-item{display:inline-flex;align-items:center;gap:5px}.chat-connection-dot{width:8px;height:8px;border-radius:50%;background:var(--text-subtle);display:inline-block}.chat-connection-dot.is-online{background:var(--brand)}.chat-scroll{position:relative;flex:1;min-height:0;overflow-y:auto;padding:18px}.chat-messages{display:flex;flex-direction:column;gap:15px}.chat-message{display:flex;align-items:flex-start;gap:10px;max-width:85%}.chat-message.is-mine{align-self:flex-end;flex-direction:row-reverse}.chat-avatar{width:34px;height:34px;flex:0 0 34px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:var(--bg-soft,var(--line));color:var(--text-muted);font-size:var(--font-size-sm);font-weight:700;text-decoration:none;overflow:hidden}.chat-message-body{min-width:0}.chat-message-head{display:flex;align-items:center;gap:8px;min-height:18px;margin-bottom:4px}.chat-message.is-mine .chat-message-head{justify-content:flex-end}.chat-author{color:var(--text);font-weight:650;font-size:var(--font-size-sm);text-decoration:none}.chat-message-head time{color:var(--text-subtle);font-size:var(--font-size-xxs)}.chat-message-delete{margin-left:4px;padding:0;border:0;background:transparent;color:var(--text-subtle);font-size:var(--font-size-xxs);cursor:pointer}.chat-message-delete:hover{color:var(--brand-hover)}.chat-message-content{padding:9px 12px;border:1px solid var(--line);border-radius:14px;background:var(--bg,var(--panel));color:var(--text);line-height:1.65;overflow-wrap:anywhere}.chat-message.is-mine .chat-message-content{background:var(--bg-soft,var(--line))}.chat-message-content p:first-child{margin-top:0}.chat-message-content p:last-child{margin-bottom:0}.chat-deleted-message{padding:8px 11px;border:1px dashed var(--line);border-radius:12px;color:var(--text-subtle);font-size:var(--font-size-sm);font-style:italic}.chat-new-marker{position:absolute;bottom:12px;left:50%;transform:translateX(-50%);padding:6px 12px;border:1px solid var(--line);border-radius:999px;background:var(--panel);box-shadow:var(--shadow,0 2px 10px rgba(0,0,0,.08));color:var(--brand-hover);font-size:var(--font-size-xs);font-weight:650;cursor:pointer}.chat-new-marker.is-hidden{display:none}.chat-composer-wrap{padding:10px 12px;border-top:1px solid var(--line)}.chat-composer{display:block}.chat-composer-row{display:flex;align-items:flex-end;gap:8px}.chat-composer textarea{flex:1;min-height:42px;max-height:140px;resize:none;box-sizing:border-box;padding:10px 12px;border:1px solid var(--line);border-radius:12px;background:var(--bg,var(--panel));color:var(--text);font:inherit;line-height:1.4;outline:none}.chat-composer textarea:focus{border-color:var(--brand)}.chat-composer button,.chat-form-actions button{border:0;border-radius:10px;padding:10px 16px;background:var(--brand);color:var(--brand-contrast,#fff);font:inherit;font-weight:650;cursor:pointer}.chat-composer button:disabled{opacity:.55;cursor:wait}.chat-composer-status{min-height:18px;margin:5px 2px 0;color:var(--text-muted);font-size:var(--font-size-xs)}.chat-login-hint{padding:10px 4px;color:var(--text-muted);font-size:var(--font-size-sm)}.chat-login-hint a{color:var(--brand-hover);font-weight:650;text-decoration:none}.chat-empty-room{padding:30px}.chat-empty-room h1{margin-top:0}.chat-manage-page{max-width:1000px}.chat-page-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:14px}.chat-page-head h1{margin:0;color:var(--text);font-size:var(--font-size-xl)}.chat-page-head p{margin:4px 0 0;color:var(--text-muted);font-size:var(--font-size-sm)}.chat-manage-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px}.chat-panel{padding:16px}.chat-panel h2{margin:0 0 14px;color:var(--text);font-size:var(--font-size-lg)}.chat-room-form .grid{display:grid;gap:6px;margin-bottom:12px}.chat-room-form .grid>span{color:var(--text-muted);font-size:var(--font-size-sm)}.chat-room-form input[type=text],.chat-room-form input[type=number],.chat-room-form textarea{width:100%;box-sizing:border-box;padding:9px 10px;border:1px solid var(--line);border-radius:9px;background:var(--bg,var(--panel));color:var(--text);font:inherit}.chat-check{display:flex;align-items:center;gap:7px;color:var(--text);font-size:var(--font-size-sm);margin:12px 0}.chat-form-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}.chat-danger-button{background:transparent;border:1px solid var(--line);color:var(--brand-hover)}.chat-room-admin-card{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding:12px 0;border-bottom:1px solid var(--line)}.chat-room-admin-card:last-child{border-bottom:0}.chat-room-admin-card strong{color:var(--text)}.chat-room-admin-card p{margin:4px 0 0;color:var(--text-muted);font-size:var(--font-size-xs);overflow-wrap:anywhere}.chat-room-admin-actions{display:flex;align-items:center;gap:10px;white-space:nowrap}.chat-room-status{font-size:var(--font-size-xxs);color:var(--text-muted);padding:2px 6px;border:1px solid var(--line);border-radius:999px}.chat-muted{color:var(--text-muted);font-size:var(--font-size-sm)}.chat-attachment-tools{display:flex;align-items:center;gap:6px;margin:0 0 8px}.chat-attachment-tools button{border:1px solid var(--line);background:var(--bg,var(--panel));color:var(--text-muted);border-radius:8px;padding:6px 9px;font:inherit;font-size:var(--font-size-xs);cursor:pointer}.chat-attachment-tools button[aria-expanded="true"]{border-color:var(--brand);color:var(--brand-hover)}.chat-attachment-panel{margin:0 0 8px;padding:8px;border:1px solid var(--line);border-radius:10px;background:var(--bg-soft,var(--panel))}.chat-attachment-panel.is-hidden{display:none}.chat-attachment-panel .attachment-field{margin:0}@media (max-width:860px){.chat-page{height:var(--chat-viewport-height,calc(100dvh - var(--chat-page-offset, 0px)));padding:8px}.chat-layout{grid-template-columns:1fr;min-height:0;overflow:hidden}.chat-room-list{display:flex;gap:6px;overflow-x:auto;overflow-y:hidden;padding:7px;flex:0 0 auto;max-height:76px}.chat-room-list-head{display:none}.chat-room-link{min-width:150px;margin:0}.chat-main{min-height:0;height:100%;overflow:hidden}.chat-manage-grid{grid-template-columns:1fr}}@media (max-width:640px){.chat-page{height:var(--chat-viewport-height,calc(100dvh - var(--chat-page-offset, 0px)));padding:0}.chat-layout{gap:0;height:100%}.chat-room-list{border-radius:0;border-left:0;border-right:0;border-top:0;max-height:70px}.chat-panel{border-radius:0;border-left:0;border-right:0}.chat-main-head{padding:12px 14px;flex:0 0 auto}.chat-main-title h1{font-size:var(--font-size-lg)}.chat-main-title p{max-width:48vw}.chat-scroll{padding:14px 12px;overscroll-behavior:contain}.chat-message{max-width:92%}.chat-composer-wrap{position:relative;flex:0 0 auto;background:var(--panel);padding:8px}.chat-composer textarea{font-size:16px}.chat-composer button{padding:10px 13px}.chat-page-head{padding:14px;align-items:flex-start}.chat-manage-grid{gap:0}.chat-manage-page .chat-panel{padding:14px}.chat-room-admin-card{flex-direction:column}.chat-room-admin-actions{align-self:flex-start}.chat-new-marker{bottom:8px}.chat-mobile-forum-link{display:inline-flex}}
.chat-avatar-button{border:0;cursor:pointer;padding:0}.chat-avatar-action-menu{position:fixed;z-index:10050;min-width:128px;padding:6px;border:1px solid var(--line);border-radius:10px;background:var(--panel);box-shadow:var(--shadow,0 10px 30px rgba(0,0,0,.16))}.chat-avatar-action-item{display:block;width:100%;box-sizing:border-box;padding:9px 12px;border:0;border-radius:7px;background:transparent;color:var(--text);font:inherit;text-align:left;text-decoration:none;cursor:pointer}.chat-avatar-action-item:hover{background:var(--bg-soft,var(--line));color:var(--text)}.chat-avatar-button .chat-avatar-inner{display:contents}.chat-private-section{margin-top:12px;padding-top:12px;border-top:1px solid var(--line)}.chat-private-head{padding:6px 8px 8px;color:var(--text);font-size:var(--font-size-sm)}.chat-private-link{display:flex;align-items:center;gap:8px;padding:8px;border-radius:8px;color:var(--text);text-decoration:none;margin-bottom:3px}.chat-private-link:hover,.chat-private-link.is-active{background:var(--bg-soft,var(--line))}.chat-private-avatar{width:28px;height:28px;flex:0 0 28px;border-radius:50%;overflow:hidden;display:flex}.chat-private-avatar img{width:100%;height:100%;object-fit:cover}.chat-private-name{min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--font-size-sm)}.chat-private-empty{padding:8px;color:var(--text-subtle);font-size:var(--font-size-xs);line-height:1.5}.chat-user-card-modal{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px}.chat-user-card-modal.is-hidden{display:none}.chat-user-card-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.35)}.chat-user-card{position:relative;width:min(360px,calc(100vw - 32px));padding:22px;border:1px solid var(--line);border-radius:16px;background:var(--panel);box-shadow:var(--shadow,0 10px 40px rgba(0,0,0,.16));text-align:center}.chat-user-card-close{position:absolute;right:10px;top:8px;border:0;background:transparent;color:var(--text-muted);font-size:24px;cursor:pointer}.chat-user-card-avatar{width:64px;height:64px;margin:4px auto 10px;border-radius:50%;overflow:hidden}.chat-user-card-avatar img{width:100%;height:100%;object-fit:cover}.chat-user-card h3{margin:0;color:var(--text)}.chat-user-card-bio{margin:8px 0 16px;color:var(--text-muted);font-size:var(--font-size-sm);line-height:1.6}.chat-user-card-actions button{border:0;border-radius:10px;padding:9px 18px;background:var(--brand);color:var(--brand-contrast,#fff);font:inherit;font-weight:650;cursor:pointer}.chat-settings-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.chat-settings-grid .grid{display:grid;gap:6px}.chat-settings-grid input[type=number]{width:100%;box-sizing:border-box;padding:9px 10px;border:1px solid var(--line);border-radius:9px;background:var(--bg,var(--panel));color:var(--text);font:inherit}.chat-settings-grid small{color:var(--text-subtle);font-size:var(--font-size-xs);line-height:1.5}.chat-admin-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:16px}.chat-admin-stats>div{padding:14px;border:1px solid var(--line);border-radius:10px;background:var(--bg-soft,var(--panel));display:flex;flex-direction:column;gap:4px}.chat-admin-stats strong{font-size:var(--font-size-xl);color:var(--text)}.chat-admin-stats span{font-size:var(--font-size-xs);color:var(--text-muted)}@media(max-width:860px){.chat-settings-grid,.chat-admin-stats{grid-template-columns:1fr}.chat-private-page .chat-room-list{max-height:82px}.chat-private-page .chat-private-link{min-width:180px}.chat-private-page .chat-main-head{gap:8px}.chat-private-page .chat-private-status-meta{gap:6px;min-width:0}.chat-private-page .chat-main-title p{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.chat-private-page .chat-attachment-tools{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}.chat-private-page .chat-attachment-tools button{flex:0 0 auto}}@media(max-width:640px){.chat-private-page .chat-room-list{max-height:76px;padding:6px}.chat-private-page .chat-private-link{min-width:155px;padding:7px}.chat-private-page .chat-private-avatar{width:26px;height:26px;flex-basis:26px}.chat-private-page .chat-main-head{padding:10px 12px}.chat-private-page .chat-main-title h1{font-size:16px}.chat-private-page .chat-main-title p{font-size:11px;max-width:72vw}.chat-private-page .chat-layout{height:auto;flex:1;min-height:0}.chat-private-page .chat-main{height:auto;flex:1;min-height:0}.chat-private-page .chat-scroll{padding:10px 9px;flex:1;min-height:0}.chat-private-page .chat-composer-wrap{position:relative;left:auto;right:auto;bottom:auto;width:auto;padding:7px;flex:0 0 auto}.chat-private-page .chat-composer-row{gap:6px}.chat-private-page .chat-composer textarea{min-height:40px}.chat-private-page .chat-composer button{padding:9px 12px}.chat-private-page .chat-attachment-panel{max-height:32vh;overflow:auto}}

.chat-mobile-switch{display:none}
.chat-avatar-action-menu{position:fixed !important;min-width:136px;padding:5px;transform:none;box-sizing:border-box;max-width:min(220px,calc(100vw - 16px))}
.chat-avatar-action-menu:before{content:'';position:absolute;top:12px;left:-6px;width:10px;height:10px;background:var(--panel);border-left:1px solid var(--line);border-bottom:1px solid var(--line);transform:rotate(45deg)}
.chat-private-avatar-action-menu:before{display:none}
.chat-public-avatar-action-menu{will-change:left,top}
.chat-public-avatar-action-menu:before{left:-6px;right:auto}
.chat-public-avatar-action-menu.is-left:before{left:auto;right:-6px;transform:rotate(225deg)}
.chat-avatar-action-item{position:relative;z-index:1}
@media(max-width:860px){
 html.chat-active-page,body.chat-active-page{overflow:hidden;height:100%;overscroll-behavior:none}
 body.chat-active-page main{min-height:0;height:100dvh;overflow:hidden}
 body.chat-active-page main.wrap[data-slot="page.before_render"]{min-height:0}
 .chat-page{height:calc(100dvh - var(--chat-page-top-gap, 0px));min-height:0;overflow:hidden;padding:0}
 /* 移动端公共/个人聊天室统一采用“窗口固定输入区 + 消息区滚动”。
  * 输入区只作用于 .chat-page，不影响论坛其它页面。 */
 .chat-page .chat-main{position:relative;min-height:0;overflow:hidden}
 .chat-page .chat-scroll{min-height:0;padding-bottom:calc(var(--chat-composer-height, 68px) + 12px);}
 .chat-page .chat-composer-wrap{position:fixed;left:0;right:0;bottom:0;width:100%;box-sizing:border-box;margin:0;border-top:1px solid var(--line);padding:7px max(7px, env(safe-area-inset-left)) calc(7px + env(safe-area-inset-bottom)) max(7px, env(safe-area-inset-right));z-index:1000;background:var(--panel)}
 .chat-page .chat-composer{width:100%;max-width:1180px;margin:0 auto}
 .chat-mobile-switch{display:flex;gap:4px;position:sticky;top:0;z-index:40;padding:6px 8px;border-bottom:1px solid var(--line);background:var(--panel)}
 .chat-mobile-switch a{flex:1;min-width:0;text-align:center;padding:9px 8px;border-radius:9px;color:var(--text-muted);text-decoration:none;font-size:13px;font-weight:650}
 .chat-mobile-switch a.is-active{background:var(--bg-soft,var(--line));color:var(--text)}
 .chat-layout{display:flex;flex-direction:column;gap:0;height:100%;min-height:0;overflow:hidden}
 .chat-room-list{display:flex;flex-direction:row;gap:6px;overflow-x:auto;overflow-y:hidden;padding:7px 8px;flex:0 0 auto;max-height:64px;border-radius:0;border-left:0;border-right:0;border-top:0}
 .chat-room-list-head{display:none}
 .chat-room-link{flex:0 0 148px;min-width:148px;padding:8px;margin:0}
 .chat-private-section{display:flex;flex:0 0 auto;gap:6px;margin:0;padding:0;border:0}
 .chat-private-head{display:none}
 .chat-private-link{flex:0 0 148px;min-width:148px;margin:0;padding:8px;background:var(--panel);border:1px solid var(--line)}
 .chat-private-empty{min-width:180px;padding:8px}
 .chat-main{display:flex;flex-direction:column;flex:1;min-height:0;height:100%;border-radius:0;border-left:0;border-right:0;overflow:hidden}
 .chat-main-head{padding:10px 12px;min-height:48px;flex:0 0 auto}
 .chat-scroll{padding:12px 10px;flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain}
 .chat-message{max-width:94%}
 .chat-composer-wrap{padding:7px;position:relative;flex:0 0 auto;z-index:20;background:var(--panel)}
 .chat-composer{min-width:0}
 .chat-attachment-tools{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}
 .chat-attachment-tools button{flex:0 0 auto}
 /* 个人聊天室单独处理：composer 留在 chat-main 的正常布局流中。这样附件工具栏出现/隐藏时，消息区会自动让出对应高度，最后一条消息不会被遮挡。 */
 /* 个人聊天室与公共聊天室使用完全相同的移动端高度模型。
  * composer 固定在窗口底部；消息区通过 --chat-composer-height 自动让出空间。
  * 特别保留附件工具栏的动态高度，避免出现工具栏后遮挡最后一条消息。 */
 .chat-private-page .chat-layout{height:100%;flex:1;min-height:0;overflow:hidden}
 .chat-private-page .chat-main{flex:1;min-height:0;height:100%;overflow:hidden}
 .chat-private-page .chat-scroll{flex:1;min-height:0;overflow-y:auto;padding-bottom:calc(var(--chat-composer-height, 68px) + 12px)}
 .chat-private-page .chat-composer-wrap{position:fixed;left:0;right:0;bottom:0;width:100%;box-sizing:border-box;margin:0;flex:0 0 auto;z-index:1000;border-top:1px solid var(--line);padding:7px max(7px, env(safe-area-inset-left)) calc(7px + env(safe-area-inset-bottom)) max(7px, env(safe-area-inset-right));background:var(--panel)}
 .chat-private-page .chat-composer{width:100%;max-width:1180px;margin:0 auto}
 .chat-private-page .chat-room-list{max-height:66px}
 .chat-private-page .chat-private-link{flex-basis:150px;min-width:150px}
 .chat-private-page .chat-attachment-tools{flex:0 0 auto}
 .chat-private-page .chat-attachment-panel{max-height:34dvh;overflow:auto}
}
@media(max-width:640px){
 .chat-mobile-switch{padding:5px 6px}
 .chat-mobile-switch a{padding:8px 5px;font-size:12px}
 .chat-layout{height:100%;min-height:0}
 .chat-room-list{max-height:60px;padding:6px}
 .chat-room-link,.chat-private-link{flex-basis:138px;min-width:138px;padding:7px}
 .chat-main-head{padding:9px 10px}
 .chat-main-title h1{font-size:16px}
 .chat-main-title p{font-size:11px;max-width:65vw}
 .chat-scroll{padding:10px 8px}
 .chat-composer-wrap{padding:6px}
 .chat-composer-row{gap:5px}
 .chat-composer textarea{min-height:42px;padding:9px 10px}
 .chat-composer button{padding:9px 12px}
 .chat-avatar-action-menu{min-width:128px}
}
CSS;
}

/* =========================================================
 * 8. Manifest
 * ========================================================= */

return [
    'id' => 'forum_chat_room',
    'name' => '论坛聊天室',
    'version' => CHAT_PLUGIN_VERSION,
    'description' => '提供多房间实时聊天、个人双向私聊、聊天内头像操作、历史消息、未读提醒、活跃人数、独立活跃心跳、消息管理，以及可配置的 SSE 生命周期与网络压力控制，并显示私聊双方在线状态。',
    'author' => 'bbc',
    'assets' => [
        'css' => 'chat_css',
        'js' => 'chat_js',
    ],
    'hooks' => [
        'top.menu_links' => 'chat_top_menu',
        'page.before_render' => 'chat_page_before_render',
        'user_files.reference_tabs' => 'chat_user_files_reference_tab',
    ],
    'admin_tabs' => [
        'chat_manage' => 'chat_admin_manage_page',
        'chat_private' => 'chat_admin_private_page',
        'chat_sse' => 'chat_admin_sse_page',
    ],
    'entries' => ['top_menu' => true],
    'routes' => [
        'chat' => 'chat_page',
    ],
    'install' => 'chat_install',
    'uninstall' => 'chat_uninstall',
];