<?php
if (!defined('APP_ROOT')) exit;

function markdown_textarea_token(array &$tokens, string $html): string
{
    $key = "\x1A" . count($tokens) . "\x1A";
    $tokens[$key] = $html;
    return $key;
}

function markdown_textarea_inline(string $text, int $topic_id = 0): string
{
    if (strpbrk($text, '`*[@') === false && stripos($text, 'http') === false) return h($text);
    $has_url = stripos($text, 'http://') !== false || stripos($text, 'https://') !== false;
    $has_markdown_url = $has_url || str_contains($text, '](/');
    $text = h($text);
    $tokens = [];
    if (str_contains($text, '`')) {
        $text = preg_replace_callback('/`([^`\n]+)`/u', function ($m) use (&$tokens) {
            return markdown_textarea_token($tokens, '<code>' . $m[1] . '</code>');
        }, $text) ?? $text;
    }
    if (str_contains($text, '*')) {
        $text = preg_replace_callback('/\*\*\*([^*\n]+)\*\*\*|\*\*([^*\n]+)\*\*|(?<!\*)\*([^*\n]+)\*(?!\*)/u', function ($m) {
            if (($m[1] ?? '') !== '') return '<em><strong>' . $m[1] . '</strong></em>';
            if (($m[2] ?? '') !== '') return '<strong>' . $m[2] . '</strong>';
            return '<em>' . $m[3] . '</em>';
        }, $text) ?? $text;
    }
    if (str_contains($text, '[') && $has_markdown_url) {
        $text = preg_replace_callback('/!\[((?:\\\\.|[^\]\\\\\n])*)\]\(((?:https?:\/\/|\/)[^\s)<]+)\)|\[((?:\\\\.|[^\]\\\\\n])+)\]\(((?:https?:\/\/|\/)[^\s)<]+)\)/ui', function ($m) use (&$tokens) {
            $image = str_starts_with($m[0], '![');
            $label = (string)$m[$image ? 1 : 3];
            $label = str_replace(['\\]', '\\[', '\\\\'], [']', '[', '\\'], $label);
            $url = html_entity_decode((string)$m[$image ? 2 : 4], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $html = $image
                ? '<img src="' . h($url) . '" alt="' . $label . '" loading="lazy" referrerpolicy="no-referrer">'
                : '<a href="' . h($url) . '" target="_blank" rel="nofollow noopener">' . $label . '</a>';
            return markdown_textarea_token($tokens, $html);
        }, $text) ?? $text;
    }
    $text = content_special_links_html($text, $topic_id);
    if ($has_url) {
        $text = preg_replace_callback('/(?<!["\'>=])(https?:\/\/[^\s<]+)/ui', function ($m) {
            $raw_url = rtrim($m[1], '.,;:!?');
            $url = html_entity_decode($raw_url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $tail = substr($m[1], strlen($raw_url));
            return '<a href="' . h($url) . '" target="_blank" rel="nofollow noopener">' . h($url) . '</a>' . h($tail);
        }, $text) ?? $text;
    }
    return strtr($text, $tokens);
}

function markdown_textarea_table_cells(string $line): array
{
    $line = trim($line);
    if (str_starts_with($line, '|')) $line = substr($line, 1);
    if (str_ends_with($line, '|')) $line = substr($line, 0, -1);
    $cells = [];
    $cell = '';
    $code = false;
    $escaped = false;
    for ($i = 0, $length = strlen($line); $i < $length; $i++) {
        $char = $line[$i];
        if ($escaped) {
            $cell .= $char;
            $escaped = false;
            continue;
        }
        if ($char === '\\') {
            $cell .= $char;
            $escaped = true;
            continue;
        }
        if ($char === '`') $code = !$code;
        if ($char === '|' && !$code) {
            $cells[] = trim(str_replace('\\|', '|', $cell));
            $cell = '';
            continue;
        }
        $cell .= $char;
    }
    $cells[] = trim(str_replace('\\|', '|', $cell));
    return $cells;
}

function markdown_textarea_table_html(array $lines, int $topic_id = 0): string
{
    if (count($lines) < 2) return '';
    $aligns = [];
    foreach (markdown_textarea_table_cells($lines[1]) as $cell) {
        $cell = trim($cell);
        if (!preg_match('/^:?-{3,}:?$/', $cell)) return '';
        $left = str_starts_with($cell, ':');
        $right = str_ends_with($cell, ':');
        $aligns[] = $left && $right ? 'center' : ($right ? 'right' : ($left ? 'left' : ''));
    }
    if (!$aligns) return '';
    $headers = markdown_textarea_table_cells($lines[0]);
    if (!$headers || count($headers) !== count($aligns)) return '';
    $cell_attr = fn(string $align) => $align !== '' ? ' style="text-align:' . $align . '"' : '';
    $html = '<div class="markdown-table-wrap"><table><thead><tr>';
    foreach ($headers as $i => $cell) $html .= '<th' . $cell_attr((string)($aligns[$i] ?? '')) . '>' . markdown_textarea_inline($cell, $topic_id) . '</th>';
    $html .= '</tr></thead><tbody>';
    foreach (array_slice($lines, 2) as $line) {
        if (trim($line) === '') continue;
        $row_style = '';
        if (preg_match('/<!--\s*bg:(yellow|red|blue)\s*-->\s*$/i', $line, $row_match)) {
            $row_style = ['yellow' => 'background:var(--warning-soft)', 'red' => 'background:var(--danger-soft)', 'blue' => 'background:var(--info-soft)'][strtolower($row_match[1])] ?? '';
            $line = trim((string)preg_replace('/\s*<!--\s*bg:(?:yellow|red|blue)\s*-->\s*$/i', '', $line));
        }
        $cells = markdown_textarea_table_cells($line);
        if (!$cells) continue;
        $html .= '<tr' . ($row_style !== '' ? ' style="' . $row_style . '"' : '') . '>';
        for ($i = 0, $count = count($headers); $i < $count; $i++) {
            $html .= '<td' . $cell_attr((string)($aligns[$i] ?? '')) . '>' . markdown_textarea_inline((string)($cells[$i] ?? ''), $topic_id) . '</td>';
        }
        $html .= '</tr>';
    }
    return $html . '</tbody></table></div>';
}

function markdown_textarea_plain_block_html(array $lines, int $topic_id = 0): string
{
    $block = trim(implode("\n", $lines));
    if ($block === '') return '';
    $lines = explode("\n", $block);
    if (count($lines) === 1 && preg_match('/^(#{1,6})\s+(.+)$/u', $lines[0], $m)) {
        $level = strlen($m[1]);
        return '<h' . $level . '>' . markdown_textarea_inline($m[2], $topic_id) . '</h' . $level . '>';
    }
    $table = markdown_textarea_table_html($lines, $topic_id);
    if ($table !== '') return $table;
    if (count($lines) > 1 && preg_match('/^\s*[-*]\s+/', $lines[0])) {
        $items = '';
        $tail = [];
        $list_open = true;
        foreach ($lines as $line) {
            if ($list_open && preg_match('/^\s*[-*]\s+(.+)$/u', $line, $m)) {
                $items .= '<li>' . markdown_textarea_inline($m[1], $topic_id) . '</li>';
                continue;
            }
            $list_open = false;
            $tail[] = $line;
        }
        if ($items !== '') return '<ul>' . $items . '</ul>' . ($tail ? markdown_textarea_plain_block_html($tail, $topic_id) : '');
    }
    return '<p>' . str_replace("\n", '<br>', markdown_textarea_inline($block, $topic_id)) . '</p>';
}

function markdown_textarea_block_html(array $lines, int $quote_depth, int $topic_id): string
{
    $lines = explode("\n", trim(implode("\n", $lines)));
    $html = '';
    $chunk = [];
    $quote = false;
    $lines[] = null;
    foreach ($lines as $line) {
        $is_quote = $line !== null && preg_match('/^\s*>\s?/u', $line) === 1;
        if ($chunk && ($line === null || $is_quote !== $quote)) {
            if (!$quote) $html .= markdown_textarea_plain_block_html($chunk, $topic_id);
            else {
                $inner = trim(implode("\n", array_map(fn($item) => preg_replace('/^\s*>\s?/u', '', $item) ?? $item, $chunk)));
                $inner_html = $inner === '' ? '' : ($quote_depth + 1 >= 32
                    ? markdown_textarea_plain_block_html(explode("\n", $inner), $topic_id)
                    : markdown_textarea_render_html($inner, $quote_depth + 1, $topic_id));
                $html .= '<blockquote>' . $inner_html . '</blockquote>';
            }
            $chunk = [];
        }
        if ($line !== null) {
            $quote = $is_quote;
            $chunk[] = $line;
        }
    }
    return $html;
}

function markdown_textarea_code_block_html(array $lines, string $lang): string
{
    $lang = strtolower(trim($lang));
    $class = preg_match('/^[a-z0-9_-]{1,32}$/', $lang) ? ' class="language-' . h($lang) . '"' : '';
    return '<pre><code' . $class . '>' . h(rtrim(implode("\n", $lines), "\n")) . '</code></pre>';
}

function markdown_textarea_render_html(string $text, int $quote_depth = 0, int $topic_id = 0): string
{
    $html = [];
    $buffer = [];
    $state = 'text';
    $lang = '';
    foreach (explode("\n", $text) as $line) {
        $fence = preg_match('/^\s*```\s*([\w-]*)\s*$/u', $line, $m) === 1;
        if ($state === 'code') {
            if ($fence) {
                $html[] = markdown_textarea_code_block_html($buffer, $lang);
                $buffer = [];
                $state = 'text';
            } else $buffer[] = $line;
            continue;
        }
        if ($fence) {
            if ($buffer) $html[] = markdown_textarea_block_html($buffer, $quote_depth, $topic_id);
            $buffer = [];
            $state = 'code';
            $lang = (string)($m[1] ?? '');
            continue;
        }
        if (trim($line) === '') {
            if ($buffer) $html[] = markdown_textarea_block_html($buffer, $quote_depth, $topic_id);
            $buffer = [];
            continue;
        }
        if (preg_match('/^(#{1,6})\s+(.+)$/u', $line)) {
            if ($buffer) $html[] = markdown_textarea_block_html($buffer, $quote_depth, $topic_id);
            $html[] = markdown_textarea_plain_block_html([$line], $topic_id);
            $buffer = [];
            continue;
        }
        if (preg_match('/^\s*-{3,}\s*$/u', $line)) {
            if ($buffer) $html[] = markdown_textarea_block_html($buffer, $quote_depth, $topic_id);
            $html[] = '<hr>';
            $buffer = [];
            continue;
        }
        $buffer[] = $line;
    }
    if ($state === 'code') $html[] = markdown_textarea_code_block_html($buffer, $lang);
    elseif ($buffer) $html[] = markdown_textarea_block_html($buffer, $quote_depth, $topic_id);
    return implode('', $html);
}

function markdown_textarea_render(mixed $rendered, array $ctx): ?string
{
    if (is_string($rendered)) return null;
    return markdown_textarea_render_html(
        (string)($ctx['text'] ?? ''),
        (int)($ctx['quote_depth'] ?? 0),
        (int)($ctx['topic_id'] ?? 0)
    );
}

function markdown_textarea_form_extra($html, array $ctx): string
{
    return (string)$html . '<div class="markdown-textarea" data-markdown-textarea role="toolbar" aria-label="Markdown 编辑器">'
        . '<button type="button" data-markdown-action="emoji" title="表情" aria-label="表情"><span class="markdown-textarea-emoji-icon">☺</span></button>'
        . '<button type="button" data-markdown-action="bold" title="粗体" aria-label="粗体">B</button>'
        . '<button type="button" data-markdown-action="italic" title="斜体" aria-label="斜体"><em>I</em></button>'
        . '<button type="button" data-markdown-action="heading" title="标题" aria-label="标题">H</button>'
        . '<button type="button" data-markdown-action="quote" title="引用" aria-label="引用">&gt;</button>'
        . '<button type="button" data-markdown-action="code" title="行内代码" aria-label="行内代码">`</button>'
        . '<button type="button" data-markdown-action="code_block" title="代码块" aria-label="代码块">&lt;/&gt;</button>'
        . '<button type="button" data-markdown-action="ul" title="无序列表" aria-label="无序列表">&bull;</button>'
        . '<button type="button" data-markdown-action="link" title="链接" aria-label="链接">↗</button>'
        . '<button type="button" data-markdown-action="image" title="图片" aria-label="图片">▧</button>'
        . '</div>';
}

function markdown_textarea_form_sidebar($html, array $ctx): string
{
    return (string)$html . sidebar_notice_card_html('Markdown 说明', [
        '**粗体**，*斜体*',
        '`代码`',
        '- 列表项',
        '| 表头 | 表头 | + | --- | --- |',
        '[链接文字](https://example.com)',
        '![图片描述](https://example.com/a.jpg)',
    ]);
}

function markdown_textarea_css(): string
{
    return <<<'CSS'
.markdown-textarea[data-markdown-textarea]{display:flex;align-items:center;flex-wrap:wrap;gap:0;margin:0;padding:0;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--bg)}
.markdown-textarea[data-markdown-textarea] button{display:inline-flex;align-items:center;justify-content:center;min-width:30px;height:28px;padding:0 7px;border:1px solid transparent;border-radius:var(--radius-sm);background:transparent;color:var(--text-muted);font:600 13px/1 var(--font-sans,inherit);cursor:pointer}
.markdown-textarea[data-markdown-textarea] button[data-markdown-action=emoji]{font-size:16px}
.markdown-textarea-emoji-icon{display:block;transform:translateY(-1px)}
.markdown-textarea[data-markdown-textarea] button:hover{border-color:var(--line);background:var(--panel);color:var(--text)}
.markdown-textarea[data-markdown-textarea] button:focus-visible{outline:2px solid var(--focus-ring);outline-offset:1px}
.markdown-textarea-dialog-field{display:grid;gap:5px;color:var(--text-muted);font-size:var(--font-size-sm)}
.markdown-textarea-dialog-field .prompt-input{box-sizing:border-box}
.markdown-textarea-emoji-grid{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:4px}
.markdown-textarea-emoji-grid button{display:grid;place-items:center;min-width:0;height:36px;padding:0;border:1px solid transparent;border-radius:var(--radius-sm);background:transparent;font-size:20px;line-height:1;cursor:pointer}
.markdown-textarea-emoji-grid button:hover,.markdown-textarea-emoji-grid button:focus-visible{border-color:var(--line);background:var(--brand-soft);outline:0}
.markdown-table-wrap{box-sizing:border-box;width:100%;max-width:100%;overflow-x:auto;overflow-y:hidden;overscroll-behavior-inline:contain;-webkit-overflow-scrolling:touch;scrollbar-width:thin;scrollbar-color:var(--line) transparent;scrollbar-gutter:stable}
.markdown-table-wrap table{width:100%;min-width:0;table-layout:auto}
.markdown-table-wrap::-webkit-scrollbar{height:8px}
.markdown-table-wrap::-webkit-scrollbar-track{background:transparent}
.markdown-table-wrap::-webkit-scrollbar-thumb{border-radius:4px;background:var(--line)}
@media(max-width:720px){.markdown-table-wrap table{min-width:max-content}}
.form-panel .markdown-textarea-field{display:grid;row-gap:0;margin:0 0 8px}
.reply-panel .markdown-textarea-field{display:grid;row-gap:0;margin:0}
.markdown-textarea-field>span{margin-bottom:6px;color:var(--text-muted);font-size:var(--font-size-sm)}
.markdown-textarea-field>span>small{display:block}
.reply-panel .markdown-textarea-field>span{display:none}
.markdown-textarea-field>[data-markdown-textarea]{border-bottom:0;border-radius:var(--radius-sm) var(--radius-sm) 0 0;background:var(--bg)}
.markdown-textarea-field>textarea[name=body]{border-top:0;border-radius:0 0 var(--radius-sm) var(--radius-sm);background:var(--panel)}
.markdown-textarea-field:focus-within [data-markdown-textarea]{border-color:var(--brand)}
@media(max-width:480px){.markdown-textarea[data-markdown-textarea]{flex-wrap:nowrap;gap:0;padding:0;overflow-x:auto;scrollbar-width:none}.markdown-textarea[data-markdown-textarea]::-webkit-scrollbar{display:none}.markdown-textarea[data-markdown-textarea] button{flex:0 0 auto;min-width:28px;height:28px;padding:0 6px}}
CSS;
}

function markdown_textarea_js(): string
{
    return <<<'JS'
(function () {
    'use strict';
    if (window.__markdownTextareaReady) return;
    window.__markdownTextareaReady = true;
    const toolbarSelector = '[data-markdown-textarea]';
    let fieldId = 0;

    const placeToolbar = toolbar => {
        if (!toolbar || !toolbar.isConnected) return;
        const form = toolbar.closest('form');
        const textarea = form?.querySelector('textarea[name="body"]');
        const field = textarea?.closest('label');
        if (!field) return;
        const caption = Array.from(field.children).find(element => element.tagName === 'SPAN');
        if (!caption) return;
        let wrapper = field.parentElement?.matches('.markdown-textarea-field') ? field.parentElement : null;
        if (!wrapper) {
            wrapper = document.createElement('div');
            wrapper.className = 'markdown-textarea-field';
            field.before(wrapper);
        }
        if (!textarea.id) textarea.id = 'markdown-textarea-' + (++fieldId);
        caption.setAttribute('for', textarea.id);
        wrapper.append(caption, toolbar, textarea);
        field.remove();
    };

    const dispatchInput = textarea => textarea.dispatchEvent(new Event('input', {bubbles: true}));

    const replaceRange = (textarea, value, start, end, selectionStart, selectionEnd) => {
        textarea.focus();
        textarea.setSelectionRange(start, end);
        const expected = textarea.value.slice(0, start) + value + textarea.value.slice(end);
        let inserted = false;
        if (typeof document.execCommand === 'function') {
            try {
                document.execCommand('insertText', false, value);
                inserted = textarea.value === expected;
            } catch (error) {
                inserted = false;
            }
        }
        if (!inserted) {
            textarea.setRangeText(value, start, end, 'select');
            dispatchInput(textarea);
        }
        textarea.setSelectionRange(start + selectionStart, start + selectionEnd);
    };

    const replaceSelection = (textarea, value, selectionStart, selectionEnd) => {
        const start = textarea.selectionStart || 0;
        const end = textarea.selectionEnd || start;
        replaceRange(textarea, value, start, end, selectionStart, selectionEnd);
    };

    const template = (textarea, before, after, placeholder) => {
        const start = textarea.selectionStart || 0;
        const end = textarea.selectionEnd || start;
        const selected = textarea.value.slice(start, end);
        const content = selected || placeholder;
        replaceSelection(textarea, before + content + after, before.length, before.length + content.length);
    };

    const linePrefix = (textarea, prefix, placeholder, numbered) => {
        const start = textarea.selectionStart || 0;
        const end = textarea.selectionEnd || start;
        const selected = textarea.value.slice(start, end);
        const content = selected || placeholder;
        const lines = content.split('\n').map((line, index) => prefix + (numbered ? (index + 1) + '. ' : '') + line);
        const value = lines.join('\n');
        const firstPrefixLength = numbered ? 3 : prefix.length;
        replaceSelection(textarea, value, firstPrefixLength, value.length);
    };

    let dialogFinish = null;
    const markdownTextareaEmojis = ['😀','😃','😄','😁','😆','😅','😂','🤣','😊','😇','🙂','🙃','😉','😍','🥰','😘','😋','😛','😜','🤪','🤨','🧐','🤓','😎','🤩','🥳','😏','😒','😞','😔','😟','😕','🙁','😣','😫','🥺','😢','😭','😤','😠','😡','🤬','🤯','😳','🥵','🥶','😱','😨','😰','🤗','🤔','🤭','🤫','😶','😐','😑','😬','🙄','😯','😮','😲','🥱','😴','🤤','😪','😵','🤐','🤑','🤠','👍','👎','👏','🙏','💪','🔥','✨','🎉','❤️','💔','✅','❌','⭐'];

    const finishDialog = value => {
        const finish = dialogFinish;
        dialogFinish = null;
        const dialog = document.getElementById('notify-modal');
        const body = document.getElementById('notify-modal-body');
        if (dialog) dialog.hidden = true;
        if (body) body.innerHTML = '';
        if (finish) finish(value);
    };

    const openMarkdownDialog = (title, fields) => new Promise(resolve => {
        const dialog = document.getElementById('notify-modal');
        const titleElement = document.getElementById('notify-modal-title');
        const body = document.getElementById('notify-modal-body');
        if (!dialog || !body) { resolve(null); return; }
        dialogFinish = resolve;
        if (titleElement) titleElement.textContent = title;
        body.innerHTML = '';
        const box = document.createElement('form');
        box.className = 'confirm-box markdown-textarea-dialog';
        const inputs = {};
        fields.forEach(field => {
            const label = document.createElement('label');
            label.className = 'markdown-textarea-dialog-field';
            const caption = document.createElement('span');
            caption.textContent = field.label;
            const input = document.createElement('input');
            input.className = 'prompt-input';
            input.type = field.type || 'text';
            input.value = field.value || '';
            input.placeholder = field.placeholder || '';
            input.autocomplete = 'off';
            inputs[field.name] = input;
            label.append(caption, input);
            box.appendChild(label);
        });
        const actions = document.createElement('div');
        actions.className = 'confirm-actions';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'btn alt';
        cancel.textContent = '取消';
        const ok = document.createElement('button');
        ok.type = 'submit';
        ok.className = 'danger';
        ok.textContent = '确定';
        cancel.addEventListener('click', () => finishDialog(null));
        box.addEventListener('submit', event => {
            event.preventDefault();
            const values = {};
            Object.keys(inputs).forEach(name => { values[name] = inputs[name].value; });
            finishDialog(values);
        });
        actions.append(cancel, ok);
        box.appendChild(actions);
        body.appendChild(box);
        dialog.hidden = false;
        inputs[fields[0].name]?.focus();
        inputs[fields[0].name]?.select();
    });

    const openMarkdownEmojiDialog = () => new Promise(resolve => {
        const dialog = document.getElementById('notify-modal');
        const titleElement = document.getElementById('notify-modal-title');
        const body = document.getElementById('notify-modal-body');
        if (!dialog || !body) { resolve(null); return; }
        dialogFinish = resolve;
        if (titleElement) titleElement.textContent = '选择表情';
        body.innerHTML = '';
        const box = document.createElement('div');
        box.className = 'confirm-box markdown-textarea-dialog';
        const grid = document.createElement('div');
        grid.className = 'markdown-textarea-emoji-grid';
        markdownTextareaEmojis.forEach(emoji => {
            const button = document.createElement('button');
            button.type = 'button';
            button.textContent = emoji;
            button.setAttribute('aria-label', emoji);
            button.addEventListener('click', () => finishDialog(emoji));
            grid.appendChild(button);
        });
        const actions = document.createElement('div');
        actions.className = 'confirm-actions';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'btn alt';
        cancel.textContent = '取消';
        cancel.addEventListener('click', () => finishDialog(null));
        actions.appendChild(cancel);
        box.append(grid, actions);
        body.appendChild(box);
        dialog.hidden = false;
        grid.querySelector('button')?.focus();
    });

    const insertLink = async textarea => {
        const start = textarea.selectionStart || 0;
        const end = textarea.selectionEnd || start;
        const selected = textarea.value.slice(start, end);
        const label = selected || '链接文字';
        const values = await openMarkdownDialog('插入链接', [{name: 'url', label: '链接地址', type: 'url', value: 'https://'}]);
        if (!values) return;
        const target = String(values.url || '').trim();
        if (!target) return;
        const value = '[' + label + '](' + target + ')';
        replaceRange(textarea, value, start, end, 1, 1 + label.length);
    };

    const insertImage = async textarea => {
        const start = textarea.selectionStart || 0;
        const end = textarea.selectionEnd || start;
        const selected = textarea.value.slice(start, end);
        const values = await openMarkdownDialog('插入图片', [
            {name: 'url', label: '图片地址', type: 'url', value: 'https://'},
            {name: 'alt', label: '图片描述', value: selected},
        ]);
        if (!values) return;
        const target = String(values.url || '').trim();
        if (!target) return;
        const alt = String(values.alt || '').trim();
        const value = '![' + alt + '](' + target + ')';
        replaceRange(textarea, value, start, end, 2, 2 + alt.length);
    };

    const insertEmoji = async textarea => {
        const start = textarea.selectionStart || 0;
        const end = textarea.selectionEnd || start;
        const emoji = await openMarkdownEmojiDialog();
        if (!emoji) return;
        replaceRange(textarea, emoji, start, end, emoji.length, emoji.length);
    };

    const applyAction = async (action, textarea) => {
        switch (action) {
            case 'bold': template(textarea, '**', '**', '粗体文字'); break;
            case 'italic': template(textarea, '*', '*', '斜体文字'); break;
            case 'strike': template(textarea, '~~', '~~', '删除线文字'); break;
            case 'heading': linePrefix(textarea, '## ', '标题', false); break;
            case 'quote': linePrefix(textarea, '> ', '引用内容', false); break;
            case 'code': template(textarea, '`', '`', '代码'); break;
            case 'code_block': template(textarea, '```\n', '\n```', '代码'); break;
            case 'ul': linePrefix(textarea, '- ', '列表项', false); break;
            case 'ol': linePrefix(textarea, '', '列表项', true); break;
            case 'link': await insertLink(textarea); break;
            case 'image': await insertImage(textarea); break;
            case 'emoji': await insertEmoji(textarea); break;
            case 'hr': template(textarea, '\n', '\n', '---'); break;
        }
    };

    const scan = root => {
        if (root.matches?.(toolbarSelector)) placeToolbar(root);
        root.querySelectorAll?.(toolbarSelector).forEach(placeToolbar);
    };

    document.addEventListener('click', event => {
        const target = event.target instanceof Element ? event.target : null;
        const dialog = document.getElementById('notify-modal');
        if (dialogFinish && dialog && target?.closest('[data-modal-close]')) finishDialog(null);
        const button = event.target.closest?.('[data-markdown-action]');
        if (!button) return;
        const toolbar = button.closest(toolbarSelector);
        const textarea = toolbar?.closest('form')?.querySelector('textarea[name="body"]');
        if (!toolbar || !textarea) return;
        event.preventDefault();
        void applyAction(button.dataset.markdownAction || '', textarea);
    });

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && dialogFinish) finishDialog(null);
    });

    scan(document);
    if (document.body && window.MutationObserver) {
        new MutationObserver(mutations => mutations.forEach(mutation => mutation.addedNodes.forEach(node => {
            if (node.nodeType === 1) scan(node);
        }))).observe(document.body, {childList: true, subtree: true});
    }
}());
JS;
}

return [
    'id' => 'markdown_textarea',
    'name' => 'Markdown 编辑器',
    'version' => '1.0.18',
    'description' => '为发帖和回帖提供常用排版工具，并正确显示标题、链接、图片、代码和表格。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'markdown_textarea_css', 'js' => 'markdown_textarea_js'],
    'hooks' => [
        'topic.form_extra' => 'markdown_textarea_form_extra',
        'reply.form_extra' => 'markdown_textarea_form_extra',
        'topic.form_sidebar' => 'markdown_textarea_form_sidebar',
        'markdown.render' => 'markdown_textarea_render',
    ],
];