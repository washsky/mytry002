<?php
if (!defined('APP_ROOT')) exit;

function custom_header_footer_config(): array
{
    $config = plugin_config('custom_header_footer', []);
    return [
        'header_html' => cut((string)($config['header_html'] ?? ''), 20000),
        'footer_html' => cut((string)($config['footer_html'] ?? ''), 20000),
    ];
}

function custom_header_footer_header($html, array $ctx): string
{
    return (string)$html . custom_header_footer_config()['header_html'];
}

function custom_header_footer_footer($html, array $ctx): string
{
    return (string)$html . custom_header_footer_config()['footer_html'];
}

function custom_header_footer_admin_page(array $plugin): string
{
    need_admin();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        plugin_save_config('custom_header_footer', [
            'header_html' => post('header_html', 20000),
            'footer_html' => post('footer_html', 20000),
        ]);
        set_flash('自定义页头页脚已保存');
        go(admin_url(['tab' => 'custom_header_footer']));
    }
    $config = custom_header_footer_config();
    $fields = [
        'header_html' => ['label' => '页头内容', 'type' => 'textarea'],
        'footer_html' => ['label' => '页脚内容', 'type' => 'textarea'],
    ];
    return '<div class="form-panel settings-form"><h2>自定义页头页脚</h2><form method="post">' . form_token() . render_form_fields($fields, $config) . '<div class="row settings-actions"><button type="submit">保存</button></div></form></div>';
}

return [
    'id' => 'custom_header_footer',
    'name' => '自定义页头页脚',
    'version' => '1.0.0',
    'description' => '在网站页头或页脚加入公告、统计代码及其他自定义内容。',
    'author' => 'bbs1org',
    'hooks' => [
        'page.header' => 'custom_header_footer_header',
        'page.footer' => 'custom_header_footer_footer',
    ],
    'admin_tabs' => ['custom_header_footer' => 'custom_header_footer_admin_page'],
];