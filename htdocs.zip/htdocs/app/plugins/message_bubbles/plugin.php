<?php
if (!defined('APP_ROOT')) exit;

/**
 * 回复气泡 2.4.9
 *
 * 这版重写了 1.x 的渲染路径：
 * - 不在逐条 reply.after_render 中读取用户设置，用户偏好从核心 settings cache 一次建立请求级映射。
 * - 不猜测引用关系；连接线只依据论坛原生已经渲染出的 post-floor-mention（@用户名 #楼层）。
 * - 主题主楼使用 topic.replies 提供的 topic 上下文判断楼主，不修改核心楼层结构。
 * - 固定 CSS / JS 通过 manifest assets 提供，所有自有标识均使用 message-bubbles 前缀。
 */

function message_bubbles_version(): string
{
    return '2.4.9';
}

function message_bubbles_defaults(): array
{
    return [
        'enabled' => 1,
        'style' => 'modern',
        'tail' => 'none',
        'radius' => 16,
        'width' => 92,
        'mobile_width' => 100,
        'shadow' => 1,
        'border' => 1,
        'density' => 'comfortable',
        'hover_lift' => 0,
        'avatar_ring' => 0,
        'meta_layout' => 'outside',
        'topic_enabled' => 0,
        'topic_style' => 'card',
        'show_owner_badge' => 0,
        'owner_badge_text' => '楼主',
        'quote_bubble' => 0,
        'quote_depth' => 3,
        'quote_style' => 'compact',
        'quote_collapse' => 0,
        'quote_collapse_lines' => 8,
        'reply_reference' => 1,
        'reply_reference_link' => 1,
        'identity_colors' => 0,
        'identity_mode' => 'accent',
        'conversation_line' => 0,
        'conversation_mode' => 'quoted',
        'conversation_line_style' => 'curve',
        'merge_bubbles' => 0,
        'merge_window' => 10,
        'animation' => 0,
        'user_customization' => 1,
        'user_custom_style' => 1,
        'user_custom_tail' => 1,
        'user_custom_colors' => 0,
        'user_custom_density' => 0,
        'image_follow_radius' => 1,
        'code_breakout' => 0,
        'code_max_height' => 520,
        'long_content_wrap' => 1,
        'bubble_bg' => '#ffffff',
        'bubble_border' => '#d9e2dc',
        'bubble_text' => '#1f2937',
        'bubble_accent' => '#2ecc71',
        'quote_bg' => '#eefaf3',
        'quote_border' => '#2ecc71',
        'bg_opacity' => 100,
        'accent_2' => '#8b5cf6',
    ];
}

function message_bubbles_styles(): array
{
    return [
        'classic' => 'Classic｜经典圆角',
        'modern' => 'Modern｜现代气泡',
        'chat' => 'Chat｜聊天气泡',
        'card' => 'Card｜卡片',
        'minimal' => 'Minimal｜极简',
        'accent' => 'Accent｜主题标记',
        'glass' => 'Glass｜毛玻璃',
        'soft' => 'Soft｜柔和',
        'outline' => 'Outline｜描边',
        'pill' => 'Pill｜胶囊',
        'paper' => 'Paper｜纸张',
        'terminal' => 'Terminal｜终端',
    ];
}

function message_bubbles_tails(): array
{
    return [
        'none' => '无尾巴',
        'bottom-left' => '左下',
        'top-left' => '左上',
        'bottom-right' => '右下',
        'top-right' => '右上',
    ];
}

function message_bubbles_densities(): array
{
    return [
        'compact' => '紧凑',
        'comfortable' => '舒适',
        'spacious' => '宽松',
    ];
}

function message_bubbles_identity_modes(): array
{
    return [
        'accent' => '左侧强调色',
        'border' => '边框强调色',
        'name' => '用户名强调色',
        'dot' => '身份小圆点',
    ];
}

function message_bubbles_conversation_modes(): array
{
    return [
        'quoted' => '原生引用关系（@用户名 #楼层）',
    ];
}

function message_bubbles_meta_layouts(): array
{
    return [
        'outside' => '气泡外',
        'inside' => '气泡内',
        'compact' => '紧凑模式',
    ];
}

function message_bubbles_quote_styles(): array
{
    return [
        'compact' => '紧凑引用',
        'card' => '引用卡片',
        'line' => '侧线引用',
    ];
}

function message_bubbles_hex(string $value, string $fallback): string
{
    $value = trim($value);
    if (preg_match('/^#[0-9a-fA-F]{6}$/D', $value) !== 1) return $fallback;
    return strtolower($value);
}

function message_bubbles_hex_rgba(string $hex, int $opacity): string
{
    $hex = message_bubbles_hex($hex, '#ffffff');
    $opacity = min(100, max(0, $opacity));
    $r = hexdec(substr($hex, 1, 2));
    $g = hexdec(substr($hex, 3, 2));
    $b = hexdec(substr($hex, 5, 2));
    return 'rgba(' . $r . ',' . $g . ',' . $b . ',' . ($opacity / 100) . ')';
}

function message_bubbles_config(): array
{
    static $config = null;
    if (is_array($config)) return $config;

    $d = message_bubbles_defaults();
    $raw = plugin_config('message_bubbles', $d);
    $styles = array_keys(message_bubbles_styles());
    $tails = array_keys(message_bubbles_tails());
    $densities = array_keys(message_bubbles_densities());
    $identity_modes = array_keys(message_bubbles_identity_modes());
    $conversation_modes = array_keys(message_bubbles_conversation_modes());
    $meta_layouts = array_keys(message_bubbles_meta_layouts());
    $quote_styles = array_keys(message_bubbles_quote_styles());
    $line_styles = ['curve', 'straight', 'dot'];

    $style = (string)($raw['style'] ?? $d['style']);
    $tail = (string)($raw['tail'] ?? $d['tail']);
    $density = (string)($raw['density'] ?? $d['density']);
    $topic_style = (string)($raw['topic_style'] ?? $d['topic_style']);
    $identity_mode = (string)($raw['identity_mode'] ?? $d['identity_mode']);
    $conversation_mode = (string)($raw['conversation_mode'] ?? $d['conversation_mode']);
    $meta_layout = (string)($raw['meta_layout'] ?? $d['meta_layout']);
    $quote_style = (string)($raw['quote_style'] ?? $d['quote_style']);
    $line_style = (string)($raw['conversation_line_style'] ?? $d['conversation_line_style']);

    return $config = [
        'enabled' => !empty($raw['enabled']),
        'style' => in_array($style, $styles, true) ? $style : $d['style'],
        'tail' => in_array($tail, $tails, true) ? $tail : $d['tail'],
        'radius' => min(32, max(0, (int)($raw['radius'] ?? $d['radius']))),
        'width' => min(100, max(55, (int)($raw['width'] ?? $d['width']))),
        'mobile_width' => min(100, max(70, (int)($raw['mobile_width'] ?? $d['mobile_width']))),
        'shadow' => !empty($raw['shadow']),
        'border' => !empty($raw['border']),
        'density' => in_array($density, $densities, true) ? $density : $d['density'],
        'hover_lift' => !empty($raw['hover_lift']),
        'avatar_ring' => !empty($raw['avatar_ring']),
        'meta_layout' => in_array($meta_layout, $meta_layouts, true) ? $meta_layout : $d['meta_layout'],
        'topic_enabled' => !empty($raw['topic_enabled']),
        'topic_style' => in_array($topic_style, $styles, true) ? $topic_style : $d['topic_style'],
        'show_owner_badge' => !empty($raw['show_owner_badge']),
        'owner_badge_text' => cut(trim((string)($raw['owner_badge_text'] ?? $d['owner_badge_text'])), 20),
        'quote_bubble' => !empty($raw['quote_bubble']),
        'quote_depth' => min(5, max(1, (int)($raw['quote_depth'] ?? $d['quote_depth']))),
        'quote_style' => in_array($quote_style, $quote_styles, true) ? $quote_style : $d['quote_style'],
        'quote_collapse' => !empty($raw['quote_collapse']),
        'quote_collapse_lines' => min(30, max(3, (int)($raw['quote_collapse_lines'] ?? $d['quote_collapse_lines']))),
        'reply_reference' => !empty($raw['reply_reference']),
        'reply_reference_link' => !empty($raw['reply_reference_link']),
        'identity_colors' => !empty($raw['identity_colors']),
        'identity_mode' => in_array($identity_mode, $identity_modes, true) ? $identity_mode : $d['identity_mode'],
        'conversation_line' => !empty($raw['conversation_line']),
        'conversation_mode' => in_array($conversation_mode, $conversation_modes, true) ? $conversation_mode : $d['conversation_mode'],
        'conversation_line_style' => in_array($line_style, $line_styles, true) ? $line_style : $d['conversation_line_style'],
        'merge_bubbles' => !empty($raw['merge_bubbles']),
        'merge_window' => min(120, max(1, (int)($raw['merge_window'] ?? $d['merge_window']))),
        'animation' => !empty($raw['animation']),
        'user_customization' => !empty($raw['user_customization']),
        'user_custom_style' => !empty($raw['user_custom_style']),
        'user_custom_tail' => !empty($raw['user_custom_tail']),
        'user_custom_colors' => !empty($raw['user_custom_colors']),
        'user_custom_density' => !empty($raw['user_custom_density']),
        'image_follow_radius' => !empty($raw['image_follow_radius']),
        'code_breakout' => !empty($raw['code_breakout']),
        'code_max_height' => min(1200, max(120, (int)($raw['code_max_height'] ?? $d['code_max_height']))),
        'long_content_wrap' => !empty($raw['long_content_wrap']),
        'bubble_bg' => message_bubbles_hex((string)($raw['bubble_bg'] ?? ''), $d['bubble_bg']),
        'bubble_border' => message_bubbles_hex((string)($raw['bubble_border'] ?? ''), $d['bubble_border']),
        'bubble_text' => message_bubbles_hex((string)($raw['bubble_text'] ?? ''), $d['bubble_text']),
        'bubble_accent' => message_bubbles_hex((string)($raw['bubble_accent'] ?? ''), $d['bubble_accent']),
        'quote_bg' => message_bubbles_hex((string)($raw['quote_bg'] ?? ''), $d['quote_bg']),
        'quote_border' => message_bubbles_hex((string)($raw['quote_border'] ?? ''), $d['quote_border']),
        'bg_opacity' => min(100, max(20, (int)($raw['bg_opacity'] ?? $d['bg_opacity']))),
        'accent_2' => message_bubbles_hex((string)($raw['accent_2'] ?? ''), $d['accent_2']),
    ];
}

function message_bubbles_user_key(int $user_id): string
{
    return 'plugin_message_bubbles_user_' . max(0, $user_id);
}

function message_bubbles_user_defaults(): array
{
    return [
        // mode=inherit：完全使用站点默认；mode=custom：只覆盖用户被允许修改的字段。
        'mode' => 'inherit',
        'enabled' => 1, // 兼容 2.4.2/2.4.6；新逻辑以 mode 为准。
        'style' => 'inherit',
        'tail' => 'inherit',
        'density' => 'inherit',
        'custom_colors' => 0,
        'radius' => 16,
        'bubble_bg' => '#ffffff',
        'bubble_border' => '#d9e2dc',
        'bubble_text' => '#1f2937',
        'bubble_accent' => '#2ecc71',
        'quote_bg' => '#eefaf3',
        'quote_border' => '#2ecc71',
        'bg_opacity' => 100,
        'initialized' => 0,
    ];
}

function message_bubbles_normalize_user_preferences(array $raw): array
{
    $d = message_bubbles_user_defaults();
    $styles = array_keys(message_bubbles_styles());
    $tails = array_keys(message_bubbles_tails());
    $densities = array_keys(message_bubbles_densities());
    $style = (string)($raw['style'] ?? $d['style']);
    $tail = (string)($raw['tail'] ?? $d['tail']);
    $density = (string)($raw['density'] ?? $d['density']);

    $mode = (string)($raw['mode'] ?? '');
    if ($mode !== 'inherit' && $mode !== 'custom') {
        // 兼容旧版本：旧数据如果曾经开启个人气泡或选择过具体值，则迁移为 custom。
        $legacy_override = !empty($raw['enabled'])
            && ($style !== 'inherit' || $tail !== 'inherit' || $density !== 'inherit' || !empty($raw['custom_colors']));
        $mode = $legacy_override ? 'custom' : 'inherit';
    }

    return [
        'mode' => $mode,
        'enabled' => !empty($raw['enabled']),
        'style' => $style === 'inherit' || in_array($style, $styles, true) ? $style : 'inherit',
        'tail' => $tail === 'inherit' || in_array($tail, $tails, true) ? $tail : 'inherit',
        'density' => $density === 'inherit' || in_array($density, $densities, true) ? $density : 'inherit',
        'custom_colors' => !empty($raw['custom_colors']),
        'radius' => min(32, max(0, (int)($raw['radius'] ?? $d['radius']))),
        'bubble_bg' => message_bubbles_hex((string)($raw['bubble_bg'] ?? ''), $d['bubble_bg']),
        'bubble_border' => message_bubbles_hex((string)($raw['bubble_border'] ?? ''), $d['bubble_border']),
        'bubble_text' => message_bubbles_hex((string)($raw['bubble_text'] ?? ''), $d['bubble_text']),
        'bubble_accent' => message_bubbles_hex((string)($raw['bubble_accent'] ?? ''), $d['bubble_accent']),
        'quote_bg' => message_bubbles_hex((string)($raw['quote_bg'] ?? ''), $d['quote_bg']),
        'quote_border' => message_bubbles_hex((string)($raw['quote_border'] ?? ''), $d['quote_border']),
        'bg_opacity' => min(100, max(20, (int)($raw['bg_opacity'] ?? $d['bg_opacity']))),
        'initialized' => !empty($raw['initialized']) ? 1 : 0,
    ];
}

function message_bubbles_user_map(): array
{
    if (is_array($GLOBALS['message_bubbles_user_map'] ?? null)) return $GLOBALS['message_bubbles_user_map'];

    $map = [];
    $config = message_bubbles_config();
    if (!$config['user_customization']) return $GLOBALS['message_bubbles_user_map'] = $map;

    // 一次读取 settings cache，禁止在逐条回复渲染时查询数据库。
    foreach (settings_cache() as $key => $value) {
        $key = (string)$key;
        $prefix = 'plugin_message_bubbles_user_';
        if (!str_starts_with($key, $prefix)) continue;
        $uid = (int)substr($key, strlen($prefix));
        if ($uid < 1) continue;
        $raw = json_decode((string)$value, true);
        if (is_array($raw)) $map[$uid] = message_bubbles_normalize_user_preferences($raw);
    }
    return $GLOBALS['message_bubbles_user_map'] = $map;
}

function message_bubbles_user_preferences(int $user_id): array
{
    if ($user_id < 1) return message_bubbles_user_defaults();
    $map = message_bubbles_user_map();
    return $map[$user_id] ?? message_bubbles_user_defaults();
}

function message_bubbles_user_has_override(array $user): bool
{
    // 2.4.7 以后只认 mode=custom。这样“管理员默认”和“用户覆盖”在数据层彻底分离。
    return ($user['mode'] ?? 'inherit') === 'custom';
}

function message_bubbles_resolve(array $config, int $user_id): array
{
    // 管理员配置永远是基准配置。没有用户自定义时，直接原样返回，绝不复制/改写。
    if (!$config['user_customization'] || $user_id < 1) return $config;

    $user = message_bubbles_user_preferences($user_id);
    if (!message_bubbles_user_has_override($user)) return $config;

    // 只覆盖管理员明确允许用户修改的项目；其余全部继承管理员默认值。
    if ($config['user_custom_style'] && $user['style'] !== 'inherit') $config['style'] = $user['style'];
    if ($config['user_custom_tail'] && $user['tail'] !== 'inherit') $config['tail'] = $user['tail'];
    if ($config['user_custom_density'] && $user['density'] !== 'inherit') $config['density'] = $user['density'];
    if ($config['user_custom_colors'] && $user['custom_colors']) {
        foreach (['bubble_bg', 'bubble_border', 'bubble_text', 'bubble_accent', 'quote_bg', 'quote_border', 'bg_opacity'] as $key) {
            $config[$key] = $user[$key];
        }
        $config['radius'] = $user['radius'];
    }
    return $config;
}

function message_bubbles_identity_color(int $user_id): string
{
    if ($user_id < 1) return '#2ecc71';
    $palette = ['#2ecc71', '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#06b6d4', '#ef4444', '#14b8a6', '#6366f1', '#84cc16', '#f97316', '#0ea5e9'];
    return $palette[$user_id % count($palette)];
}

function message_bubbles_color_input(string $label, string $name, string $value, string $help = ''): string
{
    return '<label class="grid message-bubbles-color-field"><span>' . h($label) . ($help !== '' ? '<small>' . h($help) . '</small>' : '') . '<code>' . h($value) . '</code></span><input type="color" name="' . h($name) . '" value="' . h($value) . '"></label>';
}

function message_bubbles_checkbox(string $label, string $name, bool $value, string $help = ''): string
{
    return checkbox($label, $name, $value, $help);
}

function message_bubbles_save_admin(): void
{
    need_admin();
    require_post();

    $d = message_bubbles_defaults();
    $styles = array_keys(message_bubbles_styles());
    $tails = array_keys(message_bubbles_tails());
    $densities = array_keys(message_bubbles_densities());
    $identity_modes = array_keys(message_bubbles_identity_modes());
    $conversation_modes = array_keys(message_bubbles_conversation_modes());
    $meta_layouts = array_keys(message_bubbles_meta_layouts());
    $quote_styles = array_keys(message_bubbles_quote_styles());
    $line_styles = ['curve', 'straight', 'dot'];

    $style = (string)($_POST['style'] ?? $d['style']);
    $tail = (string)($_POST['tail'] ?? $d['tail']);
    $density = (string)($_POST['density'] ?? $d['density']);
    $topic_style = (string)($_POST['topic_style'] ?? $d['topic_style']);
    $identity_mode = (string)($_POST['identity_mode'] ?? $d['identity_mode']);
    $conversation_mode = (string)($_POST['conversation_mode'] ?? $d['conversation_mode']);
    $meta_layout = (string)($_POST['meta_layout'] ?? $d['meta_layout']);
    $quote_style = (string)($_POST['quote_style'] ?? $d['quote_style']);
    $line_style = (string)($_POST['conversation_line_style'] ?? $d['conversation_line_style']);

    if (!in_array($style, $styles, true)) $style = $d['style'];
    if (!in_array($tail, $tails, true)) $tail = $d['tail'];
    if (!in_array($density, $densities, true)) $density = $d['density'];
    if (!in_array($topic_style, $styles, true)) $topic_style = $d['topic_style'];
    if (!in_array($identity_mode, $identity_modes, true)) $identity_mode = $d['identity_mode'];
    if (!in_array($conversation_mode, $conversation_modes, true)) $conversation_mode = $d['conversation_mode'];
    if (!in_array($meta_layout, $meta_layouts, true)) $meta_layout = $d['meta_layout'];
    if (!in_array($quote_style, $quote_styles, true)) $quote_style = $d['quote_style'];
    if (!in_array($line_style, ['curve', 'straight', 'dot'], true)) $line_style = $d['conversation_line_style'];

    $config = [
        'enabled' => (string)($_POST['enabled'] ?? '') === '1' ? 1 : 0,
        'style' => $style,
        'tail' => $tail,
        'radius' => min(32, max(0, (int)($_POST['radius'] ?? $d['radius']))),
        'width' => min(100, max(55, (int)($_POST['width'] ?? $d['width']))),
        'mobile_width' => min(100, max(70, (int)($_POST['mobile_width'] ?? $d['mobile_width']))),
        'shadow' => (string)($_POST['shadow'] ?? '') === '1' ? 1 : 0,
        'border' => (string)($_POST['border'] ?? '') === '1' ? 1 : 0,
        'density' => $density,
        'hover_lift' => (string)($_POST['hover_lift'] ?? '') === '1' ? 1 : 0,
        'avatar_ring' => (string)($_POST['avatar_ring'] ?? '') === '1' ? 1 : 0,
        'meta_layout' => $meta_layout,
        'topic_enabled' => (string)($_POST['topic_enabled'] ?? '') === '1' ? 1 : 0,
        'topic_style' => $topic_style,
        'show_owner_badge' => (string)($_POST['show_owner_badge'] ?? '') === '1' ? 1 : 0,
        'owner_badge_text' => cut(trim((string)($_POST['owner_badge_text'] ?? $d['owner_badge_text'])), 20),
        'quote_bubble' => (string)($_POST['quote_bubble'] ?? '') === '1' ? 1 : 0,
        'quote_depth' => min(5, max(1, (int)($_POST['quote_depth'] ?? $d['quote_depth']))),
        'quote_style' => $quote_style,
        'quote_collapse' => (string)($_POST['quote_collapse'] ?? '') === '1' ? 1 : 0,
        'quote_collapse_lines' => min(30, max(3, (int)($_POST['quote_collapse_lines'] ?? $d['quote_collapse_lines']))),
        'reply_reference' => (string)($_POST['reply_reference'] ?? '') === '1' ? 1 : 0,
        'reply_reference_link' => (string)($_POST['reply_reference_link'] ?? '') === '1' ? 1 : 0,
        'identity_colors' => (string)($_POST['identity_colors'] ?? '') === '1' ? 1 : 0,
        'identity_mode' => $identity_mode,
        'conversation_line' => (string)($_POST['conversation_line'] ?? '') === '1' ? 1 : 0,
        'conversation_mode' => $conversation_mode,
        'conversation_line_style' => $line_style,
        'merge_bubbles' => (string)($_POST['merge_bubbles'] ?? '') === '1' ? 1 : 0,
        'merge_window' => min(120, max(1, (int)($_POST['merge_window'] ?? $d['merge_window']))),
        'animation' => (string)($_POST['animation'] ?? '') === '1' ? 1 : 0,
        'user_customization' => (string)($_POST['user_customization'] ?? '') === '1' ? 1 : 0,
        'user_custom_style' => (string)($_POST['user_custom_style'] ?? '') === '1' ? 1 : 0,
        'user_custom_tail' => (string)($_POST['user_custom_tail'] ?? '') === '1' ? 1 : 0,
        'user_custom_colors' => (string)($_POST['user_custom_colors'] ?? '') === '1' ? 1 : 0,
        'user_custom_density' => (string)($_POST['user_custom_density'] ?? '') === '1' ? 1 : 0,
        'image_follow_radius' => (string)($_POST['image_follow_radius'] ?? '') === '1' ? 1 : 0,
        'code_breakout' => (string)($_POST['code_breakout'] ?? '') === '1' ? 1 : 0,
        'code_max_height' => min(1200, max(120, (int)($_POST['code_max_height'] ?? $d['code_max_height']))),
        'long_content_wrap' => (string)($_POST['long_content_wrap'] ?? '') === '1' ? 1 : 0,
        'bubble_bg' => message_bubbles_hex((string)($_POST['bubble_bg'] ?? ''), $d['bubble_bg']),
        'bubble_border' => message_bubbles_hex((string)($_POST['bubble_border'] ?? ''), $d['bubble_border']),
        'bubble_text' => message_bubbles_hex((string)($_POST['bubble_text'] ?? ''), $d['bubble_text']),
        'bubble_accent' => message_bubbles_hex((string)($_POST['bubble_accent'] ?? ''), $d['bubble_accent']),
        'quote_bg' => message_bubbles_hex((string)($_POST['quote_bg'] ?? ''), $d['quote_bg']),
        'quote_border' => message_bubbles_hex((string)($_POST['quote_border'] ?? ''), $d['quote_border']),
        'bg_opacity' => min(100, max(20, (int)($_POST['bg_opacity'] ?? $d['bg_opacity']))),
        'accent_2' => message_bubbles_hex((string)($_POST['accent_2'] ?? ''), $d['accent_2']),
    ];

    plugin_save_config('message_bubbles', $config);
    // 管理员保存的是站点默认值与权限，不改写任何用户自己的设置。
    // 请求级用户映射只在当前请求存在时失效，跨请求数据仍保留在 app_settings。
    $GLOBALS['message_bubbles_user_map'] = null;
    set_flash('回复气泡 2.4.7 设置已保存');
    go(admin_url(['tab' => 'message_bubbles']));
}

function message_bubbles_save_user(): void
{
    need_login();
    require_post();
    $config = message_bubbles_config();
    if (!$config['user_customization']) {
        set_flash('站长暂未开放个人气泡设置');
        go(route_url('message_bubbles_settings'));
    }

    $styles = array_keys(message_bubbles_styles());
    $tails = array_keys(message_bubbles_tails());
    $densities = array_keys(message_bubbles_densities());
    $d = message_bubbles_user_defaults();
    $style = (string)($_POST['style'] ?? 'inherit');
    $tail = (string)($_POST['tail'] ?? 'inherit');
    $density = (string)($_POST['density'] ?? 'inherit');
    if ($style !== 'inherit' && !in_array($style, $styles, true)) $style = 'inherit';
    if ($tail !== 'inherit' && !in_array($tail, $tails, true)) $tail = 'inherit';
    if ($density !== 'inherit' && !in_array($density, $densities, true)) $density = 'inherit';

    $personal_enabled = (string)($_POST['enabled'] ?? '') === '1';
    $prefs = [
        // 关闭个人气泡 = 完全回到管理员默认；开启后才启用本人的覆盖层。
        'mode' => $personal_enabled ? 'custom' : 'inherit',
        'enabled' => $personal_enabled ? 1 : 0,
        'style' => $config['user_custom_style'] ? $style : 'inherit',
        'tail' => $config['user_custom_tail'] ? $tail : 'inherit',
        'density' => $config['user_custom_density'] ? $density : 'inherit',
        'custom_colors' => ($config['user_custom_colors'] && (string)($_POST['custom_colors'] ?? '') === '1') ? 1 : 0,
        'radius' => min(32, max(0, (int)($_POST['radius'] ?? $d['radius']))),
        'bubble_bg' => message_bubbles_hex((string)($_POST['bubble_bg'] ?? ''), $d['bubble_bg']),
        'bubble_border' => message_bubbles_hex((string)($_POST['bubble_border'] ?? ''), $d['bubble_border']),
        'bubble_text' => message_bubbles_hex((string)($_POST['bubble_text'] ?? ''), $d['bubble_text']),
        'bubble_accent' => message_bubbles_hex((string)($_POST['bubble_accent'] ?? ''), $d['bubble_accent']),
        'quote_bg' => message_bubbles_hex((string)($_POST['quote_bg'] ?? ''), $d['quote_bg']),
        'quote_border' => message_bubbles_hex((string)($_POST['quote_border'] ?? ''), $d['quote_border']),
        'bg_opacity' => min(100, max(20, (int)($_POST['bg_opacity'] ?? $d['bg_opacity']))),
        'initialized' => 1,
    ];

    save_settings_values([
        message_bubbles_user_key(uid()) => json_encode($prefs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
    ]);
    $GLOBALS['message_bubbles_user_map'] = null;
    set_flash('个人气泡设置已保存');
    go(route_url('message_bubbles_settings'));
}

function message_bubbles_profile_after_form(mixed $value, array $ctx): string
{
    $config = message_bubbles_config();
    if (!uid()) return is_string($value) ? $value : '';

    $html = is_string($value) ? $value : '';
    $prefs = message_bubbles_user_preferences(uid());
    $styles = ['inherit' => '跟随站点默认'] + message_bubbles_styles();
    $tails = ['inherit' => '跟随站点默认'] + message_bubbles_tails();
    $densities = ['inherit' => '跟随站点默认'] + message_bubbles_densities();

    $preview_config = $config;
    $preview_active = message_bubbles_user_has_override($prefs);
    $preview_config['style'] = $preview_active && $prefs['style'] !== 'inherit' ? $prefs['style'] : $config['style'];
    $preview_config['tail'] = $preview_active && $prefs['tail'] !== 'inherit' ? $prefs['tail'] : $config['tail'];
    $preview_config['density'] = $preview_active && $prefs['density'] !== 'inherit' ? $prefs['density'] : $config['density'];
    if ($preview_active && $prefs['custom_colors'] && $config['user_custom_colors']) {
        foreach (['bubble_bg', 'bubble_border', 'bubble_text', 'bubble_accent', 'quote_bg', 'quote_border', 'bg_opacity'] as $key) {
            $preview_config[$key] = $prefs[$key];
        }
        $preview_config['radius'] = $prefs['radius'];
    }

    $panel = '<section class="message-bubbles-profile-settings" id="message-bubbles-settings">';
    $panel .= '<div class="message-bubbles-profile-settings-head"><div><h2>回复气泡</h2><p>这里只控制你发布的“回复”，不会改变主题首帖。管理员调整默认样式不会覆盖你已经保存的个人设置；只有关闭对应权限时，该项才暂时跟随站点默认。</p></div><span class="message-bubbles-profile-version">v' . h(message_bubbles_version()) . '</span></div>';

    if (!$config['user_customization']) {
        $panel .= '<div class="message-bubbles-profile-disabled"><strong>个人气泡自定义暂未开放</strong><span>站长已安装回复气泡，但暂时没有开放用户自行修改外观。</span></div></section>';
        return $html . $panel;
    }

    if (is_post_request() && isset($_POST['message_bubbles_profile_save'])) {
        message_bubbles_save_user();
    }

    $panel .= '<form method="post" class="message-bubbles-profile-form">' . form_token() . '<input type="hidden" name="message_bubbles_profile_save" value="1">';
    $panel .= '<div class="message-bubbles-profile-grid">';
    $panel .= '<div class="message-bubbles-profile-main">';
    $panel .= message_bubbles_checkbox('启用我的个人气泡', 'enabled', $prefs['enabled'], '关闭后你的回复恢复为站点默认外观；主题首帖不受影响。');

    if ($config['user_custom_style']) $panel .= select_input('我的气泡样式', 'style', $prefs['style'], $styles);
    if ($config['user_custom_tail']) $panel .= select_input('我的气泡尾巴', 'tail', $prefs['tail'], $tails);
    if ($config['user_custom_density']) $panel .= select_input('我的回复默认密度', 'density', $prefs['density'], $densities);

    if ($config['user_custom_colors']) {
        $panel .= message_bubbles_checkbox('使用我自己的颜色', 'custom_colors', $prefs['custom_colors'], '开启后可自定义背景、边框、文字、强调色和圆角。');
        $panel .= '<div class="message-bubbles-color-grid">';
        $panel .= message_bubbles_color_input('我的气泡背景', 'bubble_bg', $prefs['bubble_bg']);
        $panel .= message_bubbles_color_input('我的边框', 'bubble_border', $prefs['bubble_border']);
        $panel .= message_bubbles_color_input('我的文字', 'bubble_text', $prefs['bubble_text']);
        $panel .= message_bubbles_color_input('我的强调色', 'bubble_accent', $prefs['bubble_accent']);
        $panel .= message_bubbles_color_input('我的引用背景', 'quote_bg', $prefs['quote_bg']);
        $panel .= message_bubbles_color_input('我的引用边框', 'quote_border', $prefs['quote_border']);
        $panel .= number_input('我的圆角', 'radius', $prefs['radius'], 0, 32, true);
        $panel .= number_input('背景不透明度', 'bg_opacity', $prefs['bg_opacity'], 20, 100, true);
        $panel .= '</div>';
    }
    $panel .= '<div class="row settings-actions"><button type="submit">保存我的气泡</button><a class="btn alt" href="#message-bubbles-preview">查看预览</a></div>';
    $panel .= '</div>';
    $panel .= '<div class="message-bubbles-profile-preview" id="message-bubbles-preview"><div class="message-bubbles-profile-preview-head"><strong>实时预览</strong><span>这里展示你自己的气泡效果</span></div>' . message_bubbles_preview('user', $preview_config) . '</div>';
    $panel .= '</div></form></section>';
    return $html . $panel;
}

function message_bubbles_user_menu_links(array $value, array $ctx): array
{
    $user = is_array($ctx['user'] ?? null) ? $ctx['user'] : [];
    $self = !empty($ctx['self']);
    if (!$self || (int)($user['id'] ?? 0) < 1) return $value;

    $config = message_bubbles_config();
    if (!$config['user_customization']) return $value;

    $value['message_bubbles'] = [
        'text' => '回复气泡',
        'url' => route_url('message_bubbles_settings'),
        'icon' => 'settings',
    ];
    return $value;
}

function message_bubbles_preview(string $style, array $config): string
{
    $style = $style === 'user' ? (string)($config['style'] ?? 'classic') : $style;
    if (!array_key_exists($style, message_bubbles_styles())) $style = 'classic';
    $tail = (string)($config['tail'] ?? 'none');
    if (!array_key_exists($tail, message_bubbles_tails())) $tail = 'none';
    $density = (string)($config['density'] ?? 'comfortable');
    if (!array_key_exists($density, message_bubbles_densities())) $density = 'comfortable';
    $classes = 'message-bubbles-preview message-bubbles-density-' . h($density) . ' message-bubbles-tail-' . h($tail);
    $bubble_classes = 'message-bubbles-preview-bubble message-bubbles-style-' . h($style);
    if (empty($config['shadow'])) $bubble_classes .= ' message-bubbles-no-shadow';
    if (empty($config['border'])) $bubble_classes .= ' message-bubbles-no-border';
    $style_attr = ' style="--message-bubbles-preview-radius:' . (int)($config['radius'] ?? 16) . 'px;--message-bubbles-preview-width:' . (int)($config['width'] ?? 92) . '%;--message-bubbles-preview-bg:' . h((string)($config['bubble_bg'] ?? '#fff')) . ';--message-bubbles-preview-border:' . h((string)($config['bubble_border'] ?? '#ddd')) . ';--message-bubbles-preview-text:' . h((string)($config['bubble_text'] ?? '#222')) . ';--message-bubbles-preview-accent:' . h((string)($config['bubble_accent'] ?? '#2ecc71')) . ';--message-bubbles-preview-accent-2:' . h((string)($config['accent_2'] ?? '#8b5cf6')) . ';--message-bubbles-preview-bg-rgba:' . h(message_bubbles_hex_rgba((string)($config['bubble_bg'] ?? '#ffffff'), (int)($config['bg_opacity'] ?? 100))) . '"';
    $tail_html = $tail !== 'none' ? '<span class="message-bubbles-preview-tail" aria-hidden="true"></span>' : '';
    return '<div class="' . $classes . '"' . $style_attr . '><div class="message-bubbles-preview-head"><span class="message-bubbles-preview-avatar">A</span><span><strong>示例用户</strong><small>刚刚</small></span></div><div class="' . $bubble_classes . '"><span class="message-bubbles-preview-label">' . h(message_bubbles_styles()[$style]) . '</span><p>这是一条气泡回复预览。长内容、引用、图片和代码都会保持在正文区域内。</p><div class="message-bubbles-preview-quote">引用：这是一段被引用的内容。</div><div class="message-bubbles-preview-meta">#12　回复</div>' . $tail_html . '</div></div>';
}

function message_bubbles_settings_page(array $plugin): void
{
    need_login();
    $config = message_bubbles_config();
    if (is_post_request() && isset($_POST['message_bubbles_profile_save'])) {
        message_bubbles_save_user();
    }

    $prefs = message_bubbles_user_preferences(uid());
    $styles = ['inherit' => '跟随站点默认'] + message_bubbles_styles();
    $tails = ['inherit' => '跟随站点默认'] + message_bubbles_tails();
    $densities = ['inherit' => '跟随站点默认'] + message_bubbles_densities();
    $preview_config = $config;
    $preview_active = message_bubbles_user_has_override($prefs);
    $preview_config['style'] = $preview_active && $prefs['style'] !== 'inherit' ? $prefs['style'] : $config['style'];
    $preview_config['tail'] = $preview_active && $prefs['tail'] !== 'inherit' ? $prefs['tail'] : $config['tail'];
    $preview_config['density'] = $preview_active && $prefs['density'] !== 'inherit' ? $prefs['density'] : $config['density'];
    if ($preview_active && $prefs['custom_colors'] && $config['user_custom_colors']) {
        foreach (['bubble_bg', 'bubble_border', 'bubble_text', 'bubble_accent', 'quote_bg', 'quote_border', 'bg_opacity'] as $key) $preview_config[$key] = $prefs[$key];
        $preview_config['radius'] = $prefs['radius'];
    }

    $html = '<div class="form-panel message-bubbles-user-panel"><div class="message-bubbles-user-head"><div><h2>回复气泡设置</h2><p>这里只影响你自己发布的回复。管理员修改站点默认样式不会覆盖你已经保存的个人设置。</p></div><span class="message-bubbles-version">v' . h(message_bubbles_version()) . '</span></div>';
    $status = message_bubbles_user_has_override($prefs) ? '当前：使用我的个人覆盖' : '当前：跟随站点默认';
    $html .= '<div class="message-bubbles-profile-status">' . h($status) . '。管理员后台设置始终是默认值，只有你自己保存的项目会覆盖你自己的回复。</div>';
    if (!$config['user_customization']) {
        $html .= '<div class="message-bubbles-profile-disabled"><strong>个人气泡自定义暂未开放</strong><span>站长已安装回复气泡，但暂时没有开放用户自行修改外观。</span></div></div>';
        page('回复气泡设置', form_shell($html, me()));
        return;
    }

    $html .= '<form method="post" class="message-bubbles-profile-form">' . form_token() . '<input type="hidden" name="message_bubbles_profile_save" value="1">';
    $html .= message_bubbles_checkbox('启用我的个人气泡', 'enabled', $prefs['enabled'], '关闭后你的回复恢复为站点默认外观。');
    if ($config['user_custom_style']) $html .= select_input('我的气泡样式', 'style', $prefs['style'], $styles);
    if ($config['user_custom_tail']) $html .= select_input('我的气泡尾巴', 'tail', $prefs['tail'], $tails);
    if ($config['user_custom_density']) $html .= select_input('我的回复默认密度', 'density', $prefs['density'], $densities);
    if ($config['user_custom_colors']) {
        $html .= message_bubbles_checkbox('使用我自己的颜色', 'custom_colors', $prefs['custom_colors'], '开启后可自定义颜色与圆角。');
        $html .= number_input('我的圆角', 'radius', $prefs['radius'], 0, 32, true);
        $html .= '<div class="message-bubbles-color-grid">';
        $html .= message_bubbles_color_input('气泡背景色', 'bubble_bg', $prefs['bubble_bg']);
        $html .= message_bubbles_color_input('边框色', 'bubble_border', $prefs['bubble_border']);
        $html .= message_bubbles_color_input('文字色', 'bubble_text', $prefs['bubble_text']);
        $html .= message_bubbles_color_input('强调色', 'bubble_accent', $prefs['bubble_accent']);
        $html .= message_bubbles_color_input('引用背景色', 'quote_bg', $prefs['quote_bg']);
        $html .= message_bubbles_color_input('引用边框色', 'quote_border', $prefs['quote_border']);
        $html .= number_input('背景不透明度', 'bg_opacity', $prefs['bg_opacity'], 20, 100, true);
        $html .= '</div>';
    }
    $html .= '<div class="row settings-actions"><button type="submit">保存我的气泡</button></div>';
    $html .= '<div class="message-bubbles-user-preview"><strong>预览</strong>' . message_bubbles_preview('user', $preview_config) . '</div></form></div>';
    page('回复气泡设置', form_shell($html, me()));
}

function message_bubbles_admin_page(array $plugin): string
{
    if (is_post_request()) message_bubbles_save_admin();
    $config = message_bubbles_config();
    $styles = message_bubbles_styles();
    $tails = message_bubbles_tails();
    $densities = message_bubbles_densities();
    $identity = message_bubbles_identity_modes();
    $conversation = message_bubbles_conversation_modes();
    $meta = message_bubbles_meta_layouts();
    $quotes = message_bubbles_quote_styles();

    $html = '<section class="admin-list-panel message-bubbles-admin-panel"><div class="admin-list-head"><div class="admin-plugin-summary"><strong>回复气泡</strong><span>把主题首帖与回复作为两个独立层级管理：主题首帖使用站长主题样式，回复可按用户偏好覆盖默认样式。</span></div><span class="message-bubbles-version">v' . h(message_bubbles_version()) . '</span></div><div class="plugin-panel-body message-bubbles-admin-body"><form method="post">' . form_token();

    $html .= '<div class="message-bubbles-setting-group"><h3>① 总体外观</h3>';
    $html .= message_bubbles_checkbox('启用回复气泡', 'enabled', $config['enabled'], '关闭后恢复论坛原有回复皮肤。');
    $html .= select_input('回复默认样式', 'style', $config['style'], $styles);
    $html .= select_input('回复默认密度', 'density', $config['density'], $densities);
    $html .= select_input('回复默认尾巴', 'tail', $config['tail'], $tails);
    $html .= number_input('圆角大小', 'radius', $config['radius'], 0, 32, true, 'px。');
    $html .= number_input('桌面端最大宽度', 'width', $config['width'], 55, 100, true, '占原正文区域百分比。');
    $html .= number_input('手机端最大宽度', 'mobile_width', $config['mobile_width'], 70, 100, true);
    $html .= message_bubbles_checkbox('显示柔和阴影', 'shadow', $config['shadow']);
    $html .= message_bubbles_checkbox('显示细边框', 'border', $config['border']);
    $html .= message_bubbles_checkbox('悬停轻微抬升', 'hover_lift', $config['hover_lift'], '只增强鼠标交互，不影响手机触摸。');
    $html .= message_bubbles_checkbox('头像使用身份环', 'avatar_ring', $config['avatar_ring'], '需要同时开启身份颜色才会有明显区分。');
    $html .= select_input('信息栏布局', 'meta_layout', $config['meta_layout'], $meta);
    $html .= '</div>';

    $html .= '<div class="message-bubbles-setting-group"><h3>② 主题首帖 / 楼主</h3>';
    $html .= message_bubbles_checkbox('主题首帖使用气泡', 'topic_enabled', $config['topic_enabled'], '默认关闭。');
    $html .= select_input('主题首帖样式', 'topic_style', $config['topic_style'], $styles);
    $html .= message_bubbles_checkbox('显示楼主标识', 'show_owner_badge', $config['show_owner_badge'], '默认关闭。仅依据当前主题的 user_id 判断。');
    $html .= input('楼主标识文字', 'owner_badge_text', $config['owner_badge_text'], '例如：楼主、OP、主题作者。');
    $html .= '</div>';

    $html .= '<div class="message-bubbles-setting-group"><h3>③ 引用系统</h3>';
    $html .= message_bubbles_checkbox('引用内容气泡化', 'quote_bubble', $config['quote_bubble'], '论坛原生“引用回复”就是 @用户名 #楼层；本插件直接接管这个原生标记，不假设存在其他引用格式。');
    $html .= message_bubbles_checkbox('识别“引用回复”标记', 'reply_reference', $config['reply_reference'], '默认开启。识别论坛原生“引用回复”产生的 @用户名 #楼层，并把它变成可点击的引用提示。');
    $html .= message_bubbles_checkbox('引用提示可跳转原楼层', 'reply_reference_link', $config['reply_reference_link'], '默认开启。目标楼层在当前页时直接定位；不在当前页时跳转到楼层地址。');
    $html .= select_input('引用样式', 'quote_style', $config['quote_style'], $quotes);
    $html .= number_input('引用最大视觉层级', 'quote_depth', $config['quote_depth'], 1, 5, true);
    $html .= message_bubbles_checkbox('长引用自动折叠', 'quote_collapse', $config['quote_collapse'], '默认关闭；由前端按实际高度判断。');
    $html .= number_input('折叠触发行数', 'quote_collapse_lines', $config['quote_collapse_lines'], 3, 30, true);
    $html .= '</div>';

    $html .= '<div class="message-bubbles-setting-group"><h3>④ 身份色 / 对话关系</h3>';
    $html .= message_bubbles_checkbox('启用身份颜色', 'identity_colors', $config['identity_colors'], '默认关闭。颜色由 user_id 稳定生成，不新增数据库字段。');
    $html .= select_input('身份色表现方式', 'identity_mode', $config['identity_mode'], $identity);
    $html .= message_bubbles_checkbox('显示回复关系连接线', 'conversation_line', $config['conversation_line'], '默认关闭。只连接论坛原生“@用户名 #楼层”引用目标，不根据相邻楼层或用户名猜测关系。');
    $html .= select_input('连接线模式', 'conversation_mode', $config['conversation_mode'], $conversation);
    $html .= select_input('连接线样式', 'conversation_line_style', $config['conversation_line_style'], ['curve' => '曲线', 'straight' => '直线', 'dot' => '点划线']);
    $html .= message_bubbles_checkbox('连续回复视觉合并', 'merge_bubbles', $config['merge_bubbles'], '默认关闭。只处理当前页面上可见的连续回复。');
    $html .= number_input('连续回复合并时间窗口', 'merge_window', $config['merge_window'], 1, 120, true, '分钟；只在同一用户连续回复时使用。');
    $html .= '</div>';

    $html .= '<div class="message-bubbles-setting-group"><h3>⑤ 用户个性化</h3>';
    $html .= message_bubbles_checkbox('允许用户自定义自己的气泡', 'user_customization', $config['user_customization'], '总开关。开启后用户才会看到个人回复气泡设置。');
    $html .= message_bubbles_checkbox('允许用户修改样式', 'user_custom_style', $config['user_custom_style']);
    $html .= message_bubbles_checkbox('允许用户修改尾巴', 'user_custom_tail', $config['user_custom_tail']);
    $html .= message_bubbles_checkbox('允许用户修改颜色和圆角', 'user_custom_colors', $config['user_custom_colors']);
    $html .= message_bubbles_checkbox('允许用户修改密度', 'user_custom_density', $config['user_custom_density']);
    $html .= '</div>';

    $html .= '<div class="message-bubbles-setting-group"><h3>⑥ 内容兼容</h3>';
    $html .= message_bubbles_checkbox('图片和媒体圆角跟随气泡', 'image_follow_radius', $config['image_follow_radius'], '默认开启。');
    $html .= message_bubbles_checkbox('代码块突破气泡左右内边距', 'code_breakout', $config['code_breakout'], '默认关闭。');
    $html .= number_input('代码块最大高度', 'code_max_height', $config['code_max_height'], 120, 1200, true, 'px，超出后内部滚动。');
    $html .= message_bubbles_checkbox('长 URL / 长文本自动换行', 'long_content_wrap', $config['long_content_wrap'], '默认开启。');
    $html .= '</div>';

    $html .= '<div class="message-bubbles-setting-group"><h3>⑦ 动效</h3>';
    $html .= message_bubbles_checkbox('启用轻微出现动画', 'animation', $config['animation'], '默认关闭；同时遵循 prefers-reduced-motion。');
    $html .= '</div>';

    $html .= '<div class="message-bubbles-setting-group"><h3>⑧ 颜色</h3><p class="message-bubbles-setting-note">颜色与风格分离，方便同一套配色套用到所有气泡风格。</p><div class="message-bubbles-color-grid">';
    $html .= message_bubbles_color_input('默认气泡背景色', 'bubble_bg', $config['bubble_bg']);
    $html .= message_bubbles_color_input('默认边框色', 'bubble_border', $config['bubble_border']);
    $html .= message_bubbles_color_input('默认文字色', 'bubble_text', $config['bubble_text']);
    $html .= message_bubbles_color_input('主强调色', 'bubble_accent', $config['bubble_accent']);
    $html .= message_bubbles_color_input('第二强调色', 'accent_2', $config['accent_2']);
    $html .= message_bubbles_color_input('引用背景色', 'quote_bg', $config['quote_bg']);
    $html .= message_bubbles_color_input('引用边框色', 'quote_border', $config['quote_border']);
    $html .= number_input('背景不透明度', 'bg_opacity', $config['bg_opacity'], 20, 100, true, '尤其影响 Glass。');
    $html .= '</div></div>';

    $html .= '<div class="message-bubbles-preview-panel"><div class="message-bubbles-preview-heading"><strong>样式实验室</strong><span>当前配置下的所有内置风格</span></div>';
    foreach ($styles as $key => $label) $html .= '<div class="message-bubbles-preview-item"><span>' . h($label) . '</span>' . message_bubbles_preview($key, $config) . '</div>';
    $html .= '</div><div class="row settings-actions"><button type="submit">保存回复气泡 v2.4.8</button></div></form></div></section>';
    return $html;
}

function message_bubbles_topic_owner_id(array $ctx): int
{
    $topic = is_array($ctx['topic'] ?? null) ? $ctx['topic'] : [];
    return (int)($topic['user_id'] ?? 0);
}

function message_bubbles_topic_replies(mixed $value, array $ctx): mixed
{
    if (!is_array($value)) return $value;
    if (!message_bubbles_config()['enabled']) return $value;

    $GLOBALS['message_bubbles_topic_owner_id'] = message_bubbles_topic_owner_id($ctx);
    $GLOBALS['message_bubbles_page_initialized'] = true;
    if (message_bubbles_config()['user_customization']) message_bubbles_user_map();
    return $value;
}

function message_bubbles_prepare_context(array $row, array $ctx): array
{
    $config = message_bubbles_config();
    $user_id = (int)($row['user_id'] ?? 0);
    $resolved = message_bubbles_resolve($config, $user_id);
    $owner_id = (int)($GLOBALS['message_bubbles_topic_owner_id'] ?? 0);
    if ($owner_id < 1) $owner_id = message_bubbles_topic_owner_id($ctx);

    $is_owner = $owner_id > 0 && $user_id === $owner_id;
    $classes = [];
    if ($is_owner && $resolved['show_owner_badge']) $classes[] = 'message-bubbles-is-owner';
    if ($resolved['identity_colors']) $classes[] = 'message-bubbles-identity-enabled';
    if ($resolved['conversation_line']) $classes[] = 'message-bubbles-conversation-enabled';
    if ($resolved['hover_lift']) $classes[] = 'message-bubbles-hover-lift';
    if ($resolved['avatar_ring']) $classes[] = 'message-bubbles-avatar-ring';
    if ($resolved['animation']) $classes[] = 'message-bubbles-animation';
    if ($resolved['image_follow_radius']) $classes[] = 'message-bubbles-image-radius';
    if ($resolved['code_breakout']) $classes[] = 'message-bubbles-code-breakout';
    if ($resolved['long_content_wrap']) $classes[] = 'message-bubbles-wrap-long';
    if ($resolved['meta_layout'] === 'inside') $classes[] = 'message-bubbles-meta-inside';
    if ($resolved['meta_layout'] === 'compact') $classes[] = 'message-bubbles-meta-compact';
    return [$resolved, $is_owner, $classes, message_bubbles_identity_color($user_id)];
}

function message_bubbles_add_root_metadata(string $html, array $row, array $classes): string
{
    $user_id = (int)($row['user_id'] ?? 0);
    $created_at = max(0, (int)($row['created_at'] ?? 0));
    $topic_id = max(0, (int)($row['topic_id'] ?? 0));
    if ($topic_id < 1) $topic_id = max(0, (int)($row['id'] ?? 0));
    $class_text = 'message-bubbles-entry ' . implode(' ', $classes);
    $pattern = '/<li\b([^>]*\bclass=(["\'])(.*?)\2[^>]*)>/i';
    $result = preg_replace_callback($pattern, static function (array $m) use ($class_text, $user_id, $created_at): string {
        $attrs = $m[1];
        $quote = $m[2];
        $existing = trim($m[3]);
        $new_class = trim($existing . ' ' . $class_text);
        $attrs = preg_replace('/\bclass=([' . preg_quote($quote, '/') . '])(.*?)\1/is', 'class=' . $quote . h($new_class) . $quote, $attrs, 1) ?? $attrs;
        $attrs .= ' data-message-bubbles-user="' . $user_id . '" data-message-bubbles-time="' . $created_at . '" data-message-bubbles-topic-id="' . $topic_id . '"';
        return '<li' . $attrs . '>';
    }, $html, 1);
    return is_string($result) ? $result : $html;
}

function message_bubbles_enhance_native_references(string $html, array $config): array
{
    if (!$config['reply_reference'] || trim($html) === '') return [$html, null];

    $reference = null;
    $pattern = '~<a\b([^>]*\bclass=("|\')([^"\']*\bpost-floor-mention\b[^"\']*)\2[^>]*)>(.*?)</a>~isu';
    $result = preg_replace_callback($pattern, static function (array $m) use (&$reference, $config): string {
        $attrs = (string)$m[1];
        $inner = (string)$m[4];
        $text = trim(preg_replace('/\s+/u', ' ', strip_tags($inner)) ?? '');
        if (preg_match('/^@([^\s@#<]{1,64})\s+#(\d+)$/u', $text, $match) !== 1) return $m[0];

        $username = trim((string)$match[1]);
        $floor = (int)$match[2];
        if ($username === '' || $floor < 1) return $m[0];
        if ($reference === null) $reference = ['username' => $username, 'floor' => $floor];

        $class_name = 'message-bubbles-reference-link';
        if (preg_match('/\bclass=("|\')(.*?)\1/is', $attrs, $class_match)) {
            $existing = trim((string)$class_match[2]);
            if (!preg_match('/(?:^|\s)' . preg_quote($class_name, '/') . '(?:\s|$)/', $existing)) {
                $new_class = trim($existing . ' ' . $class_name);
                $attrs = preg_replace('/\bclass=("|\')(.*?)\1/is', 'class=' . $class_match[1] . h($new_class) . $class_match[1], $attrs, 1) ?? $attrs;
            }
        }
        if (!str_contains($attrs, 'data-message-bubbles-reference-floor=')) {
            $attrs .= ' data-message-bubbles-reference-floor="' . $floor . '"';
            $attrs .= ' data-message-bubbles-reference-user="' . h($username) . '"';
            $attrs .= ' data-message-bubbles-reference-link="' . ($config['reply_reference_link'] ? '1' : '0') . '"';
        }
        return '<a' . $attrs . '>' . $inner . '</a>';
    }, $html, 1);

    return [is_string($result) ? $result : $html, $reference];
}

function message_bubbles_add_reply_reference_metadata(string $html, ?array $reference, array $config): string
{
    if (!$config['reply_reference'] || !is_array($reference)) return $html;
    $floor = (int)($reference['floor'] ?? 0);
    $username = trim((string)($reference['username'] ?? ''));
    if ($floor < 1 || $username === '') return $html;
    $attrs = ' data-message-bubbles-reference-floor="' . $floor . '" data-message-bubbles-reference-user="' . h($username) . '" data-message-bubbles-reference-link="' . ($config['reply_reference_link'] ? '1' : '0') . '"';
    $result = preg_replace('/(<li\b[^>]*)(>)/i', '$1' . $attrs . '$2', $html, 1);
    return is_string($result) ? $result : $html;
}

function message_bubbles_page_before_render(mixed $value, array $ctx): mixed
{
    if (!is_string($value) || trim($value) === '') return $value;
    $config = message_bubbles_config();
    if (!$config['enabled'] && !str_contains($value, 'message-bubbles-user-panel') && !str_contains($value, 'message-bubbles-admin-panel')) return $value;
    if (str_contains($value, 'message-bubbles-page-root')) return $value;
    return '<div class="message-bubbles-page-root" data-message-bubbles-version="' . h(message_bubbles_version()) . '">' . $value . '</div>';
}

function message_bubbles_wrap_content(string $html, array $config, bool $is_topic, int $user_id, bool $is_owner, array $classes): string
{
    if (!$config['enabled']) return $html;
    if ($is_topic && !$config['topic_enabled']) return $html;
    if (str_contains($html, 'message-bubbles-content')) return $html;

    $style = (string)$config['style'];
    if (!array_key_exists($style, message_bubbles_styles())) $style = 'classic';
    $tail = (string)$config['tail'];
    if (!array_key_exists($tail, message_bubbles_tails())) $tail = 'none';

    $classes[] = 'message-bubbles-content-host';
    $content_classes = 'post-content message-bubbles-content message-bubbles-style-' . h($style) . ' message-bubbles-tail-' . h($tail) . ' message-bubbles-density-' . h((string)$config['density']);
    if (!$config['shadow']) $content_classes .= ' message-bubbles-no-shadow';
    if (!$config['border']) $content_classes .= ' message-bubbles-no-border';
    if ($config['identity_colors']) $content_classes .= ' message-bubbles-identity-enabled message-bubbles-identity-mode-' . h((string)$config['identity_mode']);
    if ($config['conversation_line']) $content_classes .= ' message-bubbles-conversation-enabled';
    if ($config['merge_bubbles']) $content_classes .= ' message-bubbles-merge-enabled';
    foreach ($classes as $class) $content_classes .= ' ' . h($class);

    $style_attr = ' style="--message-bubbles-radius:' . (int)$config['radius'] . 'px;--message-bubbles-width:' . (int)$config['width'] . '%;--message-bubbles-mobile-width:' . (int)$config['mobile_width'] . '%;--message-bubbles-bg:' . h($config['bubble_bg']) . ';--message-bubbles-bg-rgba:' . h(message_bubbles_hex_rgba($config['bubble_bg'], (int)$config['bg_opacity'])) . ';--message-bubbles-border:' . h($config['bubble_border']) . ';--message-bubbles-text:' . h($config['bubble_text']) . ';--message-bubbles-accent:' . h($config['bubble_accent']) . ';--message-bubbles-accent-2:' . h($config['accent_2']) . ';--message-bubbles-quote-bg:' . h($config['quote_bg']) . ';--message-bubbles-quote-border:' . h($config['quote_border']) . ';--message-bubbles-code-height:' . (int)$config['code_max_height'] . 'px;--message-bubbles-identity-color:' . h(message_bubbles_identity_color($user_id)) . '"';

    $pattern = '/<div\b([^>]*\bclass=("|\')post-content\2[^>]*)>/i';
    $result = preg_replace($pattern, '<div class="' . $content_classes . '"' . $style_attr . ' data-message-bubbles-user="' . $user_id . '" data-message-bubbles-source="' . (message_bubbles_user_has_override(message_bubbles_user_preferences($user_id)) ? 'user' : 'default') . '" data-message-bubbles-style="' . h($style) . '" data-message-bubbles-tail="' . h($tail) . '" data-message-bubbles-conversation-mode="' . h((string)$config['conversation_mode']) . '" data-message-bubbles-line-style="' . h((string)$config['conversation_line_style']) . '" data-message-bubbles-merge-window="' . (int)$config['merge_window'] . '" data-message-bubbles-quote-lines="' . ($config['quote_collapse'] ? (int)$config['quote_collapse_lines'] : 0) . '">', $html, 1);
    if (!is_string($result)) return $html;

    if ($is_owner && $config['show_owner_badge']) {
        $badge = '<span class="message-bubbles-owner-badge" aria-label="' . h($config['owner_badge_text']) . '">' . h($config['owner_badge_text']) . '</span>';
        $result = preg_replace('/(<a\b[^>]*\bclass=("|\')[^"\']*\bpost-author\b[^"\']*\2[^>]*>.*?<\/a>)/is', '$1' . $badge, $result, 1) ?: $result;
    }
    if ($config['identity_colors'] && $config['identity_mode'] === 'dot') {
        $result = preg_replace('/(<a\b[^>]*\bclass=("|\')[^"\']*\bpost-author\b[^"\']*\2[^>]*>)/is', '$1<span class="message-bubbles-identity-dot" aria-hidden="true"></span>', $result, 1) ?: $result;
    }
    return $result;
}

function message_bubbles_add_quotes(string $html, array $config): string
{
    if (!$config['quote_bubble']) return $html;
    $max_depth = min(5, max(1, (int)$config['quote_depth']));
    $style = (string)$config['quote_style'];
    if (!array_key_exists($style, message_bubbles_quote_styles())) $style = 'compact';

    $parts = preg_split('/(<\/?blockquote\b[^>]*>)/i', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    if (!is_array($parts) || count($parts) < 2) return $html;
    $depth = 0;
    foreach ($parts as $i => $part) {
        if (preg_match('/^<blockquote\b/i', $part)) {
            $current = $depth + 1;
            if ($current <= $max_depth && !str_contains($part, 'message-bubbles-quote')) {
                $attrs = preg_replace('/^<blockquote\b/i', '<blockquote', $part, 1) ?? $part;
                if (preg_match('/\bclass\s*=\s*(["\'])(.*?)\1/is', $attrs, $match)) {
                    $existing = trim((string)$match[2]);
                    $new_class = trim($existing . ' message-bubbles-quote message-bubbles-quote-style-' . $style);
                    $attrs = preg_replace('/\bclass\s*=\s*(["\'])(.*?)\1/is', 'class=' . $match[1] . h($new_class) . $match[1], $attrs, 1) ?? $attrs;
                } else {
                    $attrs = rtrim(substr($attrs, 0, -1)) . ' class="message-bubbles-quote message-bubbles-quote-style-' . h($style) . '">';
                }
                $parts[$i] = $attrs;
            }
            $depth++;
        } elseif (preg_match('/^<\/blockquote\s*>/i', $part)) {
            $depth = max(0, $depth - 1);
        }
    }
    return implode('', $parts);
}

function message_bubbles_apply_meta_layout(string $html, array $config): string
{
    $layout = (string)($config['meta_layout'] ?? 'outside');
    if ($layout !== 'inside') return $html;
    if (!preg_match("~<div\\b[^>]*class=(\"|')[^\"']*\\bpost-meta\\b[^\"']*\\1[^>]*>.*?<\\/div>~is", $html, $match)) return $html;
    $meta = $match[0];
    $without_meta = preg_replace("~<div\\b[^>]*class=(\"|')[^\"']*\\bpost-meta\\b[^\"']*\\1[^>]*>.*?<\\/div>~is", '', $html, 1);
    if (!is_string($without_meta)) return $html;
    $result = preg_replace("~(<div\\b[^>]*class=(\"|')[^\"']*\\bmessage-bubbles-content\\b[^\"']*\\2[^>]*>)(.*?)(<\\/div>)(<\\/li>)~is", '$1$3' . $meta . '$4$5', $without_meta, 1);
    return is_string($result) ? $result : $html;
}

function message_bubbles_reply_after_render(mixed $value, array $ctx): ?string
{
    if (!is_string($value)) return null;
    $config = message_bubbles_config();
    if (!$config['enabled']) return $value;

    // 用户个性化只作用于“回复”，不污染主题首帖。
    $row = is_array($ctx['row'] ?? null) ? $ctx['row'] : [];
    [$resolved, $is_owner, $classes] = message_bubbles_prepare_context($row, $ctx);
    $classes[] = 'message-bubbles-reply';

    $result = message_bubbles_wrap_content(
        $value,
        $resolved,
        false,
        (int)($row['user_id'] ?? 0),
        $is_owner,
        $classes
    );

    // 引用气泡属于回复正文的一部分；以前这里只识别了引用链接，
    // 没有执行 add_quotes，导致“主题引用正常、回复引用不正常”。
    $result = message_bubbles_apply_meta_layout($result, $resolved);
    $result = message_bubbles_add_quotes($result, $resolved);
    [$result, $reference] = message_bubbles_enhance_native_references($result, $resolved);
    $result = message_bubbles_add_root_metadata($result, $row, $classes);
    $result = message_bubbles_add_reply_reference_metadata($result, $reference, $resolved);
    return $result;
}

function message_bubbles_topic_after_render(mixed $value, array $ctx): ?string
{
    if (!is_string($value)) return null;
    if (!empty($ctx['list'])) return $value;

    $config = message_bubbles_config();
    if (!$config['enabled'] || !$config['topic_enabled']) return $value;

    $row = is_array($ctx['row'] ?? null) ? $ctx['row'] : [];

    // 主题首帖使用站长定义的“主题样式”，完全独立于发帖人的个人气泡。
    // 这样楼主自己的回复偏好不会意外改掉主题首帖。
    $topic_config = $config;
    $topic_config['style'] = $config['topic_style'];
    $topic_config['tail'] = $config['tail'];
    $topic_config['density'] = $config['density'];

    $owner_id = message_bubbles_topic_owner_id($ctx);
    $user_id = (int)($row['user_id'] ?? 0);
    $is_owner = $owner_id > 0 && $user_id === $owner_id;
    $classes = ['message-bubbles-topic'];
    if ($is_owner && $topic_config['show_owner_badge']) $classes[] = 'message-bubbles-is-owner';
    if ($topic_config['identity_colors']) $classes[] = 'message-bubbles-identity-enabled';
    if ($topic_config['hover_lift']) $classes[] = 'message-bubbles-hover-lift';
    if ($topic_config['avatar_ring']) $classes[] = 'message-bubbles-avatar-ring';
    if ($topic_config['animation']) $classes[] = 'message-bubbles-animation';
    if ($topic_config['image_follow_radius']) $classes[] = 'message-bubbles-image-radius';
    if ($topic_config['code_breakout']) $classes[] = 'message-bubbles-code-breakout';
    if ($topic_config['long_content_wrap']) $classes[] = 'message-bubbles-wrap-long';
    if ($topic_config['meta_layout'] === 'inside') $classes[] = 'message-bubbles-meta-inside';
    if ($topic_config['meta_layout'] === 'compact') $classes[] = 'message-bubbles-meta-compact';

    $result = message_bubbles_wrap_content(
        $value,
        $topic_config,
        true,
        $user_id,
        $is_owner,
        $classes
    );
    $result = message_bubbles_apply_meta_layout($result, $topic_config);
    $result = message_bubbles_add_quotes($result, $topic_config);
    return message_bubbles_add_root_metadata($result, $row, $classes);
}

function message_bubbles_js(): string
{
    return <<<'JS'
(function () {
    'use strict';

    function message_bubbles_root() {
        return document.querySelector('.message-bubbles-page-root');
    }

    function message_bubbles_entries(root) {
        if (!root) return [];
        return Array.from(root.querySelectorAll('.message-bubbles-entry'));
    }

    function message_bubbles_find_reference_target(root, entry) {
        const floor = entry.getAttribute('data-message-bubbles-reference-floor') || '';
        if (!/^\d+$/.test(floor) || Number(floor) < 1) return null;
        return root.querySelector('.message-bubbles-entry[data-floor="' + floor + '"]');
    }

    function message_bubbles_mark_groups(root) {
        const entries = message_bubbles_entries(root);
        entries.forEach(function (entry) {
            entry.classList.remove('message-bubbles-group-first', 'message-bubbles-group-middle', 'message-bubbles-group-last', 'message-bubbles-group-single');
        });
        entries.forEach(function (entry, index) {
            const host = entry.querySelector('.message-bubbles-content');
            if (!host) return;
            // 主题首帖是独立视觉单元，绝不能和第一条回复合并。
            if (entry.classList.contains('message-bubbles-topic')) return;
            const merge = entry.classList.contains('message-bubbles-merge-enabled') || host.classList.contains('message-bubbles-merge-enabled');
            if (!merge) return;
            const previous = entries[index - 1];
            const next = entries[index + 1];
            const user = entry.getAttribute('data-message-bubbles-user') || '';
            const time = Number(entry.getAttribute('data-message-bubbles-time') || 0);
            const windowSeconds = Number(host.getAttribute('data-message-bubbles-merge-window') || 10) * 60;
            const same = function (other) {
                if (!other || !time) return false;
                return other.getAttribute('data-message-bubbles-user') === user && Math.abs(Number(other.getAttribute('data-message-bubbles-time') || 0) - time) <= windowSeconds;
            };
            const prev = same(previous);
            const nextMatch = same(next);
            if (prev && nextMatch) entry.classList.add('message-bubbles-group-middle');
            else if (prev) entry.classList.add('message-bubbles-group-last');
            else if (nextMatch) entry.classList.add('message-bubbles-group-first');
            else entry.classList.add('message-bubbles-group-single');
        });
    }

    function message_bubbles_prepare_reference_markers(root) {
        message_bubbles_entries(root).forEach(function (entry) {
            const ref = entry.querySelector('.message-bubbles-reference-link');
            if (!ref) return;
            const floor = entry.getAttribute('data-message-bubbles-reference-floor') || ref.getAttribute('data-message-bubbles-reference-floor') || '';
            if (!/^\d+$/.test(floor) || Number(floor) < 1) return;
            const target = message_bubbles_find_reference_target(root, entry);
            const linkEnabled = entry.getAttribute('data-message-bubbles-reference-link') !== '0';
            ref.classList.toggle('is-clickable', !!target && linkEnabled);
            ref.setAttribute('aria-label', '引用 ' + ref.textContent.trim());
            if (target && linkEnabled) {
                ref.title = '查看 #' + floor;
                if (ref.dataset.messageBubblesBound !== '1') {
                    ref.dataset.messageBubblesBound = '1';
                    ref.addEventListener('click', function (event) {
                        event.preventDefault();
                        target.classList.add('message-bubbles-reference-target');
                        target.scrollIntoView({behavior: 'smooth', block: 'center'});
                        window.setTimeout(function () { target.classList.remove('message-bubbles-reference-target'); }, 1200);
                    });
                }
            } else {
                ref.title = '引用 #' + floor;
            }
        });
    }

    function message_bubbles_draw_relations(root) {
        if (!root) return;
        const entries = message_bubbles_entries(root);
        const enabled = entries.some(function (entry) { return entry.classList.contains('message-bubbles-conversation-enabled'); });
        let svg = root.querySelector('.message-bubbles-relation-svg');
        if (!enabled) {
            if (svg) svg.remove();
            return;
        }
        if (!svg) {
            svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.classList.add('message-bubbles-relation-svg');
            svg.setAttribute('aria-hidden', 'true');
            root.insertBefore(svg, root.firstChild);
        }
        while (svg.firstChild) svg.removeChild(svg.firstChild);
        const rootRect = root.getBoundingClientRect();
        svg.setAttribute('width', String(Math.max(root.scrollWidth, root.clientWidth)));
        svg.setAttribute('height', String(Math.max(root.scrollHeight, root.clientHeight)));
        entries.forEach(function (entry) {
            if (!entry.classList.contains('message-bubbles-conversation-enabled')) return;
            const host = entry.querySelector('.message-bubbles-content');
            const target = message_bubbles_find_reference_target(root, entry);
            if (!host || !target || target === entry) return;
            const targetHost = target.querySelector('.message-bubbles-content');
            if (!targetHost) return;
            const a = targetHost.getBoundingClientRect();
            const b = host.getBoundingClientRect();
            const ax = a.left - rootRect.left;
            const ay = a.top - rootRect.top + a.height / 2;
            const bx = b.left - rootRect.left;
            const by = b.top - rootRect.top + Math.min(28, b.height / 2);
            const gutter = Math.max(8, Math.min(ax, bx) - 14);
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            path.classList.add('message-bubbles-relation-path');
            const style = host.getAttribute('data-message-bubbles-line-style') || 'curve';
            let d = 'M ' + ax + ' ' + ay + ' C ' + gutter + ' ' + ay + ', ' + gutter + ' ' + by + ', ' + bx + ' ' + by;
            if (style === 'straight') d = 'M ' + ax + ' ' + ay + ' L ' + gutter + ' ' + ay + ' L ' + gutter + ' ' + by + ' L ' + bx + ' ' + by;
            if (style === 'dot') path.classList.add('is-dashed');
            path.setAttribute('d', d);
            svg.appendChild(path);
            const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            dot.classList.add('message-bubbles-relation-dot');
            dot.setAttribute('cx', String(bx));
            dot.setAttribute('cy', String(by));
            dot.setAttribute('r', '2.5');
            svg.appendChild(dot);
        });
    }

    function message_bubbles_prepare_quotes(root) {
        root.querySelectorAll('.message-bubbles-content .message-bubbles-quote').forEach(function (quote) {
            if (quote.dataset.messageBubblesPrepared === '1') return;
            quote.dataset.messageBubblesPrepared = '1';
            const host = quote.closest('.message-bubbles-content');
            if (!host) return;
            const maxLines = Number(host.getAttribute('data-message-bubbles-quote-lines') || 0);
            if (!maxLines) return;
            const computed = window.getComputedStyle(quote);
            const lineHeight = parseFloat(computed.lineHeight);
            if (!lineHeight || quote.scrollHeight <= lineHeight * maxLines + 4) return;
            const body = document.createElement('div');
            body.className = 'message-bubbles-quote-body';
            while (quote.firstChild) body.appendChild(quote.firstChild);
            quote.appendChild(body);
            quote.classList.add('message-bubbles-quote-collapsible');
            quote.setAttribute('data-message-bubbles-expanded', '0');
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'message-bubbles-quote-toggle';
            button.setAttribute('aria-expanded', 'false');
            button.textContent = '展开引用';
            button.addEventListener('click', function () {
                const expanded = quote.getAttribute('data-message-bubbles-expanded') === '1';
                quote.setAttribute('data-message-bubbles-expanded', expanded ? '0' : '1');
                button.setAttribute('aria-expanded', expanded ? 'false' : 'true');
                button.textContent = expanded ? '展开引用' : '收起引用';
            });
            quote.appendChild(button);
        });
    }

    function message_bubbles_init() {
        const root = message_bubbles_root();
        if (!root) return;
        message_bubbles_mark_groups(root);
        message_bubbles_prepare_reference_markers(root);
        message_bubbles_prepare_quotes(root);
        message_bubbles_draw_relations(root);
        window.addEventListener('resize', function () { message_bubbles_draw_relations(root); });
        window.addEventListener('load', function () { message_bubbles_draw_relations(root); }, {once: true});
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', message_bubbles_init, {once: true});
    else message_bubbles_init();
}());
JS;
}

function message_bubbles_css(): string
{
    return <<<'CSS'
.message-bubbles-page-root{position:relative;min-width:0;}
.message-bubbles-page-root .message-bubbles-relation-svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none;z-index:0;}
.message-bubbles-page-root .message-bubbles-relation-path{fill:none;stroke:var(--message-bubbles-accent);stroke-width:1.5;stroke-linecap:round;opacity:.55;}
.message-bubbles-page-root .message-bubbles-relation-path.is-dashed{stroke-dasharray:4 4;}
.message-bubbles-page-root .message-bubbles-relation-dot{fill:var(--message-bubbles-accent);opacity:.7;}
.message-bubbles-page-root .message-bubbles-entry{position:relative;z-index:1;}
.message-bubbles-entry .message-bubbles-content{box-sizing:border-box;min-width:0;max-width:var(--message-bubbles-width);width:fit-content;justify-self:start;position:relative;margin-top:2px;padding:13px 15px;border:1px solid var(--message-bubbles-border);border-radius:var(--message-bubbles-radius);background:var(--message-bubbles-bg-rgba);color:var(--message-bubbles-text);overflow-wrap:anywhere;word-break:break-word;line-height:1.65;transition:transform .16s ease,box-shadow .16s ease,border-color .16s ease}.message-bubbles-entry .message-bubbles-content.message-bubbles-tail-bottom-left::after,.message-bubbles-entry .message-bubbles-content.message-bubbles-tail-bottom-right::after,.message-bubbles-entry .message-bubbles-content.message-bubbles-tail-top-left::after,.message-bubbles-entry .message-bubbles-content.message-bubbles-tail-top-right::after{content:"";position:absolute;width:10px;height:10px;background:var(--message-bubbles-bg-rgba);border:1px solid var(--message-bubbles-border);transform:rotate(45deg);z-index:0}
.message-bubbles-entry .message-bubbles-content.message-bubbles-tail-bottom-left::after{left:14px;bottom:-6px;border-left:0;border-top:0}
.message-bubbles-entry .message-bubbles-content.message-bubbles-tail-bottom-right::after{right:14px;bottom:-6px;border-left:0;border-top:0}
.message-bubbles-entry .message-bubbles-content.message-bubbles-tail-top-left::after{left:14px;top:-6px;border-right:0;border-bottom:0}
.message-bubbles-entry .message-bubbles-content.message-bubbles-tail-top-right::after{right:14px;top:-6px;border-right:0;border-bottom:0}

.message-bubbles-entry .message-bubbles-content.message-bubbles-no-border{border-color:transparent}
.message-bubbles-entry .message-bubbles-content.message-bubbles-no-shadow{box-shadow:none}
.message-bubbles-entry .message-bubbles-content:not(.message-bubbles-no-shadow){box-shadow:0 2px 8px var(--shadow-base)}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-classic{background:var(--message-bubbles-bg-rgba)}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-modern{background:linear-gradient(135deg,var(--message-bubbles-bg-rgba),color-mix(in srgb,var(--message-bubbles-bg-rgba) 82%,var(--message-bubbles-accent) 12%,var(--message-bubbles-accent-2) 6%))}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-chat{padding:11px 15px;border-radius:20px}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-card{padding:15px 16px;border-radius:12px;width:100%}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-minimal{padding:10px 12px;background:transparent;box-shadow:none}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-accent{padding-left:14px;border-left:4px solid var(--message-bubbles-accent);border-radius:8px}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-glass{background:var(--message-bubbles-bg-rgba);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-soft{border-color:transparent;background:color-mix(in srgb,var(--message-bubbles-bg-rgba) 90%,var(--message-bubbles-accent) 10%);box-shadow:none}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-outline{background:transparent;border-color:var(--message-bubbles-accent);box-shadow:none}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-pill{border-radius:999px}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-paper{box-shadow:1px 3px 0 color-mix(in srgb,var(--message-bubbles-accent) 12%,transparent),0 3px 10px var(--shadow-base)}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-terminal{border-radius:9px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono",monospace}
.message-bubbles-entry.message-bubbles-hover-lift .message-bubbles-content:hover{transform:translateY(-1px);box-shadow:0 5px 14px var(--shadow-base)}
.message-bubbles-entry .message-bubbles-content.message-bubbles-density-compact{padding-top:9px;padding-bottom:9px}
.message-bubbles-entry .message-bubbles-content.message-bubbles-density-spacious{padding-top:17px;padding-bottom:17px}
.message-bubbles-entry.message-bubbles-group-first .message-bubbles-content{border-bottom-left-radius:max(7px,calc(var(--message-bubbles-radius) - 7px));border-bottom-right-radius:max(7px,calc(var(--message-bubbles-radius) - 7px));margin-bottom:1px}
.message-bubbles-entry.message-bubbles-group-middle .message-bubbles-content{border-radius:8px;margin-top:1px;margin-bottom:1px}
.message-bubbles-entry.message-bubbles-group-last .message-bubbles-content{border-top-left-radius:max(7px,calc(var(--message-bubbles-radius) - 7px));border-top-right-radius:max(7px,calc(var(--message-bubbles-radius) - 7px));margin-top:1px}
.message-bubbles-entry{position:relative}
.message-bubbles-entry.message-bubbles-line-after::after{content:"";position:absolute;left:15px;bottom:-12px;width:1px;height:12px;background:var(--line-soft);pointer-events:none}
.message-bubbles-entry.message-bubbles-line-before::before{content:"";position:absolute;left:15px;top:-12px;width:1px;height:12px;background:var(--line-soft);pointer-events:none}
.message-bubbles-entry .message-bubbles-content.message-bubbles-identity-enabled.message-bubbles-identity-mode-accent{border-left:3px solid var(--message-bubbles-identity-color)}
.message-bubbles-entry .message-bubbles-content.message-bubbles-identity-enabled.message-bubbles-identity-mode-border{border-color:var(--message-bubbles-identity-color)}
.message-bubbles-entry.message-bubbles-identity-enabled.message-bubbles-identity-mode-name .post-author{color:var(--message-bubbles-identity-color)}
.message-bubbles-entry .message-bubbles-identity-dot{display:inline-block;width:7px;height:7px;margin-right:5px;border-radius:50%;background:var(--message-bubbles-identity-color);vertical-align:middle}
.message-bubbles-entry.message-bubbles-avatar-ring .post-avatar{position:relative}
.message-bubbles-entry.message-bubbles-avatar-ring .post-avatar::after{content:"";position:absolute;inset:1px;border:2px solid var(--message-bubbles-identity-color,#2ecc71);border-radius:50%;pointer-events:none}
.message-bubbles-entry .message-bubbles-reference-link{display:inline-flex;align-items:center;gap:2px;margin-right:4px;padding:2px 7px;border-radius:999px;background:var(--brand-soft);color:var(--brand);font-size:var(--font-size-xs);font-weight:600;line-height:1.4;vertical-align:middle;cursor:default}
.message-bubbles-entry .message-bubbles-reference-link.is-clickable{cursor:pointer;text-decoration:none}.message-bubbles-entry .message-bubbles-reference-link.is-clickable:hover{filter:brightness(.97)}
.message-bubbles-entry.message-bubbles-reference-target .message-bubbles-content{box-shadow:0 0 0 2px color-mix(in srgb,var(--brand) 18%,transparent),0 5px 16px var(--shadow-base)}
.message-bubbles-relation-svg{position:fixed;inset:0;width:100vw;height:100vh;z-index:20;pointer-events:none;overflow:visible}
.message-bubbles-page-root .message-bubbles-relation-path{fill:none;stroke:var(--brand);stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;opacity:.42}
.message-bubbles-relation-path.is-dashed{stroke-dasharray:2 5}
.message-bubbles-page-root .message-bubbles-relation-dot{fill:var(--brand);opacity:.55}
.message-bubbles-entry .message-bubbles-owner-badge{display:inline-flex;align-items:center;margin-left:6px;padding:2px 7px;border-radius:999px;background:var(--brand-soft);color:var(--brand);font-size:var(--font-size-xs);font-weight:700;vertical-align:middle}
.message-bubbles-entry .message-bubbles-quote{box-sizing:border-box;margin:9px 0;padding:8px 10px;border:1px solid var(--message-bubbles-quote-border);border-left:3px solid var(--message-bubbles-accent);border-radius:9px;background:var(--message-bubbles-quote-bg);color:var(--message-bubbles-text);overflow-wrap:anywhere;max-width:100%;line-height:1.55}
.message-bubbles-entry .message-bubbles-quote.message-bubbles-quote-style-card{padding:10px 12px;border-radius:10px;box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--message-bubbles-quote-border) 35%,transparent)}
.message-bubbles-entry .message-bubbles-quote.message-bubbles-quote-style-line{border-top:0;border-right:0;border-bottom:0;border-radius:0;background:transparent;padding-left:12px}
.message-bubbles-entry .message-bubbles-quote-collapsible .message-bubbles-quote-body{display:block;max-height:calc(var(--message-bubbles-quote-lines) * 1.55em);overflow:hidden}
.message-bubbles-entry .message-bubbles-quote-collapsible[data-message-bubbles-expanded="1"] .message-bubbles-quote-body{max-height:none}
.message-bubbles-entry .message-bubbles-quote-toggle{display:inline-flex;align-items:center;margin-top:6px;padding:2px 7px;border:0;border-radius:999px;background:var(--brand-soft);color:var(--brand);font:inherit;font-size:var(--font-size-xs);cursor:pointer}
.message-bubbles-entry .message-bubbles-quote-toggle:focus-visible{outline:2px solid var(--focus-ring);outline-offset:2px}
.message-bubbles-entry .message-bubbles-content img,.message-bubbles-entry .message-bubbles-content video,.message-bubbles-entry .message-bubbles-content iframe{display:block;max-width:100%;height:auto}
.message-bubbles-entry.message-bubbles-image-radius .message-bubbles-content img,.message-bubbles-entry.message-bubbles-image-radius .message-bubbles-content video,.message-bubbles-entry.message-bubbles-image-radius .message-bubbles-content iframe{border-radius:max(8px,calc(var(--message-bubbles-radius) - 5px))}
.message-bubbles-entry .message-bubbles-content pre{box-sizing:border-box;max-width:100%;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;max-height:var(--message-bubbles-code-height);border-radius:9px}
.message-bubbles-entry.message-bubbles-code-breakout .message-bubbles-content pre{width:calc(100% + 24px);margin-left:-12px;margin-right:-12px}
.message-bubbles-entry.message-bubbles-wrap-long .message-bubbles-content{overflow-wrap:anywhere;word-break:break-word}
.message-bubbles-entry .message-bubbles-content table{display:block;max-width:100%;overflow:auto}
.message-bubbles-entry.message-bubbles-meta-inside .post-time,.message-bubbles-entry.message-bubbles-meta-inside .post-floor{opacity:.78}
.message-bubbles-entry.message-bubbles-meta-compact .post-time{margin-left:4px}
.message-bubbles-entry.message-bubbles-animation .message-bubbles-content{animation:message-bubbles-fade-in .18s ease-out}
@keyframes message-bubbles-fade-in{from{opacity:.72;transform:translateY(3px)}to{opacity:1;transform:none}}
.message-bubbles-admin-panel .message-bubbles-admin-body{display:block}
.message-bubbles-admin-panel .message-bubbles-setting-group{padding:16px 0;border-bottom:1px solid var(--line-soft)}
.message-bubbles-admin-panel .message-bubbles-setting-group:first-child{padding-top:0}
.message-bubbles-admin-panel .message-bubbles-setting-group h3{margin:0 0 11px;font-size:var(--font-size-lg);color:var(--text)}
.message-bubbles-setting-note{margin:0 0 10px;color:var(--text-muted);font-size:var(--font-size-sm);line-height:1.6}
.message-bubbles-color-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.message-bubbles-color-field{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:10px}
.message-bubbles-color-field>span{display:grid;gap:2px;min-width:0}
.message-bubbles-color-field small{color:var(--text-muted);font-size:var(--font-size-xs)}
.message-bubbles-color-field code{color:var(--text-muted);font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono",monospace;font-size:var(--font-size-xs)}
.message-bubbles-color-field input[type=color]{width:48px;height:32px;padding:2px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel)}
.message-bubbles-preview-panel{margin-top:18px;padding-top:18px;border-top:1px solid var(--line-soft)}
.message-bubbles-preview-heading{display:flex;justify-content:space-between;gap:12px;align-items:baseline;margin-bottom:12px}
.message-bubbles-preview-heading span{font-size:var(--font-size-sm);color:var(--text-muted)}
.message-bubbles-preview-item{padding:12px 0;border-bottom:1px solid var(--line-soft)}
.message-bubbles-preview-item>span{display:block;margin-bottom:8px;font-size:var(--font-size-sm);font-weight:600;color:var(--text-muted)}
.message-bubbles-preview{padding:13px;background:var(--bg);border:1px solid var(--line-soft);border-radius:11px;overflow:hidden}
.message-bubbles-preview-head{display:flex;align-items:center;gap:8px;margin-bottom:8px;color:var(--text)}
.message-bubbles-preview-head>span:last-child{display:flex;flex-direction:column;gap:2px}
.message-bubbles-preview-head small{font-size:var(--font-size-xs);color:var(--text-muted)}
.message-bubbles-preview-avatar{display:grid;place-items:center;width:30px;height:30px;border-radius:50%;background:var(--brand-soft);color:var(--brand);font-size:var(--font-size-sm);font-weight:700}
.message-bubbles-preview-bubble{position:relative;width:fit-content;max-width:var(--message-bubbles-preview-width);padding:11px 13px;border:1px solid var(--message-bubbles-preview-border);background:var(--message-bubbles-preview-bg-rgba);color:var(--message-bubbles-preview-text);border-radius:var(--message-bubbles-preview-radius);overflow-wrap:anywhere;box-shadow:0 2px 8px var(--shadow-base);line-height:1.6}
.message-bubbles-preview-bubble.message-bubbles-no-shadow{box-shadow:none}
.message-bubbles-preview-bubble.message-bubbles-no-border{border-color:transparent}
.message-bubbles-preview-bubble.message-bubbles-style-modern{background:linear-gradient(135deg,var(--message-bubbles-preview-bg-rgba),color-mix(in srgb,var(--message-bubbles-preview-bg-rgba) 82%,var(--message-bubbles-preview-accent) 12%,var(--message-bubbles-preview-accent-2) 6%))}
.message-bubbles-preview-bubble.message-bubbles-style-chat{border-radius:20px}
.message-bubbles-preview-bubble.message-bubbles-style-card{width:100%;border-radius:12px;padding:14px 15px}
.message-bubbles-preview-bubble.message-bubbles-style-minimal{box-shadow:none;background:transparent}
.message-bubbles-preview-bubble.message-bubbles-style-accent{border-left:4px solid var(--message-bubbles-preview-accent);border-radius:8px}
.message-bubbles-preview-bubble.message-bubbles-style-glass{backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}
.message-bubbles-preview-bubble.message-bubbles-style-soft{border-color:transparent}
.message-bubbles-preview-bubble.message-bubbles-style-outline{background:transparent;border:1.5px solid var(--message-bubbles-preview-accent);box-shadow:none}
.message-bubbles-preview-bubble.message-bubbles-style-pill{border-radius:999px}
.message-bubbles-preview-bubble.message-bubbles-style-paper{box-shadow:1px 3px 0 color-mix(in srgb,var(--message-bubbles-preview-accent) 12%,transparent),0 3px 10px var(--shadow-base)}
.message-bubbles-preview-bubble.message-bubbles-style-terminal{border-radius:9px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono",monospace}
.message-bubbles-preview-bubble p{margin:4px 0;font-size:var(--font-size-sm)}
.message-bubbles-preview-label{display:block;margin-bottom:4px;font-size:var(--font-size-xs);opacity:.72}
.message-bubbles-preview-meta{margin-top:8px;font-size:var(--font-size-xs);opacity:.68}
.message-bubbles-preview-quote{margin-top:8px;padding:6px 8px;border-left:3px solid var(--message-bubbles-preview-accent);border-radius:6px;background:color-mix(in srgb,var(--message-bubbles-preview-accent) 8%,transparent);font-size:var(--font-size-xs)}
.message-bubbles-preview-tail{position:absolute;width:8px;height:8px;background:inherit;border:inherit;transform:rotate(45deg)}
.message-bubbles-preview.message-bubbles-tail-bottom-left .message-bubbles-preview-tail{left:12px;bottom:-5px;border-left:0;border-top:0}
.message-bubbles-preview.message-bubbles-tail-top-left .message-bubbles-preview-tail{left:12px;top:-5px;border-right:0;border-bottom:0}
.message-bubbles-preview.message-bubbles-tail-bottom-right .message-bubbles-preview-tail{right:12px;bottom:-5px;border-left:0;border-top:0}
.message-bubbles-preview.message-bubbles-tail-top-right .message-bubbles-preview-tail{right:12px;top:-5px;border-right:0;border-bottom:0}
.message-bubbles-user-panel{max-width:none}
.message-bubbles-user-head{display:flex;justify-content:space-between;gap:12px;margin-bottom:14px}
.message-bubbles-user-head p{margin-top:4px;color:var(--text-muted);font-size:var(--font-size-sm)}
.message-bubbles-user-preview{margin-top:16px;padding-top:16px;border-top:1px solid var(--line-soft)}
.message-bubbles-user-preview>strong{display:block;margin-bottom:8px;font-size:var(--font-size-sm)}
.message-bubbles-version{display:inline-flex;align-items:center;white-space:nowrap;padding:4px 8px;border-radius:999px;background:var(--brand-soft);color:var(--brand);font-size:var(--font-size-xs);font-weight:700}
.message-bubbles-entry .message-bubbles-reference-link{color:var(--message-bubbles-accent);font-weight:600;text-decoration:none;border-radius:5px;transition:background-color .16s ease,box-shadow .16s ease;}
.message-bubbles-entry .message-bubbles-reference-link.is-clickable{cursor:pointer;}
.message-bubbles-entry .message-bubbles-reference-link.is-clickable:hover{background:var(--brand-soft);box-shadow:0 0 0 3px var(--brand-soft);}
.message-bubbles-entry.message-bubbles-reference-target .message-bubbles-content{box-shadow:0 0 0 3px var(--brand-soft),0 6px 18px var(--shadow-medium);}
.message-bubbles-entry .message-bubbles-content.message-bubbles-style-modern{background:linear-gradient(135deg,var(--message-bubbles-bg-rgba),color-mix(in srgb,var(--message-bubbles-bg-rgba) 82%,var(--message-bubbles-accent) 18%))}
@media (max-width:700px){.message-bubbles-entry .message-bubbles-content{max-width:var(--message-bubbles-mobile-width)}.message-bubbles-color-grid{grid-template-columns:1fr}.message-bubbles-preview-heading{display:block}.message-bubbles-preview-heading span{display:block;margin-top:4px}.message-bubbles-user-head{display:block}.message-bubbles-version{margin-top:7px}.message-bubbles-entry.message-bubbles-line-after::after,.message-bubbles-entry.message-bubbles-line-before::before{display:none}}
.message-bubbles-profile-settings{margin-top:18px;padding:22px;border:1px solid var(--line);border-radius:var(--radius-lg,16px);background:var(--panel);box-shadow:0 4px 18px var(--shadow-base,rgba(0,0,0,.04))}
.message-bubbles-profile-settings-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:18px}
.message-bubbles-profile-settings-head h2{margin:0;font-size:var(--font-size-xl,22px)}
.message-bubbles-profile-settings-head p{margin:5px 0 0;color:var(--text-muted);font-size:var(--font-size-sm);line-height:1.65}
.message-bubbles-profile-version{flex:0 0 auto;padding:5px 9px;border:1px solid var(--line);border-radius:999px;color:var(--text-muted);font-size:var(--font-size-xs)}
.message-bubbles-profile-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(280px,360px);gap:22px;align-items:start}
.message-bubbles-profile-main{min-width:0}
.message-bubbles-profile-preview{position:sticky;top:18px;min-width:0;padding:14px;border:1px solid var(--line-soft,var(--line));border-radius:12px;background:var(--bg,var(--panel))}
.message-bubbles-profile-preview-head{display:flex;justify-content:space-between;gap:10px;margin-bottom:10px;font-size:var(--font-size-sm)}
.message-bubbles-profile-preview-head span{color:var(--text-muted)}
.message-bubbles-profile-disabled{display:flex;flex-direction:column;gap:4px;padding:13px 15px;border:1px solid var(--line);border-radius:10px;background:var(--bg,var(--panel));color:var(--text-muted)}
.message-bubbles-profile-status{margin:0 0 16px;padding:10px 12px;border-radius:9px;background:var(--brand-soft);color:var(--brand);font-size:var(--font-size-sm);line-height:1.6}
.message-bubbles-profile-disabled strong{color:var(--text)}
@media(max-width:850px){.message-bubbles-profile-grid{grid-template-columns:1fr}.message-bubbles-profile-preview{position:static}}
@media (prefers-reduced-motion:reduce){.message-bubbles-entry.message-bubbles-animation .message-bubbles-content,.message-bubbles-entry.message-bubbles-hover-lift .message-bubbles-content{animation:none;transition:none}.message-bubbles-entry.message-bubbles-hover-lift .message-bubbles-content:hover{transform:none}}
CSS;
}

function message_bubbles_install(array $plugin): void
{
    $current = plugin_config('message_bubbles', []);
    if (!$current) plugin_save_config('message_bubbles', message_bubbles_defaults());
}

/**
 * 卸载时彻底清理本插件写入 app_settings 的数据。
 *
 * bbs1org 的通用卸载表单默认传 keep_plugin_data=1，用于给普通插件保留数据。
 * 本插件没有独立数据表，个人设置全部以 plugin_message_bubbles_* 存在 app_settings 中。
 * 为避免“卸载后个人气泡设置仍残留”，本插件对自己的设置始终执行清理。
 */
function message_bubbles_uninstall(array $plugin, bool $keep_data = true): void
{
    $delete = [];
    foreach (settings_cache() as $name => $_value) {
        $name = (string)$name;
        if (str_starts_with($name, 'plugin_message_bubbles_')) {
            $delete[] = $name;
        }
    }

    if ($delete) {
        $delete = array_values(array_unique($delete));
        q("DELETE FROM app_settings WHERE name IN (" . sql_marks(count($delete)) . ")", $delete);
        db_row_cache_clear();

        if (is_array($GLOBALS['__settings_cache'] ?? null)) {
            foreach ($delete as $name) unset($GLOBALS['__settings_cache'][$name]);
        }
    }

    $GLOBALS['message_bubbles_user_map'] = null;
    plugin_runtime_cache_reset();
}

return [
    'id' => 'message_bubbles',
    'name' => '回复气泡',
    'version' => message_bubbles_version(),
    'description' => '为论坛主题首帖与回复提供多种气泡风格、引用提示、回复关系、身份强调、响应式适配和个人外观设置。',
    'author' => 'bbc',
    'assets' => ['css' => 'message_bubbles_css', 'js' => 'message_bubbles_js'],
    'hooks' => [
        'reply.after_render' => 'message_bubbles_reply_after_render',
        'topic.after_render' => 'message_bubbles_topic_after_render',
        'topic.replies' => 'message_bubbles_topic_replies',
        'page.before_render' => 'message_bubbles_page_before_render',
        'user.menu_links' => 'message_bubbles_user_menu_links',
    ],
    'routes' => ['message_bubbles_settings' => 'message_bubbles_settings_page'],
    'entries' => [
        'profile_card' => true,
    ],
    'admin_tabs' => ['message_bubbles' => 'message_bubbles_admin_page'],
    'install' => 'message_bubbles_install',
    'uninstall' => 'message_bubbles_uninstall',
];