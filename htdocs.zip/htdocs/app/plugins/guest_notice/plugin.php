<?php
if (!defined('APP_ROOT')) exit;

function guest_notice_config(): array
{
    $raw = plugin_config('guest_notice', []);
    return [
        'enabled' => (int)($raw['enabled'] ?? 1) === 1,
        'text' => trim((string)($raw['text'] ?? '')) !== '' ? (string)$raw['text'] : '欢迎光临，登录后可以发帖和回帖。',
        'show_register' => (int)($raw['show_register'] ?? 1) === 1,
    ];
}

function guest_notice_install(array $plugin): void
{
    plugin_save_config('guest_notice', ['enabled' => 1, 'text' => '欢迎光临，登录后可以发帖和回帖。', 'show_register' => 1]);
}

function guest_notice_uninstall(array $plugin): void
{
    plugin_save_config('guest_notice', []);
}

function guest_notice_page_header($html, array $ctx): string
{
    $cfg = guest_notice_config();
    if (!$cfg['enabled'] || uid()) return (string)$html;
    $a = (string)($_GET['a'] ?? '');
    if ($a === 'login' || $a === 'register') return (string)$html;
    $links = '<a class="guest-notice-link" href="' . h(route_url('login')) . '">登录</a>';
    if ($cfg['show_register'] && setting('allow_register', '1') === '1') {
        $links .= '<a class="guest-notice-link" href="' . h(route_url('register')) . '">注册</a>';
    }
    $bar = '<div class="guest-notice-bar">' . h($cfg['text']) . $links . '</div>';
    return (string)$html . $bar;
}

function guest_notice_admin_page(array $plugin): string
{
    need_admin();
    $cfg = guest_notice_config();
    if (is_post_request()) {
        require_post();
        $enabled = isset($_POST['enabled']) ? 1 : 0;
        $text = trim((string)post('text', 500));
        if ($text === '') $text = '欢迎光临，登录后可以发帖和回帖。';
        $show_register = isset($_POST['show_register']) ? 1 : 0;
        plugin_save_config('guest_notice', ['enabled' => $enabled, 'text' => $text, 'show_register' => $show_register]);
        set_flash('游客提示条设置已保存');
        go(admin_url(['tab' => 'guest_notice']));
    }
    $form = '<form class="plugin-settings-form guest-notice-admin" method="post">' . form_token()
        . checkbox('启用提示条', 'enabled', $cfg['enabled'], '关闭后不再向访客显示提示。')
        . input('提示文案', 'text', $cfg['text'], 'text', false, '未登录访客在页面顶部看到的提示内容。')
        . checkbox('显示注册链接', 'show_register', $cfg['show_register'], '站点评允许注册时才显示注册链接。')
        . '<button>保存设置</button></form>';
    return '<div class="admin-list-panel plugin-manage-panel"><div class="plugin-panel-body"><h2>游客提示条</h2><p>在未登录访客的页面顶部显示登录和注册引导。</p>' . $form . '</div></div>';
}

function guest_notice_css(): string
{
    return <<<'CSS'
.guest-notice-bar{background:var(--brand-soft);color:var(--brand);font-size:var(--font-size-sm);text-align:center;padding:8px 16px;line-height:1.5}.guest-notice-bar .guest-notice-link{color:inherit;font-weight:600;margin-left:10px;text-decoration:underline}
CSS;
}

function guest_notice_admin_tabs(array $items, array $ctx): array
{
    $items['guest_notice'] = ['label' => '游客提示条', 'href' => admin_url(['tab' => 'guest_notice'])];
    return $items;
}

return [
    'id' => 'guest_notice',
    'name' => '游客提示条',
    'version' => '1.0.1',
    'description' => '未登录访客访问时在页面顶部显示登录和注册引导，帮助访客快速参与讨论。',
    'author' => 'bbs1 community',
    'assets' => ['css' => 'guest_notice_css'],
    'hooks' => [
        'admin.tabs' => 'guest_notice_admin_tabs',
        'page.header' => 'guest_notice_page_header',
    ],
    'routes' => [],
    'admin_tabs' => ['guest_notice' => 'guest_notice_admin_page'],
    'install' => 'guest_notice_install',
    'uninstall' => 'guest_notice_uninstall',
];