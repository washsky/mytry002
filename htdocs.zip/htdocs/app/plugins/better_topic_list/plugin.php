<?php
if (!defined('APP_ROOT')) exit;

function better_topic_list_config(): array
{
    $raw = plugin_config('better_topic_list', []);
    return [
        'enabled' => (int)($raw['enabled'] ?? 1) === 1,
        'poll_interval' => min(600, max(5, (int)($raw['poll_interval'] ?? 8))),
        'notice_content' => trim((string)($raw['notice_content'] ?? '')),
        'notice_enabled' => (int)($raw['notice_enabled'] ?? 0) === 1,
    ];
}

function better_topic_list_install(array $plugin): void
{
    plugin_save_config('better_topic_list', [
        'enabled' => 1,
        'poll_interval' => 8,
        'notice_content' => '**友善**、**团结**、**热心**、**专业**，共建你我引以为荣之社区。[《社区准则》](/index.php)',
        'notice_enabled' => 1,
    ]);
}

function better_topic_list_uninstall(array $plugin): void
{
    plugin_save_config('better_topic_list', []);
}

function better_topic_list_current_page(): array
{
    $a = (string)($_GET['a'] ?? 'home');
    $query = trim((string)($_GET['q'] ?? ''));
    $forum_id = 0;
    $is_timeline = false;
    if ($a === 'home' && $query === '') {
        $is_timeline = true;
    } elseif ($a === 'forum') {
        $forum_id = (int)($_GET['id'] ?? 0);
        if ($forum_id > 0) {
            $is_timeline = true;
        }
    }
    $page = max(1, (int)($_GET['p'] ?? 1));
    return ['is_timeline' => $is_timeline, 'forum_id' => $forum_id, 'page' => $page];
}

function better_topic_list_admin_page(array $plugin): string
{
    $config = better_topic_list_config();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals(csrf_token(), (string)($_POST['_csrf'] ?? ''))) {
            err('请求已过期');
        }
        $next = [
            'enabled' => ($_POST['enabled'] ?? '0') === '1' ? 1 : 0,
            'notice_enabled' => ($_POST['notice_enabled'] ?? '0') === '1' ? 1 : 0,
            'poll_interval' => min(600, max(5, (int)($_POST['poll_interval'] ?? 8))),
            'notice_content' => trim((string)($_POST['notice_content'] ?? ''))
        ];
        plugin_save_config('better_topic_list', $next);
        set_flash('设置已保存');
        go(admin_url(['tab' => 'better_topic_list']));
    }

    $enabled_checked = $config['enabled'] ? ' checked' : '';
    $notice_enabled_checked = $config['notice_enabled'] ? ' checked' : '';
    $poll_interval_val = (int)$config['poll_interval'];
    $notice_content_val = h($config['notice_content']);

    $form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'better_topic_list'])) . '">'
        . form_token()
        . '<label class="grid"><span>启用实时更新帖子列表</span><input type="hidden" name="enabled" value="0"><input type="checkbox" name="enabled" value="1"' . $enabled_checked . '></label>'
        . '<label class="grid"><span>每次更新间隔（秒）</span><input type="number" name="poll_interval" value="' . $poll_interval_val . '" min="5" max="600" step="1"></label>'
        . '<hr><h4>站点核心守则</h4>'
        . '<label class="grid"><span>启用守则横幅</span><input type="hidden" name="notice_enabled" value="0"><input type="checkbox" name="notice_enabled" value="1"' . $notice_enabled_checked . '></label>'
        . '<label class="grid"><span>守则内容（支持 Markdown）</span><textarea name="notice_content" rows="4" style="width:100%;box-sizing:border-box;">' . $notice_content_val . '</textarea></label>'
        . '<button>保存设置</button></form>';

    $head = '<div class="admin-plugin-summary"><strong>更好的帖子列表</strong><span>自动更新帖子列表，并可配置展示站点核心守则</span></div>';
    return '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head($head, '') . '<div class="plugin-panel-body">' . $form . '</div></div>';
}

function better_topic_list_row_html(array $topic, string $sort): string
{
    if (!function_exists('topic_list_row')) return '';
    $html = (string)topic_list_row($topic, $sort);
    if ($html === '') return '';
    // 与核心列表结构保持一致，仅补一个带前缀的主题 ID，供去重、定位和返回高亮使用。
    return preg_replace('/<li(?=[\s>])/i', '<li data-better-topic-list-id="' . (int)$topic['id'] . '"', $html, 1) ?? $html;
}

function better_topic_list_api(): void
{
    header('Content-Type: application/json; charset=utf-8');

    $action = (string)($_GET['action'] ?? '');
    if ($action !== 'get_new') {
        echo json_encode(['success' => false, 'error' => '未知操作']);
        exit;
    }

    $config = better_topic_list_config();
    if (!$config['enabled']) {
        echo json_encode(['success' => false, 'error' => '插件未启用']);
        exit;
    }

    $last_id = max(0, (int)($_GET['last_id'] ?? 0));
    $forum_id = max(0, (int)($_GET['forum_id'] ?? 0));
    $limit = min(20, max(1, (int)($_GET['limit'] ?? 10)));

    if ($forum_id > 0) {
        $forum = forum_by_id($forum_id);
        if (!$forum || !forum_group_allowed($forum, 'allow_view_groups')) {
            echo json_encode(['success' => false, 'error' => '无权限']);
            exit;
        }
    }

    $pinned_ids = pinned_topic_ids();

    $where = 'id > ?';
    $params = [$last_id];
    if ($forum_id > 0) {
        $where .= ' AND forum_id = ?';
        $params[] = $forum_id;
    }
    if (!empty($pinned_ids)) {
        $where .= ' AND id NOT IN (' . sql_marks(count($pinned_ids)) . ')';
        $params = array_merge($params, $pinned_ids);
    }

    $columns = function_exists('topic_list_select_columns') ? topic_list_select_columns() : '*';
    $rows = q("SELECT $columns FROM app_topics WHERE $where ORDER BY id DESC LIMIT ?", array_merge($params, [$limit]))->fetchAll();
    if (empty($rows)) {
        echo json_encode(['success' => true, 'html' => '', 'count' => 0, 'latest_id' => $last_id]);
        exit;
    }

    $latest_id = (int)$rows[0]['id'];
    $rows = array_reverse($rows);
    $rows = function_exists('attach_topic_list_users') ? attach_topic_list_users($rows) : $rows;
    $sort = function_exists('topic_index_sort') ? topic_index_sort(false) : 'comment';

    $html = '';
    $count = 0;
    foreach ($rows as $topic) {
        $topic['time'] = (int)($topic['created_at'] ?? 0);
        $topic['forum'] = forum_by_id((int)$topic['forum_id']) ?: ['id' => (int)$topic['forum_id'], 'name' => ''];
        $row_html = better_topic_list_row_html($topic, $sort);
        if ($row_html === '') continue;
        $html .= $row_html;
        $count++;
    }

    echo json_encode(['success' => true, 'html' => $html, 'count' => $count, 'latest_id' => $latest_id]);
    exit;
}

function better_topic_list_bar_html(int $forum_id, int $poll_interval): string
{
    $api = route_url('better_topic_list_api');
    return '<div class="better-topic-list-bar" data-better-topic-list-bar'
        . ' data-better-topic-list-api="' . h($api) . '"'
        . ' data-better-topic-list-forum="' . $forum_id . '"'
        . ' data-better-topic-list-interval="' . $poll_interval . '"'
        . '><a tabindex="0" role="button" href="#" class="alert clickable" data-better-topic-list-action>'
        . '<span>查看 <span data-better-topic-list-count>0</span> 个新的或更新的话题</span></a></div>';
}

function better_topic_list_notice_html(string $content): string
{
    return '<div class="better-topic-list-notice">'
        . '<div class="row">'
        . '<div class="alert better-topic-list-notice-alert"><span class="text">' . markdown_html($content) . '</span></div>'
        . '</div></div>';
}

function better_topic_list_before_render($html, array $ctx): string
{
    if (!is_string($html)) return $html;

    $config = better_topic_list_config();
    if (!$config['enabled']) {
        return $html;
    }

    $page_info = better_topic_list_current_page();
    if (!$page_info['is_timeline'] || $page_info['page'] !== 1) {
        return $html;
    }

    // 只处理首页和版块页的主列表，跳过帖子页和搜索结果页的同名列表。
    $prefix = '';
    if ($config['notice_enabled'] && $config['notice_content'] !== '') {
        $prefix .= better_topic_list_notice_html($config['notice_content']);
    }
    $prefix .= better_topic_list_bar_html($page_info['forum_id'], (int)$config['poll_interval']);

    $replaced = false;
    return preg_replace_callback('/(<ul\s+class=")([^"]*post-list[^"]*)(")/i', function (array $m) use (&$replaced, $prefix): string {
        if ($replaced) return $m[0];
        $classes = ' ' . strtolower((string)$m[2]) . ' ';
        if (strpos($classes, 'topic-post-list') !== false || strpos($classes, 'search-page-results') !== false) {
            return $m[0];
        }
        $replaced = true;
        return $prefix . $m[0];
    }, $html) ?? $html;
}

function better_topic_list_footer($html, array $ctx): string
{
    if (!is_string($html)) return $html;

    $config = better_topic_list_config();
    if (!$config['enabled']) {
        return $html;
    }

    // 从帖子页返回列表时，记住刚看过的主题，由列表页脚本高亮定位。
    if ((string)($_GET['a'] ?? '') === 'topic') {
        $topic_id = (int)($_GET['id'] ?? 0);
        if ($topic_id > 0) {
            $topic = row('app_topics', 'id', $topic_id);
            $forum_id = $topic ? (int)$topic['forum_id'] : 0;
            $expire = time() + 1200;
            setcookie('better_topic_list_hl_topic', (string)$topic_id, $expire, '/');
            setcookie('better_topic_list_hl_forum', (string)$forum_id, $expire, '/');
        }
    }

    return $html;
}

function better_topic_list_css(): string
{
    return <<<'CSS'
.better-topic-list-notice {
    width: 100%;
    margin-bottom: 12px;
}
.better-topic-list-notice .alert {
    width: 100%;
    box-sizing: border-box;
    display: block;
    padding: 10px 18px;
    border-radius: 0;
    background: var(--brand-soft);
    opacity: 0.7;
    color: var(--text);
    text-decoration: none;
    border: none;
    text-align: center;
}
.better-topic-list-notice .alert a {
    color: var(--brand-hover);
    text-decoration: none;
}

.better-topic-list-bar {
    width: 100%;
    max-height: 0;
    overflow: hidden;
    opacity: 0;
    transition: max-height 0.5s ease, opacity 0.5s ease, margin-bottom 0.5s ease;
    margin-bottom: 0;
}
.better-topic-list-bar.is-visible {
    max-height: 1000px;
    opacity: 1;
    margin-bottom: 12px;
}
.better-topic-list-bar .alert {
    display: block;
    padding: 10px 18px;
    border-radius: 0;
    background: var(--brand-soft);
    opacity: 0.7;
    color: var(--text);
    cursor: pointer;
    text-decoration: none;
    border: none;
    text-align: center;
}

@keyframes better-topic-list-flash {
    0% { background: var(--brand-soft); }
    100% { background: transparent; }
}
.better-topic-list-new,
.better-topic-list-visited {
    animation: better-topic-list-flash 4s ease-out forwards;
}
CSS;
}

function better_topic_list_js(): string
{
    return <<<'JS'
(function better_topic_list_main() {
    'use strict';

    var bar = document.querySelector('[data-better-topic-list-bar]');
    if (!bar) return;

    var list = document.querySelector('.main-panel > ul.post-list') || document.querySelector('ul.post-list');
    if (!list || list.classList.contains('topic-post-list')) return;

    var apiUrl = bar.getAttribute('data-better-topic-list-api') || '';
    if (apiUrl === '') return;

    var forumId = parseInt(bar.getAttribute('data-better-topic-list-forum') || '0', 10);
    if (!isFinite(forumId) || forumId < 0) forumId = 0;
    var pollSeconds = parseInt(bar.getAttribute('data-better-topic-list-interval') || '8', 10);
    if (!isFinite(pollSeconds) || pollSeconds < 5) pollSeconds = 8;

    var countEl = bar.querySelector('[data-better-topic-list-count]');
    var actionEl = bar.querySelector('[data-better-topic-list-action]');
    var pendingNodes = [];
    var lastTopicId = 0;

    function items() {
        return Array.prototype.slice.call(list.querySelectorAll('li.post-item'));
    }

    function topicIdOf(item) {
        var raw = item.getAttribute('data-better-topic-list-id') || item.getAttribute('data-topic-id');
        if (raw) return parseInt(raw, 10) || 0;
        var link = item.querySelector('a.post-title');
        if (!link) return 0;
        var matched = /[?&]id=(\d+)/.exec(link.getAttribute('href') || '');
        return matched ? (parseInt(matched[1], 10) || 0) : 0;
    }

    function readCookie(name) {
        var parts = ('; ' + document.cookie).split('; ' + name + '=');
        if (parts.length !== 2) return '';
        return decodeURIComponent(parts.pop().split(';').shift() || '');
    }

    function dropCookie(name) {
        document.cookie = name + '=; path=/; max-age=0';
    }

    function highlightVisited() {
        var id = readCookie('better_topic_list_hl_topic') || readCookie('highlight_topic');
        if (id === '') return;
        var forum = readCookie('better_topic_list_hl_forum') || readCookie('highlight_forum');
        dropCookie('better_topic_list_hl_topic');
        dropCookie('better_topic_list_hl_forum');
        dropCookie('highlight_topic');
        dropCookie('highlight_forum');
        if (forumId > 0 && forum !== '' && parseInt(forum, 10) !== forumId) return;
        var rows = items();
        for (var i = 0; i < rows.length; i++) {
            var topicId = topicIdOf(rows[i]);
            if (topicId > 0 && String(topicId) === id) {
                rows[i].classList.add('better-topic-list-visited');
                return;
            }
        }
    }

    // 置顶帖固定排在列表最前，且接口不会返回置顶帖，取它们的最大 ID 会漏掉新帖。
    function maxTopicId() {
        var normalMax = 0;
        var allMax = 0;
        items().forEach(function (item) {
            var id = topicIdOf(item);
            if (id <= 0) return;
            if (id > allMax) allMax = id;
            if (item.classList.contains('topic-pinned')) return;
            if (id > normalMax) normalMax = id;
        });
        return normalMax > 0 ? normalMax : allMax;
    }

    function dropEmptyState() {
        var empty = list.querySelector('li.empty-state');
        if (empty && !empty.hasAttribute('data-home-keyword-filter-empty')) empty.remove();
    }

    function notifyListUpdated(added) {
        if (!added.length) return;
        if (typeof window.homeKeywordFilterApply === 'function') {
            try { window.homeKeywordFilterApply(added); } catch (err) {}
        }
        if (typeof window.CustomEvent !== 'function') return;
        var detail = { list: list, items: added, source: 'better_topic_list' };
        ['better-topic-list:updated', 'topic-list-updated', 'sb:topic-list-updated'].forEach(function (name) {
            try { document.dispatchEvent(new window.CustomEvent(name, { detail: detail })); } catch (err) {}
        });
    }

    // 已在列表里或已在待插入队列里的主题 ID，用于避免重复入队。
    function knownIds() {
        var map = {};
        items().forEach(function (item) {
            var id = topicIdOf(item);
            if (id > 0) map[id] = true;
        });
        pendingNodes.forEach(function (node) {
            var id = topicIdOf(node);
            if (id > 0) map[id] = true;
        });
        return map;
    }

    function parseRows(html) {
        var holder = document.createElement('div');
        holder.innerHTML = html;
        return Array.prototype.slice.call(holder.querySelectorAll('li.post-item'));
    }

    function flushPending() {
        if (!pendingNodes.length) return;
        dropEmptyState();
        // 新帖一律插到列表最前，排在置顶帖之上。
        // 队列按时间从旧到新排列，依次插到上一个之前，最新的自然留在最顶。
        var cursor = list.firstChild;
        var added = [];
        pendingNodes.forEach(function (node) {
            node.classList.add('better-topic-list-new');
            list.insertBefore(node, cursor);
            cursor = node;
            added.push(node);
        });

        pendingNodes = [];
        updateBar();
        notifyListUpdated(added);
    }

    function updateBar() {
        if (countEl) countEl.textContent = String(pendingNodes.length);
        bar.classList.toggle('is-visible', pendingNodes.length > 0);
    }

    function fetchNewTopics() {
        if (document.hidden) return;
        // 用客户端维护的进度取下一批：新帖在用户点击前还没进 DOM，
        // 若每次都从 DOM 重新算，会反复拉到同一批并把计数无限累加。
        lastTopicId = Math.max(lastTopicId, maxTopicId());
        // 列表为空时以 0 起步，让接口返回最新的若干主题；已有帖子却取不到 ID 则不轮询。
        if (lastTopicId < 1 && items().length > 0) return;
        var url = apiUrl + (apiUrl.indexOf('?') >= 0 ? '&' : '?') + 'action=get_new&last_id=' + lastTopicId + '&forum_id=' + forumId;
        fetch(url, { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (response) { return response.ok ? response.json() : null; })
            .then(function (data) {
                if (!data || !data.success || !data.html) return;
                var latest = parseInt(data.latest_id, 10) || 0;
                if (latest > lastTopicId) lastTopicId = latest;
                var known = knownIds();
                var fresh = parseRows(String(data.html)).filter(function (node) {
                    var id = topicIdOf(node);
                    if (id > 0 && known[id]) return false;
                    if (id > 0) known[id] = true;
                    return true;
                });
                if (!fresh.length) return;
                pendingNodes = pendingNodes.concat(fresh);
                updateBar();
            })
            .catch(function () {});
    }

    if (actionEl) {
        actionEl.addEventListener('click', function (event) {
            event.preventDefault();
            flushPending();
        });
        actionEl.addEventListener('keydown', function (event) {
            if (event.key !== 'Enter' && event.key !== ' ') return;
            event.preventDefault();
            flushPending();
        });
    }

    highlightVisited();
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) fetchNewTopics();
    });
    window.addEventListener('pageshow', function (event) {
        if (event.persisted) highlightVisited();
    });

    setTimeout(fetchNewTopics, 3000);
    setInterval(fetchNewTopics, pollSeconds * 1000);
})();
JS;
}

return [
    'id' => 'better_topic_list',
    'name' => '更好的帖子列表',
    'version' => '1.2.1',
    'description' => '在首页和版块页自动提示并插入新帖，可展示站点守则横幅，从帖子返回列表时高亮刚看过的话题。',
    'author' => 'banming',
    'assets' => ['css' => 'better_topic_list_css', 'js' => 'better_topic_list_js'],
    'hooks' => [
        'page.before_render' => 'better_topic_list_before_render',
        'page.footer' => 'better_topic_list_footer',
    ],
    'routes' => [
        'better_topic_list_api' => 'better_topic_list_api',
    ],
    'admin_tabs' => [
        'better_topic_list' => 'better_topic_list_admin_page',
    ],
    'install' => 'better_topic_list_install',
    'uninstall' => 'better_topic_list_uninstall',
];