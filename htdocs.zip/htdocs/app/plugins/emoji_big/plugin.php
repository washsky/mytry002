<?php
if (!defined('APP_ROOT')) exit;

const EMOJI_BIG_VERSION = '1.6.0';

function emoji_big_config(): array
{
    $defaults = [
        'enabled' => 1,
        'size' => 2.3,
        'scope_topic' => 1,
        'scope_reply' => 1,
        'limited_mode' => 0,
        'trigger_chars' => '',
        'merge_before_chars' => '',
        'merge_after_chars' => '',
        'custom_tokens' => '',
        'emoji_only_suffix' => 1,
        'whole_message_mode' => 0,
        'whole_message_tokens' => '',
        'keyword_emoji_mode' => 'none',
        'keyword_emoji_tokens' => '',
        'keyword_emoji_distance' => 20,
        'numeric_emoji_mode' => 0,
        'numeric_emoji_max_digits' => 2,
        'line_height_mode' => 'dynamic',
        'vertical_align' => 'middle',
        'debug_layout' => 0,
        'custom_emoji_mode' => 'none',
        'custom_emoji_rules' => '',
    ];
    $raw = plugin_config('emoji_big', $defaults);
    $size = (float)($raw['size'] ?? $defaults['size']);
    $size = min(60.0, max(0.1, $size));
    $normalize = static function (mixed $value, int $max = 200): string {
        return cut(trim((string)$value), $max);
    };
    return [
        'enabled' => (int)($raw['enabled'] ?? 0) === 1,
        'size' => $size,
        'scope_topic' => (int)($raw['scope_topic'] ?? 1) === 1,
        'scope_reply' => (int)($raw['scope_reply'] ?? 1) === 1,
        'limited_mode' => (int)($raw['limited_mode'] ?? 0) === 1,
        'trigger_chars' => $normalize($raw['trigger_chars'] ?? ''),
        'merge_before_chars' => $normalize($raw['merge_before_chars'] ?? ''),
        'merge_after_chars' => $normalize($raw['merge_after_chars'] ?? ''),
        'custom_tokens' => $normalize($raw['custom_tokens'] ?? '', 500),
        'emoji_only_suffix' => (int)($raw['emoji_only_suffix'] ?? 1) === 1,
        'whole_message_mode' => (int)($raw['whole_message_mode'] ?? 0) === 1,
        'whole_message_tokens' => $normalize($raw['whole_message_tokens'] ?? '', 500),
        'keyword_emoji_mode' => in_array(($raw['keyword_emoji_mode'] ?? 'none'), ['none', 'emoji_only', 'distance'], true)
            ? $raw['keyword_emoji_mode'] : 'none',
        'keyword_emoji_tokens' => $normalize($raw['keyword_emoji_tokens'] ?? '', 500),
        'keyword_emoji_distance' => min(1000.0, max(1.0, (float)($raw['keyword_emoji_distance'] ?? 20))),
        'numeric_emoji_mode' => (int)($raw['numeric_emoji_mode'] ?? 0) === 1,
        'numeric_emoji_max_digits' => min(6, max(1, (int)($raw['numeric_emoji_max_digits'] ?? 2))),
        'line_height_mode' => in_array(($raw['line_height_mode'] ?? 'dynamic'), ['dynamic', 'fixed'], true)
            ? $raw['line_height_mode'] : 'dynamic',
        'vertical_align' => in_array(($raw['vertical_align'] ?? 'middle'), ['top', 'middle', 'bottom'], true)
            ? $raw['vertical_align'] : 'middle',
        'debug_layout' => (int)($raw['debug_layout'] ?? 0) === 1,
        'custom_emoji_mode' => in_array(($raw['custom_emoji_mode'] ?? 'none'), ['none', 'override', 'only'], true) ? $raw['custom_emoji_mode'] : 'none',
        'custom_emoji_rules' => $normalize($raw['custom_emoji_rules'] ?? '', 2000),
    ];
}

function emoji_big_tokens(): array
{
    $config = emoji_big_config();
    $tokens = [];
    foreach (preg_split('/[,，\r\n]+/u', $config['custom_tokens']) ?: [] as $token) {
        $token = trim($token);
        if ($token !== '') $tokens[] = $token;
    }
    usort($tokens, static fn(string $a, string $b): int => mb_strlen($b, 'UTF-8') <=> mb_strlen($a, 'UTF-8'));
    return array_values(array_unique($tokens));
}

function emoji_big_mark_post(string $html, array $ctx): string
{
    $config = emoji_big_config();
    if (!$config['enabled']) return $html;

    $is_reply = isset($ctx['row']['topic_id']) && (int)($ctx['row']['topic_id'] ?? 0) > 0;
    if ($is_reply && !$config['scope_reply']) return $html;
    if (!$is_reply && !$config['scope_topic']) return $html;

    $tokens = emoji_big_tokens();
    $data = [
        'enabled' => 1,
        'size' => $config['size'],
        'limited' => $config['limited_mode'] ? 1 : 0,
        'trigger' => $config['trigger_chars'],
        'before' => $config['merge_before_chars'],
        'after' => $config['merge_after_chars'],
        'tokens' => $tokens,
        'emojiOnlySuffix' => $config['emoji_only_suffix'] ? 1 : 0,
        'wholeMessage' => $config['whole_message_mode'] ? 1 : 0,
        'wholeTokens' => preg_split('/[,，\r\n]+/u', $config['whole_message_tokens']) ?: [],
        'keywordEmojiMode' => $config['keyword_emoji_mode'],
        'keywordEmojiTokens' => preg_split('/[,，\r\n]+/u', $config['keyword_emoji_tokens']) ?: [],
        'keywordEmojiDistance' => $config['keyword_emoji_distance'],
        'numericEmojiMode' => $config['numeric_emoji_mode'] ? 1 : 0,
        'numericEmojiMaxDigits' => $config['numeric_emoji_max_digits'],
        'lineHeightMode' => $config['line_height_mode'],
        'verticalAlign' => $config['vertical_align'],
        'debugLayout' => $config['debug_layout'] ? 1 : 0,
        'customEmojiMode' => $config['custom_emoji_mode'],
        'customEmojiRules' => $config['custom_emoji_rules'],
    ];
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    if (!is_string($json)) return $html;

    return preg_replace_callback('/(<div class="post-content)(")/u', static function (array $m) use ($json): string {
        return $m[1] . ' emoji-big-root" data-emoji-big-config="' . h($json) . $m[2];
    }, $html, 1) ?? $html;
}

function emoji_big_install(array $plugin): void
{
    $current = plugin_config('emoji_big', []);
    plugin_save_config('emoji_big', array_merge([
        'enabled' => 1,
        'size' => 1.8,
        'scope_topic' => 1,
        'scope_reply' => 1,
        'limited_mode' => 0,
        'trigger_chars' => '',
        'merge_before_chars' => '',
        'merge_after_chars' => '',
        'custom_tokens' => '',
        'emoji_only_suffix' => 1,
        'whole_message_mode' => 0,
        'whole_message_tokens' => '',
        'keyword_emoji_mode' => 'none',
        'keyword_emoji_tokens' => '',
        'keyword_emoji_distance' => 20,
        'numeric_emoji_mode' => 0,
        'numeric_emoji_max_digits' => 2,
        'line_height_mode' => 'dynamic',
        'vertical_align' => 'middle',
        'debug_layout' => 0,
        'custom_emoji_mode' => 'none',
        'custom_emoji_rules' => '',
    ], $current));
}

function emoji_big_admin_save(): void
{
    need_admin();
    require_post();

    $enabled = isset($_POST['enabled']) ? 1 : 0;
    $limited = isset($_POST['limited_mode']) ? 1 : 0;
    $scope_topic = isset($_POST['scope_topic']) ? 1 : 0;
    $scope_reply = isset($_POST['scope_reply']) ? 1 : 0;
    // 放大倍数使用独立的小数解析，避免后台 number_input/整数过滤导致合法小数被截断。
    $size_raw = trim((string)($_POST['size'] ?? '1.8'));
    // 同时接受 1.8 和 1,8；允许 .5 / 0.5 / 60 / 60.0 等合法数字。
    $size_raw = str_replace(',', '.', $size_raw);
    if (!preg_match('/^(?:\d+(?:\.\d*)?|\.\d+)$/', $size_raw)) {
        $size = 1.8;
    } else {
        $size = (float)$size_raw;
    }
    if (!is_finite($size)) $size = 1.8;
    $size = min(60.0, max(0.1, $size));
    $trigger = cut(trim((string)($_POST['trigger_chars'] ?? '')), 200);
    $before = cut(trim((string)($_POST['merge_before_chars'] ?? '')), 200);
    $after = cut(trim((string)($_POST['merge_after_chars'] ?? '')), 200);
    $tokens = cut(trim((string)($_POST['custom_tokens'] ?? '')), 500);
    $emoji_only_suffix = isset($_POST['emoji_only_suffix']) ? 1 : 0;
    $whole_message_mode = isset($_POST['whole_message_mode']) ? 1 : 0;
    $whole_message_tokens = cut(trim((string)($_POST['whole_message_tokens'] ?? '')), 500);
    $keyword_emoji_mode = (string)($_POST['keyword_emoji_mode'] ?? 'none');
    $keyword_emoji_tokens = cut(trim((string)($_POST['keyword_emoji_tokens'] ?? '')), 500);
    if (!in_array($keyword_emoji_mode, ['none', 'emoji_only', 'distance'], true)) $keyword_emoji_mode = 'none';
    $keyword_emoji_distance = (float)str_replace(',', '.', (string)($_POST['keyword_emoji_distance'] ?? 20));
    if (!is_finite($keyword_emoji_distance)) $keyword_emoji_distance = 20.0;
    $keyword_emoji_distance = min(1000.0, max(1.0, $keyword_emoji_distance));
    $numeric_emoji_mode = isset($_POST['numeric_emoji_mode']) ? 1 : 0;
    $numeric_emoji_max_digits = (int)($_POST['numeric_emoji_max_digits'] ?? 2);
    $numeric_emoji_max_digits = min(6, max(1, $numeric_emoji_max_digits));
    $line_height_mode = (string)($_POST['line_height_mode'] ?? 'dynamic');
    if (!in_array($line_height_mode, ['dynamic', 'fixed'], true)) $line_height_mode = 'dynamic';
    $vertical_align = (string)($_POST['vertical_align'] ?? 'middle');
    if (!in_array($vertical_align, ['top', 'middle', 'bottom'], true)) $vertical_align = 'middle';
    $debug_layout = isset($_POST['debug_layout']) ? 1 : 0;
    $custom_emoji_mode = (string)($_POST['custom_emoji_mode'] ?? 'none');
    if (!in_array($custom_emoji_mode, ['none', 'override', 'only'], true)) $custom_emoji_mode = 'none';
    $custom_emoji_rules = cut(trim((string)($_POST['custom_emoji_rules'] ?? '')), 2000);


    plugin_save_config('emoji_big', [
        'enabled' => $enabled,
        'size' => $size,
        'scope_topic' => $scope_topic,
        'scope_reply' => $scope_reply,
        'limited_mode' => $limited,
        'trigger_chars' => $trigger,
        'merge_before_chars' => $before,
        'merge_after_chars' => $after,
        'custom_tokens' => $tokens,
        'emoji_only_suffix' => $emoji_only_suffix,
        'whole_message_mode' => $whole_message_mode,
        'whole_message_tokens' => $whole_message_tokens,
        'keyword_emoji_mode' => $keyword_emoji_mode,
        'keyword_emoji_tokens' => $keyword_emoji_tokens,
        'keyword_emoji_distance' => $keyword_emoji_distance,
        'numeric_emoji_mode' => $numeric_emoji_mode,
        'numeric_emoji_max_digits' => $numeric_emoji_max_digits,
        'line_height_mode' => $line_height_mode,
        'vertical_align' => $vertical_align,
        'debug_layout' => $debug_layout,
        'custom_emoji_mode' => $custom_emoji_mode,
        'custom_emoji_rules' => $custom_emoji_rules,
    ]);
    set_flash('大号表情符号设置已保存');
    go(admin_url(['tab' => 'emoji_big']));
}

function emoji_big_admin_toggle(): void
{
    need_admin();
    require_post();
    $config = emoji_big_config();
    $config['enabled'] = !$config['enabled'] ? 1 : 0;
    plugin_save_config('emoji_big', $config);
    set_flash($config['enabled'] ? '大号表情符号已开启' : '大号表情符号已关闭');
    go(admin_url(['tab' => 'emoji_big']));
}

function emoji_big_decimal_size_field(float $value): string
{
    $value = min(60.0, max(0.1, $value));
    // 使用最多 4 位小数显示，避免 1.8 被格式化成整数；保存时仍接受更高精度的小数。
    $display = rtrim(rtrim(number_format($value, 4, '.', ''), '0'), '.');
    if ($display === '') $display = '0.1';

    return '<div class="emoji-big-admin-field emoji-big-size-field">'
        . '<div class="emoji-big-admin-field-label"><label for="emoji-big-size-input">Emoji 放大倍数</label></div>'
        . '<div class="emoji-big-size-control">'
        . '<button type="button" class="emoji-big-size-step" data-step="-0.1" aria-label="减少 0.1">−</button>'
        . '<input id="emoji-big-size-input" name="size" type="number" min="0.1" max="60.0" step="any" inputmode="decimal" value="' . h($display) . '" autocomplete="off">'
        . '<button type="button" class="emoji-big-size-step" data-step="0.1" aria-label="增加 0.1">+</button>'
        . '</div>'
        . '<small>范围 0.1～60.0；支持小数，例如 0.1、0.25、1.8、2.5、10.75、60.0。按钮每次增减 0.1，也可以直接输入任意合法小数。</small>'
        . '</div>';
}

function emoji_big_admin_page(array $plugin): string
{
    $config = emoji_big_config();
    if (is_post_request()) {
        if ((string)($_POST['emoji_big_action'] ?? '') === 'toggle') emoji_big_admin_toggle();
        emoji_big_admin_save();
    }

    $status = $config['enabled'] ? '已开启' : '已关闭';
    $toggle_label = $config['enabled'] ? '快捷关闭' : '快捷开启';
    $toggle_class = $config['enabled'] ? 'danger' : '';
    $tokens = h($config['custom_tokens']);

    $html = '<div class="form-panel emoji-big-admin-root">'
        . '<div class="emoji-big-admin-head">'
        . '<div class="emoji-big-admin-title">'
        . '<div class="emoji-big-admin-title-row"><h2>大号表情符号</h2><span class="emoji-big-admin-status ' . ($config['enabled'] ? 'is-on' : 'is-off') . '">' . h($status) . '</span></div>'
        . '<p>版本 ' . h(EMOJI_BIG_VERSION) . ' · 控制帖子和回复中的 Emoji 放大规则</p>'
        . '</div>'
        . '<div class="emoji-big-admin-head-action">' . post_action_form(admin_url(['tab' => 'emoji_big']), $toggle_label, ['emoji_big_action' => 'toggle'], $toggle_class) . '</div>'
        . '</div>'
        . '<form method="post">' . form_token()
        . '<section class="emoji-big-admin-section">'
        . '<div class="emoji-big-admin-section-head"><h3>基础设置</h3><p>先决定插件是否工作、放大倍数以及应用范围。</p></div>'
        . '<div class="emoji-big-admin-fields">'
        . checkbox('启用插件', 'enabled', $config['enabled'], '关闭后不再放大帖子和回复中的 Emoji。')
        . emoji_big_decimal_size_field($config['size'])
        . checkbox('主题正文启用', 'scope_topic', $config['scope_topic'])
        . checkbox('回复内容启用', 'scope_reply', $config['scope_reply'])
        . '</div>'
        . '</section>'
        . '<section class="emoji-big-admin-section">'
        . '<div class="emoji-big-admin-section-head"><h3>限定与合并</h3><p>控制哪些 Emoji 会被放大，以及是否把相邻字符一起纳入放大范围。</p></div>'
        . '<div class="emoji-big-admin-fields">'
        . checkbox('启用限定模式', 'limited_mode', $config['limited_mode'], '开启后，只有满足“触发字符”或“自定义字符串”的 Emoji 才会放大。')
        . textarea('触发字符', 'trigger_chars', $config['trigger_chars'], false, '限定模式使用。Emoji 左右紧邻这些字符时才触发，例如：! ? ~ 。')
        . textarea('Emoji 前置合并字符', 'merge_before_chars', $config['merge_before_chars'], false, '命中后，将 Emoji 左侧连续出现的这些字符一起放大，例如输入：(*😂。')
        . textarea('Emoji 后置合并字符', 'merge_after_chars', $config['merge_after_chars'], false, '命中后，将 Emoji 右侧连续出现的这些字符一起放大，例如输入：😂!!!')
        . textarea('自定义字符串', 'custom_tokens', $tokens, false, '用逗号或换行分隔，例如：[狗头]、:smile:、233。限定模式下，Emoji 紧邻这些字符串也会触发，并会把字符串一起放大。')
        . '</div>'
        . '</section>'
        . '<section class="emoji-big-admin-section">'
        . '<div class="emoji-big-admin-section-head"><h3>关键词规则</h3><p>独立于旧限定模式，可按关键词决定放大全部 Emoji 或关键词附近的 Emoji。</p></div>'
        . '<div class="emoji-big-admin-fields">'
        . '<div class="emoji-big-admin-field"><label for="emoji-big-keyword-emoji-tokens">关键词/词语</label>'
        . '<textarea id="emoji-big-keyword-emoji-tokens" name="keyword_emoji_tokens" rows="3" placeholder="例如：开心,重要,哈哈,狗头">' . h($config['keyword_emoji_tokens'] ?? '') . '</textarea>'
        . '<small>单独填写此功能要匹配的关键词或词语，用逗号或换行分隔。不会使用“整条消息限定词”里的内容。</small></div>'
        . '<div class="emoji-big-admin-field"><label for="emoji-big-keyword-emoji-mode">关键词/词语限定表情放大</label>'
        . '<select id="emoji-big-keyword-emoji-mode" name="keyword_emoji_mode">'
        . '<option value="none" ' . (($config['keyword_emoji_mode'] ?? 'none') === 'none' ? 'selected' : '') . '>关闭</option>'
        . '<option value="emoji_only" ' . (($config['keyword_emoji_mode'] ?? 'none') === 'emoji_only' ? 'selected' : '') . '>匹配到关键词后，仅放大消息中的 Emoji</option>'
        . '<option value="distance" ' . (($config['keyword_emoji_mode'] ?? 'none') === 'distance' ? 'selected' : '') . '>仅放大关键词附近距离内的 Emoji</option>'
        . '</select><small>这是独立的限定模式，只使用下面“关键词/词语”输入框。开启后，即使旧的“启用限定模式”关闭，也可以单独按关键词放大 Emoji；与旧限定同时开启时，两套规则任意命中即可。</small></div>'
        . '<div class="emoji-big-admin-field" id="emoji-big-keyword-distance-row"><label for="emoji-big-keyword-emoji-distance">附近距离</label>'
        . '<input id="emoji-big-keyword-emoji-distance" name="keyword_emoji_distance" type="number" min="1" max="1000" step="1" value="' . h((string)($config['keyword_emoji_distance'] ?? 20)) . '">'
        . '<small>仅“附近距离”模式生效，按关键词前后字符距离 1～1000 判断。关键词模式单独计算，不会要求同时满足触发字符或自定义字符串。</small></div>'
        . '</div>'
        . '</section>'
        . '<section class="emoji-big-admin-section">'
        . '<div class="emoji-big-admin-section-head"><h3>指定 Emoji 自定义放大</h3><p>可以为指定 Emoji 单独设置放大倍数，也可以切换为“仅指定 Emoji 放大”。</p></div>'
        . '<div class="emoji-big-admin-fields">'
        . '<div class="emoji-big-admin-field"><label for="emoji-big-custom-emoji-mode">指定 Emoji 规则</label>'
        . '<select id="emoji-big-custom-emoji-mode" name="custom_emoji_mode">'
        . '<option value="none" ' . (($config['custom_emoji_mode'] ?? 'none') === 'none' ? 'selected' : '') . '>关闭</option>'
        . '<option value="override" ' . (($config['custom_emoji_mode'] ?? 'none') === 'override' ? 'selected' : '') . '>指定 Emoji 使用自定义倍数，其余按全局规则</option>'
        . '<option value="only" ' . (($config['custom_emoji_mode'] ?? 'none') === 'only' ? 'selected' : '') . '>仅指定 Emoji 放大，其余 Emoji 不放大</option>'
        . '</select><small>规则会精确匹配 Emoji。数字快捷规则仍可叠加：例如 🥶=4 时，3x🥶 会按 4×3=12 倍显示；🥶x3 会复制 3 个并各按 4 倍显示。</small></div>'
        . '<div class="emoji-big-admin-field"><label for="emoji-big-custom-emoji-rules">Emoji 与自定义倍数</label>'
        . '<textarea id="emoji-big-custom-emoji-rules" name="custom_emoji_rules" rows="5" placeholder="例如：&#10;😂=3&#10;🥶=4.5&#10;❤️=2.2">' . h($config['custom_emoji_rules'] ?? '') . '</textarea>'
        . '<small>每行一个规则，也支持逗号或分号分隔；格式为 <strong>Emoji=倍数</strong>。倍数范围 0.1～60，例如：😂=3、🥶=4.5。建议一个 Emoji 一行，便于移动端查看和修改。</small></div>'
        . '</div>'
        . '</section>'
        . '<section class="emoji-big-admin-section">'
        . '<div class="emoji-big-admin-section-head"><h3>数字 Emoji 快捷规则</h3><p>使用数字控制 Emoji 的放大倍数或重复数量。</p></div>'
        . '<div class="emoji-big-admin-fields">'
        . '<div class="emoji-big-admin-field emoji-big-display-settings"><label>Emoji 行高与垂直对齐</label>'
        . '<div class="emoji-big-display-grid">'
        . '<div><select name="line_height_mode" id="emoji-big-line-height-mode">'
        . '<option value="dynamic" ' . (($config['line_height_mode'] ?? 'dynamic') === 'dynamic' ? 'selected' : '') . '>行高度跟着 Emoji 变化（默认）</option>'
        . '<option value="fixed" ' . (($config['line_height_mode'] ?? 'dynamic') === 'fixed' ? 'selected' : '') . '>行高度不变化</option>'
        . '</select><small>默认保持现在的效果；固定行高模式使用视觉缩放，不会因为 Emoji 放大把这一行撑高。</small></div>'
        . '<div><select name="vertical_align" id="emoji-big-vertical-align">'
        . '<option value="top" ' . (($config['vertical_align'] ?? 'middle') === 'top' ? 'selected' : '') . '>Emoji 上对齐文字</option>'
        . '<option value="middle" ' . (($config['vertical_align'] ?? 'middle') === 'middle' ? 'selected' : '') . '>Emoji 中间对齐文字（默认）</option>'
        . '<option value="bottom" ' . (($config['vertical_align'] ?? 'middle') === 'bottom' ? 'selected' : '') . '>Emoji 下对齐文字</option>'
        . '</select><small>控制 Emoji 相对同一行文字的位置。可与“行高度不变化”组合使用。</small></div>'
        . '</div></div>'
        . checkbox('开启排版调试信息', 'debug_layout', $config['debug_layout'], '临时调试用。开启后会在帖子正文下方显示不参与正文排版的调试面板，记录 Emoji 与前后文本的实际布局、视觉位置、字体、行高和字间距。确认问题来源后建议关闭。')
        . checkbox('开启“数字x”放大 / “x数字”重复', 'numeric_emoji_mode', $config['numeric_emoji_mode'], '例如 3x😂 会让 😂 按 3 倍大小显示；😂x3 会额外显示 3 个该 Emoji。处理后“数字x”和“x数字”控制符都会隐藏，不会出现在最终消息中。')
        . '<div class="emoji-big-admin-field"><label for="emoji-big-numeric-emoji-max-digits">数字最大位数</label>'
        . '<input id="emoji-big-numeric-emoji-max-digits" name="numeric_emoji_max_digits" type="number" min="1" max="6" step="1" value="' . h((string)$config['numeric_emoji_max_digits']) . '">'
        . '<small>限制数字最多允许几位，例如设置 2 后只接受 1～99；超出位数的“数字x”或“x数字”不执行。建议 1～3 位。</small></div>'
        . '</div>'
        . '</section>'
        . '<section class="emoji-big-admin-example"><strong>示例</strong><span>😂 → 单独放大（普通模式）</span><span>😂!!! → 开启“后置符号只放大 Emoji”时，仅 😂 放大，!!! 不放大</span><span>[狗头]😂 → 可把 [狗头] 与 Emoji 作为一个整体放大</span><span>消息含“开心” → 在“关键词/词语”中填写“开心”，再选择“仅放大 Emoji”后，只有该消息的 Emoji 按规则放大</span></section>'
        . '<div class="emoji-big-admin-actions"><button type="submit">保存设置</button></div>'
        . '</form></div>';
    return $html;
}

function emoji_big_css(): string
{
    return <<<'CSS'
.emoji-big-root.emoji-big-whole-message { font-size: var(--emoji-big-size); }
.emoji-big-root .emoji-big-emoji {
    display: inline-block;
    font-size: var(--emoji-big-size);
    line-height: 1;
    vertical-align: -0.08em;
}

.emoji-big-root.emoji-big-line-height-fixed .emoji-big-emoji {
    font-size: 1em;
    line-height: 1;
    transform: scale(var(--emoji-big-scale, 1));
    transform-origin: center center;
    /* transform 不参与排版宽度计算，因此额外用 margin-right 补足视觉放大后的宽度。
       这样大 Emoji 不会与后面的文字重叠，同时行高仍保持原来的高度。 */
    margin-left: var(--emoji-big-extra-left, 0px);
    margin-right: var(--emoji-big-extra-right, 0px);
}

.emoji-big-root.emoji-big-line-height-fixed .emoji-big-emoji.emoji-big-align-top {
    vertical-align: text-top;
    transform-origin: center top;
}

.emoji-big-root.emoji-big-line-height-fixed .emoji-big-emoji.emoji-big-align-middle {
    vertical-align: middle;
    transform-origin: center center;
}

.emoji-big-root.emoji-big-line-height-fixed .emoji-big-emoji.emoji-big-align-bottom {
    vertical-align: text-bottom;
    transform-origin: center bottom;
}

.emoji-big-root:not(.emoji-big-line-height-fixed) .emoji-big-emoji.emoji-big-align-top {
    vertical-align: text-top;
}

.emoji-big-root:not(.emoji-big-line-height-fixed) .emoji-big-emoji.emoji-big-align-middle {
    vertical-align: middle;
}

.emoji-big-root:not(.emoji-big-line-height-fixed) .emoji-big-emoji.emoji-big-align-bottom {
    vertical-align: text-bottom;
}

.emoji-big-debug-panel {
    display: block;
    box-sizing: border-box;
    width: 100%;
    max-width: 100%;
    margin: 10px 0 0;
    padding: 10px;
    border: 1px solid var(--line-soft);
    border-radius: 8px;
    background: var(--bg);
    color: var(--text-muted);
    font: 11px/1.5 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    overflow: hidden;
}
.emoji-big-debug-panel > summary {
    cursor: pointer;
    color: var(--text);
    font: 600 12px/1.4 inherit;
    user-select: none;
}
.emoji-big-debug-panel .emoji-big-debug-meta {
    margin-top: 7px;
    padding: 7px 8px;
    border-radius: 6px;
    background: var(--panel);
    overflow-wrap: anywhere;
}
.emoji-big-debug-panel .emoji-big-debug-row {
    margin-top: 7px;
    padding: 8px;
    border: 1px dashed var(--line-soft);
    border-radius: 6px;
    background: var(--panel);
    overflow-wrap: anywhere;
}
.emoji-big-debug-panel .emoji-big-debug-row strong {
    color: var(--text);
}
.emoji-big-debug-panel .emoji-big-debug-good { color: var(--success); }
.emoji-big-debug-panel .emoji-big-debug-warn { color: var(--danger); }

.emoji-big-admin-root {
    max-width: 900px;
    margin: 12px auto;
}

.emoji-big-admin-root .emoji-big-admin-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 18px;
    padding-bottom: 14px;
    border-bottom: 1px solid var(--line-soft);
}

.emoji-big-admin-root .emoji-big-admin-title {
    min-width: 0;
}

.emoji-big-admin-root .emoji-big-admin-title-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
}

.emoji-big-admin-root .emoji-big-admin-head h2 {
    margin: 0;
}

.emoji-big-admin-root .emoji-big-admin-head p {
    margin: 5px 0 0;
    color: var(--text-muted);
    font-size: var(--font-size-sm);
}

.emoji-big-admin-root .emoji-big-admin-status {
    display: inline-flex;
    align-items: center;
    min-height: 22px;
    padding: 2px 8px;
    border-radius: 999px;
    background: var(--bg);
    color: var(--text-muted);
    font-size: var(--font-size-xs);
    font-weight: 600;
}

.emoji-big-admin-root .emoji-big-admin-status.is-on {
    background: var(--success-soft);
    color: var(--success);
}

.emoji-big-admin-root .emoji-big-admin-status.is-off {
    background: var(--danger-soft);
    color: var(--danger);
}

.emoji-big-admin-root .emoji-big-admin-head-action {
    flex: 0 0 auto;
}

.emoji-big-admin-root .emoji-big-admin-head-action .post-action-form {
    margin: 0;
}

.emoji-big-admin-root .emoji-big-admin-section {
    margin: 0 0 12px;
    padding: 14px;
    border: 1px solid var(--line-soft);
    border-radius: var(--radius);
    background: var(--panel);
}

.emoji-big-admin-root .emoji-big-admin-section-head {
    margin-bottom: 10px;
}

.emoji-big-admin-root .emoji-big-admin-section-head h3 {
    margin: 0;
    font-size: var(--font-size-lg);
}

.emoji-big-admin-root .emoji-big-admin-section-head p {
    margin: 4px 0 0;
    color: var(--text-muted);
    font-size: var(--font-size-sm);
    line-height: 1.5;
}

.emoji-big-admin-root .emoji-big-admin-fields {
    display: grid;
    gap: 10px;
    min-width: 0;
}

.emoji-big-admin-root .emoji-big-admin-fields > .grid {
    grid-template-columns: minmax(0, 1fr) auto;
    align-items: center;
    gap: 12px;
    margin: 0;
    padding: 10px 0;
    border-bottom: 1px solid var(--line-soft);
}

.emoji-big-admin-root .emoji-big-admin-fields > .grid:last-child {
    border-bottom: 0;
}

.emoji-big-admin-root .emoji-big-admin-fields > .grid > span {
    min-width: 0;
    padding-top: 0;
}

.emoji-big-admin-root .emoji-big-admin-fields > .grid > span > small {
    max-width: 680px;
    margin-top: 3px;
    line-height: 1.5;
}

.emoji-big-admin-root .emoji-big-admin-field {
    display: grid;
    gap: 5px;
    min-width: 0;
}

.emoji-big-admin-root .emoji-big-admin-field > label,
.emoji-big-admin-root .emoji-big-admin-field-label > label {
    display: block;
    color: var(--text);
    font-weight: 600;
}

.emoji-big-admin-root .emoji-big-admin-field > small,
.emoji-big-admin-root .emoji-big-size-field > small {
    color: var(--text-muted);
    line-height: 1.5;
}

.emoji-big-admin-root .emoji-big-admin-field > input,
.emoji-big-admin-root .emoji-big-admin-field > select,
.emoji-big-admin-root .emoji-big-admin-field > textarea {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    box-sizing: border-box;
}

.emoji-big-admin-root .emoji-big-admin-field > textarea {
    min-height: 76px;
    resize: vertical;
}

.emoji-big-admin-root .emoji-big-size-field {
    gap: 7px;
    margin: 0;
    padding: 10px 0;
    border-bottom: 1px solid var(--line-soft);
}

.emoji-big-admin-root .emoji-big-size-control {
    display: grid;
    grid-template-columns: 40px minmax(90px, 150px) 40px;
    align-items: center;
    gap: 6px;
    max-width: 252px;
}

.emoji-big-admin-root .emoji-big-size-control input {
    width: 100%;
    max-width: none;
    text-align: center;
}

.emoji-big-admin-root .emoji-big-size-step {
    min-width: 40px;
    min-height: 40px;
    padding: 0;
    cursor: pointer;
}

.emoji-big-admin-root #emoji-big-keyword-distance-row {
    margin-top: 0;
}

.emoji-big-admin-root .emoji-big-display-settings {
    padding: 10px 0;
    border-bottom: 1px solid var(--line-soft);
}

.emoji-big-admin-root .emoji-big-display-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
}

.emoji-big-admin-root .emoji-big-display-grid > div {
    display: grid;
    gap: 5px;
    min-width: 0;
}

.emoji-big-admin-root .emoji-big-display-grid select {
    width: 100%;
    min-width: 0;
    box-sizing: border-box;
}

.emoji-big-admin-root .emoji-big-admin-example {
    display: grid;
    gap: 6px;
    margin-top: 14px;
    padding: 12px 14px;
    border: 1px solid var(--line-soft);
    border-radius: var(--radius);
    background: var(--bg);
    color: var(--text-muted);
    line-height: 1.5;
}

.emoji-big-admin-root .emoji-big-admin-example strong {
    color: var(--text);
}

.emoji-big-admin-root .emoji-big-admin-actions {
    display: flex;
    justify-content: flex-end;
    margin-top: 14px;
    padding-top: 14px;
    border-top: 1px solid var(--line-soft);
}

@media (max-width: 720px) {
    .emoji-big-admin-root {
        max-width: none;
        margin: 8px 0;
    }

    .emoji-big-admin-root .emoji-big-admin-head {
        flex-direction: column;
        align-items: stretch;
        gap: 10px;
        margin-bottom: 12px;
        padding-bottom: 12px;
    }

    .emoji-big-admin-root .emoji-big-admin-head-action,
    .emoji-big-admin-root .emoji-big-admin-head-action .post-action-form,
    .emoji-big-admin-root .emoji-big-admin-head-action button {
        width: 100%;
    }

    .emoji-big-admin-root .emoji-big-admin-section {
        padding: 12px;
        border-radius: var(--radius-sm);
    }

    .emoji-big-admin-root .emoji-big-admin-fields > .grid {
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 10px;
        padding: 9px 0;
    }

    .emoji-big-admin-root .emoji-big-admin-fields > .grid > input[type="checkbox"] {
        width: 38px;
        flex: 0 0 auto;
    }

    .emoji-big-admin-root .emoji-big-admin-field {
        width: 100%;
    }

    .emoji-big-admin-root .emoji-big-size-control {
        grid-template-columns: 42px minmax(0, 1fr) 42px;
        max-width: 100%;
    }

    .emoji-big-admin-root .emoji-big-display-grid {
        grid-template-columns: minmax(0, 1fr);
    }

    .emoji-big-admin-root .emoji-big-admin-actions {
        justify-content: stretch;
    }

    .emoji-big-admin-root .emoji-big-admin-actions button {
        width: 100%;
    }
}

@media (max-width: 360px) {
    .emoji-big-admin-root .emoji-big-admin-section {
        padding: 10px;
    }

    .emoji-big-admin-root .emoji-big-admin-section-head h3 {
        font-size: var(--font-size-md);
    }

    .emoji-big-admin-root .emoji-big-admin-fields > .grid {
        gap: 8px;
    }

    .emoji-big-admin-root .emoji-big-admin-example {
        padding: 10px;
    }
}
CSS;
}

function emoji_big_js(): string
{
    return <<<'JS'
(function () {
    "use strict";

    const emoji_big_emoji_pattern = /(?:\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?)*(?:\p{Emoji_Modifier})?|\p{Regional_Indicator}{2})/gu;

    function emoji_big_read_config(root) {
        try {
            const data = JSON.parse(root.getAttribute("data-emoji-big-config") || "{}");
            data.tokens = Array.isArray(data.tokens) ? data.tokens.filter(Boolean) : [];
            data.trigger = String(data.trigger || "");
            data.before = String(data.before || "");
            data.after = String(data.after || "");
            data.size = Math.max(0.1, Math.min(60.0, Number(data.size || 1.8)));
            data.limited = Number(data.limited || 0) === 1;
            data.emojiOnlySuffix = Number(data.emojiOnlySuffix || 0) === 1;
            data.wholeMessage = Number(data.wholeMessage || 0) === 1;
            data.wholeTokens = Array.isArray(data.wholeTokens) ? data.wholeTokens.map(String).filter(Boolean) : [];
            data.keywordEmojiTokens = Array.isArray(data.keywordEmojiTokens) ? data.keywordEmojiTokens.map(String).filter(Boolean) : [];
            data.keywordEmojiMode = ['none', 'emoji_only', 'distance'].includes(String(data.keywordEmojiMode || 'none')) ? String(data.keywordEmojiMode || 'none') : 'none';
            data.keywordEmojiDistance = Math.max(1, Math.min(1000, Number(data.keywordEmojiDistance || 20)));
            data.numericEmojiMode = Number(data.numericEmojiMode || 0) === 1;
            data.numericEmojiMaxDigits = Math.max(1, Math.min(6, Number(data.numericEmojiMaxDigits || 2)));
            data.customEmojiMode = ['none', 'override', 'only'].includes(String(data.customEmojiMode || 'none')) ? String(data.customEmojiMode || 'none') : 'none';
            data.customEmojiRules = String(data.customEmojiRules || '');
            data.lineHeightMode = ['dynamic', 'fixed'].includes(String(data.lineHeightMode || 'dynamic')) ? String(data.lineHeightMode || 'dynamic') : 'dynamic';
            data.verticalAlign = ['top', 'middle', 'bottom'].includes(String(data.verticalAlign || 'middle')) ? String(data.verticalAlign || 'middle') : 'middle';
            return data;
        } catch (error) {
            return null;
        }
    }

    function emoji_big_has_any_char(text, chars) {
        if (!text || !chars) return false;
        for (const char of Array.from(chars)) {
            if (text.includes(char)) return true;
        }
        return false;
    }

    function emoji_big_take_left(text, index, chars, tokens) {
        let start = index;
        while (start > 0) {
            let matched = false;
            for (const token of tokens) {
                if (token && text.slice(Math.max(0, start - token.length), start) === token) {
                    start -= token.length;
                    matched = true;
                    break;
                }
            }
            if (matched) continue;
            const previous = Array.from(text.slice(0, start)).pop() || "";
            if (!previous || !chars.includes(previous)) break;
            start -= previous.length;
        }
        return start;
    }

    function emoji_big_take_right(text, end, chars, tokens) {
        let finish = end;
        while (finish < text.length) {
            let matched = false;
            for (const token of tokens) {
                if (token && text.slice(finish, finish + token.length) === token) {
                    finish += token.length;
                    matched = true;
                    break;
                }
            }
            if (matched) continue;
            const next = Array.from(text.slice(finish)).shift() || "";
            if (!next || !chars.includes(next)) break;
            finish += next.length;
        }
        return finish;
    }

    function emoji_big_keyword_ranges(text, config) {
        if (config.keywordEmojiMode === "none" || !config.keywordEmojiTokens.length) return [];

        const ranges = [];
        // 关键词匹配允许跨换行：把 CRLF/CR 统一成 LF，并把连续空白视为可跨行空白。
        const normalized = String(text).replace(/\r\n?/g, "\n");

        for (const rawKeyword of config.keywordEmojiTokens) {
            const keyword = String(rawKeyword).trim();
            if (!keyword) continue;

            // 精确匹配优先；如果关键词本身包含换行，按原样匹配。
            let pos = normalized.indexOf(keyword);
            while (pos !== -1) {
                if (config.keywordEmojiMode === "emoji_only") {
                    ranges.push([0, text.length]);
                } else {
                    ranges.push([
                        Math.max(0, pos - config.keywordEmojiDistance),
                        Math.min(text.length, pos + keyword.length + config.keywordEmojiDistance)
                    ]);
                }
                pos = normalized.indexOf(keyword, pos + Math.max(1, keyword.length));
            }

            // 关键词不含换行时，额外允许关键词两部分之间出现换行/空白。
            if (!keyword.includes("\n") && /\s/.test(keyword)) {
                const escaped = keyword.split(/\s+/u).filter(Boolean)
                    .map(part => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
                    .join("\\s+");
                const re = new RegExp(escaped, "gu");
                let match;
                while ((match = re.exec(normalized)) !== null) {
                    if (config.keywordEmojiMode === "emoji_only") {
                        ranges.push([0, text.length]);
                    } else {
                        ranges.push([
                            Math.max(0, match.index - config.keywordEmojiDistance),
                            Math.min(text.length, match.index + match[0].length + config.keywordEmojiDistance)
                        ]);
                    }
                }
            }
        }
        return ranges;
    }


    function emoji_big_index_in_ranges(index, ranges) {
        for (const range of ranges) {
            if (index >= range[0] && index <= range[1]) return true;
        }
        return false;
    }

    function emoji_big_custom_emoji_rules(config) {
        const map = new Map();
        if (!config.customEmojiRules) return map;
        const parts = String(config.customEmojiRules).split(/[\r\n,;]+/u);
        for (const raw of parts) {
            const line = raw.trim();
            if (!line) continue;
            const match = line.match(/^(.*?)\s*(?:=>|=|:)\s*((?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)$/u);
            if (!match) continue;
            const emoji = match[1].trim();
            const value = Number(match[2]);
            if (!emoji || !Number.isFinite(value)) continue;
            map.set(emoji, Math.max(0.1, Math.min(60, value)));
        }
        return map;
    }

    function emoji_big_custom_scale(value, config, customRules) {
        if (config.customEmojiMode === 'none') return null;
        if (!customRules.has(value)) return config.customEmojiMode === 'only' ? 0 : null;
        return customRules.get(value);
    }

    function emoji_big_numeric_rule(text, emojiStart, emojiEnd, config) {
        if (!config.numericEmojiMode) return null;

        const maxDigits = config.numericEmojiMaxDigits;
        // 前置：数字x😂 / 数字X😂。只取紧邻 Emoji 的数字，且不能超过位数上限。
        const before = text.slice(0, emojiStart);
        const beforeMatch = before.match(new RegExp("(\\d{1," + maxDigits + "})[xX]$"));
        if (beforeMatch) {
            const count = Math.max(1, Math.min(Number(beforeMatch[1]), Math.pow(10, maxDigits) - 1));
            return {type: "scale", count: count, removeStart: emojiStart - beforeMatch[0].length, removeEnd: emojiStart};
        }

        // 后置：😂x数字 / 😂X数字。只接受紧邻 Emoji 的 x + 数字。
        const after = text.slice(emojiEnd);
        const afterMatch = after.match(new RegExp("^[xX](\\d{1," + maxDigits + "})"));
        if (afterMatch) {
            const count = Math.max(1, Math.min(Number(afterMatch[1]), Math.pow(10, maxDigits) - 1));
            return {type: "repeat", count: count, removeStart: emojiEnd, removeEnd: emojiEnd + afterMatch[0].length};
        }
        return null;
    }

    function emoji_big_prepare_root(root, config) {
        root.classList.toggle('emoji-big-line-height-fixed', config.lineHeightMode === 'fixed');
        root.classList.remove('emoji-big-align-top', 'emoji-big-align-middle', 'emoji-big-align-bottom');
        root.classList.add('emoji-big-align-' + config.verticalAlign);
        root.classList.toggle('emoji-big-debug-layout', !!config.debugLayout);
    }

    function emoji_big_apply_span_style(span, config, scale) {
        span.classList.remove('emoji-big-align-top', 'emoji-big-align-middle', 'emoji-big-align-bottom');
        span.classList.add('emoji-big-align-' + config.verticalAlign);
        const visualScale = config.size * scale;
        span.style.setProperty('--emoji-big-scale', String(visualScale));
        span.style.setProperty('--emoji-big-size', visualScale + 'em');
        span.style.setProperty('--emoji-big-extra-left', '0px');
        span.style.setProperty('--emoji-big-extra-right', '0px');
    }

    function emoji_big_fix_scaled_width(span, config) {
        if (!span || !span.classList.contains('emoji-big-emoji')) return;
        if (config.lineHeightMode !== 'fixed') return;

        const scale = Number(span.style.getPropertyValue('--emoji-big-scale')) || 1;
        if (scale <= 1.0001) {
            span.style.setProperty('--emoji-big-extra-left', '0px');
            span.style.setProperty('--emoji-big-extra-right', '0px');
            return;
        }

        // transform: scale() 只改变视觉尺寸，不会改变 inline 排版盒。
        // 当前 transform-origin 的水平轴始终在 center，所以视觉图形会向左右
        // 各伸出一半。两侧各补一半额外宽度，才能同时避免前后文字被压住。
        // 不假设 Emoji 是 1em 宽，而是直接测量当前字体下的真实布局宽度。
        const layoutWidth = span.offsetWidth;
        const visualWidth = span.getBoundingClientRect().width;
        const extraWidth = Math.max(0, visualWidth - layoutWidth);
        const extraEachSide = extraWidth / 2;
        span.style.setProperty('--emoji-big-extra-left', extraEachSide.toFixed(3) + 'px');
        span.style.setProperty('--emoji-big-extra-right', extraEachSide.toFixed(3) + 'px');
    }

    function emoji_big_fix_scaled_widths(root, config) {
        if (!root || config.lineHeightMode !== 'fixed') return;
        const spans = root.matches?.('.emoji-big-emoji')
            ? [root]
            : Array.from(root.querySelectorAll('.emoji-big-emoji'));
        spans.forEach(span => emoji_big_fix_scaled_width(span, config));
    }

    function emoji_big_debug_remove_panel(root) {
        if (!root || !root.parentElement) return;
        const next = root.nextElementSibling;
        if (next && next.classList.contains('emoji-big-debug-panel')) next.remove();
    }

    function emoji_big_debug_text_range(node) {
        if (!node || node.nodeType !== Node.TEXT_NODE || !node.nodeValue) return null;
        try {
            const range = document.createRange();
            range.selectNodeContents(node);
            const rect = range.getBoundingClientRect();
            const rects = Array.from(range.getClientRects()).map(r => ({
                x: Math.round(r.x * 10) / 10,
                y: Math.round(r.y * 10) / 10,
                width: Math.round(r.width * 10) / 10,
                height: Math.round(r.height * 10) / 10
            }));
            return {
                text: node.nodeValue,
                rect: {
                    x: Math.round(rect.x * 10) / 10,
                    y: Math.round(rect.y * 10) / 10,
                    width: Math.round(rect.width * 10) / 10,
                    height: Math.round(rect.height * 10) / 10
                },
                rects: rects
            };
        } catch (error) {
            return null;
        }
    }

    function emoji_big_debug_short_text(text, max = 40) {
        return String(text || '')
            .replace(/\r\n?/g, '\\n')
            .replace(/\n/g, '\\n')
            .replace(/\t/g, '\\t')
            .slice(0, max);
    }

    function emoji_big_debug_render_all(root, config) {
        if (!root || !root.parentElement) return;

        // 先移除旧面板。面板放在 .post-content 外部，绝不进入正文 inline 排版。
        emoji_big_debug_remove_panel(root);
        if (!config.debugLayout) return;

        const spans = root.matches?.('.emoji-big-emoji')
            ? [root]
            : Array.from(root.querySelectorAll('.emoji-big-emoji'));

        const rows = [];
        const customRules = emoji_big_custom_emoji_rules(config);
        spans.forEach((span, index) => {
            const cs = getComputedStyle(span);
            const parent = span.parentElement;
            const ps = parent ? getComputedStyle(parent) : null;
            const rect = span.getBoundingClientRect();
            const layoutWidth = span.offsetWidth;
            const layoutHeight = span.offsetHeight;

            const previousText = span.previousSibling && span.previousSibling.nodeType === Node.TEXT_NODE
                ? emoji_big_debug_text_range(span.previousSibling)
                : null;
            const nextText = span.nextSibling && span.nextSibling.nodeType === Node.TEXT_NODE
                ? emoji_big_debug_text_range(span.nextSibling)
                : null;

            const visualX = Math.round(rect.x * 10) / 10;
            const visualY = Math.round(rect.y * 10) / 10;
            const visualW = Math.round(rect.width * 10) / 10;
            const visualH = Math.round(rect.height * 10) / 10;

            const leftGap = previousText
                ? Math.round((visualX - (previousText.rect.x + previousText.rect.width)) * 10) / 10
                : null;
            const rightGap = nextText
                ? Math.round((nextText.rect.x - (visualX + visualW)) * 10) / 10
                : null;

            const scaleValue = Number(span.style.getPropertyValue('--emoji-big-scale')) || 1;
            const customScale = customRules.get(span.textContent || '');
            const ruleLabel = customScale !== undefined
                ? 'custom=' + customScale + '×'
                : (config.customEmojiMode === 'only' ? 'custom=未匹配' : 'rule=global');
            const extraLeft = cs.marginLeft;
            const extraRight = cs.marginRight;
            const collisionClass = (leftGap !== null && leftGap < -0.5) || (rightGap !== null && rightGap < -0.5)
                ? 'emoji-big-debug-warn' : 'emoji-big-debug-good';
            rows.push({
                title: '#' + (index + 1) + ' ' + (span.textContent || ''),
                className: collisionClass,
                text: [
                    'layout ' + layoutWidth + '×' + layoutHeight + ' · visual ' + visualW + '×' + visualH + ' · x/y ' + visualX + '/' + visualY,
                    'rule ' + ruleLabel + ' · effective=' + scaleValue + '× · font ' + cs.fontSize + ' · line ' + cs.lineHeight + ' · parent-line ' + (ps ? ps.lineHeight : '?') + ' · align ' + cs.verticalAlign,
                    'space L/R ' + extraLeft + '/' + extraRight + ' · transform ' + (cs.transform === 'none' ? 'none' : cs.transform),
                    'prev ' + (previousText ? JSON.stringify(emoji_big_debug_short_text(previousText.text)) + ' ' + JSON.stringify(previousText.rects) : 'none'),
                    'next ' + (nextText ? JSON.stringify(emoji_big_debug_short_text(nextText.text)) + ' ' + JSON.stringify(nextText.rects) : 'none'),
                    'gap L/R ' + (leftGap === null ? '-' : leftGap + 'px') + ' / ' + (rightGap === null ? '-' : rightGap + 'px')
                ].join(' | ')
            });
        });

        const panel = document.createElement('details');
        panel.className = 'emoji-big-debug-panel';
        panel.open = true;
        const summary = document.createElement('summary');
        summary.textContent = 'Emoji 排版调试 · ' + rows.length + ' 个 Emoji（面板不参与正文排版）';
        panel.appendChild(summary);

        const meta = document.createElement('div');
        meta.className = 'emoji-big-debug-meta';
        meta.textContent = '模式：' + config.lineHeightMode + ' · 对齐：' + config.verticalAlign + ' · 全局：' + config.size + '× · 指定规则：' + config.customEmojiMode + ' · 已解析 ' + customRules.size + ' 条';
        panel.appendChild(meta);
        const hint = document.createElement('div');
        hint.className = 'emoji-big-debug-meta';
        hint.textContent = 'gap < -0.5px 会标红；接近 0px 通常属于浏览器亚像素误差。layout=排版盒，visual=视觉盒，space L/R=为固定行高模式补出的横向占位。';
        panel.appendChild(hint);

        rows.forEach(item => {
            const row = document.createElement('div');
            row.className = 'emoji-big-debug-row ' + item.className;
            const strong = document.createElement('strong');
            strong.textContent = item.title;
            row.appendChild(strong);
            row.appendChild(document.createElement('br'));
            row.appendChild(document.createTextNode(item.text));
            panel.appendChild(row);
        });

        root.parentElement.insertBefore(panel, root.nextElementSibling);
    }

    function emoji_big_wrap_text_node(node, config, fullText, nodeOffset, customRules) {
        const text = node.nodeValue || "";
        if (!text) return;

        emoji_big_emoji_pattern.lastIndex = 0;
        const matches = [];
        let match;
        while ((match = emoji_big_emoji_pattern.exec(text)) !== null) matches.push({start: match.index, end: match.index + match[0].length, value: match[0]});
        if (!matches.length) return;

        const keywordModeActive = config.keywordEmojiMode !== "none" && config.keywordEmojiTokens.length > 0;
        const fullKeywordRanges = keywordModeActive
            ? emoji_big_keyword_ranges(fullText, config)
            : [];
        const keywordRanges = fullKeywordRanges.map(range => [
            range[0] - nodeOffset,
            range[1] - nodeOffset
        ]);

        const fragment = document.createDocumentFragment();
        let cursor = 0;

        for (const item of matches) {
            let start = item.start;
            let end = item.end;
            const left = text.slice(0, start);
            const right = text.slice(end);
            const leftTrigger = emoji_big_has_any_char(Array.from(left).slice(-1).join(""), config.trigger);
            const rightTrigger = emoji_big_has_any_char(Array.from(right)[0] || "", config.trigger);
            const tokenTrigger = config.tokens.some(token => (token && (left.endsWith(token) || right.startsWith(token))));
            const limitedMatch = leftTrigger || rightTrigger || tokenTrigger;

            // 1.3.1：关键词限定是“独立规则”，不再给原来的限定模式额外加一层限制。
            // 旧规则命中 OR 新关键词规则命中，即可放大。
            // 三类规则彼此独立：
            // 1) 普通模式：没有启用任何限定时，Emoji 全部放大；
            // 2) 旧限定模式：仅按触发字符/前后字符/自定义字符串判断；
            // 3) 关键词模式：仅按“关键词/词语”输入框判断。
            // 如果旧限定和关键词限定同时开启，则两套规则任意一套命中即可。
            const keywordRuleEnabled = keywordModeActive && config.keywordEmojiTokens.length > 0;
            const keywordRuleMatch = keywordRuleEnabled && emoji_big_index_in_ranges(item.start, keywordRanges);
            const oldRuleMatch = config.limited && limitedMatch;
            const normalMode = !config.limited && !keywordRuleEnabled;
            const numericRule = emoji_big_numeric_rule(text, item.start, item.end, config);
            const customScale = emoji_big_custom_scale(item.value, config, customRules);
            const customRuleMatch = customScale !== null;
            const customOnlyBlocked = config.customEmojiMode === 'only' && customScale === 0;
            const shouldEnlarge = !customOnlyBlocked && (normalMode || oldRuleMatch || keywordRuleMatch || customRuleMatch || !!numericRule);

            if (!shouldEnlarge) {
                if (start > cursor) fragment.appendChild(document.createTextNode(text.slice(cursor, start)));
                fragment.appendChild(document.createTextNode(item.value));
                cursor = end;
                continue;
            }

            // 数字快捷规则优先处理：数字x / x数字本身不进入放大内容。
            if (numericRule) {
                if (numericRule.type === "scale") {
                    // “数字x”是控制符，不输出；只保留并放大后面的 Emoji。
                    // 必须从控制符的起点保留前文，不能把“数字x”本身追加到文本节点。
                    const visibleStart = numericRule.removeStart;
                    if (visibleStart > cursor) {
                        fragment.appendChild(document.createTextNode(text.slice(cursor, visibleStart)));
                    }

                    const span = document.createElement("span");
                    span.className = "emoji-big-emoji";
                    emoji_big_apply_span_style(span, config, numericRule.count * (customScale && customScale > 0 ? customScale / config.size : 1));
                    span.textContent = item.value;
                    fragment.appendChild(span);

                    cursor = item.end;
                    continue;
                }

                if (numericRule.type === "repeat") {
                    // “x数字”是控制符，不输出；只保留 Emoji，并额外复制指定数量。
                    const visibleStart = item.start;
                    if (visibleStart > cursor) {
                        fragment.appendChild(document.createTextNode(text.slice(cursor, visibleStart)));
                    }

                    const repeatCount = numericRule.count;
                    for (let i = 0; i <= repeatCount; i++) {
                        const span = document.createElement("span");
                        span.className = "emoji-big-emoji";
                        emoji_big_apply_span_style(span, config, customScale && customScale > 0 ? customScale / config.size : 1);
                        span.textContent = item.value;
                        fragment.appendChild(span);
                    }

                    cursor = numericRule.removeEnd;
                    continue;
                }
            }

            start = emoji_big_take_left(text, start, config.before, config.tokens);
            const emojiEnd = item.end;
            end = emoji_big_take_right(text, end, config.after, config.tokens);
            if (config.emojiOnlySuffix && end > emojiEnd) end = emojiEnd;
            if (start < cursor) start = cursor;

            if (start > cursor) fragment.appendChild(document.createTextNode(text.slice(cursor, start)));
            const span = document.createElement("span");
            span.className = "emoji-big-emoji";
            const baseScale = customScale && customScale > 0 ? customScale / config.size : 1;
            emoji_big_apply_span_style(span, config, baseScale);
            span.textContent = text.slice(start, end);
            fragment.appendChild(span);
            cursor = end;
        }

        if (cursor < text.length) fragment.appendChild(document.createTextNode(text.slice(cursor)));
        node.replaceWith(fragment);
    }

    function emoji_big_process(root) {
        if (!root || !(root instanceof Element || root instanceof Document)) return;
        const containers = root.matches?.(".emoji-big-root") ? [root] : Array.from(root.querySelectorAll(".emoji-big-root"));
        for (const container of containers) {
            const config = emoji_big_read_config(container);
            if (!config) continue;

            emoji_big_prepare_root(container, config);

            if (config.wholeMessage && config.wholeTokens.some(token => container.textContent.includes(token))) {
                container.classList.add("emoji-big-whole-message");
                container.style.setProperty("--emoji-big-size", config.size + "em");
                continue;
            }
            const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
                acceptNode(node) {
                    const parent = node.parentElement;
                    if (!parent || parent.closest(".emoji-big-emoji, script, style, textarea, input, code, pre")) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                }
            });
            const nodes = [];
            let node;
            while ((node = walker.nextNode())) nodes.push(node);

            // 统一按整个帖子正文计算关键词位置，避免关键词/距离判断在换行、
            // <br> 或多个文本节点之间被截断。
            const fullText = container.textContent || "";
            const customRules = emoji_big_custom_emoji_rules(config);
            let searchOffset = 0;
            nodes.forEach(function (item) {
                const nodeText = item.nodeValue || "";
                const nodeOffset = fullText.indexOf(nodeText, searchOffset);
                const offset = nodeOffset >= 0 ? nodeOffset : searchOffset;
                emoji_big_wrap_text_node(item, config, fullText, offset, customRules);
                searchOffset = offset + nodeText.length;
            });

            // DOM 插入完成后才能取得真实的 Emoji 宽度；这里补足 transform
            // 缩放后没有参与排版计算的横向空间，避免大 Emoji 与前后文字重叠。
            emoji_big_fix_scaled_widths(container, config);
            // 调试面板放在 .post-content 外部，避免调试文本本身改变正文换行。
            emoji_big_debug_render_all(container, config);
        }
    }

    function emoji_big_init() {
        emoji_big_process(document);
        if (!document.body) return;
        const observer = new MutationObserver(mutations => {
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE) emoji_big_process(node);
                    else if (node.nodeType === Node.TEXT_NODE && node.parentElement) emoji_big_process(node.parentElement);
                }
            }
        });
        observer.observe(document.body, {childList: true, subtree: true});
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", emoji_big_init, {once: true});
    else emoji_big_init();
}());
(function () {
    const keywordEmojiMode = document.getElementById("emoji-big-keyword-emoji-mode");
    const keywordDistanceRow = document.getElementById("emoji-big-keyword-distance-row");
    function emojiBigSyncKeywordDistance() {
        if (!keywordEmojiMode || !keywordDistanceRow) return;
        keywordDistanceRow.style.display = keywordEmojiMode.value === "distance" ? "" : "none";
    }
    if (keywordEmojiMode) {
        keywordEmojiMode.addEventListener("change", emojiBigSyncKeywordDistance);
        emojiBigSyncKeywordDistance();
    }

    const customEmojiMode = document.getElementById("emoji-big-custom-emoji-mode");
    const customEmojiRules = document.getElementById("emoji-big-custom-emoji-rules");
    function emojiBigSyncCustomEmojiRules() {
        if (!customEmojiMode || !customEmojiRules) return;
        customEmojiRules.disabled = customEmojiMode.value === "none";
    }
    if (customEmojiMode) {
        customEmojiMode.addEventListener("change", emojiBigSyncCustomEmojiRules);
        emojiBigSyncCustomEmojiRules();
    }

    const input = document.getElementById("emoji-big-size-input");
    if (!input) return;

    document.querySelectorAll(".emoji-big-size-step").forEach(function (button) {
        button.addEventListener("click", function () {
            let value = Number(String(input.value).replace(",", "."));
            if (!Number.isFinite(value)) value = 1.8;
            const step = Number(button.dataset.step || 0);
            value = Math.round((value + step) * 1000) / 1000;
            value = Math.min(60, Math.max(0.1, value));
            input.value = String(value);
            input.dispatchEvent(new Event("input", {bubbles: true}));
        });
    });

    input.addEventListener("blur", function () {
        let value = Number(String(input.value).replace(",", "."));
        if (!Number.isFinite(value)) value = 1.8;
        value = Math.min(60, Math.max(0.1, value));
        input.value = String(Math.round(value * 1000) / 1000);
    });
}());

JS;
}

return [
    'id' => 'emoji_big',
    'name' => '大号表情符号',
    'version' => EMOJI_BIG_VERSION,
    'description' => '放大论坛主题和回复中的表情符号emoji，并可在插件后台自定义放大倍数、触发字符和合并规则,也能指定哪些emoji自定义放大。还有后台管理开启数字快捷规则后输入“阿拉伯数字x🥶”或“🥶x阿拉伯数字”有奇效',
    'author' => 'bbc',
    'assets' => ['css' => 'emoji_big_css', 'js' => 'emoji_big_js'],
    'hooks' => [
        'topic.after_render' => 'emoji_big_mark_post',
        'reply.after_render' => 'emoji_big_mark_post',
    ],
    'admin_tabs' => ['emoji_big' => 'emoji_big_admin_page'],
    'install' => 'emoji_big_install',
];