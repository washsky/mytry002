<?php if (!defined('APP_ROOT')) exit;

function video_player_css(): string
{
    return '
.bbs-video-wrap{
    margin:16px 0;
}
.bbs-video-player{
    width:100%;
    max-width:820px;
    border-radius:8px;
    background:#000000;
}
@media(max-width:768px){
    .bbs-video-player{
        max-width:100%;
    }
}
';
}

function video_player_filter(string $html, array $ctx): string
{
    $action = $_GET['a'] ?? '';
    if (str_starts_with($action, 'admin')) {
        return $html;
    }

    $pattern = '/<p>\s*<a\s+href=["\']([^"\']+\.mp4)["\'][^>]*>.*?<\/a>\s*<\/p>/is';

    $html = preg_replace_callback($pattern, function($m){
        $url = htmlspecialchars($m[1]);
        return '
<div class="bbs-video-wrap">
<video class="bbs-video-player" controls preload="metadata">
<source src="'.$url.'" type="video/mp4">
浏览器不支持播放视频：<a href="'.$url.'" target="_blank">'.$url.'</a>
</video>
</div>';
    }, $html);

    return $html;
}

return [
    'id' => 'video_player',
    'name' => '帖子视频播放器',
    'version' => '3.0.1',
    'description' => '视频播放器，直接粘贴视频地址就会自动生成，包括回复帖也会',
    'author' => 'custom',
    'assets' => [
        'css' => 'video_player_css'
    ],
    'hooks' => [
        'page.before_render' => 'video_player_filter'
    ]
];