<?php
if (!defined('APP_ROOT')) exit;

/**
 * 我的文件 / 用户文件中心
 *
 * v2.7.14
 *
 * 重要设计：
 * 1. 不修改 attachment_upload 1.0.14。
 * 2. 不修改 index.php / index.js。
 * 3. “文件”直接加入核心 user.profile_tabs，所以：
 *
 *    主题 | 回帖 | 通知 | 文件 | 设置 | 后台
 *
 *    与用户主页使用完全相同的 tab-bar。
 *
 * 4. user.menu_links 同时加入“我的文件”。
 *    核心 sidebar_user_card_html() 和 mobile_menu_content_html()
 *    都会读取该 Hook，因此 PC 个人卡片和移动端菜单自然同步。
 *
 * 5. 引用位置仅由本插件维护论坛 topic/reply 引用；其他插件各自维护自己的外部引用，并通过 user_files.reference_tabs Hook 向文件页提供独立入口。
 *
 * 6. “N 个引用”和“引用位置”使用同一个 URL：
 *
 *    a=user_files&view=references&id=123
 *
 *    不再设置一个重复的 user_file_references 路由。
 *
 * 7. 对外提供抽象 user_files.api 文件服务；外部插件的引用关系由外部插件自己维护，不写入本插件论坛引用索引。
 *
 * 8. 引用位置直接跳到：
 *
 *    主题主楼：
 *      a=topic&id=123#post=...
 *
 *    回帖：
 *      a=topic&id=123&replyid=456#post-456
 *
 *    核心 topic_page() 已支持 replyid 定位。
 */


/* =========================================================
 * 基础工具
 * ========================================================= */

function user_files_format_size(int $bytes): string
{
    $bytes = max(0, $bytes);

    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return round($bytes / 1024, 1) . ' KB';
    if ($bytes < 1073741824) return round($bytes / 1048576, 1) . ' MB';

    return round($bytes / 1073741824, 2) . ' GB';
}

function user_files_file_label(array $file): string
{
    $name = trim((string)($file['original_name'] ?? ''));

    return $name !== ''
        ? $name
        : (string)($file['file_name'] ?? '附件');
}

function user_files_attachment_url(array $file): string
{
    $hash = (string)($file['hash'] ?? '');
    $name = (string)($file['file_name'] ?? '');

    if (
        preg_match('/^[a-f0-9]{64}$/', $hash) !== 1 ||
        preg_match('/^[a-f0-9]{64}\.[a-z0-9]{1,25}$/', $name) !== 1
    ) {
        return '';
    }

    return asset_url(
        'app/upload/' .
        rawurlencode(upload_hash_dir($hash)) .
        '/' .
        rawurlencode(basename($name))
    );
}

function user_files_download_url(array $file): string
{
    return route_url('attachment', [
        'f' => (string)$file['file_name'],
        'name' => user_files_file_label($file),
    ]);
}

function user_files_file_path(array $file): string
{
    $download = user_files_download_url($file);
    return $download !== '' ? $download : '';
}

function user_files_file_absolute_path(array $file): string
{
    $path = user_files_file_path($file);
    return $path !== '' ? absolute_url($path) : '';
}

function user_files_compat_link_exts(): array
{
    $raw = user_files_config()['compat_link_exts'] ?? [];
    if (!is_array($raw)) return [];

    $exts = [];
    foreach ($raw as $ext) {
        $ext = strtolower(trim((string)$ext));
        $ext = ltrim($ext, '.');
        if ($ext !== '' && preg_match('/^[a-z0-9]{1,25}$/', $ext) === 1) {
            $exts[$ext] = true;
        }
    }

    return array_keys($exts);
}

function user_files_use_compat_link(array $file): bool
{
    $ext = strtolower(trim((string)($file['ext'] ?? '')));
    if ($ext === '') {
        $name = (string)($file['file_name'] ?? '');
        $ext = strtolower((string)pathinfo($name, PATHINFO_EXTENSION));
    }

    return $ext !== '' && in_array($ext, user_files_compat_link_exts(), true);
}

function user_files_insert_markdown(array $file): string
{
    $name = user_files_file_label($file);
    $label = markdown_link_text($name !== '' ? $name : '附件');
    // 管理员可按扩展名决定是否使用图片上传插件兼容的静态链接。
    $url = user_files_use_compat_link($file)
        ? user_files_attachment_url($file)
        : user_files_file_path($file);

    if ($url === '') return '';

    $is_image = !empty($file['is_image']) || user_files_preview_type($file) === 'image';
    return ($is_image ? '![' : '[') . $label . '](' . $url . ')';
}

function user_files_preview_url(array $file): string
{
    $id = (int)($file['id'] ?? 0);
    return $id > 0
        ? route_url('user_file_preview', ['id' => $id])
        : '';
}

function user_files_preview_type(array $file): string
{
    $mime = strtolower(trim((string)($file['mime'] ?? '')));
    $ext = strtolower(trim((string)($file['ext'] ?? '')));

    $image_mimes = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml',
    ];
    $audio_mimes = [
        'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav',
        'audio/ogg', 'audio/mp4', 'audio/webm',
    ];
    $video_mimes = [
        'video/mp4', 'video/webm', 'video/ogg',
    ];
    $text_exts = [
        'txt', 'log', 'csv', 'json', 'xml', 'md', 'css', 'js',
        'mjs', 'cjs', 'html', 'htm', 'svg', 'yml', 'yaml', 'ini', 'conf',
    ];

    if (in_array($mime, $image_mimes, true)) return 'image';
    if ($mime === 'application/pdf') return 'pdf';
    if (in_array($mime, $audio_mimes, true)) return 'audio';
    if (in_array($mime, $video_mimes, true)) return 'video';

    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'], true)) {
        return $ext === 'svg' ? 'text' : 'image';
    }

    if (in_array($ext, $text_exts, true)) return 'text';

    return '';
}

function user_files_preview_attachment(int $id): ?array
{
    if ($id <= 0) return null;

    $row = one(
        'SELECT id,user_id,hash,file_name,original_name,ext,mime,size,is_image,created_at
         FROM app_attachments
         WHERE id=?',
        [$id]
    );

    return is_array($row) ? $row : null;
}

function user_files_preview_route(array $plugin = []): void
{
    need_login();

    $id = (int)($_GET['id'] ?? 0);
    $file = user_files_preview_attachment($id);

    if (!is_array($file)) {
        err('文件不存在', 404);
    }

    $owner_id = (int)$file['user_id'];
    if ($owner_id !== uid() && !can_access_admin()) {
        err('无权预览此文件', 403);
    }

    $hash = (string)$file['hash'];
    $stored = (string)$file['file_name'];

    if (
        preg_match('/^[a-f0-9]{64}$/', $hash) !== 1 ||
        preg_match('/^[a-f0-9]{64}\.[a-z0-9]{1,25}$/', $stored) !== 1
    ) {
        err('文件不存在', 404);
    }

    $path = UPLOAD_DIR . '/' . upload_hash_dir($hash) . '/' . $stored;
    if (!is_file($path)) {
        err('文件不存在', 404);
    }

    $type = user_files_preview_type($file);
    if ($type === '') {
        err('此文件暂不支持在线预览，请下载查看', 415);
    }

    $size = (int)$file['size'];
    $max_inline = match ($type) {
        'text' => 2 * 1024 * 1024,
        'image' => 25 * 1024 * 1024,
        'pdf' => 50 * 1024 * 1024,
        'audio', 'video' => 200 * 1024 * 1024,
        default => 0,
    };

    if ($max_inline > 0 && $size > $max_inline) {
        err('文件过大，暂不提供在线预览，请下载查看', 413);
    }

    /*
     * 默认先显示一个文件预览页面。
     * 真正的文件内容通过同一路由的 raw=1 输出，避免把原始
     * 文件地址直接暴露给页面，同时保持“预览 / 下载 / 关闭”操作集中。
     */
    if ((string)($_GET['raw'] ?? '') !== '1') {
        $preview_url = route_url('user_file_preview', [
            'id' => $id,
            'raw' => 1,
        ]);
        $download_url = user_files_download_url($file);
        $name = user_files_file_label($file);
        $size_label = user_files_format_size($size);
        $type_label = strtoupper((string)($file['ext'] ?? 'FILE'));
        $content = '';

        if ($type === 'image') {
            $content = '<img src="' . h($preview_url) . '" alt="' . h($name) . '">';
        } elseif ($type === 'audio') {
            $content = '<audio controls preload="metadata" src="' . h($preview_url) . '"></audio>';
        } elseif ($type === 'video') {
            $content = '<video controls preload="metadata" src="' . h($preview_url) . '"></video>';
        } elseif ($type === 'pdf') {
            $content = '<iframe title="' . h($name) . '" src="' . h($preview_url) . '"></iframe>';
        } else {
            $content = '<iframe title="' . h($name) . '" src="' . h($preview_url) . '"></iframe>';
        }

        $main = '<section class="user-files-preview-page">' .
            '<div class="user-files-preview-card">' .
            '<div class="user-files-preview-head">' .
            '<div class="user-files-preview-title"><strong title="' . h($name) . '">' . h($name) . '</strong>' .
            '<span>' . h($type_label) . ' · ' . h($size_label) . ' · ' . h(date('Y-m-d H:i', (int)$file['created_at'])) . '</span></div>' .
            '</div>' .
            '<div class="user-files-preview-body">' . $content . '</div>' .
            '<div class="user-files-preview-foot">' .
            '<a href="' . h(user_files_url(1, '', 'all', 'references', $id)) . '">引用位置</a>' .
            '<a href="' . h($download_url) . '" target="_blank" rel="noopener">下载</a>' .
            '<a href="' . h($download_url) . '" target="_blank" rel="noopener" class="button">在新窗口打开</a>' .
            '</div></div></section>';

        echo shell_html($main, '', 'user-files-page');
        return;
    }

    $mime = strtolower(trim((string)$file['mime']));
    $safe_mimes = [
        'image/jpeg' => 'image/jpeg',
        'image/png' => 'image/png',
        'image/gif' => 'image/gif',
        'image/webp' => 'image/webp',
        'image/svg+xml' => 'image/svg+xml',
        'application/pdf' => 'application/pdf',
        'audio/mpeg' => 'audio/mpeg',
        'audio/mp3' => 'audio/mpeg',
        'audio/wav' => 'audio/wav',
        'audio/x-wav' => 'audio/wav',
        'audio/ogg' => 'audio/ogg',
        'audio/mp4' => 'audio/mp4',
        'audio/webm' => 'audio/webm',
        'video/mp4' => 'video/mp4',
        'video/webm' => 'video/webm',
        'video/ogg' => 'video/ogg',
        'text/plain' => 'text/plain; charset=UTF-8',
        'text/csv' => 'text/plain; charset=UTF-8',
        'application/json' => 'text/plain; charset=UTF-8',
        'application/xml' => 'text/plain; charset=UTF-8',
        'text/xml' => 'text/plain; charset=UTF-8',
        'text/css' => 'text/plain; charset=UTF-8',
        'text/javascript' => 'text/plain; charset=UTF-8',
        'application/javascript' => 'text/plain; charset=UTF-8',
    ];

    $content_type = $safe_mimes[$mime] ?? '';
    if ($content_type === '') {
        $content_type = match ($type) {
            'image' => 'image/*',
            'pdf' => 'application/pdf',
            'audio' => 'audio/*',
            'video' => 'video/*',
            default => 'text/plain; charset=UTF-8',
        };
    }

    header('Content-Type: ' . $content_type);
    header('Content-Length: ' . (string)$size);
    header('Content-Disposition: inline');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store, max-age=0');
    header('Referrer-Policy: no-referrer');

    if ($type === 'text') {
        $content = file_get_contents($path);
        if ($content === false) {
            err('文件读取失败', 500);
        }
        echo $content;
    } else {
        readfile($path);
    }

    exit;
}

function user_files_api_reference_context(array $ctx): array
{
    $source_type = user_files_api_normalize_source_type((string)($ctx['source_type'] ?? ''));
    $source_id = (int)($ctx['source_id'] ?? 0);
    // user_files 的引用 API 只允许维护自己的论坛 topic/reply；外部插件必须自行维护外部引用。
    if (!in_array($source_type, ['topic', 'reply'], true) || $source_id <= 0) return [];

    return [
        'source_type' => $source_type,
        'source_id' => $source_id,
        'topic_id' => (int)($ctx['topic_id'] ?? 0),
        'source_url' => user_files_api_normalize_source_url((string)($ctx['source_url'] ?? '')),
        'source_title' => user_files_api_source_text((string)($ctx['source_title'] ?? '')),
        'source_label' => user_files_api_source_text((string)($ctx['source_label'] ?? ''), 100),
    ];
}

function user_files_api_reference_valid_attachments(array $ids, bool $trusted = false, int $user_id = 0): array
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $id): bool => $id > 0)));
    if (!$ids) return [];

    $marks = sql_marks(count($ids));
    $sql =
        'SELECT a.id
         FROM app_attachments a
         WHERE a.id IN (' . $marks . ')
           AND NOT EXISTS (SELECT 1 FROM plugin_user_files_detached d WHERE d.attachment_id=a.id)';
    $params = $ids;

    if (!$trusted) {
        $user_id = $user_id > 0 ? $user_id : uid();
        if ($user_id <= 0) return [];
        $sql = str_replace('WHERE a.id IN', 'WHERE a.user_id=? AND a.id IN', $sql);
        $params = array_merge([$user_id], $params);
    }

    $rows = q($sql, $params)->fetchAll();
    return array_values(array_map(static fn(array $row): int => (int)$row['id'], $rows));
}

function user_files_api_reference_register(array $ctx, bool $trusted = false): array
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return ['ok' => false, 'reason' => 'reference_index_unavailable'];

    $attachment_id = (int)($ctx['attachment_id'] ?? 0);
    $context = user_files_api_reference_context($ctx);
    if ($attachment_id <= 0 || !$context) return ['ok' => false, 'reason' => 'invalid_reference'];

    $valid = user_files_api_reference_valid_attachments([$attachment_id], $trusted, (int)($ctx['user_id'] ?? 0));
    if (!$valid) return ['ok' => false, 'reason' => 'not_found'];

    $now = time();
    tx(function () use ($attachment_id, $context, $now): void {
        app_db_upsert(
            'plugin_user_files_references',
            [
                'attachment_id' => $attachment_id,
                'source_type' => $context['source_type'],
                'source_id' => $context['source_id'],
                'topic_id' => $context['source_type'] === 'topic' ? $context['source_id'] : $context['topic_id'],
                'reply_id' => $context['source_type'] === 'reply' ? $context['source_id'] : 0,
                'source_url' => $context['source_url'],
                'source_title' => $context['source_title'],
                'source_label' => $context['source_label'],
                'created_at' => $now,
            ],
            ['attachment_id', 'source_type', 'source_id']
        );
    });

    // 外部插件正式登记引用也属于一次“使用”，同步刷新该 attachment 的最近日期。
    // 只按 attachment_id 更新，不会影响其他用户拥有的同 hash 文件。
    user_files_api_file_use($attachment_id, true);

    return [
        'ok' => true,
        'attachment_id' => $attachment_id,
        'source_type' => $context['source_type'],
        'source_id' => $context['source_id'],
    ];
}

function user_files_api_reference_register_batch(array $ctx, bool $trusted = false): array
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return ['ok' => false, 'reason' => 'reference_index_unavailable'];

    $context = user_files_api_reference_context($ctx);
    if (!$context) return ['ok' => false, 'reason' => 'invalid_reference'];

    $attachments = $ctx['attachments'] ?? ($ctx['attachment_ids'] ?? []);
    if (!is_array($attachments)) $attachments = [$attachments];
    $valid = user_files_api_reference_valid_attachments($attachments, $trusted, (int)($ctx['user_id'] ?? 0));
    if (!$valid) return ['ok' => false, 'reason' => 'not_found'];

    $now = time();
    tx(function () use ($valid, $context, $now): void {
        foreach ($valid as $attachment_id) {
            app_db_upsert(
                'plugin_user_files_references',
                [
                    'attachment_id' => $attachment_id,
                    'source_type' => $context['source_type'],
                    'source_id' => $context['source_id'],
                    'topic_id' => $context['source_type'] === 'topic' ? $context['source_id'] : $context['topic_id'],
                    'reply_id' => $context['source_type'] === 'reply' ? $context['source_id'] : 0,
                    'source_url' => $context['source_url'],
                    'source_title' => $context['source_title'],
                    'source_label' => $context['source_label'],
                    'created_at' => $now,
                ],
                ['attachment_id', 'source_type', 'source_id']
            );
        }
    });

    foreach ($valid as $attachment_id) {
        user_files_api_file_use((int)$attachment_id, true);
    }

    return ['ok' => true, 'registered' => count($valid), 'attachment_ids' => $valid];
}

function user_files_api_reference_unregister(array $ctx, bool $trusted = false): array
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return ['ok' => false, 'reason' => 'reference_index_unavailable'];
    $attachment_id = (int)($ctx['attachment_id'] ?? 0);
    $context = user_files_api_reference_context($ctx);
    if ($attachment_id <= 0 || !$context) return ['ok' => false, 'reason' => 'invalid_reference'];

    $valid = user_files_api_reference_valid_attachments([$attachment_id], $trusted, (int)($ctx['user_id'] ?? 0));
    if (!$valid) return ['ok' => false, 'reason' => 'not_found'];

    q(
        'DELETE FROM plugin_user_files_references WHERE attachment_id=? AND source_type=? AND source_id=?',
        [$attachment_id, $context['source_type'], $context['source_id']]
    );
    return ['ok' => true, 'removed' => 1];
}

function user_files_api_reference_unregister_batch(array $ctx, bool $trusted = false): array
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return ['ok' => false, 'reason' => 'reference_index_unavailable'];
    $context = user_files_api_reference_context($ctx);
    if (!$context) return ['ok' => false, 'reason' => 'invalid_reference'];

    $attachments = $ctx['attachments'] ?? ($ctx['attachment_ids'] ?? []);
    if (!is_array($attachments)) $attachments = [$attachments];
    $owned = user_files_api_reference_valid_attachments($attachments, $trusted, (int)($ctx['user_id'] ?? 0));
    if (!$owned) return ['ok' => true, 'removed' => 0];

    $marks = sql_marks(count($owned));
    $removed = (int)val(
        'SELECT COUNT(*) FROM plugin_user_files_references
         WHERE source_type=? AND source_id=? AND attachment_id IN (' . $marks . ')',
        array_merge([$context['source_type'], $context['source_id']], $owned)
    );
    q(
        'DELETE FROM plugin_user_files_references
         WHERE source_type=? AND source_id=? AND attachment_id IN (' . $marks . ')',
        array_merge([$context['source_type'], $context['source_id']], $owned)
    );
    return ['ok' => true, 'removed' => $removed];
}

function user_files_api_reference_unregister_source(array $ctx, bool $trusted = false): array
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return ['ok' => false, 'reason' => 'reference_index_unavailable'];
    $context = user_files_api_reference_context($ctx);
    if (!$context) return ['ok' => false, 'reason' => 'invalid_reference'];

    $sql = 'DELETE FROM plugin_user_files_references WHERE source_type=? AND source_id=?';
    $params = [$context['source_type'], $context['source_id']];
    if (!$trusted) {
        $user_id = (int)($ctx['user_id'] ?? uid());
        if ($user_id <= 0) return ['ok' => false, 'reason' => 'not_found'];
        $sql =
            'DELETE FROM plugin_user_files_references
             WHERE source_type=? AND source_id=?
               AND attachment_id IN (SELECT id FROM app_attachments WHERE user_id=?)';
        $params[] = $user_id;
    }

    $removed = (int)val(
        'SELECT COUNT(*) FROM plugin_user_files_references WHERE source_type=? AND source_id=?',
        [$context['source_type'], $context['source_id']]
    );
    if (!$trusted) {
        $removed = (int)val(
            'SELECT COUNT(*) FROM plugin_user_files_references
             WHERE source_type=? AND source_id=?
               AND attachment_id IN (SELECT id FROM app_attachments WHERE user_id=?)',
            [$context['source_type'], $context['source_id'], (int)($ctx['user_id'] ?? uid())]
        );
    }
    q($sql, $params);
    return ['ok' => true, 'removed' => $removed];
}

function user_files_api_reference_source_list(array $ctx, bool $trusted = false): array
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return ['ok' => false, 'reason' => 'reference_index_unavailable', 'references' => []];
    $context = user_files_api_reference_context($ctx);
    if (!$context) return ['ok' => false, 'reason' => 'invalid_reference', 'references' => []];

    $sql =
        'SELECT r.attachment_id
         FROM plugin_user_files_references r
         INNER JOIN app_attachments a ON a.id=r.attachment_id
         WHERE r.source_type=? AND r.source_id=?';
    $params = [$context['source_type'], $context['source_id']];
    if (!$trusted) {
        $user_id = (int)($ctx['user_id'] ?? uid());
        if ($user_id <= 0) return ['ok' => true, 'references' => []];
        $sql .= ' AND a.user_id=?';
        $params[] = $user_id;
    }

    $rows = q($sql, $params)->fetchAll();
    $ids = array_values(array_map(static fn(array $row): int => (int)$row['attachment_id'], $rows));
    return ['ok' => true, 'source_type' => $context['source_type'], 'source_id' => $context['source_id'], 'attachment_ids' => $ids, 'references' => array_map(
        static fn(int $id): array => ['attachment_id' => $id],
        $ids
    )];
}

function user_files_api_reference_list(int $attachment_id, bool $trusted = false): array
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return [];
    if ($attachment_id <= 0) return [];
    $file = user_files_api_attachment($attachment_id, !$trusted);
    if (!$file) return [];
    return user_files_references_for_file($file);
}

function user_files_api_capabilities(): array
{
    return [
        'service' => 'user_files',
        'api_version' => '2.0',
        'operations' => [
            'file.get',
            'file.recent',
            'file.can_use',
            'file.use',
        ],
        'objects' => [
            'file' => 'stable attachment object',
            'reference' => 'forum topic/reply relationship is owned by user_files; external references are owned by their source plugins',
        ],
    ];
}

function user_files_api_dispatch(array $ctx, bool $trusted = false): array
{
    $op = strtolower(trim((string)($ctx['op'] ?? '')));
    $attachment_id = (int)($ctx['attachment_id'] ?? $ctx['id'] ?? 0);
    $user_id = (int)($ctx['user_id'] ?? 0);
    if (!$trusted) $user_id = uid();

    $result = match ($op) {
        'api.capabilities', 'service.info' => user_files_api_capabilities(),
        'file.get' => (static function () use ($attachment_id, $trusted): array {
            $file = user_files_api_file_get($attachment_id, $trusted);
            return $file ? ['ok' => true, 'file' => $file] : ['ok' => false, 'reason' => 'not_found'];
        })(),
        'file.recent' => ['ok' => true, ...user_files_api_recent(
            (int)($ctx['limit'] ?? 5),
            !isset($ctx['include_pinned']) || !empty($ctx['include_pinned']),
            $user_id
        )],
        'file.can_use' => user_files_api_file_can_use($attachment_id, $trusted),
        'file.use' => user_files_api_file_use($attachment_id, $trusted),
        'reference.register' => user_files_api_reference_register($ctx, $trusted),
        'reference.register_batch' => user_files_api_reference_register_batch($ctx, $trusted),
        'reference.unregister' => user_files_api_reference_unregister($ctx, $trusted),
        'reference.unregister_batch' => user_files_api_reference_unregister_batch($ctx, $trusted),
        'reference.unregister_source' => user_files_api_reference_unregister_source($ctx, $trusted),
        'reference.list' => ['ok' => true, 'references' => user_files_api_reference_list($attachment_id, $trusted)],
        'reference.source_list' => user_files_api_reference_source_list($ctx, $trusted),
        default => ['ok' => false, 'reason' => 'unknown_operation'],
    };
    $result['api_version'] = '2.0';
    return $result;
}

function user_files_api_hook(mixed $value, array $ctx): mixed
{
    return user_files_api_dispatch($ctx, true);
}

function user_files_api_route(array $plugin = []): never
{
    if (!uid()) {
        http_response_code(403);
        exit;
    }

    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (!in_array($method, ['GET', 'POST'], true)) err('请求方式错误', 405);
    $input = $method === 'POST' ? $_POST : $_GET;
    $input['op'] = strtolower(trim((string)($input['op'] ?? '')));

    if ((str_starts_with((string)$input['op'], 'reference.') || $input['op'] === 'file.use') && $method !== 'POST') {
        err($input['op'] === 'file.use' ? '文件使用接口必须使用 POST' : '引用接口必须使用 POST', 405);
    }
    if ($method === 'POST') require_post();

    if (isset($input['attachments']) && !is_array($input['attachments'])) {
        $input['attachments'] = preg_split('/\s*,\s*/', (string)$input['attachments'], -1, PREG_SPLIT_NO_EMPTY) ?: [];
    }
    if (isset($input['attachment_ids']) && !is_array($input['attachment_ids'])) {
        $input['attachment_ids'] = preg_split('/\s*,\s*/', (string)$input['attachment_ids'], -1, PREG_SPLIT_NO_EMPTY) ?: [];
    }

    $result = user_files_api_dispatch($input, false);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function user_files_install(array $plugin = []): void
{
    $t = app_db_types();

    app_db_create_table(
        'plugin_user_files_folders',
        "id {$t['id']},user_id {$t['uint']} NOT NULL,name {$t['string']} NOT NULL,is_pinned {$t['uint']} NOT NULL DEFAULT 0,sort_order {$t['uint']} NOT NULL DEFAULT 0,created_at {$t['uint']} NOT NULL,updated_at {$t['uint']} NOT NULL"
    );
    app_db_create_index(
        'plugin_user_files_folders_user_pin',
        'plugin_user_files_folders(user_id,is_pinned,sort_order,id)'
    );
    app_db_create_table(
        'plugin_user_files_folder_items',
        "id {$t['id']},folder_id {$t['uint']} NOT NULL,attachment_id {$t['uint']} NOT NULL,created_at {$t['uint']} NOT NULL,UNIQUE(folder_id,attachment_id),UNIQUE(attachment_id)"
    );
    app_db_create_index(
        'plugin_user_files_folder_items_folder',
        'plugin_user_files_folder_items(folder_id,created_at,id)'
    );

    /*
     * 文件引用索引：帖子正文只在保存时解析一次，页面查询直接走关系表。
     * 不修改 app_topics / app_replies / app_attachments 核心结构。
     */
    /*
     * 文件引用索引：只维护论坛 topic/reply。外部插件不写入、不参与本索引。
     * 升级时保留既有关系数据，并仅重建 topic/reply；重建批次不会删除外部插件自己的数据。
     */
    $reference_schema = (string)setting('plugin_user_files_reference_schema', '');
    $reference_table_exists = app_db_table_exists(db(), db_driver(), 'plugin_user_files_references');

    if ($reference_table_exists) {
        // 兼容 2.5.x 的旧关系表；补齐新字段，但数据归属仍严格限定为论坛 topic/reply。
        app_db_ensure_columns('plugin_user_files_references', [
            'source_type' => $t['string'] . " NOT NULL DEFAULT 'topic'",
            'source_id' => $t['uint'] . ' NOT NULL DEFAULT 0',
            'source_url' => $t['string'] . " NOT NULL DEFAULT ''",
            'source_title' => $t['string'] . " NOT NULL DEFAULT ''",
            'source_label' => $t['string'] . " NOT NULL DEFAULT ''",
        ]);
        q("UPDATE plugin_user_files_references SET source_type='reply', source_id=reply_id WHERE reply_id>0", []);
        q("UPDATE plugin_user_files_references SET source_type='topic', source_id=topic_id WHERE reply_id=0 AND topic_id>0", []);
    }

    if (!$reference_table_exists) {
        app_db_create_table(
            'plugin_user_files_references',
            "id {$t['id']},attachment_id {$t['uint']} NOT NULL,source_type {$t['string']} NOT NULL,source_id {$t['uint']} NOT NULL,topic_id {$t['uint']} NOT NULL DEFAULT 0,reply_id {$t['uint']} NOT NULL DEFAULT 0,source_url {$t['string']} NOT NULL DEFAULT '',source_title {$t['string']} NOT NULL DEFAULT '',source_label {$t['string']} NOT NULL DEFAULT '',created_at {$t['uint']} NOT NULL,UNIQUE(attachment_id,source_type,source_id)"
        );
        app_db_create_index('plugin_user_files_references_attachment', 'plugin_user_files_references(attachment_id,source_type,source_id)');
        app_db_create_index('plugin_user_files_references_source', 'plugin_user_files_references(source_type,source_id)');
        save_settings_values([
            'plugin_user_files_reference_schema' => '2.7.10',
            'plugin_user_files_reference_index_ready' => '0',
            'plugin_user_files_reference_rebuild_phase' => 'topics',
            'plugin_user_files_reference_rebuild_cursor' => '0',
        ]);
    } elseif (in_array($reference_schema, ['2.6.0', '2.7.0', '2.7.2', '2.7.3', '2.7.4', '2.7.5', '2.7.8', '2.7.9', '2.7.10', '2.7.12'], true)) {
        app_db_create_index('plugin_user_files_references_attachment', 'plugin_user_files_references(attachment_id,source_type,source_id)');
        app_db_create_index('plugin_user_files_references_source', 'plugin_user_files_references(source_type,source_id)');
        $settings = ['plugin_user_files_reference_schema' => '2.7.10'];
        if ($reference_schema !== '2.7.10') {
            // 本次升级只重建论坛引用，rebuild_batch 自身按 topic/reply 删除，因此不会碰外部数据。
            $settings['plugin_user_files_reference_index_ready'] = '0';
            $settings['plugin_user_files_reference_rebuild_phase'] = 'topics';
            $settings['plugin_user_files_reference_rebuild_cursor'] = '0';
        }
        save_settings_values($settings);
    } else {
        /*
         * 关键兼容原则：只要关系表已经存在，就绝不能因为 schema 设置缺失、
         * 来自旧版本或值未知而 DROP TABLE。这里仅补齐论坛引用所需结构并保留现有数据；
         * user_files 不再把外部插件引用写入或读取到自己的引用位置。
         */
        app_db_create_index('plugin_user_files_references_attachment', 'plugin_user_files_references(attachment_id,source_type,source_id)');
        app_db_create_index('plugin_user_files_references_source', 'plugin_user_files_references(source_type,source_id)');
        save_settings_values([
            'plugin_user_files_reference_schema' => '2.7.10',
            'plugin_user_files_reference_index_ready' => '0',
            'plugin_user_files_reference_rebuild_phase' => 'topics',
            'plugin_user_files_reference_rebuild_cursor' => '0',
        ]);
    }


    /*
     * 兼容旧索引：早期版本可能只保存 reply_id，没有正确回填 topic_id。
     * 这里仅修复引用索引自身的数据，不修改核心论坛表结构。
     */
    if (app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) {
        q(
            "UPDATE plugin_user_files_references
             SET topic_id=(SELECT topic_id FROM app_replies WHERE app_replies.id=plugin_user_files_references.reply_id)
             WHERE source_type='reply' AND reply_id>0
               AND EXISTS (SELECT 1 FROM app_replies WHERE app_replies.id=plugin_user_files_references.reply_id AND app_replies.topic_id>0)",
            []
        );
        q(
            "UPDATE plugin_user_files_references
             SET topic_id=source_id
             WHERE source_type='topic' AND source_id>0 AND topic_id=0",
            []
        );
    }

    /*
     * 文件管理层的“软移除”关系：
     * 当本人没有使用某文件，但其他用户仍在使用时，
     * 只从本人的“我的文件”中隐藏，不删除 app_attachments 和物理文件。
     */
    app_db_create_table(
        'plugin_user_files_detached',
        "id {$t['id']},attachment_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,detached_at {$t['uint']} NOT NULL,UNIQUE(attachment_id)"
    );
    app_db_create_index(
        'plugin_user_files_detached_user',
        'plugin_user_files_detached(user_id,detached_at,attachment_id)'
    );


}

function user_files_uninstall(array $plugin = [], bool $keep_data = true): void
{
    if ($keep_data) return;
    app_db_drop_table('plugin_user_files_detached');
    app_db_drop_table('plugin_user_files_references');
    app_db_drop_table('plugin_user_files_folder_items');
    app_db_drop_table('plugin_user_files_folders');
    save_settings_values([
        'plugin_user_files_reference_index_ready' => '',
        'plugin_user_files_reference_rebuild_phase' => '',
        'plugin_user_files_reference_rebuild_cursor' => '',
    ]);
}

function user_files_folder_name(string $name): string
{
    $name = trim(preg_replace('/[\\x00-\\x1F\\x7F]+/u', ' ', $name) ?? $name);
    return cut($name, 50);
}

function user_files_folder_find(int $id): ?array
{
    if ($id <= 0 || uid() <= 0) return null;
    $row = one(
        'SELECT id,user_id,name,is_pinned,sort_order,created_at,updated_at
         FROM plugin_user_files_folders
         WHERE id=? AND user_id=?',
        [$id, uid()]
    );
    return is_array($row) ? $row : null;
}

function user_files_folder_rows(): array
{
    static $cache = null;
    if ($cache !== null) return $cache;
    if (uid() <= 0) return $cache = [];
    return $cache = q(
        'SELECT id,user_id,name,is_pinned,sort_order,created_at,updated_at
         FROM plugin_user_files_folders
         WHERE user_id=?
         ORDER BY is_pinned DESC,sort_order ASC,name ASC,id ASC',
        [uid()]
    )->fetchAll();
}

function user_files_folder_counts(array $folder_ids): array
{
    $folder_ids = array_values(array_unique(array_filter(array_map('intval', $folder_ids))));
    if (!$folder_ids) return [];

    $marks = sql_marks(count($folder_ids));
    $rows = q(
        'SELECT folder_id,COUNT(*) AS file_count
         FROM plugin_user_files_folder_items
         WHERE folder_id IN (' . $marks . ')
         GROUP BY folder_id',
        $folder_ids
    )->fetchAll();

    $map = [];
    foreach ($rows as $row) $map[(int)$row['folder_id']] = (int)$row['file_count'];
    return $map;
}

function user_files_folder_options(int $selected = 0, bool $include_all = true): string
{
    $folders = user_files_folder_rows();
    $html = '';
    if ($include_all) {
        $html .= '<option value="0"' . ($selected === 0 ? ' selected' : '') . '>全部文件</option>';
    }
    foreach ($folders as $folder) {
        $id = (int)$folder['id'];
        $name = (string)$folder['name'];
        $html .= '<option value="' . $id . '"' . ($selected === $id ? ' selected' : '') . '>' . h($name) . '</option>';
    }
    return $html;
}

function user_files_folder_selector(int $selected = 0): string
{
    $folders = user_files_folder_rows();
    if (!$folders) return '';
    return '<label class="user-files-folder-select"><span>上传到</span><select name="folder_id"><option value="0">不指定（未分类）</option>' .
        user_files_folder_options($selected, false) .
        '</select></label>';
}

function user_files_folder_create_route(array $plugin = []): void
{
    require_post();
    user_files_require_user_center();

    $name = user_files_folder_name((string)($_POST['name'] ?? ''));
    if ($name === '') err('请输入文件夹名称');

    $exists = val(
        'SELECT id FROM plugin_user_files_folders WHERE user_id=? AND name=? LIMIT 1',
        [uid(), $name]
    );
    if ($exists !== false && $exists !== null) err('同名文件夹已存在');

    $now = time();
    q(
        'INSERT INTO plugin_user_files_folders(user_id,name,is_pinned,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?)',
        [uid(), $name, 0, 0, $now, $now]
    );

    set_flash('文件夹已创建');
    go(user_files_url(1, '', 'all'));
}

function user_files_folder_rename_route(array $plugin = []): void
{
    require_post();
    user_files_require_user_center();

    $id = (int)($_POST['folder_id'] ?? 0);
    $folder = user_files_folder_find($id);
    if (!$folder) err('文件夹不存在或无权操作');

    $name = user_files_folder_name((string)($_POST['name'] ?? ''));
    if ($name === '') err('请输入文件夹名称');

    $exists = val(
        'SELECT id FROM plugin_user_files_folders WHERE user_id=? AND name=? AND id<>? LIMIT 1',
        [uid(), $name, $id]
    );
    if ($exists !== false && $exists !== null) err('同名文件夹已存在');

    q(
        'UPDATE plugin_user_files_folders SET name=?,updated_at=? WHERE id=? AND user_id=?',
        [$name, time(), $id, uid()]
    );

    set_flash('文件夹名称已更新');
    go(user_files_url(1, '', 'all', '', 0, $id));
}

function user_files_folder_pin_route(array $plugin = []): void
{
    require_post();
    user_files_require_user_center();

    $id = (int)($_POST['folder_id'] ?? 0);
    $folder = user_files_folder_find($id);
    if (!$folder) err('文件夹不存在或无权操作');

    $pin = !empty($_POST['pin']) ? 1 : 0;
    $sort = $pin ? (int)val('SELECT COALESCE(MAX(sort_order),0)+1 FROM plugin_user_files_folders WHERE user_id=? AND is_pinned=1', [uid()]) : (int)$folder['sort_order'];
    q(
        'UPDATE plugin_user_files_folders SET is_pinned=?,sort_order=?,updated_at=? WHERE id=? AND user_id=?',
        [$pin, $sort, time(), $id, uid()]
    );

    $back = (int)($_POST['back_folder_id'] ?? 0);
    set_flash($pin ? '文件夹已置顶' : '已取消文件夹置顶');
    go(user_files_url(1, '', 'all', '', 0, $back > 0 ? $back : ($pin ? $id : 0)));
}

function user_files_folder_delete_route(array $plugin = []): void
{
    require_post();
    user_files_require_user_center();

    $id = (int)($_POST['folder_id'] ?? 0);
    $folder = user_files_folder_find($id);
    if (!$folder) err('文件夹不存在或无权操作');

    tx(function () use ($id): void {
        q('DELETE FROM plugin_user_files_folder_items WHERE folder_id=?', [$id]);
        q('DELETE FROM plugin_user_files_folders WHERE id=? AND user_id=?', [$id, uid()]);
    });

    set_flash('文件夹已删除，文件已保留在全部文件中');
    go(user_files_url());
}

function user_files_move_route(array $plugin = []): void
{
    require_post();
    user_files_require_user_center();

    $folder_id = (int)($_POST['folder_id'] ?? 0);
    if ($folder_id > 0 && !user_files_folder_find($folder_id)) err('目标文件夹不存在或无权操作');

    $ids = $_POST['ids'] ?? [];
    if (!is_array($ids)) $ids = [$ids];
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $id): bool => $id > 0)));
    if (!$ids) {
        $single = (int)($_POST['id'] ?? 0);
        if ($single > 0) $ids = [$single];
    }
    if (!$ids) err('请选择要移动的文件');

    $marks = sql_marks(count($ids));
    $owned = q(
        'SELECT id FROM app_attachments WHERE user_id=? AND id IN (' . $marks . ')',
        array_merge([uid()], $ids)
    )->fetchAll();
    $owned_ids = array_values(array_map(static fn(array $row): int => (int)$row['id'], $owned));
    if (count($owned_ids) !== count($ids)) err('部分文件不存在或无权操作');

    tx(function () use ($owned_ids, $folder_id): void {
        $marks = sql_marks(count($owned_ids));
        q(
            'DELETE FROM plugin_user_files_folder_items WHERE attachment_id IN (' . $marks . ')',
            $owned_ids
        );
        if ($folder_id <= 0) return;

        $values = [];
        $params = [];
        $now = time();
        foreach ($owned_ids as $attachment_id) {
            $values[] = '(?,?,?)';
            $params[] = $folder_id;
            $params[] = $attachment_id;
            $params[] = $now;
        }
        q(
            'INSERT INTO plugin_user_files_folder_items(folder_id,attachment_id,created_at) VALUES ' . implode(',', $values),
            $params
        );
    });

    set_flash($folder_id > 0 ? '文件已移动到文件夹' : '文件已移出文件夹');
    $back = (int)($_POST['back_folder_id'] ?? 0);
    go(user_files_url(1, '', 'all', '', 0, $back));
}

function user_files_folder_admin_html(int $current_folder_id = 0): string
{
    $folders = user_files_folder_rows();
    $counts = user_files_folder_counts(array_map(static fn(array $row): int => (int)$row['id'], $folders));

    $html = '<section class="user-files-folders">'
        . '<div class="user-files-folders-head"><div><strong>文件夹</strong><span>整理附件，不改变实际存储位置</span></div>'
        . '<form method="post" action="' . h(route_url('user_file_folder_create')) . '" class="user-files-folder-create-form">'
        . form_token()
        . '<input type="text" name="name" maxlength="50" placeholder="新建文件夹" required>'
        . '<button type="submit">新建</button></form></div>';

    if (!$folders) {
        return $html . '<div class="user-files-folders-empty">还没有文件夹，可先创建一个常用分类。</div></section>';
    }

    $html .= '<div class="user-files-folder-list">';
    foreach ($folders as $folder) {
        $id = (int)$folder['id'];
        $name = (string)$folder['name'];
        $active = $id === $current_folder_id;
        $count = $counts[$id] ?? 0;
        $pin = (int)$folder['is_pinned'] === 1;
        $folder_url = user_files_url(1, '', 'all', '', 0, $id);

        $html .= '<article class="user-files-folder-card' . ($active ? ' user-files-folder-card-active' : '') . '">'
            . '<a class="user-files-folder-main" href="' . h($folder_url) . '">'
            . '<span class="user-files-folder-icon">' . '📁' . '</span>'
            . '<span class="user-files-folder-copy"><strong title="' . h($name) . '">' . h($name) . '</strong><small>' . h((string)$count) . ' 个文件' . ($pin ? ' · 已置顶' : '') . '</small></span>'
            . '</a>'
            . '<div class="user-files-folder-actions">'
            . '<form method="post" action="' . h(route_url('user_file_folder_pin')) . '">' . form_token() . '<input type="hidden" name="folder_id" value="' . $id . '"><input type="hidden" name="pin" value="' . ($pin ? '0' : '1') . '"><input type="hidden" name="back_folder_id" value="' . $current_folder_id . '"><button type="submit">' . ($pin ? '取消置顶' : '置顶') . '</button></form>'
            . '<details class="user-files-folder-menu"><summary>管理</summary><div class="user-files-folder-menu-body">'
            . '<form method="post" action="' . h(route_url('user_file_folder_rename')) . '">' . form_token() . '<input type="hidden" name="folder_id" value="' . $id . '"><input type="text" name="name" maxlength="50" value="' . h($name) . '" required><button type="submit">保存名称</button></form>'
            . '<form method="post" action="' . h(route_url('user_file_folder_delete')) . '" data-no-ajax="1" data-confirm="确定删除这个文件夹吗？里面的文件会保留并回到全部文件。">' . form_token() . '<input type="hidden" name="folder_id" value="' . $id . '"><button type="submit" class="user-files-delete">删除文件夹</button></form>'
            . '</div></details>'
            . '</div></article>';
    }
    return $html . '</div></section>';
}

function user_files_url(
    int $page = 1,
    string $query = '',
    string $type = 'all',
    string $view = '',
    int $id = 0,
    int $folder_id = 0,
    string $source = ''
): string {
    $params = [];

    if ($page > 1) $params['p'] = $page;
    if ($query !== '') $params['q'] = $query;
    if ($type !== '' && $type !== 'all') $params['type'] = $type;
    if ($view !== '') $params['view'] = $view;
    if ($id > 0) $params['id'] = $id;
    if ($folder_id > 0) $params['folder'] = $folder_id;
    if ($source !== '') $params['source'] = $source;

    return route_url('user_files', $params);
}

/* =========================================================
 * 插件配置
 *
 * 管理员始终可以进入后台文件管理。
 * 普通用户是否显示“文件”入口，由这里的配置控制。
 * ========================================================= */

function user_files_config(): array
{
    return plugin_config('user_files', [
        'user_center_enabled' => 1,
        'compat_link_exts' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    ]);
}

function user_files_user_center_enabled(): bool
{
    return !empty(user_files_config()['user_center_enabled']);
}

function user_files_require_user_center(): void
{
    need_login();

    if (!can_access_admin() && !user_files_user_center_enabled()) {
        err('管理员已关闭普通用户文件管理', 403);
    }
}

/* =========================================================
 * 当前用户文件
 * ========================================================= */

function user_files_attachment_visible_to_owner(int $attachment_id, int $user_id): bool
{
    if ($attachment_id <= 0 || $user_id <= 0) return false;
    return (int)val(
        'SELECT COUNT(*)
         FROM app_attachments a
         LEFT JOIN plugin_user_files_detached d ON d.attachment_id=a.id
         WHERE a.id=? AND a.user_id=? AND d.attachment_id IS NULL',
        [$attachment_id, $user_id]
    ) > 0;
}

function user_files_detach_attachment(int $attachment_id, int $user_id): void
{
    if ($attachment_id <= 0 || $user_id <= 0) return;
    app_db_upsert(
        'plugin_user_files_detached',
        [
            'attachment_id' => $attachment_id,
            'user_id' => $user_id,
            'detached_at' => time(),
        ],
        ['attachment_id']
    );
}

function user_files_reattach_attachment(int $attachment_id, int $user_id): void
{
    if ($attachment_id <= 0 || $user_id <= 0) return;
    q(
        'DELETE FROM plugin_user_files_detached WHERE attachment_id=? AND user_id=?',
        [$attachment_id, $user_id]
    );
}

function user_files_reference_stats(array $file): array
{
    $attachment_id = (int)($file['id'] ?? 0);
    $owner_id = (int)($file['user_id'] ?? 0);
    if ($attachment_id <= 0 || $owner_id <= 0) return ['total' => 0, 'own' => 0, 'other' => 0];

    if (user_files_reference_index_ready()) {
        $count = (int)val(
            'SELECT COUNT(*)
             FROM plugin_user_files_references r
             INNER JOIN app_attachments a ON a.id=r.attachment_id
             LEFT JOIN app_replies rp ON rp.id=r.reply_id AND r.source_type=\'reply\' AND r.reply_id>0
             LEFT JOIN app_topics t ON t.id=(CASE WHEN r.source_type=\'reply\' THEN rp.topic_id ELSE r.topic_id END)
             WHERE r.attachment_id=?
               AND a.user_id=?
               AND ((r.source_type=\'topic\' AND r.reply_id=0 AND t.id IS NOT NULL AND t.user_id=a.user_id)
                    OR (r.source_type=\'reply\' AND r.reply_id>0 AND rp.id IS NOT NULL AND rp.user_id=a.user_id)
                    )',
            [$attachment_id, $owner_id]
        );
        return ['total' => $count, 'own' => $count, 'other' => 0];
    }

    /* 重建完成前也严格按 attachment_id + 内容作者归属计算，绝不把其他用户的同物理文件算进来。 */
    $references = user_files_references_for_file($file);
    $count = 0;
    foreach ($references as $reference) {
        if ((int)($reference['attachment_id'] ?? 0) !== $attachment_id) continue;
        if ((int)($reference['author_id'] ?? 0) !== $owner_id) continue;
        $count++;
    }
    return ['total' => $count, 'own' => $count, 'other' => 0];
}

function user_files_physical_source_shared(array $file): bool
{
    $hash = (string)($file['hash'] ?? '');
    $file_name = (string)($file['file_name'] ?? '');
    if ($hash === '' || $file_name === '') return true;

    return (int)val(
        'SELECT COUNT(*) FROM app_attachments WHERE hash=? AND file_name=? AND id<>?',
        [$hash, $file_name, (int)$file['id']]
    ) > 0;
}

function user_files_physical_source_referenced(array $file): bool
{
    $hash = (string)($file['hash'] ?? '');
    $file_name = (string)($file['file_name'] ?? '');
    if ($hash === '' || $file_name === '') return true;

    return (int)val(
        "SELECT COUNT(*)
         FROM plugin_user_files_references r
         INNER JOIN app_attachments a ON a.id=r.attachment_id
         WHERE a.hash=? AND a.file_name=?
           AND r.source_type IN ('topic','reply')",
        [$hash, $file_name]
    ) > 0;
}

function user_files_remove_owner_management(int $attachment_id, int $user_id): void
{
    q('DELETE FROM plugin_user_files_folder_items WHERE attachment_id=?', [$attachment_id]);
    user_files_detach_attachment($attachment_id, $user_id);
}

function user_files_find_attachment(int $id): ?array
{
    if ($id <= 0 || uid() <= 0) return null;

    $row = one(
        'SELECT
            id,
            user_id,
            hash,
            file_name,
            original_name,
            ext,
            mime,
            size,
            is_image,
            created_at
         FROM app_attachments a
         WHERE a.id=? AND a.user_id=?
           AND NOT EXISTS (SELECT 1 FROM plugin_user_files_detached d WHERE d.attachment_id=a.id)',
        [$id, uid()]
    );

    return is_array($row) ? $row : null;
}


/* =========================================================
 * 引用检测
 *
 * 当前页最多 30 个文件。
 * 一次批量读取：
 *   - app_topics
 *   - app_replies
 *   - 涉及的 app_topics
 *
 * 不产生“一个文件一次查询”的 N+1。
 * ========================================================= */

function user_files_reference_extract_links(string $body): array
{
    if ($body === '') return [];

    $links = [];
    preg_match_all(
        '~!?\[((?:\\.|[^\]])*)\]\(([^)\s]+)\)~u',
        $body,
        $matches,
        PREG_SET_ORDER
    );

    foreach ($matches as $match) {
        $url = trim((string)($match[2] ?? ''));
        if ($url === '') continue;

        $parsed = parse_url($url);
        $path = is_array($parsed) ? (string)($parsed['path'] ?? '') : '';
        $query = is_array($parsed) ? (string)($parsed['query'] ?? '') : '';
        $fragment = is_array($parsed) ? (string)($parsed['fragment'] ?? '') : '';

        // 普通附件：必须是 attachment 路由，并且 f 是完整的 hash.ext。
        if ($query !== '') {
            $params = [];
            parse_str($query, $params);
            if ((string)($params['a'] ?? '') === 'attachment') {
                $file_name = strtolower(trim((string)($params['f'] ?? '')));
                if (preg_match('/^[a-f0-9]{64}\.[a-z0-9]{1,25}$/', $file_name) === 1) {
                    $links[$file_name] = [
                        'file_name' => $file_name,
                        'label' => (string)($params['name'] ?? ''),
                        'kind' => 'attachment',
                    ];
                    continue;
                }
            }
        }

        // 图片附件：attachment_upload 生成的是 /app/upload/xx/hash.ext 静态地址。
        if ($path !== '' && preg_match('~/app/upload/[a-f0-9]{2}/([a-f0-9]{64}\.[a-z0-9]{1,25})$~i', $path, $m) === 1) {
            $file_name = strtolower($m[1]);
            $links[$file_name] = [
                'file_name' => $file_name,
                'label' => '',
                'kind' => 'image',
            ];
            continue;
        }
    }

    return array_values($links);
}

function user_files_reference_extract_names(string $body): array
{
    return array_values(array_map(
        static fn(array $link): string => (string)$link['file_name'],
        user_files_reference_extract_links($body)
    ));
}

function user_files_claim_attachment_for_link(int $user_id, array $link): int
{
    if ($user_id <= 0) return 0;

    $file_name = strtolower(trim((string)($link['file_name'] ?? '')));
    if (preg_match('/^([a-f0-9]{64})\.([a-z0-9]{1,25})$/', $file_name, $m) !== 1) return 0;
    $hash = strtolower($m[1]);

    $owned = one(
        'SELECT id FROM app_attachments WHERE user_id=? AND hash=? AND file_name=? LIMIT 1',
        [$user_id, $hash, $file_name]
    );
    if (is_array($owned)) {
        user_files_reattach_attachment((int)$owned['id'], $user_id);
        return (int)$owned['id'];
    }

    $path = UPLOAD_DIR . '/' . upload_hash_dir($hash) . '/' . basename($file_name);
    if (!is_file($path)) return 0;

    // 优先复制已有附件记录的元数据；这样“收藏”与原附件完全一致。
    $source = one(
        'SELECT original_name,ext,mime,size,is_image,created_at
         FROM app_attachments
         WHERE hash=? AND file_name=?
         ORDER BY id ASC LIMIT 1',
        [$hash, $file_name]
    );

    $size = (int)filesize($path);
    if ($size < 0) return 0;
    $original = trim((string)($source['original_name'] ?? ''));
    if ($original === '') $original = trim((string)($link['label'] ?? ''));
    if ($original === '') $original = $file_name;
    $original = trim(preg_replace('/[\r\n"\\\/]+/', ' ', basename($original)) ?? '');
    if ($original === '') $original = $file_name;

    $storage_ext = strtolower((string)$m[2]);
    $ext = strtolower((string)($source['ext'] ?? ''));
    if ($ext === '') {
        $ext = $storage_ext;
        if (str_ends_with($ext, '1') && strlen($ext) > 1) $ext = substr($ext, 0, -1);
    }
    if (preg_match('/^[a-z0-9]{1,25}$/', $ext) !== 1) $ext = 'file';

    $mime = strtolower(trim((string)($source['mime'] ?? '')));
    $is_image = !empty($source['is_image']);
    if ($mime === '') {
        $image_exts = ['jpg','jpeg','png','gif','webp','avif','bmp','ico','svg'];
        $is_image = in_array($ext, $image_exts, true);
        $mime = $is_image ? 'image/' . ($ext === 'jpg' ? 'jpeg' : $ext) : 'application/octet-stream';
    }

    $created_at = (int)($source['created_at'] ?? time());
    app_db_insert_ignore('app_attachments', [
        'user_id' => $user_id,
        'hash' => $hash,
        'file_name' => $file_name,
        'original_name' => $original,
        'ext' => $ext,
        'mime' => $mime,
        'size' => $size,
        'is_image' => $is_image ? 1 : 0,
        'created_at' => $created_at,
    ], ['user_id', 'hash']);

    $claimed = one(
        'SELECT id FROM app_attachments WHERE user_id=? AND hash=? AND file_name=? LIMIT 1',
        [$user_id, $hash, $file_name]
    );
    if (!is_array($claimed)) return 0;

    user_files_reattach_attachment((int)$claimed['id'], $user_id);
    return (int)$claimed['id'];
}

function user_files_collect_reference_map_legacy(array $files): array
{
    $map = [];
    foreach ($files as $file) {
        $id = (int)($file['id'] ?? 0);
        if ($id > 0) $map[(string)$id] = [];
    }
    if (!$map) return $map;

    $names = [];
    foreach ($files as $file) {
        $name = strtolower(trim((string)($file['file_name'] ?? '')));
        if ($name !== '') $names[$name] = true;
    }
    if (!$names) return $map;

    foreach (array_chunk(array_keys($names), 30) as $chunk) {
        $conditions = [];
        $params = [];
        foreach ($chunk as $name) {
            $conditions[] = 'body LIKE ?';
            $params[] = '%' . $name . '%';
        }

        $topics = q(
            'SELECT id,user_id,forum_id,title,body,created_at FROM app_topics WHERE ' . implode(' OR ', $conditions),
            $params
        )->fetchAll();
        foreach ($topics as $topic) {
            $author_id = (int)($topic['user_id'] ?? 0);
            foreach (user_files_reference_extract_links((string)($topic['body'] ?? '')) as $link) {
                $name = (string)$link['file_name'];
                if (!in_array($name, $chunk, true)) continue;
                $attachment_id = user_files_claim_attachment_for_link($author_id, $link);
                $key = (string)$attachment_id;
                if ($attachment_id <= 0 || !isset($map[$key])) continue;
                $map[$key][] = [
                    'type' => 'topic',
                    'topic_id' => (int)$topic['id'],
                    'reply_id' => 0,
                    'forum_id' => (int)$topic['forum_id'],
                    'title' => (string)$topic['title'],
                    'created_at' => (int)$topic['created_at'],
                    'attachment_id' => $attachment_id,
                    'author_id' => $author_id,
                ];
            }
        }

        $replies = q(
            'SELECT id,topic_id,user_id,body,created_at FROM app_replies WHERE ' . implode(' OR ', $conditions),
            $params
        )->fetchAll();
        $topic_ids = [];
        foreach ($replies as $reply) {
            $topic_id = (int)($reply['topic_id'] ?? 0);
            if ($topic_id > 0) $topic_ids[$topic_id] = true;
        }
        $topic_map = [];
        foreach (array_chunk(array_keys($topic_ids), 80) as $topic_chunk) {
            if (!$topic_chunk) continue;
            $marks = sql_marks(count($topic_chunk));
            foreach (q('SELECT id,forum_id,title FROM app_topics WHERE id IN (' . $marks . ')', $topic_chunk)->fetchAll() as $topic_row) {
                $topic_map[(int)$topic_row['id']] = $topic_row;
            }
        }
        foreach ($replies as $reply) {
            $topic_id = (int)($reply['topic_id'] ?? 0);
            $topic = $topic_map[$topic_id] ?? null;
            if (!$topic) continue;
            $author_id = (int)($reply['user_id'] ?? 0);
            foreach (user_files_reference_extract_links((string)($reply['body'] ?? '')) as $link) {
                $name = (string)$link['file_name'];
                if (!in_array($name, $chunk, true)) continue;
                $attachment_id = user_files_claim_attachment_for_link($author_id, $link);
                $key = (string)$attachment_id;
                if ($attachment_id <= 0 || !isset($map[$key])) continue;
                $map[$key][] = [
                    'type' => 'reply',
                    'topic_id' => $topic_id,
                    'reply_id' => (int)$reply['id'],
                    'forum_id' => (int)$topic['forum_id'],
                    'title' => (string)$topic['title'],
                    'created_at' => (int)$reply['created_at'],
                    'attachment_id' => $attachment_id,
                    'author_id' => $author_id,
                ];
            }
        }
    }

    foreach ($map as $id => $references) {
        $seen = [];
        $map[$id] = array_values(array_filter($references, static function (array $reference) use (&$seen): bool {
            $key = (int)$reference['topic_id'] . ':' . (int)$reference['reply_id'] . ':' . (int)($reference['attachment_id'] ?? 0);
            if (isset($seen[$key])) return false;
            $seen[$key] = true;
            return true;
        }));
    }
    return $map;
}

/* =========================================================
 * 公共抽象 API
 *
 * 其它插件不得直接依赖 user_files 数据表或内部函数。
 * 服务端插件间交互统一通过 user_files.api Hook；浏览器/外部
 * UI 可通过 user_files_api Route。公开对象只暴露稳定字段。
 *
 * Hook 调用约定：
 *   $result = hook('user_files.api', null, [
 *       'op' => 'file.recent',
 *   ]);
 *
 * 不使用 fire() 获取查询结果，因为 fire() 会丢弃返回值。
 * ========================================================= */

function user_files_api_file(array $file): array
{
    $attachment_id = (int)($file['id'] ?? $file['attachment_id'] ?? 0);
    if ($attachment_id <= 0) return [];

    $name = user_files_file_label($file);
    $url = user_files_attachment_url($file);
    $download_url = user_files_download_url($file);
    $markdown = user_files_insert_markdown($file);

    return [
        'id' => $attachment_id,
        'attachment_id' => $attachment_id,
        'owner_id' => (int)($file['user_id'] ?? $file['owner_id'] ?? 0),
        'name' => $name,
        'original_name' => (string)($file['original_name'] ?? ''),
        'file_name' => (string)($file['file_name'] ?? ''),
        'ext' => strtolower((string)($file['ext'] ?? '')),
        'mime' => (string)($file['mime'] ?? ''),
        'size' => (int)($file['size'] ?? 0),
        'is_image' => !empty($file['is_image']),
        'created_at' => (int)($file['created_at'] ?? 0),
        'url' => $url,
        'download_url' => $download_url,
        'markdown' => $markdown,
    ];
}

function user_files_api_normalize_source_type(string $source_type): string
{
    $source_type = strtolower(trim($source_type));
    if ($source_type === 'topic' || $source_type === 'reply') return $source_type;
    if (preg_match('/^[a-z0-9_]+\.[a-z0-9_:-]{1,48}$/', $source_type) !== 1) return '';
    return $source_type;
}

function user_files_api_normalize_source_url(string $url): string
{
    $url = trim($url);
    if ($url === '') return '';
    if (preg_match('/[\x00-\x20<>"\']/', $url) === 1) return '';

    $parts = parse_url($url);
    if ($parts === false) return '';
    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    if ($scheme !== '' && !in_array($scheme, ['http', 'https'], true)) return '';
    if ($scheme === '' && !str_starts_with($url, '/')) return '';

    return cut($url, 255);
}

function user_files_api_source_text(string $value, int $max = 255): string
{
    $value = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $value) ?? $value);
    return cut($value, $max);
}

function user_files_api_recent(int $limit = 5, bool $include_pinned = true, int $user_id = 0): array
{
    $user_id = $user_id > 0 ? $user_id : uid();
    if ($user_id <= 0) return ['files' => [], 'folders' => []];
    $limit = max(1, min(50, $limit));

    $rows = q(
        'SELECT id,user_id,hash,file_name,original_name,ext,mime,size,is_image,created_at
         FROM app_attachments a
         WHERE a.user_id=?
           AND NOT EXISTS (SELECT 1 FROM plugin_user_files_detached d WHERE d.attachment_id=a.id)
         ORDER BY a.created_at DESC,id DESC
         LIMIT ' . $limit,
        [$user_id]
    )->fetchAll();

    $files = [];
    foreach ($rows as $row) {
        $item = user_files_api_file($row);
        if ($item) $files[] = $item;
    }

    $folders = [];
    if ($include_pinned) {
        $pinned = q(
            'SELECT id,name,is_pinned,sort_order
             FROM plugin_user_files_folders
             WHERE user_id=? AND is_pinned=1
             ORDER BY sort_order ASC,id ASC
             LIMIT 3',
            [$user_id]
        )->fetchAll();

        if ($pinned) {
            $folder_ids = array_values(array_map(static fn(array $row): int => (int)$row['id'], $pinned));
            $marks = sql_marks(count($folder_ids));
            $folder_file_rows = q(
                'SELECT fi.folder_id,a.id,a.user_id,a.hash,a.file_name,a.original_name,a.ext,a.mime,a.size,a.is_image,a.created_at
                 FROM plugin_user_files_folder_items fi
                 INNER JOIN app_attachments a ON a.id=fi.attachment_id AND a.user_id=?
                 LEFT JOIN plugin_user_files_detached d ON d.attachment_id=a.id
                 WHERE d.attachment_id IS NULL AND fi.folder_id IN (' . $marks . ')
                 ORDER BY fi.folder_id ASC,a.created_at DESC,a.id DESC',
                array_merge([$user_id], $folder_ids)
            )->fetchAll();

            $folder_map = [];
            foreach ($folder_file_rows as $row) {
                $folder_id = (int)$row['folder_id'];
                if (!isset($folder_map[$folder_id])) $folder_map[$folder_id] = [];
                if (count($folder_map[$folder_id]) < 5) {
                    $item = user_files_api_file($row);
                    if ($item) $folder_map[$folder_id][] = $item;
                }
            }

            foreach ($pinned as $folder) {
                $id = (int)$folder['id'];
                $folders[] = [
                    'id' => $id,
                    'name' => (string)$folder['name'],
                    'is_pinned' => true,
                    'sort_order' => (int)$folder['sort_order'],
                    'files' => $folder_map[$id] ?? [],
                ];
            }
        }
    }

    return ['files' => $files, 'folders' => $folders];
}

function user_files_api_attachment(int $attachment_id, bool $require_current_user = true): ?array
{
    if ($attachment_id <= 0) return null;

    $sql =
        'SELECT
            a.id,a.user_id,a.hash,a.file_name,a.original_name,a.ext,a.mime,a.size,a.is_image,a.created_at
         FROM app_attachments a
         WHERE a.id=?';
    $params = [$attachment_id];

    if ($require_current_user) {
        if (uid() <= 0) return null;
        $sql .= ' AND a.user_id=?';
        $params[] = uid();
    }

    $sql .= ' AND NOT EXISTS (SELECT 1 FROM plugin_user_files_detached d WHERE d.attachment_id=a.id)';

    $row = one($sql, $params);
    return is_array($row) ? $row : null;
}

function user_files_api_file_get(int $attachment_id, bool $trusted = false): array
{
    $file = user_files_api_attachment($attachment_id, !$trusted);
    return $file ? user_files_api_file($file) : [];
}

function user_files_api_file_can_use(int $attachment_id, bool $trusted = false): array
{
    $file = user_files_api_attachment($attachment_id, !$trusted);
    if (!$file) return ['ok' => false, 'reason' => 'not_found'];
    return [
        'ok' => true,
        'attachment_id' => $attachment_id,
        'owner_id' => (int)$file['user_id'],
    ];
}

/**
 * 将文件标记为“最近使用”。
 *
 * 这里故意只更新指定 attachment_id 对应的 app_attachments 记录，
 * 不按 hash 批量更新，因此同一个物理文件即使被其他用户拥有，
 * 也不会把其他用户的最近文件日期一起刷新。
 */
function user_files_api_file_use(int $attachment_id, bool $trusted = false): array
{
    if ($attachment_id <= 0) return ['ok' => false, 'reason' => 'invalid_attachment'];

    $file = user_files_api_attachment($attachment_id, !$trusted);
    if (!$file) return ['ok' => false, 'reason' => 'not_found'];

    $owner_id = (int)($file['user_id'] ?? 0);
    if ($owner_id <= 0) return ['ok' => false, 'reason' => 'not_found'];

    $now = time();
    $updated = q(
        'UPDATE app_attachments SET created_at=? WHERE id=? AND user_id=?',
        [$now, $attachment_id, $owner_id]
    )->rowCount();

    if ($updated <= 0) return ['ok' => false, 'reason' => 'not_found'];

    return [
        'ok' => true,
        'attachment_id' => $attachment_id,
        'owner_id' => $owner_id,
        'created_at' => $now,
    ];
}

function user_files_reference_index_ready(): bool
{
    if (setting('plugin_user_files_reference_index_ready', '0') !== '1') return false;
    // 数据库表异常缺失时，立即退回 legacy 扫描，避免页面请求直接触发 PDOException。
    return app_db_table_exists(db(), db_driver(), 'plugin_user_files_references');
}

function user_files_reference_count_map(array $files): array
{
    $map = [];
    $ids = [];
    foreach ($files as $file) {
        $id = (int)($file['id'] ?? 0);
        if ($id > 0) {
            $ids[$id] = true;
            $map[(string)$id] = 0;
        }
    }
    $ids = array_keys($ids);
    if (!$ids) return $map;

    if (!user_files_reference_index_ready()) {
        /*
         * 索引尚未完成时只对当前分页的文件做兼容扫描。
         * 文件中心不会因此一次性扫描用户全部文件。
         */
        $legacy = user_files_collect_reference_map_legacy($files);
        foreach ($legacy as $id => $references) $map[$id] = count($references);
        return $map;
    }

    foreach (array_chunk($ids, 200) as $chunk) {
        $marks = sql_marks(count($chunk));
        $rows = q(
            'SELECT r.attachment_id,COUNT(*) AS reference_count
             FROM plugin_user_files_references r
             INNER JOIN app_attachments a ON a.id=r.attachment_id
             WHERE r.attachment_id IN (' . $marks . ')
               AND (
                    (r.source_type=\'topic\' AND r.reply_id=0 AND EXISTS (
                        SELECT 1 FROM app_topics t
                        WHERE t.id=r.topic_id AND t.user_id=a.user_id
                    ))
                    OR
                    (r.source_type=\'reply\' AND r.reply_id>0 AND EXISTS (
                        SELECT 1 FROM app_replies rp
                        WHERE rp.id=r.reply_id AND rp.user_id=a.user_id
                    ))
               )
             GROUP BY r.attachment_id',
            $chunk
        )->fetchAll();
        foreach ($rows as $row) {
            $id = (string)(int)($row['attachment_id'] ?? 0);
            if (isset($map[$id])) $map[$id] = (int)$row['reference_count'];
        }
    }
    return $map;
}

function user_files_collect_reference_map(array $files): array
{
    if (!user_files_reference_index_ready()) {
        return user_files_collect_reference_map_legacy($files);
    }

    $ids = [];
    $map = [];
    foreach ($files as $file) {
        $id = (int)($file['id'] ?? 0);
        if ($id > 0) {
            $ids[$id] = true;
            $map[(string)$id] = [];
        }
    }
    $ids = array_keys($ids);
    if (!$ids) return $map;

    foreach (array_chunk($ids, 100) as $chunk) {
        $marks = sql_marks(count($chunk));
        $rows = q(
            'SELECT r.attachment_id,r.source_type,r.source_id,r.topic_id,r.reply_id,r.source_url,r.source_title,r.source_label,r.created_at,
                    a.user_id,
                    t.forum_id,t.title,t.user_id AS topic_author_id,
                    rp.topic_id AS reply_topic_id,rp.created_at AS reply_created_at,rp.user_id AS reply_author_id
             FROM plugin_user_files_references r
             INNER JOIN app_attachments a ON a.id=r.attachment_id
             LEFT JOIN app_replies rp ON rp.id=r.reply_id AND r.source_type=\'reply\' AND r.reply_id>0
             LEFT JOIN app_topics t ON t.id=(CASE WHEN r.source_type=\'reply\' THEN rp.topic_id ELSE r.topic_id END)
             WHERE r.attachment_id IN (' . $marks . ')
               AND (
                    (r.source_type=\'topic\' AND r.reply_id=0 AND t.id IS NOT NULL AND t.user_id=a.user_id)
                    OR (r.source_type=\'reply\' AND r.reply_id>0 AND rp.id IS NOT NULL AND rp.user_id=a.user_id)
               )',
            $chunk
        )->fetchAll();

        foreach ($rows as $row) {
            $type = (string)($row['source_type'] ?? '');
            $source_id = (int)($row['source_id'] ?? 0);
            $topic_id = (int)($row['topic_id'] ?? 0);
            $reply_id = (int)($row['reply_id'] ?? 0);
            if ($type === 'reply' && $topic_id <= 0) {
                $topic_id = (int)($row['reply_topic_id'] ?? 0);
            }
            $url = (string)($row['source_url'] ?? '');
            if ($url === '' && ($type === 'topic' || $type === 'reply')) {
                $url = user_files_reference_url($topic_id, $reply_id);
            }
            $title = (string)($row['source_title'] ?? '');
            if ($title === '') $title = (string)($row['title'] ?? '');
            $label = (string)($row['source_label'] ?? '');
            if ($label === '') $label = $type === 'reply' ? '回帖' : ($type === 'topic' ? '主题' : $type);

            $id = (string)(int)$row['attachment_id'];
            if (!isset($map[$id])) $map[$id] = [];
            $map[$id][] = [
                'type' => $type,
                'source_type' => $type,
                'source_id' => $source_id,
                'topic_id' => $topic_id,
                'reply_id' => $reply_id,
                'forum_id' => (int)($row['forum_id'] ?? 0),
                'title' => $title,
                'label' => $label,
                'url' => $url,
                'created_at' => (int)($row['reply_created_at'] ?? $row['created_at']),
                'attachment_id' => (int)$row['attachment_id'],
                'author_id' => $type === 'reply'
                    ? (int)($row['reply_author_id'] ?? 0)
                    : ($type === 'topic' ? (int)($row['topic_author_id'] ?? 0) : 0),
            ];
        }
    }
    return $map;
}

function user_files_references_for_file(array $file): array
{
    $map = user_files_collect_reference_map([$file]);
    return $map[(string)(int)($file['id'] ?? 0)] ?? [];
}

/* =========================================================
 * 引用索引维护
 *
 * 保存主题/回帖时只解析当前正文一次，并把引用关系写入插件表。
 * 页面展示不再扫描 app_topics/app_replies.body。
 * ========================================================= */

function user_files_reference_sync_content(string $kind, int $id, string $body, int $topic_id = 0): void
{
    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return;
    if ($id <= 0 || ($kind !== 'topic' && $kind !== 'reply')) return;

    $author_id = $kind === 'topic'
        ? (int)val('SELECT user_id FROM app_topics WHERE id=? LIMIT 1', [$id])
        : (int)val('SELECT user_id FROM app_replies WHERE id=? LIMIT 1', [$id]);
    if ($author_id <= 0) return;

    /*
     * 只在“本次保存真正新增了引用关系”时更新最近文件日期。
     * 反复编辑同一主题/回帖不会不断刷新日期；同时 UPDATE 严格限制
     * 为当前正文作者自己的 attachment 记录，不会刷新其他用户拥有的同文件。
     */
    $old_rows = q(
        'SELECT attachment_id
         FROM plugin_user_files_references
         WHERE source_type=? AND source_id=?',
        [$kind, $id]
    )->fetchAll();
    $old_attachment_ids = [];
    foreach ($old_rows as $old_row) {
        $old_id = (int)($old_row['attachment_id'] ?? 0);
        if ($old_id > 0) $old_attachment_ids[$old_id] = true;
    }

    $links = user_files_reference_extract_links($body);
    $attachment_ids = [];
    foreach ($links as $link) {
        $attachment_id = user_files_claim_attachment_for_link($author_id, $link);
        if ($attachment_id > 0) $attachment_ids[$attachment_id] = true;
    }
    $attachment_ids = array_keys($attachment_ids);

    $new_attachment_ids = [];
    foreach ($attachment_ids as $attachment_id) {
        $attachment_id = (int)$attachment_id;
        if ($attachment_id > 0 && !isset($old_attachment_ids[$attachment_id])) {
            $new_attachment_ids[] = $attachment_id;
        }
    }

    tx(function () use ($kind, $id, $topic_id, $attachment_ids, $new_attachment_ids, $author_id): void {
        if ($kind === 'topic') {
            q("DELETE FROM plugin_user_files_references WHERE source_type='topic' AND source_id=?", [$id]);
        } else {
            q("DELETE FROM plugin_user_files_references WHERE source_type='reply' AND source_id=?", [$id]);
        }
        if (!$attachment_ids) return;

        $values = [];
        $params = [];
        $now = time();
        foreach ($attachment_ids as $attachment_id) {
            $values[] = '(?,?,?,?,?,?,?,?,?)';
            $params[] = (int)$attachment_id;
            $params[] = $kind;
            $params[] = $id;
            $params[] = $kind === 'topic' ? $id : $topic_id;
            $params[] = $kind === 'reply' ? $id : 0;
            $params[] = '';
            $params[] = '';
            $params[] = '';
            $params[] = $now;
        }
        q(
            'INSERT INTO plugin_user_files_references(attachment_id,source_type,source_id,topic_id,reply_id,source_url,source_title,source_label,created_at) VALUES ' . implode(',', $values),
            $params
        );

        if ($new_attachment_ids) {
            $marks = sql_marks(count($new_attachment_ids));
            q(
                'UPDATE app_attachments
                 SET created_at=?
                 WHERE user_id=? AND id IN (' . $marks . ')',
                array_merge([time(), $author_id], $new_attachment_ids)
            );
        }
    });
}

function user_files_reference_rebuild_batch(string $kind, int $cursor, int $limit = 150): array
{
    // install/cron historically stores plural phase names (topics/replies),
    // while this function originally compared against singular names.
    // Normalize here so the rebuild always scans the intended table.
    $kind = strtolower(trim($kind));
    if ($kind === 'topics') $kind = 'topic';
    if ($kind === 'replies') $kind = 'reply';

    if (!app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) return ['done' => false, 'cursor' => $cursor, 'count' => 0];
    if ($kind === 'topic') {
        $rows = q(
            'SELECT id,user_id,body FROM app_topics WHERE id>? ORDER BY id ASC LIMIT ?',
            [$cursor, $limit]
        )->fetchAll();
    } else {
        $rows = q(
            'SELECT id,topic_id,user_id,body FROM app_replies WHERE id>? ORDER BY id ASC LIMIT ?',
            [$cursor, $limit]
        )->fetchAll();
    }

    if (!$rows) return ['done' => true, 'cursor' => $cursor, 'count' => 0];

    foreach ($rows as $row) {
        $id = (int)$row['id'];
        $body = (string)($row['body'] ?? '');
        $author_id = (int)($row['user_id'] ?? 0);
        $topic_id = $kind === 'reply' ? (int)($row['topic_id'] ?? 0) : $id;
        $links = user_files_reference_extract_links($body);
        $attachment_ids = [];
        foreach ($links as $link) {
            $attachment_id = user_files_claim_attachment_for_link($author_id, $link);
            if ($attachment_id > 0) $attachment_ids[$attachment_id] = true;
        }
        $attachment_ids = array_keys($attachment_ids);

        tx(function () use ($kind, $id, $topic_id, $attachment_ids): void {
            if ($kind === 'topic') {
                q("DELETE FROM plugin_user_files_references WHERE source_type='topic' AND source_id=?", [$id]);
            } else {
                q("DELETE FROM plugin_user_files_references WHERE source_type='reply' AND source_id=?", [$id]);
            }
            if (!$attachment_ids) return;

            $values = [];
            $params = [];
            $now = time();
            foreach ($attachment_ids as $attachment_id) {
                $values[] = '(?,?,?,?,?,?,?,?,?)';
                $params[] = (int)$attachment_id;
                $params[] = $kind;
                $params[] = $id;
                $params[] = $topic_id;
                $params[] = $kind === 'reply' ? $id : 0;
                $params[] = '';
                $params[] = '';
                $params[] = '';
                $params[] = $now;
            }
            q(
                'INSERT INTO plugin_user_files_references(attachment_id,source_type,source_id,topic_id,reply_id,source_url,source_title,source_label,created_at) VALUES ' . implode(',', $values),
                $params
            );
        });
    }

    return [
        'done' => count($rows) < $limit,
        'cursor' => (int)$rows[count($rows) - 1]['id'],
        'count' => count($rows),
    ];
}

function user_files_reference_rebuild_cron(array $plugin = [], array $task = []): string
{
    if (user_files_reference_index_ready()) return 'reference index ready';

    $phase = setting('plugin_user_files_reference_rebuild_phase', 'topics');
    $cursor = max(0, (int)setting('plugin_user_files_reference_rebuild_cursor', '0'));
    if (!in_array($phase, ['topics', 'replies'], true)) $phase = 'topics';

    $result = user_files_reference_rebuild_batch($phase, $cursor, 150);
    if (!$result['done']) {
        save_settings_values([
            'plugin_user_files_reference_rebuild_phase' => $phase,
            'plugin_user_files_reference_rebuild_cursor' => (string)$result['cursor'],
        ]);
        return $phase . ': ' . (int)$result['count'];
    }

    if ($phase === 'topics') {
        save_settings_values([
            'plugin_user_files_reference_rebuild_phase' => 'replies',
            'plugin_user_files_reference_rebuild_cursor' => '0',
        ]);
        return 'topics complete';
    }

    save_settings_values([
        'plugin_user_files_reference_index_ready' => '1',
        'plugin_user_files_reference_rebuild_phase' => 'done',
        'plugin_user_files_reference_rebuild_cursor' => (string)$result['cursor'],
    ]);
    return 'reference index ready';
}

function user_files_reference_cron_interval(): int
{
    return 60;
}

function user_files_reference_url(
    int $topic_id,
    int $reply_id = 0
): string {
    if ($topic_id <= 0) return '';

    if ($reply_id > 0) {
        return route_url('topic', [
            'id' => $topic_id,
            'replyid' => $reply_id,
        ]) . '#post-' . $reply_id;
    }

    /*
     * 核心主题主楼的 id 是主题自身 id。
     */
    return route_url('topic', [
        'id' => $topic_id,
    ]) . '#post-' . $topic_id;
}


/* =========================================================
 * 用户主页完整 Tab Bar
 *
 * 与核心 user_page/topic_index_page 的 profile_tabs
 * 保持同一套结构：
 *
 * 主题 | 回帖 | 通知 | 文件 | 设置 | 后台
 *
 * 设置、后台使用 tab-mobile-action，
 * 因此 PC 端与移动端行为保持核心设计。
 * ========================================================= */

function user_files_profile_tab_bar(
    int $user_id,
    string $active = 'files'
): string {
    if ($user_id <= 0) return '';

    $items = [
        'topics' => [
            'label' => '主题',
            'href' => route_url('user', [
                'id' => $user_id,
                'tab' => 'topics',
            ]),
        ],

        'replies' => [
            'label' => '回帖',
            'href' => route_url('user', [
                'id' => $user_id,
                'tab' => 'replies',
            ]),
        ],

        'notifications' => [
            'label' => '通知',
            'href' => route_url('user', [
                'id' => $user_id,
                'tab' => 'notifications',
            ]),
        ],

        'files' => [
            'label' => '文件',
            'href' => route_url('user_files'),
        ],

        'profile_settings' => [
            'label' => '设置',
            'href' => route_url('profile'),
            'class' => 'tab-mobile-action',
        ],
    ];

    if (can_access_admin()) {
        $items['admin'] = [
            'label' => '后台',
            'href' => route_url('admin'),
            'class' => 'tab-mobile-action tab-line-end',
        ];
    }

    return tab_bar_html(
        $items,
        $active,
        'user-profile-tabs'
    );
}


/* =========================================================
 * user.profile_tabs
 *
 * 这里真正把“文件”加入核心用户主页 Tab。
 *
 * 因此核心：
 *
 * <div class="profile-toolbar">
 *   <div class="tab-bar">
 *      主题
 *      回帖
 *      通知
 *      文件
 *      设置
 *      后台
 *   </div>
 * </div>
 *
 * ========================================================= */

function user_files_profile_tabs(
    mixed $value,
    array $ctx
): mixed {
    if (!is_array($value)) return $value;

    if (empty($ctx['self'])) {
        return $value;
    }

    if (!can_access_admin() && !user_files_user_center_enabled()) {
        return $value;
    }

    $user = $ctx['user'] ?? null;

    if (!is_array($user)) {
        return $value;
    }

    $value['files'] = [
        'label' => '文件',
        'href' => route_url('user_files'),
    ];

    return $value;
}


/* =========================================================
 * user.menu_links
 *
 * 核心 sidebar_user_card_html() 会把这里的内容放进：
 *
 * <div class="user-links" data-slot="user.menu_links">
 *
 * mobile_menu_content_html() 也会读取同一个 Hook。
 *
 * 所以这里不用另外写移动端菜单。
 * ========================================================= */

function user_files_menu_links(
    mixed $value,
    array $ctx
): mixed {
    if (!is_array($value)) return $value;

    if (empty($ctx['self'])) {
        return $value;
    }

    if (!can_access_admin() && !user_files_user_center_enabled()) {
        return $value;
    }

    $value[] = [
        'text' => '我的文件',
        'url' => route_url('user_files'),
        'icon' => 'pages',
    ];

    return $value;
}


/* =========================================================
 * 文件列表过滤 Tab
 *
 * 这是“文件中心内部”的筛选 Tab。
 *
 * 与用户主页的 profile Tab 不冲突：
 *
 * 第一层：
 *   主题 | 回帖 | 通知 | 文件 | 设置 | 后台
 *
 * 文件页面第二层：
 *   全部文件 | 图片
 *
 * ========================================================= */

function user_files_filter_tabs(
    string $active,
    string $query,
    int $folder_id = 0,
    string $source = ''
): string {
    return tab_bar_html(
        [
            'all' => [
                'label' => '全部文件',
                'href' => user_files_url(1, $query, 'all', '', 0, $folder_id),
            ],
            'images' => [
                'label' => '图片',
                'href' => user_files_url(1, $query, 'images', '', 0, $folder_id),
            ],
        ],
        $active,
        'user-files-filter-tabs'
    );
}

/* =========================================================
 * 纯上传入口
 *
 * 不改动 attachment_upload 1.0.14。
 * 如果附件上传插件存在，则直接复用其安全上传、配额、扩展名
 * 白名单及存储逻辑；本入口只负责“上传到文件中心”，不插入帖子。
 * ========================================================= */

function user_files_upload_json(bool $ok, array $payload = [], int $status = 200): never
{
    if (ob_get_level() > 0) {
        ob_end_clean();
    }

    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(
        array_merge(['ok' => $ok ? 1 : 0], $payload),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

function user_files_upload_normalize_files(array $input): array
{
    $files = [];

    if (!isset($input['name'])) return $files;

    if (is_array($input['name'])) {
        $count = count($input['name']);
        for ($i = 0; $i < $count; $i++) {
            $files[] = [
                'name' => $input['name'][$i] ?? '',
                'type' => $input['type'][$i] ?? '',
                'tmp_name' => $input['tmp_name'][$i] ?? '',
                'error' => $input['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                'size' => $input['size'][$i] ?? 0,
            ];
        }
        return $files;
    }

    return [$input];
}

function user_files_upload_one(array $file, int $folder_id): array
{
    $upload_hash = '';
    $tmp_name = (string)($file['tmp_name'] ?? '');

    if ($tmp_name !== '' && is_file($tmp_name)) {
        $hash = hash_file('sha256', $tmp_name);
        if (is_string($hash)) $upload_hash = strtolower($hash);
    }

    $existing_attachment_id = 0;
    if (preg_match('/^[a-f0-9]{64}$/', $upload_hash) === 1) {
        $existing_attachment_id = (int)val(
            'SELECT id FROM app_attachments WHERE user_id=? AND hash=? LIMIT 1',
            [uid(), $upload_hash]
        );
    }

    ob_start();
    try {
        $markdown = attachment_upload_markdown($file);
    } catch (Throwable $e) {
        if (ob_get_level() > 0) ob_end_clean();
        debug_log_write('用户文件中心上传失败', $e);
        throw $e;
    }
    if (ob_get_level() > 0) ob_end_clean();

    $attachment_id = 0;
    if (preg_match('/^[a-f0-9]{64}$/', $upload_hash) === 1) {
        $attachment_id = (int)val(
            'SELECT id FROM app_attachments WHERE user_id=? AND hash=? LIMIT 1',
            [uid(), $upload_hash]
        );
    }

    if ($attachment_id > 0) {
        user_files_reattach_attachment($attachment_id, uid());
    }

    if ($attachment_id > 0 && $folder_id > 0) {
        app_db_upsert(
            'plugin_user_files_folder_items',
            [
                'folder_id' => $folder_id,
                'attachment_id' => $attachment_id,
                'created_at' => time(),
            ],
            ['attachment_id']
        );
    }

    return [
        'markdown' => (string)$markdown,
        'attachment_id' => $attachment_id,
        'already_exists' => $existing_attachment_id > 0 && $existing_attachment_id === $attachment_id,
    ];
}

/* =========================================================
 * 纯上传入口
 *
 * 这里把“纯上传”彻底独立成文件上传 API：
 * - 一个请求可以接收一个或多个文件；
 * - 每个文件独立处理，单个失败不会阻止后续文件；
 * - 成功结果始终返回 attachment_id + markdown；
 * - 仍由 attachment_upload 负责真实上传、安全检查、配额和存储；
 * - folder 只是插件自己的归类关系，不改变真实文件位置。
 * ========================================================= */
function user_files_upload_route(array $plugin = []): void
{
    require_post();
    user_files_require_user_center();

    if (!function_exists('attachment_upload_markdown')) {
        user_files_upload_json(false, ['message' => '附件上传插件未启用，暂时无法上传文件'], 503);
    }

    $input = $_FILES['attachment'] ?? null;
    if (!is_array($input)) {
        user_files_upload_json(false, ['message' => '请选择要上传的文件'], 400);
    }

    $folder_id = (int)($_POST['folder_id'] ?? 0);
    if ($folder_id > 0 && !user_files_folder_find($folder_id)) {
        user_files_upload_json(false, ['message' => '目标文件夹不存在或无权操作'], 403);
    }

    $files = user_files_upload_normalize_files($input);
    if (!$files) {
        user_files_upload_json(false, ['message' => '请选择要上传的文件'], 400);
    }

    $results = [];
    $success = 0;

    foreach ($files as $file) {
        $name = trim((string)($file['name'] ?? ''));
        if ($name === '') $name = '未命名文件';

        try {
            $result = user_files_upload_one($file, $folder_id);
            $results[] = [
                'ok' => 1,
                'name' => $name,
                'markdown' => $result['markdown'],
                'attachment_id' => (int)$result['attachment_id'],
                'already_exists' => !empty($result['already_exists']) ? 1 : 0,
            ];
            $success++;
        } catch (Throwable $e) {
            $message = database_error($e)
                ? database_error_message()
                : ($e->getMessage() ?: '上传失败');
            $results[] = [
                'ok' => 0,
                'name' => $name,
                'message' => $message,
            ];
        }
    }

    user_files_upload_json(
        $success > 0,
        [
            'message' => $success === count($results)
                ? '全部文件上传成功'
                : ($success > 0 ? '部分文件上传成功' : '文件上传失败'),
            'success' => $success,
            'total' => count($results),
            'results' => $results,
        ],
        $success > 0 ? 200 : 422
    );
}

function user_files_upload_page(): string
{
    user_files_require_user_center();

    $folder_id = (int)($_GET['folder'] ?? 0);
    if ($folder_id > 0 && !user_files_folder_find($folder_id)) $folder_id = 0;
    $folder_select = user_files_folder_selector($folder_id);

    $main =
        '<div class="profile-toolbar user-files-profile-toolbar">' .
        user_files_profile_tab_bar(uid(), 'files') .
        '</div>' .
        '<section class="user-files-upload-page">' .
        '<div class="user-files-upload-card">' .
        '<div class="user-files-upload-head">' .
        '<div><h1>上传文件</h1><p>文件会保存到你的附件文件中心，不会自动插入主题或回帖；上传完成后可直接复制插入链接。</p></div>' .
        '<a href="' . h(user_files_url(1, '', 'all', '', 0, $folder_id)) . '">返回文件管理</a>' .
        '</div>' .
        '<form method="post" enctype="multipart/form-data" action="' . h(route_url('user_file_upload')) . '" data-user-files-upload-form>' .
        form_token() .
        ($folder_select !== '' ? '<div class="user-files-upload-folder">' . $folder_select . '</div>' : '') .
        '<label class="user-files-upload-drop"><input type="file" name="attachment" multiple data-user-files-upload-input><strong>' . svg_icon('upload') . '<span>选择文件上传</span></strong><small>支持一次选择多个文件；实际大小、配额和扩展名限制以附件上传插件设置为准。</small></label>' .
        '<div class="user-files-upload-actions"><button type="submit">开始上传</button><span data-user-files-upload-status aria-live="polite"></span></div>' .
        '</form>' .
        '<div class="user-files-upload-result" data-user-files-upload-result hidden></div>' .
        '</div></section>';

    return $main;
}

/* =========================================================
 * 删除
 * ========================================================= */

function user_files_delete_route(
    array $plugin = []
): void {
    require_post();
    need_login();

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) err('文件参数错误');

    $file = user_files_find_attachment($id);
    if (!$file) err('文件不存在或无权操作');

    $stats = user_files_reference_stats($file);

    /*
     * 外部插件的引用不写入本插件 forum reference index，而是通过
     * user_files.reference_tabs 提供独立引用入口。因此删除时不能只看
     * topic/reply 引用：只要外部插件仍返回该文件的引用 Tab，就必须保留
     * app_attachments 和物理文件，否则外部引用页会立即失效。
     */
    $external_tabs = user_files_external_reference_tabs($id, $file, false);
    $has_external_reference = false;
    foreach ($external_tabs as $external_tab) {
        if (!is_array($external_tab)) continue;
        $href = trim((string)($external_tab['href'] ?? ''));
        $label = trim((string)($external_tab['label'] ?? ''));
        if ($href !== '' && $label !== '') {
            $has_external_reference = true;
            break;
        }
    }

    /*
     * 本人自己仍在帖子/回帖中使用：不能删除，也不能隐藏，避免本人内容断链。
     */
    if ($stats['own'] > 0) {
        err('该文件仍被你自己的帖子或回帖引用，请先移除引用');
    }

    $hash = (string)$file['hash'];
    $file_name = (string)$file['file_name'];
    if (
        preg_match('/^[a-f0-9]{64}$/', $hash) !== 1 ||
        preg_match('/^[a-f0-9]{64}\.[a-z0-9]{1,25}$/', $file_name) !== 1 ||
        !str_starts_with($file_name, $hash . '.')
    ) {
        err('文件信息异常');
    }

    /*
     * 还有其他用户或外部插件的引用：只从“我的文件”管理层移除。
     * app_attachments 和物理文件必须保留，引用方仍可正常访问。
     */
    if ($stats['other'] > 0 || $has_external_reference) {
        tx(function () use ($id): void {
            user_files_remove_owner_management($id, uid());
        });
        if ($has_external_reference && $stats['other'] > 0) {
            set_flash('文件已从你的文件管理中移除，但因仍被其他用户或外部插件引用，实际文件已保留');
        } elseif ($has_external_reference) {
            set_flash('文件已从你的文件管理中移除，但因仍被外部插件引用，实际文件已保留');
        } else {
            set_flash('文件已从你的文件管理中移除，但因仍被其他用户引用，实际文件已保留');
        }
        go(user_files_url());
    }

    $path = UPLOAD_DIR . '/' . upload_hash_dir($hash) . '/' . basename($file_name);
    $can_unlink = !user_files_physical_source_shared($file);

    tx(function () use ($id): void {
        q('DELETE FROM plugin_user_files_folder_items WHERE attachment_id=?', [$id]);
        q('DELETE FROM plugin_user_files_detached WHERE attachment_id=?', [$id]);
        if (app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) q("DELETE FROM plugin_user_files_references WHERE attachment_id=? AND source_type IN ('topic','reply')", [$id]);
        q('DELETE FROM app_attachments WHERE id=? AND user_id=?', [$id, uid()]);
    });

    if ($can_unlink && is_file($path)) @unlink($path);

    set_flash($can_unlink ? '文件已删除' : '文件记录已删除，实际文件因仍有其他用户文件记录而保留');
    go(user_files_url());
}

/* =========================================================
 * 文件中心
 * ========================================================= */

function user_files_page(
    array $plugin = []
): void {
    user_files_require_user_center();

    $view =
        (string)($_GET['view'] ?? '');

    /*
     * 有 view=references&id=xxx 时，
     * 直接进入同一个 user_files 路由的引用页面。
     *
     * 不再存在第二个“引用位置”路由。
     */
    if (
        $view === 'references' &&
        (int)($_GET['id'] ?? 0) > 0
    ) {
        user_files_references_view();
        return;
    }

    $page =
        max(
            1,
            (int)($_GET['p'] ?? 1)
        );

    // 主列表采用服务端分页，避免一次渲染/处理过多文件；引用详情只在引用页单独加载。
    $size = 20;

    $query =
        cut(
            trim((string)($_GET['q'] ?? '')),
            100
        );

    $type =
        (string)($_GET['type'] ?? 'all');

    $folder_id = (int)($_GET['folder'] ?? 0);
    if ($folder_id > 0 && !user_files_folder_find($folder_id)) {
        err('文件夹不存在或无权查看', 404);
    }

    if (!in_array(
        $type,
        ['all', 'images'],
        true
    )) {
        $type = 'all';
    }

    $offset =
        ($page - 1) * $size;

    /*
     * 注意 SQL 占位符顺序：文件夹 JOIN 的 ? 出现在 WHERE a.user_id=? 之前。
     * 因此 folder_id 必须先进入参数数组，再追加 uid()。
     * 之前版本这里顺序反了，导致进入文件夹后实际执行成
     * fi.folder_id = 当前用户 ID、a.user_id = 当前文件夹 ID，
     * 于是文件夹计数显示有文件，但列表查询却返回 0 行。
     */
    $from = 'FROM app_attachments a';
    $params = [];

    if ($folder_id > 0) {
        $from .= ' INNER JOIN plugin_user_files_folder_items fi ON fi.attachment_id=a.id AND fi.folder_id=?';
        $params[] = $folder_id;
    }

    $where =
        'WHERE a.user_id=?
          AND NOT EXISTS (SELECT 1 FROM plugin_user_files_detached d WHERE d.attachment_id=a.id)';
    $params[] = uid();

    if ($type === 'images') {
        $where .= ' AND a.is_image=1';
    }

    if ($query !== '') {
        $where .= '
            AND (
                a.original_name LIKE ?
                OR a.file_name LIKE ?
                OR a.ext LIKE ?
                OR a.mime LIKE ?
            )
        ';

        $like =
            '%' . $query . '%';

        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    $total =
        (int)val(
            'SELECT COUNT(*)
             ' . $from . '
             ' . $where,
            $params
        );

    $rows =
        q(
            'SELECT
                a.id,
                a.user_id,
                a.hash,
                a.file_name,
                a.original_name,
                a.ext,
                a.mime,
                a.size,
                a.is_image,
                a.created_at
             ' . $from . '
             ' . $where . '
             ORDER BY a.created_at DESC,a.id DESC
             LIMIT ? OFFSET ?',
            array_merge(
                $params,
                [$size, $offset]
            )
        )->fetchAll();

    // 列表页只需要引用数量，不再把每个文件的全部引用详情一次性加载进内存。
    $reference_count_map = user_files_reference_count_map($rows);

    $file_folder_map = [];
    $row_ids = array_values(array_map(static fn(array $row): int => (int)$row['id'], $rows));
    if ($row_ids) {
        $marks = sql_marks(count($row_ids));
        $folder_rows = q(
            'SELECT attachment_id,folder_id FROM plugin_user_files_folder_items WHERE attachment_id IN (' . $marks . ')',
            $row_ids
        )->fetchAll();
        foreach ($folder_rows as $folder_row) $file_folder_map[(int)$folder_row['attachment_id']] = (int)$folder_row['folder_id'];
    }

    $used_bytes =
        (int)val(
            'SELECT COALESCE(SUM(size),0)
             FROM app_attachments
             WHERE user_id=?',
            [uid()]
        );

    /*
     * 顶部搜索。
     */
    $search =
        '<form
            class="user-files-search"
            method="get"
            action="' .
        h(route_url('user_files')) .
        '">';

    if ($type !== 'all') {
        $search .=
            '<input
                type="hidden"
                name="type"
                value="' .
            h($type) .
            '">';
    }
    if ($folder_id > 0) {
        $search .= '<input type="hidden" name="folder" value="' . $folder_id . '">';
    }

    $search .=
        '<input
            type="search"
            name="q"
            value="' .
        h($query) .
        '"
            placeholder="搜索文件名、扩展名或类型"
            autocomplete="off">' .

        '<button type="submit">搜索</button>';

    if ($query !== '') {
        $search .=
            '<a href="' .
            h(
                user_files_url(
                    1,
                    '',
                    $type,
                    '',
                    0,
                    $folder_id
                )
            ) .
            '">清除</a>';
    }

    $search .= '</form>';


    /*
     * 文件中心页面内部顶部。
     */
    $main =
        '<div class="profile-toolbar user-files-profile-toolbar">' .
        user_files_profile_tab_bar(
            uid(),
            'files'
        ) .
        '</div>' .

        '<section class="user-files-panel">' .

        '<div class="user-files-head">' .

        '<div class="user-files-heading">' .

        '<div class="user-files-heading-icon">' .
        svg_icon('pages') .
        '</div>' .

        '<div>' .
        '<h1>我的文件</h1>' .
        '<p>' .
        h((string)$total) .
        ' 个文件 · 已使用 ' .
        h(
            user_files_format_size(
                $used_bytes
            )
        ) .
        '</p>' .
        '</div>' .

        '</div>' .

        '<div class="user-files-head-actions">' .
        $search .
        '<button type="button" class="user-files-upload-button" data-user-files-pick-files data-user-files-upload-url="' . h(route_url('user_file_upload')) . '" data-user-files-folder-id="' . h((string)$folder_id) . '">' . svg_icon('upload') . '<span>上传文件</span></button>' .
        form_token() .
        '<input type="file" name="attachment" multiple data-user-files-picker-input hidden>' .
        '<div class="user-files-direct-upload-result" data-user-files-direct-upload-result hidden></div>' .
        '</div>' .

        '</div>' .

        user_files_folder_admin_html($folder_id) .

        '<div class="user-files-current-folder">' .
        ($folder_id > 0
            ? '<a href="' . h(user_files_url(1, $query, $type)) . '">全部文件</a><span>/</span><strong>' . h((string)(user_files_folder_find($folder_id)['name'] ?? '当前文件夹')) . '</strong>'
            : '<strong>全部文件</strong>') .
        '</div>' .

        '<div class="user-files-toolbar">' .
        user_files_filter_tabs(
            $type,
            $query,
            $folder_id
        ) .
        '</div>';

    if (!$rows) {
        $main .=
            '<div class="user-files-empty">' .

            '<div class="user-files-empty-icon">' .
            svg_icon('pages') .
            '</div>' .

            '<strong>' .
            (
                $query !== ''
                    ? '没有找到匹配的文件'
                    : (
                        $type === 'images'
                            ? '还没有图片附件'
                            : '还没有上传文件'
                    )
            ) .
            '</strong>' .

            '<span>' .
            (
                $query !== ''
                    ? '换一个搜索关键词试试。'
                    : '你上传到论坛的附件会自动出现在这里。'
            ) .
            '</span>' .

            '</div>';
    } else {
        $items = '';

        foreach ($rows as $file) {
            $id =
                (int)$file['id'];

            $file_name =
                (string)$file['file_name'];

            $display_name =
                user_files_file_label(
                    $file
                );

            $ext =
                strtolower(
                    (string)$file['ext']
                );

            $mime =
                trim(
                    (string)$file['mime']
                );

            $reference_count = (int)($reference_count_map[(string)$id] ?? 0);

            /*
             * 缩略图。
             */
            $preview = '';

            if ((int)$file['is_image'] === 1) {
                $image_url =
                    user_files_attachment_url(
                        $file
                    );

                if ($image_url !== '') {
                    $preview =
                        '<a
                            class="user-files-thumb"
                            href="' .
                        h($image_url) .
                        '"
                            target="_blank"
                            rel="noopener">
                            <img
                                src="' .
                        h($image_url) .
                        '"
                                alt=""
                                loading="lazy">
                        </a>';
                }
            }

            if ($preview === '') {
                $preview =
                    '<span class="user-files-file-icon">' .
                    h(
                        $ext !== ''
                            ? strtoupper($ext)
                            : 'FILE'
                    ) .
                    '</span>';
            }

            /*
             * “N 个引用”与“引用位置”使用完全相同的路由。
             */
            $references_url =
                user_files_url(
                    1,
                    '',
                    'all',
                    'references',
                    $id
                );

            if ($reference_count > 0) {
                $reference_html =
                    '<a
                        class="user-files-reference-count"
                        href="' .
                    h($references_url) .
                    '">' .
                    h(
                        (string)$reference_count
                    ) .
                    ' 个引用' .
                    '</a>';
            } else {
                $reference_html =
                    '<a
                        class="user-files-reference-count
                        user-files-reference-count-empty"
                        href="' .
                    h($references_url) .
                    '">
                        引用位置
                    </a>';
            }

            /*
             * 有引用就禁止删除。
             */
            $preview_url =
                user_files_preview_url($file);

            $actions =
                ($preview_url !== ''
                    ? '<a href="' . h($preview_url) . '" target="_blank" rel="noopener">预览</a>'
                    : '') .
                '<a
                    href="' .
                h(
                    user_files_download_url(
                        $file
                    )
                ) .
                '"
                    target="_blank"
                    rel="noopener">
                    下载
                </a>' .

                '<a
                    href="' .
                h($references_url) .
                '">
                    引用位置
                </a>';

            $insert_markdown = user_files_insert_markdown($file);
            if ($insert_markdown !== '') {
                $actions .= '<button type="button" class="user-files-copy-button" data-copy-user-files-path data-copy-text="' . h($insert_markdown) . '">复制插入链接</button>';
            }

            /*
             * forum topic/reply 引用为 0 时，仍需检查外部插件引用。
             * 外部插件通过 user_files.reference_tabs 声明自己的引用入口；
             * 只要存在有效外部引用，就隐藏删除按钮，避免用户把仍被外部页面使用的
             * 附件从文件中心删除。实际删除路由也会再次做服务端保护。
             */
            $has_external_reference = false;
            if ($reference_count === 0) {
                $external_delete_tabs = user_files_external_reference_tabs($id, $file, false);
                foreach ($external_delete_tabs as $external_delete_tab) {
                    if (!is_array($external_delete_tab)) continue;
                    $external_href = trim((string)($external_delete_tab['href'] ?? ''));
                    $external_label = trim((string)($external_delete_tab['label'] ?? ''));
                    if ($external_href !== '' && $external_label !== '') {
                        $has_external_reference = true;
                        break;
                    }
                }
            }

            if ($reference_count === 0 && !$has_external_reference) {
                $actions .=
                    '<form
                        method="post"
                        action="' .
                    h(
                        route_url(
                            'user_file_delete'
                        )
                    ) .
                    '"
                        data-no-ajax="1"
                        data-confirm="确定删除这个文件吗？删除后无法恢复。">' .
                    form_token() .
                    '<input
                        type="hidden"
                        name="id"
                        value="' .
                    $id .
                    '">' .
                    '<button
                        type="submit"
                        class="user-files-delete">
                        删除
                    </button>' .
                    '</form>';
            }

            $main .=
                '<article class="user-files-item">' .

                '<div class="user-files-preview">' .
                $preview .
                '</div>' .

                '<div class="user-files-info">' .

                '<strong
                    class="user-files-name"
                    title="' .
                h($display_name) .
                '">' .
                h($display_name) .
                '</strong>' .

                '<div class="user-files-meta">' .
                h(
                    $mime !== ''
                        ? $mime
                        : (
                            $ext !== ''
                                ? strtoupper($ext)
                                : '文件'
                        )
                ) .
                '<span>·</span>' .
                h(
                    user_files_format_size(
                        (int)$file['size']
                    )
                ) .
                '<span>·</span>' .
                h(
                    date(
                        'Y-m-d H:i',
                        (int)$file['created_at']
                    )
                ) .
                '</div>' .

                '<div class="user-files-reference-line">' .
                $reference_html .
                '</div>' .

                '<details class="user-files-more">' .
                '<summary>文件详情</summary>' .
                '<div class="user-files-detail-grid">' .

                '<div>' .
                '<span>扩展名</span>' .
                '<strong>' .
                h(
                    $ext !== ''
                        ? '.' . $ext
                        : '—'
                ) .
                '</strong>' .
                '</div>' .

                '<div>' .
                '<span>大小</span>' .
                '<strong>' .
                h(
                    user_files_format_size(
                        (int)$file['size']
                    )
                ) .
                '</strong>' .
                '</div>' .

                '<div>' .
                '<span>实际存储文件名</span>' .
                '<strong><code>' .
                h($file_name) .
                '</code></strong>' .
                '</div>' .

                '<div>' .
                '<span>文件路径</span>' .
                '<strong><code data-user-files-path>' . h(user_files_file_absolute_path($file)) . '</code></strong>' .
                '</div>' .
                '</div>' .
                '<form class="user-files-move-form" method="post" action="' . h(route_url('user_file_move')) . '">' .
                form_token() .
                '<input type="hidden" name="id" value="' . $id . '">' .
                '<input type="hidden" name="back_folder_id" value="' . $folder_id . '">' .
                '<label><span>整理到</span><select name="folder_id"><option value="0">未分类</option>' . user_files_folder_options((int)($file_folder_map[$id] ?? 0), false) . '</select></label>' .
                '<button type="submit">移动</button>' .
                '</form>' .
                '</details>' .

                '</div>' .

                '<div class="user-files-actions user-files-primary-actions">' .
                $actions .
                '</div>' .

                '</article>';
        }

        $main .=
            '<div class="user-files-list">' .
            $items .
            '</div>';

        $pagination =
            paginate(
                $total,
                $page,
                $size,
                user_files_url(
                    1,
                    $query,
                    $type,
                    '',
                    0,
                    $folder_id
                )
            );

        if ($pagination !== '') {
            $main .=
                '<div class="pagination-bar">' .
                $pagination .
                '</div>';
        }
    }

    $main .=
        '</section>';


    /*
     * 侧栏直接使用核心组件。
     *
     * sidebar_user_card_html()
     * 会产生：
     *
     * <div class="user-links"
     *      data-slot="user.menu_links">
     *
     * 里面包含“我的文件”。
     */
    $sidebar =
        sidebar_stack_html(
            [
                sidebar_user_card_html(
                    me(),
                    false,
                    0
                ),
                sidebar_bio_card_html(
                    me()
                ),
            ],
            [
                'user' => me(),
                'self' => true,
                'page' => 'user_files',
            ]
        );

    page(
        '我的文件',
        shell_html(
            $main,
            $sidebar,
            'profile-mobile-sidebar profile-mobile-sidebar-own user-files-page'
        ),
        [
            'description' =>
                '管理自己上传的文件，查看附件引用并跳转到对应主题或回帖。',
        ]
    );
}


/* =========================================================
 * 外部引用提供者
 *
 * user_files 只负责提供“我的文件”页面中的扩展入口。
 * 每个外部插件自行维护自己的引用数据，并通过本 Hook 返回自己的 Tab。
 * user_files 不读取、不扫描、不删除外部插件的数据。
 * ========================================================= */

function user_files_external_reference_url(string $href, int $attachment_id, string $tab_key = ''): string
{
    $href = trim($href);
    if ($href === '' || $href === '#') return $href;
    if ($attachment_id <= 0) return $href;

    $fragment = '';
    $hash_pos = strpos($href, '#');
    if ($hash_pos !== false) {
        $fragment = substr($href, $hash_pos);
        $href = substr($href, 0, $hash_pos);
    }

    $separator = str_contains($href, '?') ? '&' : '?';
    $params = [
        'user_files_external_ref' => '1',
        'user_files_attachment_id' => $attachment_id,
    ];
    if ($tab_key !== '' && preg_match('/^[a-zA-Z0-9_.:-]{1,80}$/', $tab_key) === 1) {
        $params['user_files_external_tab'] = $tab_key;
    }

    return $href . $separator . http_build_query($params, '', '&', PHP_QUERY_RFC3986) . $fragment;
}

function user_files_external_reference_tabs(int $attachment_id, array $file, bool $admin_mode = false): array
{
    if ($attachment_id <= 0) return [];

    $tabs = hook('user_files.reference_tabs', [], [
        'attachment_id' => $attachment_id,
        'file' => $file,
        'admin_mode' => $admin_mode,
        'user_id' => (int)($file['user_id'] ?? 0),
    ]);

    if (!is_array($tabs)) return [];

    foreach ($tabs as $key => &$tab) {
        if (!is_array($tab) || empty($tab['href'])) continue;
        $tab['href'] = user_files_external_reference_url(
            (string)$tab['href'],
            $attachment_id,
            is_string($key) ? $key : ''
        );
        if ($admin_mode) {
            $tab['href'] = user_files_external_reference_url($tab['href'], 0);
            $separator = str_contains($tab['href'], '?') ? '&' : '?';
            $tab['href'] .= $separator . 'user_files_external_admin=1';
        }
    }
    unset($tab);

    return $tabs;
}

function user_files_reference_navigation_html(
    int $attachment_id,
    array $file,
    bool $admin_mode = false,
    string $active = 'references'
): string {
    if ($attachment_id <= 0) return '';

    $external_tabs = user_files_external_reference_tabs($attachment_id, $file, $admin_mode);
    $items = [
        'files' => [
            'label' => $admin_mode ? '全部文件' : '我的文件',
            'href' => $admin_mode
                ? admin_url(['tab' => 'user_files', 'view' => 'files', 'user_id' => (int)$file['user_id']])
                : route_url('user_files'),
        ],
        'references' => [
            'label' => '引用位置',
            'href' => $admin_mode
                ? route_url('user_files_admin_references', ['id' => $attachment_id])
                : user_files_url(1, '', 'all', 'references', $attachment_id),
        ],
    ];

    foreach ($external_tabs as $key => $tab) {
        if (!is_array($tab) || empty($tab['href']) || !isset($tab['label'])) continue;
        $items[(string)$key] = $tab;
    }

    return tab_bar_html(
        array_filter($items, static fn($item) => is_array($item) && !empty($item['href']) && isset($item['label'])),
        $active,
        'user-files-sub-tabs'
    );
}


/* =========================================================
 * 引用位置视图
 *
 * 注意：
 *   不再注册 user_file_references 路由。
 *
 * URL：
 *   a=user_files&view=references&id=123
 *
 * “N 个引用”和“引用位置”均进入这里。
 * ========================================================= */

function user_files_references_view(): void
{
    $admin_mode = (string)($_GET['admin_reference'] ?? '') === '1';
    if ($admin_mode) {
        need_admin();
    } else {
        need_login();
    }

    $id =
        (int)($_GET['id'] ?? 0);

    if ($id <= 0) {
        err('文件不存在', 404);
    }

    $file = $admin_mode
        ? one(
            'SELECT id,user_id,hash,file_name,original_name,ext,mime,size,is_image,created_at
             FROM app_attachments
             WHERE id=?',
            [$id]
        )
        : user_files_find_attachment($id);

    if (!$file) {
        err('文件不存在或无权查看', 404);
    }

    // “引用位置”严格属于 user_files 自己的论坛引用索引，只读取 topic/reply。
    $references = user_files_references_for_file($file);
    $external_tabs = user_files_external_reference_tabs($id, $file, $admin_mode);

    $display_name =
        user_files_file_label(
            $file
        );

    /*
     * 用户主页完整 Tab Bar。
     */
    $main =
        ($admin_mode
            ? user_files_admin_tabs('files')
            : '<div class="profile-toolbar user-files-profile-toolbar">' . user_files_profile_tab_bar(uid(), 'files') . '</div>') .

        '<section class="user-files-panel">' .

        '<div class="user-files-reference-nav">' .
        tab_bar_html(
            array_filter(
                array_merge(
                    [
                        'files' => [
                            'label' => $admin_mode ? '全部文件' : '我的文件',
                            'href' => $admin_mode
                                ? admin_url(['tab' => 'user_files', 'view' => 'files', 'user_id' => (int)$file['user_id']])
                                : route_url('user_files'),
                        ],
                        'references' => [
                            'label' => '引用位置',
                            'href' => $admin_mode
                                ? route_url('user_files_admin_references', ['id' => $id])
                                : user_files_url(1, '', 'all', 'references', $id),
                        ],
                    ],
                    $external_tabs
                ),
                static fn($item) => is_array($item) && !empty($item['href']) && isset($item['label'])
            ),
            'references',
            'user-files-sub-tabs'
        ) .
        '</div>' .

        '<div class="user-files-reference-head">' .

        '<div class="user-files-reference-file">' .

        '<div class="user-files-reference-file-icon">';

    $image_url =
        user_files_attachment_url(
            $file
        );

    if (
        (int)$file['is_image'] === 1 &&
        $image_url !== ''
    ) {
        $main .=
            '<img
                src="' .
            h($image_url) .
            '"
                alt=""
                loading="lazy">';
    } else {
        $main .=
            svg_icon('pages');
    }

    $main .=
        '</div>' .

        '<div class="user-files-reference-file-info">' .

        '<strong
            title="' .
        h($display_name) .
        '">' .
        h($display_name) .
        '</strong>' .

        '<span>' .
        h(
            user_files_format_size(
                (int)$file['size']
            )
        ) .
        ' · ' .
        h(
            (string)(
                $file['mime'] !== ''
                    ? $file['mime']
                    : $file['ext']
            )
        ) .
        '</span>' .

        '</div>' .

        '</div>' .

        '<a
            class="user-files-download"
            href="' .
        h(
            user_files_download_url(
                $file
            )
        ) .
        '"
            target="_blank"
            rel="noopener">
            下载文件
        </a>' .

        '</div>';

    if (!$references) {
        $main .=
            '<div class="user-files-empty">' .

            '<div class="user-files-empty-icon">' .
            svg_icon('view') .
            '</div>' .

            '<strong>暂无引用</strong>' .

            '<span>
                这个文件目前没有出现在当前分类的引用位置中。
            </span>' .

            '</div>';
    } else {
        /*
         * 批量读取版块。
         */
        $forum_ids = [];

        foreach ($references as $reference) {
            $forum_id =
                (int)($reference['forum_id'] ?? 0);

            if ($forum_id > 0) {
                $forum_ids[$forum_id] = true;
            }
        }

        $forum_map = [];

        foreach (
            array_chunk(
                array_keys($forum_ids),
                80
            ) as $forum_chunk
        ) {
            if (!$forum_chunk) continue;

            $marks =
                sql_marks(
                    count($forum_chunk)
                );

            $forums =
                q(
                    'SELECT id,name,allow_view_groups
                     FROM app_forums
                     WHERE id IN (' .
                    $marks .
                    ')',
                    $forum_chunk
                )->fetchAll();

            foreach ($forums as $forum) {
                $forum_map[
                    (int)$forum['id']
                ] = $forum;
            }
        }

        $main .=
            '<div class="user-files-reference-summary">' .
            '<strong>' .
            count($references) .
            '</strong> 个引用位置' .
            '</div>' .

            '<div class="user-files-reference-list">';

        foreach ($references as $reference) {
            $topic_id =
                (int)$reference['topic_id'];

            $reply_id =
                (int)$reference['reply_id'];

            $forum_id =
                (int)$reference['forum_id'];

            $forum =
                $forum_map[$forum_id] ?? null;

            /*
             * 检查当前用户是否仍可查看版块。
             */
            $can_view =
                $forum
                    ? forum_group_allowed(
                        $forum,
                        'allow_view_groups'
                    )
                    : true;

            $source_type = (string)($reference['source_type'] ?? $reference['type'] ?? '');
            $is_reply = $source_type === 'reply' || $reply_id > 0;
            $url = $can_view ? user_files_reference_url($topic_id, $reply_id) : '';
            $reference_label = $is_reply ? '回帖' : '主题主楼';

            $main .=
                '<article class="user-files-reference-item">' .

                '<div class="user-files-reference-icon">' .
                (
                    $is_reply
                        ? '回'
                        : ($source_type === 'topic' ? '主' : '引')
                ) .
                '</div>' .

                '<div class="user-files-reference-body">' .

                '<div class="user-files-reference-top">' .

                '<span class="user-files-reference-type">' .
                (
                    $reference_label
                ) .
                '</span>';

            if ($forum) {
                $main .=
                    '<span class="user-files-reference-forum">' .
                    h(
                        (string)$forum['name']
                    ) .
                    '</span>';
            }

            $main .=
                '</div>';

            if ($url !== '') {
                $main .=
                    '<a
                        class="user-files-reference-title"
                        href="' .
                    h($url) .
                    '">' .
                    h(
                        (string)$reference['title']
                    ) .
                    '</a>';
            } else {
                $main .=
                    '<span
                        class="user-files-reference-title
                        user-files-reference-title-disabled">' .
                    h(
                        (string)$reference['title']
                    ) .
                    '</span>';
            }

            $location =
                $is_reply
                    ? '回帖 #' . $reply_id
                    : ($source_type === 'topic' ? '主题主楼' : ($source_id > 0 ? $source_type . ' #' . $source_id : $reference_label));

            $main .=
                '<div class="user-files-reference-meta">' .
                h($location) .
                ' · ' .
                h(
                    date(
                        'Y-m-d H:i',
                        (int)$reference['created_at']
                    )
                ) .
                ' · ' .
                (
                    $url !== ''
                        ? '点击查看'
                        : '当前无浏览权限'
                ) .
                '</div>' .

                '</div>';

            if ($url !== '') {
                $main .=
                    '<a
                        class="user-files-reference-go"
                        href="' .
                    h($url) .
                    '">
                        查看
                    </a>';
            } else {
                $main .=
                    '<span
                        class="user-files-reference-go
                        user-files-reference-go-disabled">
                        不可访问
                    </span>';
            }

            $main .=
                '</article>';
        }

        $main .=
            '</div>';
    }

    $main .=
        '<div class="user-files-back">' .
        '<a href="' .
        h(
            ($admin_mode
                ? admin_url(['tab' => 'user_files', 'view' => 'files', 'user_id' => (int)$file['user_id']])
                : route_url('user_files'))
        ) .
        '">← 返回' . ($admin_mode ? '文件列表' : '我的文件') . '</a>' .
        '</div>' .

        '</section>';

    $sidebar =
        sidebar_stack_html(
            [
                sidebar_user_card_html(
                    me(),
                    false,
                    0
                ),
                sidebar_bio_card_html(
                    me()
                ),
            ],
            [
                'user' => me(),
                'self' => true,
                'page' => 'user_files',
            ]
        );

    page(
        '文件引用 - ' . $display_name,
        shell_html(
            $main,
            $sidebar,
            'profile-mobile-sidebar profile-mobile-sidebar-own user-files-page'
        ),
        [
            'description' =>
                '查看文件被哪些主题和回帖引用，并直接跳转。',
        ]
    );
}


/* =========================================================
 * 最近文件侧边卡片
 *
 * 只在发表主题、发表回复页面追加，避免污染文件管理页。
 * 一次查询最近文件，复制按钮直接复制论坛原生 Markdown/链接。
 * ========================================================= */

function user_files_recent_sidebar_card(array $ctx = []): string
{
    if (!uid()) return '';

    static $cache = [];
    $page = (string)($ctx['page'] ?? '');
    if ($page === '') $page = (string)($_GET['a'] ?? '');
    if (!in_array($page, ['topic', 'topic_edit', 'reply_edit', 'user', 'notify'], true)) return '';

    $cache_key = (string)uid();
    if (!isset($cache[$cache_key])) {
        $pinned = q(
            'SELECT id,name,is_pinned,sort_order
             FROM plugin_user_files_folders
             WHERE user_id=? AND is_pinned=1
             ORDER BY sort_order ASC,id ASC
             LIMIT 3',
            [uid()]
        )->fetchAll();

        $pinned_files = [];
        if ($pinned) {
            $folder_ids = array_values(array_map(static fn(array $row): int => (int)$row['id'], $pinned));
            $marks = sql_marks(count($folder_ids));
            $folder_file_rows = q(
                'SELECT fi.folder_id,a.id,a.user_id,a.hash,a.file_name,a.original_name,a.ext,a.mime,a.size,a.is_image,a.created_at
                 FROM plugin_user_files_folder_items fi
                 INNER JOIN app_attachments a ON a.id=fi.attachment_id AND a.user_id=?
                 LEFT JOIN plugin_user_files_detached d ON d.attachment_id=a.id
                 WHERE d.attachment_id IS NULL AND fi.folder_id IN (' . $marks . ')
                 ORDER BY fi.folder_id ASC,a.created_at DESC,a.id DESC',
                array_merge([uid()], $folder_ids)
            )->fetchAll();
            foreach ($folder_file_rows as $file) {
                $folder_id = (int)$file['folder_id'];
                if (!isset($pinned_files[$folder_id])) $pinned_files[$folder_id] = [];
                if (count($pinned_files[$folder_id]) < 5) $pinned_files[$folder_id][] = $file;
            }
        }

        $rows = q(
            'SELECT id,user_id,hash,file_name,original_name,ext,mime,size,is_image,created_at
             FROM app_attachments a
             WHERE a.user_id=?
               AND NOT EXISTS (SELECT 1 FROM plugin_user_files_detached d WHERE d.attachment_id=a.id)
             ORDER BY a.created_at DESC,id DESC
             LIMIT 5',
            [uid()]
        )->fetchAll();
        $cache[$cache_key] = ['pinned' => $pinned, 'pinned_files' => $pinned_files, 'rows' => $rows];
    }

    $pinned = $cache[$cache_key]['pinned'];
    $pinned_files = $cache[$cache_key]['pinned_files'];
    $rows = $cache[$cache_key]['rows'];
    if (!$pinned && !$rows) {
        return '<section class="user-files-recent-sidebar"><div class="sidebar-card-head"><strong>最近文件</strong></div><div class="user-files-recent-empty">暂无上传文件</div></section>';
    }

    $html = '<section class="user-files-recent-sidebar">'
        . '<div class="sidebar-card-head"><strong>最近文件</strong><a href="' . h(user_files_url()) . '">全部</a></div>';

    if ($pinned) {
        $html .= '<div class="user-files-recent-pinned" aria-label="置顶文件夹">';
        foreach ($pinned as $folder) {
            $id = (int)$folder['id'];
            $name = (string)$folder['name'];
            $files = $pinned_files[$id] ?? [];
            $html .= '<details class="user-files-recent-folder"' . (!empty($files) ? '' : ' data-user-files-empty-folder') . '>'
                . '<summary><span class="user-files-recent-folder-icon">📁</span><span class="user-files-recent-folder-name" title="' . h($name) . '">' . h($name) . '</span><span class="user-files-recent-folder-arrow" aria-hidden="true">⌄</span></summary>'
                . '<div class="user-files-recent-folder-body">';
            if (!$files) {
                $html .= '<div class="user-files-recent-folder-empty">文件夹为空</div>';
            } else {
                $html .= '<div class="user-files-recent-folder-files">';
                foreach ($files as $file) {
                    $file_name = user_files_file_label($file);
                    $insert = user_files_insert_markdown($file);
                    $preview_url = user_files_preview_url($file);
                    $html .= '<div class="user-files-recent-folder-file">'
                        . '<span class="user-files-recent-folder-file-name" title="' . h($file_name) . '">' . h($file_name) . '</span>'
                        . '<span class="user-files-recent-folder-file-actions">'
                        . ($preview_url !== '' ? '<a href="' . h($preview_url) . '" target="_blank" rel="noopener">预览</a>' : '')
                        . ($insert !== '' ? '<button type="button" data-copy-user-files-path data-copy-text="' . h($insert) . '">复制</button>' : '')
                        . '</span></div>';
                }
                $html .= '</div>';
            }
            $html .= '<a class="user-files-recent-folder-open" href="' . h(user_files_url(1, '', 'all', '', 0, $id)) . '">打开文件夹</a>'
                . '</div></details>';
        }
        $html .= '</div>';
    }

    if ($rows) {
        $html .= '<div class="user-files-recent-list">';
        foreach ($rows as $file) {
            $name = user_files_file_label($file);
            $insert = user_files_insert_markdown($file);
            $preview_url = user_files_preview_url($file);
            $size = user_files_format_size((int)$file['size']);
            $icon = strtolower((string)$file['ext']) !== '' ? strtoupper((string)$file['ext']) : 'FILE';
            $thumb = '';
            if ((int)$file['is_image'] === 1) {
                $image_url = user_files_attachment_url($file);
                if ($image_url !== '') $thumb = '<img src="' . h($image_url) . '" alt="" loading="lazy">';
            }
            if ($thumb === '') $thumb = '<span class="user-files-recent-icon">' . h($icon) . '</span>';

            $html .= '<article class="user-files-recent-item">'
                . '<div class="user-files-recent-thumb">'
                . ($preview_url !== '' ? '<a href="' . h($preview_url) . '" target="_blank" rel="noopener">' . $thumb . '</a>' : $thumb)
                . '</div>'
                . '<div class="user-files-recent-main">'
                . '<a class="user-files-recent-name" href="' . h(user_files_url()) . '" title="' . h($name) . '">' . h($name) . '</a>'
                . '<span class="user-files-recent-meta">' . h($size) . ' · ' . h(date('m-d H:i', (int)$file['created_at'])) . '</span>'
                . '<div class="user-files-recent-actions">';
            if ($preview_url !== '') $html .= '<a href="' . h($preview_url) . '" target="_blank" rel="noopener">预览</a>';
            if ($insert !== '') $html .= '<button type="button" data-copy-user-files-path data-copy-text="' . h($insert) . '">复制链接</button>';
            $html .= '</div></div></article>';
        }
        $html .= '</div>';
    }

    return $html . '</section>';
}

function user_files_content_before_delete(mixed $value, array $ctx): mixed
{
    $table = (string)($ctx['table'] ?? '');
    $row = $ctx['row'] ?? null;
    if (!is_array($row)) return $value;

    if ($table === 'topics') {
        $topic_id = (int)($row['id'] ?? 0);
        if ($topic_id > 0 && app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) q("DELETE FROM plugin_user_files_references WHERE source_type='topic' AND source_id=?", [$topic_id]);
    } elseif ($table === 'replies') {
        $reply_id = (int)($row['id'] ?? 0);
        if ($reply_id > 0 && app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) q("DELETE FROM plugin_user_files_references WHERE source_type='reply' AND source_id=?", [$reply_id]);
    }
    return $value;
}

function user_files_topic_after_save(mixed $value, array $ctx): mixed
{
    $id = (int)($ctx['id'] ?? 0);
    // 某些保存路径可能只提供 id 等上下文而不提供完整正文。
    // 缺少 body 时绝不能把现有引用误判为空并清空索引。
    if ($id > 0 && array_key_exists('body', $ctx)) {
        user_files_reference_sync_content('topic', $id, (string)$ctx['body'], $id);
    }
    return $value;
}

function user_files_reply_after_save(mixed $value, array $ctx): mixed
{
    $id = (int)($ctx['id'] ?? 0);
    $topic_id = (int)($ctx['topic_id'] ?? 0);
    // 同上：没有完整正文时保持已有引用关系，不执行“空正文重建”。
    if ($id > 0 && $topic_id > 0 && array_key_exists('body', $ctx)) {
        user_files_reference_sync_content('reply', $id, (string)$ctx['body'], $topic_id);
    }
    return $value;
}

function user_files_find_external_navigation_file(): ?array
{
    $id = (int)($_GET['user_files_attachment_id'] ?? 0);
    if ($id <= 0) return null;
    $admin_mode = (string)($_GET['user_files_external_admin'] ?? '') === '1';
    if ($admin_mode) {
        if (!can_access_admin()) return null;
        $row = one(
            'SELECT id,user_id,hash,file_name,original_name,ext,mime,size,is_image,created_at
             FROM app_attachments WHERE id=?',
            [$id]
        );
        return is_array($row) ? $row : null;
    }
    $row = one(
        'SELECT
            id,
            user_id,
            hash,
            file_name,
            original_name,
            ext,
            mime,
            size,
            is_image,
            created_at
         FROM app_attachments a
         WHERE a.id=? AND a.user_id=?',
        [$id, uid()]
    );
    return is_array($row) ? $row : null;
}

function user_files_page_before_render(mixed $value, array $ctx): mixed
{
    if (!is_string($value) || !uid()) return $value;

    /*
     * 外部引用页仍属于“我的文件”的上下文。外部插件负责自己的正文，
     * user_files 负责把用户主页一级 Tab 与文件二级 Tab 带入该完整页面。
     * 仅处理由 user_files_external_reference_tabs() 标记过的链接，避免污染其他页面。
     */
    if ((string)($_GET['user_files_external_ref'] ?? '') === '1') {
        $file = user_files_find_external_navigation_file();
        if (is_array($file)) {
            $admin_mode = (string)($_GET['user_files_external_admin'] ?? '') === '1';
            $active = trim((string)($_GET['user_files_external_tab'] ?? ''));
            if ($active === '' || preg_match('/^[a-zA-Z0-9_.:-]{1,80}$/', $active) !== 1) $active = 'references';

            $profile = $admin_mode
                ? user_files_admin_tabs('files')
                : '<div class="profile-toolbar user-files-profile-toolbar">' . user_files_profile_tab_bar((int)$file['user_id'], 'files') . '</div>';
            $sub = '<div class="user-files-reference-nav">' . user_files_reference_navigation_html(
                (int)$file['id'],
                $file,
                $admin_mode,
                $active
            ) . '</div>';

            $has_profile_tabs = strpos($value, 'user-profile-tabs') !== false;
            $has_sub_tabs = strpos($value, 'user-files-sub-tabs') !== false;
            if (!$has_profile_tabs && !$has_sub_tabs) {
                $value = $profile . $sub . $value;
            } elseif (!$has_profile_tabs) {
                $value = $profile . $value;
            } elseif (!$has_sub_tabs) {
                $value = $sub . $value;
            }
        }
    }

    $page = (string)($_GET['a'] ?? '');
    if ($page === 'notify') {
        $card = user_files_recent_sidebar_card(['page' => 'notify']);
        if ($card === '') return $value;
        if (strpos($value, 'user-files-recent-notify') !== false) return $value;

        /* 私信窗口由核心 openNotify() 动态加载，不能依赖普通 sidebar；直接把卡片放入弹窗内容。 */
        return $value . '<div class="user-files-recent-notify">' . $card . '</div>';
    }
    if (!in_array($page, ['topic', 'topic_edit', 'reply_edit', 'user'], true)) return $value;

    $card = user_files_recent_sidebar_card(['page' => $page]);
    if ($card === '') return $value;

    /* 移动端核心会隐藏普通 .sidebar，因此把最近文件卡片追加到主体底部；桌面端隐藏这个副本。 */
    $mobile_card = '<div class="user-files-recent-mobile-bottom">' . $card . '</div>';
    if (strpos($value, 'user-files-recent-mobile-bottom') !== false) return $value;

    return $value . $mobile_card;
}

function user_files_recent_route(): never
{
    if (!uid()) {
        http_response_code(403);
        exit;
    }
    header('Content-Type: text/html; charset=UTF-8');
    echo user_files_recent_sidebar_card(['page' => 'notify']);
    exit;
}

function user_files_sidebar_stack(mixed $value, array $ctx): mixed
{
    if (!is_array($value)) return $value;
    $card = user_files_recent_sidebar_card($ctx);
    if ($card !== '') $value[] = $card;
    return $value;
}

/* =========================================================
 * CSS
 * ========================================================= */

function user_files_css(): string
{
    return <<<'CSS'

/*
 * 用户文件中心
 */

.user-files-page .user-files-profile-toolbar{
    margin-bottom:12px;
}

.user-files-page .user-files-panel{
    min-width:0;
}

.user-files-page .user-files-head{
    display:flex;
    align-items:flex-end;
    justify-content:space-between;
    gap:18px;
    margin-bottom:10px;
}

.user-files-page .user-files-heading{
    min-width:0;
    display:flex;
    align-items:center;
    gap:10px;
}

.user-files-page .user-files-heading-icon{
    display:grid;
    place-items:center;
    width:40px;
    height:40px;
    flex:0 0 auto;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--panel);
    color:var(--brand);
}

.user-files-page .user-files-heading-icon .meta-icon{
    width:19px;
    height:19px;
}

.user-files-page .user-files-heading h1{
    margin:0;
    font-size:var(--font-size-lg);
}

.user-files-page .user-files-heading p{
    margin:3px 0 0;
    color:var(--text-muted);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-search{
    min-width:280px;
    display:flex;
    align-items:center;
    gap:6px;
}

.user-files-page .user-files-search input{
    min-width:0;
    flex:1;
}

.user-files-page .user-files-search a{
    color:var(--text-muted);
    white-space:nowrap;
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-toolbar{
    margin-bottom:9px;
}

.user-files-page .user-files-filter-tabs{
    margin:0;
}

.user-files-page .user-files-list{
    display:grid;
    gap:7px;
}

.user-files-page .user-files-item{
    min-width:0;
    display:grid;
    grid-template-columns:56px minmax(0,1fr) auto;
    align-items:center;
    gap:11px;
    padding:10px;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--bg);
    transition:border-color .15s ease,background .15s ease;
}

.user-files-page .user-files-item:hover{
    border-color:var(--line);
    background:var(--panel);
}

.user-files-page .user-files-preview{
    min-width:0;
}

.user-files-page .user-files-thumb,
.user-files-page .user-files-file-icon{
    display:grid;
    place-items:center;
    width:56px;
    height:56px;
    overflow:hidden;
    border-radius:var(--radius-sm);
    background:var(--panel);
    color:var(--text-muted);
}

.user-files-page .user-files-thumb img{
    display:block;
    width:100%;
    height:100%;
    object-fit:cover;
}

.user-files-page .user-files-file-icon{
    font-size:var(--font-size-xxs);
    font-weight:700;
}

.user-files-page .user-files-info{
    min-width:0;
    display:grid;
    gap:3px;
}

.user-files-page .user-files-name{
    display:block;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
    font-size:var(--font-size-sm);
}

.user-files-page .user-files-meta{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:5px;
    color:var(--text-muted);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-reference-line{
    min-height:16px;
}

.user-files-page .user-files-reference-count{
    color:var(--brand);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-reference-count-empty{
    color:var(--text-subtle);
}

.user-files-page .user-files-more{
    margin-top:2px;
    color:var(--text-subtle);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-more summary{
    cursor:pointer;
    width:max-content;
}

.user-files-recent-mobile-bottom{
    display:none;
}
.user-files-recent-mobile-bottom .user-files-recent-sidebar{
    margin-top:12px;
}
.user-files-recent-notify{margin-top:12px;}
.user-files-recent-notify .user-files-recent-sidebar{padding:10px;}


.user-files-page .user-files-detail-grid{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:7px;
    margin-top:7px;
}
.user-files-page .user-files-detail-grid>div:last-child{
    grid-column:1 / -1;
}

.user-files-page .user-files-detail-grid>div{
    min-width:0;
    display:grid;
    gap:2px;
    padding:7px 8px;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--panel);
}

.user-files-page .user-files-detail-grid span{
    color:var(--text-subtle);
    font-size:var(--font-size-xxs);
}

.user-files-page .user-files-detail-grid strong{
    min-width:0;
    overflow-wrap:anywhere;
    color:var(--text-muted);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-detail-grid code{
    overflow-wrap:anywhere;
}
@media(max-width:700px){
    .user-files-page .user-files-detail-grid{
        grid-template-columns:1fr;
    }
    .user-files-page .user-files-detail-grid>div:last-child{
        grid-column:auto;
    }
}

.user-files-page .user-files-copy-button{
    flex:0 0 auto;
    min-height:28px;
    padding:4px 9px;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--bg);
    color:var(--text);
    font-size:var(--font-size-xs);
    cursor:pointer;
}
.user-files-page .user-files-copy-button:hover{border-color:var(--brand);color:var(--brand);}

.user-files-page .user-files-actions{
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:8px;
    white-space:nowrap;
}

.user-files-page .user-files-actions a{
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-actions form{
    margin:0;
}

.user-files-page .user-files-delete{
    padding:4px;
    border:0;
    background:transparent;
    color:var(--danger);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-empty{
    display:grid;
    justify-items:center;
    gap:5px;
    padding:45px 12px;
    text-align:center;
    color:var(--text-muted);
}

.user-files-page .user-files-empty-icon{
    display:grid;
    place-items:center;
    width:42px;
    height:42px;
    margin-bottom:3px;
    border-radius:50%;
    background:var(--panel);
    color:var(--text-subtle);
}

.user-files-page .user-files-empty-icon .meta-icon{
    width:19px;
    height:19px;
}

.user-files-page .user-files-empty strong{
    color:var(--text);
    font-size:var(--font-size-md);
}

.user-files-page .user-files-empty span{
    max-width:420px;
    font-size:var(--font-size-xs);
}


/*
 * 引用位置
 */

.user-files-page .user-files-reference-nav{
    margin-bottom:10px;
}

.user-files-page .user-files-reference-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:14px;
    padding:10px;
    margin-bottom:9px;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--bg);
}

.user-files-page .user-files-reference-file{
    min-width:0;
    display:flex;
    align-items:center;
    gap:10px;
}

.user-files-page .user-files-reference-file-icon{
    display:grid;
    place-items:center;
    width:44px;
    height:44px;
    flex:0 0 auto;
    overflow:hidden;
    border-radius:var(--radius-sm);
    background:var(--panel);
    color:var(--brand);
}

.user-files-page .user-files-reference-file-icon img{
    display:block;
    width:100%;
    height:100%;
    object-fit:cover;
}

.user-files-page .user-files-reference-file-icon .meta-icon{
    width:18px;
    height:18px;
}

.user-files-page .user-files-reference-file-info{
    min-width:0;
    display:grid;
    gap:2px;
}

.user-files-page .user-files-reference-file-info strong{
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
    font-size:var(--font-size-sm);
}

.user-files-page .user-files-reference-file-info span{
    color:var(--text-muted);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-download{
    white-space:nowrap;
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-reference-summary{
    margin:4px 0 8px;
    color:var(--text-muted);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-reference-summary strong{
    color:var(--text);
}

.user-files-page .user-files-reference-list{
    display:grid;
    gap:7px;
}

.user-files-page .user-files-reference-item{
    min-width:0;
    display:grid;
    grid-template-columns:36px minmax(0,1fr) auto;
    align-items:center;
    gap:10px;
    padding:9px 10px;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--bg);
}

.user-files-page .user-files-reference-icon{
    display:grid;
    place-items:center;
    width:36px;
    height:36px;
    border-radius:var(--radius-sm);
    background:var(--brand-soft);
    color:var(--brand);
    font-size:var(--font-size-xs);
    font-weight:700;
}

.user-files-page .user-files-reference-body{
    min-width:0;
    display:grid;
    gap:3px;
}

.user-files-page .user-files-reference-top{
    min-width:0;
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:6px;
}

.user-files-page .user-files-reference-type{
    color:var(--brand);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-reference-forum{
    color:var(--text-subtle);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-reference-title{
    display:block;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
    font-size:var(--font-size-sm);
}

.user-files-page .user-files-reference-title-disabled{
    color:var(--text-muted);
}

.user-files-page .user-files-reference-meta{
    color:var(--text-muted);
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-reference-go{
    white-space:nowrap;
    font-size:var(--font-size-xs);
}

.user-files-page .user-files-reference-go-disabled{
    color:var(--text-disabled);
}

.user-files-page .user-files-back{
    margin-top:11px;
}

.user-files-page .user-files-back a{
    color:var(--text-muted);
    font-size:var(--font-size-xs);
}


/*
 * 文件预览
 */
.user-files-preview-page{
    min-width:0;
}
.user-files-preview-card{
    min-width:0;
    overflow:hidden;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--bg);
}
.user-files-preview-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:10px;
    padding:11px 12px;
    border-bottom:1px solid var(--line-soft);
}
.user-files-preview-title{
    min-width:0;
}
.user-files-preview-title strong{
    display:block;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}
.user-files-preview-title span{
    display:block;
    margin-top:3px;
    color:var(--text-muted);
    font-size:var(--font-size-xs);
}
.user-files-preview-body{
    display:grid;
    place-items:center;
    min-height:280px;
    padding:12px;
}
.user-files-preview-body img{
    display:block;
    max-width:100%;
    max-height:70vh;
    height:auto;
    object-fit:contain;
}
.user-files-preview-body iframe{
    display:block;
    width:100%;
    height:72vh;
    min-height:420px;
    border:0;
    background:#fff;
}
.user-files-preview-body audio{
    width:min(680px,100%);
}
.user-files-preview-body video{
    display:block;
    width:min(100%,960px);
    max-height:72vh;
}
.user-files-preview-code{
    width:100%;
    max-height:70vh;
    overflow:auto;
    margin:0;
    padding:12px;
    box-sizing:border-box;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--panel);
    white-space:pre-wrap;
    overflow-wrap:anywhere;
    font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;
    font-size:12px;
    line-height:1.6;
    text-align:left;
}
.user-files-preview-foot{
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:8px;
    flex-wrap:wrap;
    padding:10px 12px;
    border-top:1px solid var(--line-soft);
}
@media(max-width:700px){
    .user-files-preview-head{
        align-items:flex-start;
        flex-direction:column;
    }
    .user-files-preview-body{
        min-height:220px;
        padding:8px;
    }
    .user-files-preview-body iframe{
        height:65vh;
        min-height:320px;
    }
    .user-files-preview-body video{
        max-height:55vh;
    }
    .user-files-preview-foot{
        justify-content:stretch;
    }
    .user-files-preview-foot a,
    .user-files-preview-foot button{
        flex:1 1 auto;
        text-align:center;
    }
}

.user-files-folders{margin:0 0 12px;padding:12px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);}
.user-files-folders-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px;}
.user-files-folders-head>div{display:grid;gap:2px;min-width:0;}
.user-files-folders-head strong{font-size:var(--font-size-sm);}
.user-files-folders-head span{color:var(--text-muted);font-size:var(--font-size-xxs);}
.user-files-folder-create-form{display:flex;gap:6px;min-width:0;}
.user-files-folder-create-form input{width:150px;min-width:0;padding:6px 8px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);}
.user-files-folder-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:8px;}
.user-files-folder-card{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:6px;min-width:0;padding:8px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);}
.user-files-folder-card-active{border-color:var(--brand);}
.user-files-folder-main{display:flex;align-items:center;gap:8px;min-width:0;text-decoration:none;}
.user-files-folder-icon,.user-files-recent-folder-icon{display:grid;place-items:center;flex:0 0 auto;width:30px;height:30px;border-radius:var(--radius-sm);background:var(--bg);color:var(--brand);}
.user-files-folder-icon .meta-icon,.user-files-recent-folder-icon .meta-icon{width:17px;height:17px;}
.user-files-folder-copy{display:grid;min-width:0;gap:2px;}
.user-files-folder-copy strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--font-size-xs);}
.user-files-folder-copy small{color:var(--text-muted);font-size:var(--font-size-xxs);}
.user-files-folder-actions{display:flex;align-items:flex-start;gap:4px;}
.user-files-folder-actions form{margin:0;}
.user-files-folder-actions button,.user-files-folder-menu summary{padding:3px 5px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);color:var(--text-muted);font-size:var(--font-size-xxs);cursor:pointer;}
.user-files-folder-menu{position:relative;}
.user-files-folder-menu summary{list-style:none;}
.user-files-folder-menu summary::-webkit-details-marker{display:none;}
.user-files-folder-menu-body{position:absolute;right:0;z-index:5;display:grid;gap:7px;width:210px;margin-top:4px;padding:8px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);box-shadow:var(--shadow-sm);}
.user-files-folder-menu-body form{display:grid;gap:5px;}
.user-files-folder-menu-body input{min-width:0;padding:6px 7px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);}
.user-files-folder-menu-body button{width:100%;}
.user-files-folders-empty{color:var(--text-muted);font-size:var(--font-size-xs);}
.user-files-current-folder{display:flex;align-items:center;gap:7px;margin:0 0 9px;color:var(--text-muted);font-size:var(--font-size-xs);}
.user-files-current-folder strong{color:var(--text);}
.user-files-upload-folder{margin-bottom:10px;}
.user-files-folder-select{display:flex;align-items:center;gap:8px;font-size:var(--font-size-xs);}
.user-files-folder-select span{color:var(--text-muted);white-space:nowrap;}
.user-files-folder-select select{min-width:180px;padding:6px 8px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);}
.user-files-page .user-files-move-form{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:8px;padding:8px 0 1px;border-top:1px dashed var(--line-soft);}
.user-files-page .user-files-move-form label{display:flex;align-items:center;gap:5px;min-width:0;color:var(--text-muted);font-size:var(--font-size-xxs);}
.user-files-page .user-files-move-form select{max-width:220px;min-width:150px;padding:4px 7px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);}
.user-files-page .user-files-move-form button{padding:4px 8px;font-size:var(--font-size-xxs);}
.user-files-recent-pinned{display:grid;gap:6px;padding-bottom:8px;margin-bottom:8px;border-bottom:1px solid var(--line-soft);}
.user-files-recent-folder{min-width:0;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);overflow:hidden;}
.user-files-recent-folder>summary{display:flex;align-items:center;gap:5px;min-width:0;padding:6px 7px;cursor:pointer;list-style:none;font-size:var(--font-size-xxs);}
.user-files-recent-folder>summary::-webkit-details-marker{display:none;}
.user-files-recent-folder-icon{display:grid;place-items:center;flex:0 0 auto;width:22px;height:22px;border-radius:var(--radius-sm);background:var(--bg);}
.user-files-recent-folder-icon .meta-icon{width:13px;height:13px;}
.user-files-recent-folder-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.user-files-recent-folder-arrow{margin-left:auto;color:var(--text-subtle);transition:transform .15s ease;}
.user-files-recent-folder[open] .user-files-recent-folder-arrow{transform:rotate(180deg);}
.user-files-recent-folder-body{display:grid;gap:6px;padding:0 7px 7px;}
.user-files-recent-folder-files{display:grid;gap:4px;}
.user-files-recent-folder-file{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:6px;min-width:0;padding:5px 0;border-top:1px solid var(--line-soft);}
.user-files-recent-folder-file-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--font-size-xxs);}
.user-files-recent-folder-file-actions{display:flex;align-items:center;gap:6px;white-space:nowrap;}
.user-files-recent-folder-file-actions a,.user-files-recent-folder-file-actions button,.user-files-recent-folder-open{padding:0;border:0;background:none;color:var(--brand);font-size:var(--font-size-xxs);cursor:pointer;text-decoration:none;}
.user-files-recent-folder-empty{padding:4px 0;color:var(--text-muted);font-size:var(--font-size-xxs);}
.user-files-recent-folder-open{display:inline-block;padding-top:2px;}
.user-files-head-actions{display:flex;align-items:center;gap:8px;min-width:0;}
.user-files-upload-button{display:inline-flex;align-items:center;gap:5px;white-space:nowrap;font-size:var(--font-size-xs);}
.user-files-upload-button .meta-icon{width:15px;height:15px;}
.user-files-upload-card{min-width:0;padding:14px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);}
.user-files-upload-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:13px;}
.user-files-upload-head h1{margin:0;font-size:var(--font-size-lg);}
.user-files-upload-head p{margin:4px 0 0;color:var(--text-muted);font-size:var(--font-size-xs);}
.user-files-upload-drop{display:grid;justify-items:center;gap:7px;padding:34px 16px;border:1px dashed var(--line);border-radius:var(--radius-sm);background:var(--panel);text-align:center;cursor:pointer;}
.user-files-upload-drop input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none;}
.user-files-upload-drop strong{display:flex;align-items:center;gap:6px;font-size:var(--font-size-sm);}
.user-files-upload-drop .meta-icon{width:20px;height:20px;}
.user-files-upload-drop small{max-width:620px;color:var(--text-muted);font-size:var(--font-size-xs);}
.user-files-upload-actions{display:flex;align-items:center;gap:9px;margin-top:10px;}
.user-files-upload-actions button{min-width:96px;}
.user-files-upload-actions span{color:var(--text-muted);font-size:var(--font-size-xs);}
.user-files-upload-result{display:grid;gap:6px;margin-top:10px;padding:9px 10px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);font-size:var(--font-size-xs);}
.user-files-upload-result-item{display:flex;align-items:center;justify-content:space-between;gap:8px;min-width:0;padding:6px 0;border-bottom:1px solid var(--line-soft);}
.user-files-upload-result-item:last-of-type{border-bottom:0;}
.user-files-upload-result-item strong{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500;}
.user-files-upload-result-item button{flex:0 0 auto;padding:3px 7px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);color:var(--brand);font-size:var(--font-size-xxs);cursor:pointer;}
.user-files-upload-result-back{justify-self:start;margin-top:2px;font-size:var(--font-size-xs);}
.user-files-direct-upload-result{display:grid;gap:6px;width:min(100%,520px);margin-top:8px;padding:8px 10px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);font-size:var(--font-size-xs);}
.user-files-direct-upload-title{color:var(--text-muted);}
.user-files-head-actions>input[type="file"]{display:none;}
.user-files-upload-button{border:0;background:none;padding:0;color:inherit;cursor:pointer;font:inherit;}
.user-files-upload-button:disabled{opacity:.55;cursor:wait;}
.user-files-path-row{display:flex;align-items:center;gap:6px;min-width:0;}
.user-files-path-row code{min-width:0;flex:1;overflow-wrap:anywhere;white-space:normal;}
.user-files-path-row button,.user-files-admin-stored button{flex:0 0 auto;padding:3px 7px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);color:var(--text-muted);font-size:var(--font-size-xxs);cursor:pointer;}
.user-files-admin-stored{display:flex;align-items:center;gap:6px;min-width:0;margin-top:5px;}
.user-files-admin-stored code{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
@media(max-width:700px){
    .user-files-head-actions{width:100%;align-items:stretch;flex-direction:column;}
    .user-files-head-actions .user-files-search{min-width:0;width:100%;}
    .user-files-upload-button{justify-content:center;padding:8px 10px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);}
    .user-files-upload-head{flex-direction:column;}
    .user-files-upload-head>a{align-self:flex-start;}
    .user-files-upload-drop{padding:28px 12px;}
    .user-files-path-row{align-items:stretch;flex-direction:column;}
    .user-files-path-row button{width:100%;}
    .user-files-admin-stored{align-items:stretch;flex-direction:column;}
    .user-files-admin-stored code{white-space:normal;overflow-wrap:anywhere;}
    .user-files-admin-stored button{width:100%;}
}


/* 最近文件侧边卡片 */
.user-files-recent-sidebar{min-width:0;padding:12px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);}
.user-files-recent-sidebar .sidebar-card-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px;}
.user-files-recent-sidebar .sidebar-card-head strong{font-size:var(--font-size-sm);}
.user-files-recent-sidebar .sidebar-card-head a{color:var(--text-muted);font-size:var(--font-size-xs);}
.user-files-recent-list{display:grid;gap:8px;}
.user-files-recent-item{display:grid;grid-template-columns:38px minmax(0,1fr);gap:8px;min-width:0;padding-bottom:8px;border-bottom:1px solid var(--line-soft);}
.user-files-recent-item:last-child{padding-bottom:0;border-bottom:0;}
.user-files-recent-thumb,.user-files-recent-icon{display:grid;place-items:center;width:38px;height:38px;overflow:hidden;border-radius:var(--radius-sm);background:var(--panel);color:var(--text-muted);font-size:9px;font-weight:700;}
.user-files-recent-thumb img{display:block;width:100%;height:100%;object-fit:cover;}
.user-files-recent-main{min-width:0;display:grid;gap:2px;}
.user-files-recent-name{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--font-size-xs);}
.user-files-recent-meta{color:var(--text-muted);font-size:var(--font-size-xxs);}
.user-files-recent-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:2px;}
.user-files-recent-actions a,.user-files-recent-actions button{padding:0;border:0;background:none;color:var(--brand);font-size:var(--font-size-xxs);cursor:pointer;text-decoration:none;}
.user-files-recent-empty{color:var(--text-muted);font-size:var(--font-size-xs);}

/*
 * 移动端
 *
 * 这里不复制核心 mobile menu。
 * user.menu_links 已经被核心 mobile_menu_content_html()
 * 复用，所以“我的文件”会自动进入移动端菜单。
 */



/* 管理后台增强 */
.user-files-page .user-files-admin-tabs{margin-bottom:14px;}
.user-files-page .user-files-admin-summary-grid,
.user-files-admin-summary-grid{grid-template-columns:repeat(4,minmax(0,1fr));}
.user-files-admin-quick-panel,.user-files-admin-settings,.user-files-admin-large-files{margin-bottom:14px;}
.user-files-admin-setting-field{display:grid;gap:5px;margin-top:12px;max-width:760px;}
.user-files-admin-setting-field>span{font-size:var(--font-size-xs);color:var(--text-muted);}
.user-files-admin-setting-field input{width:100%;min-width:0;}
.user-files-admin-setting-field small{color:var(--text-subtle);font-size:var(--font-size-xxs);line-height:1.5;}
.user-files-admin-quick-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;padding:12px;}
.user-files-admin-quick{display:grid;gap:3px;min-width:0;padding:11px 12px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);text-decoration:none;}
.user-files-admin-quick:hover{background:var(--panel);border-color:var(--line);}
.user-files-admin-quick strong{font-size:var(--font-size-sm);}
.user-files-admin-quick span{color:var(--text-muted);font-size:var(--font-size-xs);}
.user-files-admin-setting-form{display:grid;grid-template-columns:minmax(280px,1.05fr) minmax(320px,1.25fr) auto;align-items:start;gap:14px;padding:12px;}
.user-files-admin-setting-form>.user-files-admin-switch{min-height:52px;padding:8px 0;}
.user-files-admin-setting-form>.user-files-admin-setting-field{margin-top:0;}
.user-files-admin-setting-form>button{align-self:center;white-space:nowrap;}
.user-files-admin-switch{display:flex;align-items:flex-start;gap:9px;min-width:0;flex:1;}
.user-files-admin-switch input{margin-top:3px;flex:0 0 auto;}
.user-files-admin-switch span{display:grid;gap:3px;min-width:0;}
.user-files-admin-switch small{color:var(--text-muted);font-size:var(--font-size-xs);}
.user-files-admin-ranking-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-bottom:14px;}
.user-files-admin-ranking{min-width:0;}
.user-files-admin-ranking ol{margin:0;padding:0 12px 12px;list-style:none;display:grid;gap:5px;}
.user-files-admin-ranking li{min-width:0;display:grid;grid-template-columns:28px minmax(0,1fr) auto;align-items:center;gap:7px;padding:7px 0;border-bottom:1px solid var(--line-soft);font-size:var(--font-size-xs);}
.user-files-admin-ranking li:last-child{border-bottom:0;}
.user-files-admin-rank{display:grid;place-items:center;width:24px;height:24px;border-radius:50%;background:var(--panel);color:var(--text-muted);}
.user-files-admin-rank-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.user-files-admin-ranking li>span:last-child{color:var(--text-muted);white-space:nowrap;}
.user-files-admin-context{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 10px;padding:9px 11px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel);font-size:var(--font-size-xs);}
.user-files-admin-context a{margin-left:auto;}
.user-files-admin-stored{
    display:grid;
    grid-template-columns:minmax(0,1fr) auto;
    align-items:center;
    gap:8px;
    margin-top:7px;
    padding:8px 9px;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--panel);
}
.user-files-admin-stored code{
    min-width:0;
    overflow-wrap:anywhere;
    word-break:break-all;
    color:var(--text-muted);
    font-size:11px;
    line-height:1.5;
}
.user-files-admin-stored button{
    min-height:30px;
    padding:5px 10px;
    border:1px solid var(--line-soft);
    border-radius:var(--radius-sm);
    background:var(--bg);
    color:var(--text);
    font-size:var(--font-size-xs);
    white-space:nowrap;
    cursor:pointer;
}
.user-files-admin-stored button:hover{border-color:var(--brand);color:var(--brand);}
@media(max-width:700px){
    .user-files-admin-summary-grid{grid-template-columns:repeat(2,minmax(0,1fr));}
    .user-files-admin-quick-grid{grid-template-columns:repeat(2,minmax(0,1fr));}
}
@media(max-width:700px){
    .user-files-admin-summary-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;}
    .user-files-admin-summary-grid>div{padding:10px;}
    .user-files-admin-summary-grid strong{font-size:17px;}
    .user-files-admin-quick-grid{grid-template-columns:1fr;padding:9px;}
    .user-files-admin-setting-form{display:flex;align-items:flex-start;flex-direction:column;}
    .user-files-admin-ranking-grid{grid-template-columns:1fr;gap:9px;}
    .user-files-admin-ranking li{grid-template-columns:26px minmax(0,1fr);}
    .user-files-admin-ranking li>span:last-child{grid-column:2;white-space:normal;}
    .user-files-admin-filter-grid,.user-files-admin-user-filters .user-files-admin-filter-grid{grid-template-columns:1fr;}
    .user-files-admin-filter-wide{grid-column:auto;}
    .user-files-admin-context a{width:100%;margin-left:0;}
}


@media (max-width:700px){
    .user-files-folders-head{align-items:stretch;flex-direction:column;}
    .user-files-folder-create-form{width:100%;}
    .user-files-folder-create-form input{flex:1;width:auto;}
    .user-files-folder-list{grid-template-columns:1fr;}
    .user-files-folder-menu-body{position:static;width:auto;margin-top:5px;}
    .user-files-folder-actions{align-items:flex-start;}
    .user-files-folder-select{align-items:flex-start;flex-direction:column;}
    .user-files-folder-select select{width:100%;min-width:0;}
}

@media (max-width: 720px){
    .user-files-recent-mobile-bottom{
        display:block;
    }
}

CSS;
}


/* =========================================================
 * JS：纯上传与复制路径
 * ========================================================= */

function user_files_js(): string
{
    $js = <<<'JS'
(() => {
    const copyText = async (text, button) => {
        let ok = false;
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
                ok = true;
            }
        } catch (e) {}
        if (!ok) {
            const area = document.createElement('textarea');
            area.value = text;
            area.setAttribute('readonly', '');
            area.style.position = 'fixed';
            area.style.opacity = '0';
            document.body.appendChild(area);
            area.select();
            try { ok = document.execCommand('copy'); } catch (e) {}
            area.remove();
        }
        if (button) {
            const old = button.textContent;
            button.textContent = ok ? '已复制' : '复制失败';
            setTimeout(() => { button.textContent = old; }, 1400);
        }
        return ok;
    };

    const userFilesUploadMessage = async (response) => {
        const text = await response.text();
        if (!text.trim()) return { ok: false, message: `服务器返回空响应（HTTP ${response.status}）` };

        try {
            const json = JSON.parse(text);
            if (json && typeof json === 'object') return json;
        } catch (e) {}

        const holder = document.createElement('div');
        holder.innerHTML = text;
        const plain = (holder.textContent || text).replace(/\s+/g, ' ').trim();
        return {
            ok: false,
            message: plain ? plain.slice(0, 240) : `服务器返回异常（HTTP ${response.status}）`,
        };
    };

    document.addEventListener('click', (event) => {
        const button = event.target.closest('[data-copy-user-files-path]');
        if (!button) return;
        const direct = button.getAttribute('data-copy-text');
        if (direct !== null) {
            copyText(direct, button);
            return;
        }
        const holder = button.closest('.user-files-path-row, .user-files-admin-stored, .user-files-path-panel');
        const code = holder ? holder.querySelector('[data-user-files-path]') : null;
        if (code) copyText(code.textContent.trim(), button);
    });

    const uploadDirectFiles = async (picker) => {
        const button = picker.closest('.user-files-head-actions')?.querySelector('[data-user-files-pick-files]');
        const result = picker.closest('.user-files-head-actions')?.querySelector('[data-user-files-direct-upload-result]');
        if (!button || !result) return;
        const files = picker.files ? Array.from(picker.files) : [];
        if (!files.length) return;

        const csrf = picker.closest('.user-files-head-actions')?.querySelector('input[name="_csrf"]');
        const uploadUrl = button.getAttribute('data-user-files-upload-url') || '';
        const folderId = button.getAttribute('data-user-files-folder-id') || '0';
        if (!uploadUrl || !csrf) {
            result.hidden = false;
            result.textContent = '上传初始化失败，请刷新页面后重试。';
            return;
        }

        button.disabled = true;
        result.hidden = false;
        result.innerHTML = '';

        const title = document.createElement('div');
        title.className = 'user-files-direct-upload-title';
        result.appendChild(title);

        let success = 0;
        for (let index = 0; index < files.length; index++) {
            const file = files[index];
            title.textContent = `正在上传 ${index + 1}/${files.length}：${file.name}`;
            const line = document.createElement('div');
            line.className = 'user-files-upload-result-item';
            const label = document.createElement('strong');
            label.textContent = `… ${file.name}`;
            line.appendChild(label);
            result.appendChild(line);

            const data = new FormData();
            data.append('_csrf', csrf.value);
            data.append('folder_id', folderId);
            data.append('attachment', file, file.name);

            try {
                const response = await fetch(uploadUrl, {
                    method: 'POST',
                    body: data,
                    credentials: 'same-origin',
                    headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
                });
                const json = await userFilesUploadMessage(response);
                const items = Array.isArray(json.results) ? json.results : [];
                const item = items.find((row) => row && row.name === file.name) || items[0] || json;
                if (!response.ok || !json.ok || !item || !item.ok) {
                    throw new Error((item && item.message) || json.message || `上传失败（HTTP ${response.status}）`);
                }

                success++;
                label.textContent = item.already_exists
                    ? `✓ ${file.name}（文件已存在，已更新到文件管理）`
                    : `✓ ${file.name}`;
                if (item.markdown) {
                    const copy = document.createElement('button');
                    copy.type = 'button';
                    copy.setAttribute('data-copy-user-files-path', '');
                    copy.setAttribute('data-copy-text', item.markdown);
                    copy.textContent = '复制插入链接';
                    line.appendChild(copy);
                }
            } catch (error) {
                label.textContent = `× ${file.name}：${error && error.message ? error.message : '上传失败'}`;
                line.classList.add('user-files-upload-result-error');
            }
        }

        picker.value = '';
        button.disabled = false;
        if (success > 0) {
            title.textContent = `上传完成：${success}/${files.length} 个文件成功，正在刷新文件列表…`;
            window.setTimeout(() => window.location.reload(), 1200);
        } else {
            title.textContent = `上传完成：${success}/${files.length} 个文件成功`;
        }
    };

    document.addEventListener('click', (event) => {
        const button = event.target.closest('[data-user-files-pick-files]');
        if (!button) return;
        const input = button.closest('.user-files-head-actions')?.querySelector('[data-user-files-picker-input]');
        if (!input) return;
        event.preventDefault();
        input.click();
    });

    document.addEventListener('change', (event) => {
        const picker = event.target.closest('[data-user-files-picker-input]');
        if (picker) {
            uploadDirectFiles(picker);
            return;
        }
        const input = event.target.closest('[data-user-files-upload-input]');
        if (!input) return;
        const form = input.closest('[data-user-files-upload-form]');
        if (!form) return;
        const status = form.querySelector('[data-user-files-upload-status]');
        const count = input.files ? input.files.length : 0;
        if (status) status.textContent = count ? `已选择 ${count} 个文件，点击“开始上传”` : '';
    });

    document.addEventListener('submit', async (event) => {
        const form = event.target.closest('[data-user-files-upload-form]');
        if (!form) return;
        event.preventDefault();

        const input = form.querySelector('[data-user-files-upload-input]');
        const status = form.querySelector('[data-user-files-upload-status]');
        const result = form.parentElement.querySelector('[data-user-files-upload-result]');
        const submit = form.querySelector('button[type="submit"]');
        const files = input && input.files ? Array.from(input.files) : [];

        if (!files.length) {
            if (status) status.textContent = '请先选择文件';
            return;
        }

        if (submit) submit.disabled = true;
        if (result) {
            result.hidden = false;
            result.innerHTML = '';
        }

        let success = 0;
        const total = files.length;

        for (let index = 0; index < total; index++) {
            const file = files[index];
            if (status) status.textContent = `正在上传 ${index + 1}/${total}：${file.name}`;

            const data = new FormData();
            for (const element of form.querySelectorAll('input[type="hidden"]')) {
                if (element.name) data.append(element.name, element.value);
            }
            const folder = form.querySelector('[name="folder_id"]');
            if (folder) data.set('folder_id', folder.value);
            data.set('attachment', file, file.name);

            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    body: data,
                    credentials: 'same-origin',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json',
                    },
                });
                const json = await userFilesUploadMessage(response);
                const items = Array.isArray(json.results) ? json.results : [];
                const item = items.find((row) => row && row.name === file.name) || items[0] || json;

                if (json.ok && item && item.ok) {
                    success++;
                    const line = document.createElement('div');
                    line.className = 'user-files-upload-result-item';

                    const label = document.createElement('strong');
                    label.textContent = `✓ ${file.name}`;
                    line.appendChild(label);

                    if (item.markdown) {
                        const copy = document.createElement('button');
                        copy.type = 'button';
                        copy.setAttribute('data-copy-user-files-path', '');
                        copy.setAttribute('data-copy-text', item.markdown);
                        copy.textContent = '复制插入链接';
                        line.appendChild(copy);
                    }
                    result.appendChild(line);
                } else {
                    const message = item && item.message ? item.message : (json.message || '上传失败');
                    throw new Error(message);
                }
            } catch (error) {
                const line = document.createElement('div');
                line.className = 'user-files-upload-result-item user-files-upload-result-error';
                line.textContent = `× ${file.name}：${error && error.message ? error.message : '上传失败'}`;
                result.appendChild(line);
            }
        }

        input.value = '';
        if (submit) submit.disabled = false;
        if (status) status.textContent = `上传完成：${success}/${total} 个文件成功`;

        const back = form.closest('.user-files-upload-page')?.querySelector('a[href*="user_files"]');
        if (back && result && success > 0) {
            const link = document.createElement('a');
            link.href = back.href;
            link.textContent = '返回文件管理';
            link.className = 'user-files-upload-result-back';
            result.appendChild(link);
        }
    });

    const user_files_recent_url = __USER_FILES_RECENT_URL__;
    const loadRecentFilesIntoNotifyModal = async () => {
        const modalBody = document.querySelector('#notify-modal-body');
        if (!modalBody || modalBody.querySelector('.user-files-recent-notify')) return;
        try {
            const url = new URL(user_files_recent_url, window.location.href);
            url.searchParams.set('_', String(Date.now()));
            const response = await fetch(url.toString(), {
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'text/html' },
            });
            if (!response.ok) return;
            const html = await response.text();
            if (!html.trim()) return;
            const wrap = document.createElement('div');
            wrap.className = 'user-files-recent-notify';
            wrap.innerHTML = html;
            modalBody.appendChild(wrap);
        } catch (e) {}
    };

    if (typeof window.openNotify === 'function' && !window.__userFilesOpenNotifyWrapped) {
        const originalOpenNotify = window.openNotify;
        window.openNotify = async function (url) {
            const result = await originalOpenNotify(url);
            await loadRecentFilesIntoNotifyModal();
            return result;
        };
        window.__userFilesOpenNotifyWrapped = true;
    }
})();
JS;
    return str_replace('__USER_FILES_RECENT_URL__', json_encode(route_url('user_files_recent'), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $js);
}



/* =========================================================
 * 后台用户文件中心
 *
 * 后台逻辑分为三层：
 *   概览：快捷筛选 + 文件最多 / 占用最大排行
 *   文件：逐文件管理与高级筛选
 *   用户：按用户聚合，支持文件数量 / 总占用筛选与排序
 *
 * 普通用户开关也放在这里，避免再增加一个分散的后台入口。
 * ========================================================= */

function user_files_admin_tabs(string $active): string
{
    $items = [
        'overview' => [
            'label' => '概览',
            'href' => admin_url(['tab' => 'user_files', 'view' => 'overview']),
        ],
        'files' => [
            'label' => '文件',
            'href' => admin_url(['tab' => 'user_files', 'view' => 'files']),
        ],
        'users' => [
            'label' => '用户',
            'href' => admin_url(['tab' => 'user_files', 'view' => 'users']),
        ],
    ];

    return tab_bar_html($items, $active, 'user-files-admin-tabs', 'user_files.admin.tabs');
}

function user_files_admin_delete_route(): void
{
    require_post();
    need_admin();

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) err('文件不存在');

    $file = one(
        'SELECT id,user_id,hash,file_name,original_name,ext,mime,size,is_image,created_at
         FROM app_attachments
         WHERE id=?',
        [$id]
    );

    if (!is_array($file)) err('文件不存在', 404);

    $stats = user_files_reference_stats($file);
    if ($stats['total'] > 0) err('该文件仍有引用，不能删除');

    $hash = (string)($file['hash'] ?? '');
    $name = (string)($file['file_name'] ?? '');
    $path = '';

    if (
        preg_match('/^[a-f0-9]{64}$/', $hash) === 1 &&
        preg_match('/^[a-f0-9]{64}\.[a-z0-9]{1,25}$/', $name) === 1 &&
        str_starts_with($name, $hash . '.')
    ) {
        $path = UPLOAD_DIR . '/' . upload_hash_dir($hash) . '/' . basename($name);
    }

    $can_unlink = !user_files_physical_source_shared($file);

    tx(function () use ($id): void {
        q('DELETE FROM plugin_user_files_folder_items WHERE attachment_id=?', [$id]);
        q('DELETE FROM plugin_user_files_detached WHERE attachment_id=?', [$id]);
        if (app_db_table_exists(db(), db_driver(), 'plugin_user_files_references')) q("DELETE FROM plugin_user_files_references WHERE attachment_id=? AND source_type IN ('topic','reply')", [$id]);
        q('DELETE FROM app_attachments WHERE id=?', [$id]);
    });

    if ($can_unlink && $path !== '' && is_file($path)) @unlink($path);

    set_flash('文件已删除');

    $back = (string)($_POST['back'] ?? 'files');
    $params = ['tab' => 'user_files', 'view' => $back === 'users' ? 'users' : 'files'];
    if ((int)($_POST['user_id'] ?? 0) > 0) $params['user_id'] = (int)$_POST['user_id'];
    go(admin_url($params));
}

function user_files_admin_settings_route(): void
{
    require_post();
    need_admin();

    $enabled = (string)($_POST['user_center_enabled'] ?? '') === '1';
    $raw_exts = (string)($_POST['compat_link_exts'] ?? '');
    $compat_exts = [];
    foreach (preg_split('/[\s,，、;；]+/u', $raw_exts, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $ext) {
        $ext = strtolower(trim((string)$ext));
        $ext = ltrim($ext, '.');
        if ($ext !== '' && preg_match('/^[a-z0-9]{1,25}$/', $ext) === 1) {
            $compat_exts[$ext] = true;
        }
    }

    $config = user_files_config();
    $config['user_center_enabled'] = $enabled ? 1 : 0;
    $config['compat_link_exts'] = array_keys($compat_exts);
    plugin_save_config('user_files', $config);

    set_flash('文件管理设置已保存');
    go(admin_url(['tab' => 'user_files', 'view' => 'overview']));
}

function user_files_admin_user_url(int $user_id): string
{
    return admin_url([
        'tab' => 'user_files',
        'view' => 'files',
        'user_id' => $user_id,
    ]);
}

function user_files_admin_size_input(string $label, string $name, string $value, string $placeholder): string
{
    return '<label class="user-files-admin-filter-field">' .
        '<span>' . h($label) . '</span>' .
        '<input type="number" min="0" step="1" name="' . h($name) . '" value="' . h($value) . '" placeholder="' . h($placeholder) . '">' .
        '</label>';
}

function user_files_admin_quick_link(string $label, string $description, array $params): string
{
    $view = (string)($params['_target'] ?? 'users');
    unset($params['_target']);
    $base = ['tab' => 'user_files', 'view' => $view];
    return '<a class="user-files-admin-quick" href="' . h(admin_url(array_merge($base, $params))) . '">' .
        '<strong>' . h($label) . '</strong>' .
        '<span>' . h($description) . '</span>' .
        '</a>';
}

function user_files_admin_overview_page(): string
{
    $config = user_files_config();
    $enabled = !empty($config['user_center_enabled']);
    $compat_exts = user_files_compat_link_exts();
    $compat_exts_text = implode(', ', $compat_exts);

    $total_files = (int)val('SELECT COUNT(*) FROM app_attachments');
    $total_size = (int)val('SELECT COALESCE(SUM(size),0) FROM app_attachments');
    $total_users = (int)val('SELECT COUNT(DISTINCT user_id) FROM app_attachments');
    $image_files = (int)val('SELECT COUNT(*) FROM app_attachments WHERE is_image=1');

    $top_count = q(
        'SELECT u.id,u.username,COUNT(a.id) AS file_count,COALESCE(SUM(a.size),0) AS total_size
         FROM app_users u
         INNER JOIN app_attachments a ON a.user_id=u.id
         GROUP BY u.id,u.username
         ORDER BY file_count DESC,total_size DESC,u.id ASC
         LIMIT 10'
    )->fetchAll();

    $top_size = q(
        'SELECT u.id,u.username,COUNT(a.id) AS file_count,COALESCE(SUM(a.size),0) AS total_size
         FROM app_users u
         INNER JOIN app_attachments a ON a.user_id=u.id
         GROUP BY u.id,u.username
         ORDER BY total_size DESC,file_count DESC,u.id ASC
         LIMIT 10'
    )->fetchAll();

    $top_large = q(
        'SELECT a.id,a.user_id,a.original_name,a.file_name,a.size,a.created_at,u.username
         FROM app_attachments a
         LEFT JOIN app_users u ON u.id=a.user_id
         ORDER BY a.size DESC,a.id DESC
         LIMIT 10'
    )->fetchAll();

    $html = user_files_admin_tabs('overview');

    $html .= '<div class="user-files-admin-summary-grid">' .
        '<div><strong>' . h((string)$total_files) . '</strong><span>全部文件</span></div>' .
        '<div><strong>' . h(user_files_format_size($total_size)) . '</strong><span>总占用</span></div>' .
        '<div><strong>' . h((string)$total_users) . '</strong><span>有文件用户</span></div>' .
        '<div><strong>' . h((string)$image_files) . '</strong><span>图片文件</span></div>' .
        '</div>';

    $html .= '<section class="user-files-admin-settings admin-list-panel">' .
        '<div class="admin-list-head"><div class="admin-plugin-summary"><strong>普通用户权限</strong><span>控制普通用户是否显示“文件”入口并使用个人文件中心</span></div></div>' .
        '<form method="post" action="' . h(route_url('user_files_admin_settings')) . '" class="user-files-admin-setting-form">' .
        form_token() .
        '<label class="user-files-admin-switch"><input type="checkbox" name="user_center_enabled" value="1"' . ($enabled ? ' checked' : '') . '><span><strong>允许普通用户使用文件管理</strong><small>关闭后，仅管理员可以从后台查看和管理全部用户文件；普通用户的“文件”和“我的文件”入口会隐藏。</small></span></label>' .
        '<label class="user-files-admin-setting-field"><span>兼容静态图片链接的文件格式</span><input type="text" name="compat_link_exts" value="' . h($compat_exts_text) . '" placeholder="jpg, jpeg, png, gif, webp"><small>填写扩展名，使用逗号分隔。点击“复制插入链接”时，这些格式会优先使用 /app/upload/... 静态链接；未列出的格式继续使用 /index.php?a=attachment... 链接。</small></label>' .
        '<button type="submit">保存设置</button>' .
        '</form></section>';

    $html .= '<section class="user-files-admin-quick-panel admin-list-panel">' .
        '<div class="admin-list-head"><div class="admin-plugin-summary"><strong>快捷筛选</strong><span>常用管理场景直接进入对应结果</span></div></div>' .
        '<div class="user-files-admin-quick-grid">' .
        user_files_admin_quick_link('文件最多', '按文件数量从高到低', ['sort' => 'count_desc']) .
        user_files_admin_quick_link('占用最大', '按用户总存储从高到低', ['sort' => 'size_desc']) .
        user_files_admin_quick_link('文件 ≥ 100 个', '快速定位文件数量较高用户', ['min_count' => '100', 'sort' => 'count_desc']) .
        user_files_admin_quick_link('占用 ≥ 1 GB', '快速定位高存储用户', ['min_total_size' => '1073741824', 'sort' => 'size_desc']) .
        user_files_admin_quick_link('占用 ≥ 100 MB', '快速定位中等存储用户', ['min_total_size' => '104857600', 'sort' => 'size_desc']) .
        user_files_admin_quick_link('单文件 ≥ 20 MB', '快速查看较大附件', ['_target' => 'files', 'min_size' => '20971520', 'sort' => 'size_desc']) .
        user_files_admin_quick_link('全部文件', '进入逐文件管理', ['_target' => 'files']) .
        '</div></section>';

    $html .= '<div class="user-files-admin-ranking-grid">';

    $html .= '<section class="admin-list-panel user-files-admin-ranking"><div class="admin-list-head"><div class="admin-plugin-summary"><strong>文件数量 TOP 10</strong><span>文件最多的用户</span></div><a href="' . h(admin_url(['tab' => 'user_files', 'view' => 'users', 'sort' => 'count_desc'])) . '">查看全部</a></div><ol>';
    foreach ($top_count as $i => $row) {
        $id = (int)$row['id'];
        $html .= '<li><span class="user-files-admin-rank">' . h((string)($i + 1)) . '</span><a class="user-files-admin-rank-name" href="' . h(user_files_admin_user_url($id)) . '">' . h((string)$row['username']) . '</a><span>' . h((string)(int)$row['file_count']) . ' 个 · ' . h(user_files_format_size((int)$row['total_size'])) . '</span></li>';
    }
    if (!$top_count) $html .= '<li class="empty-state">暂无数据</li>';
    $html .= '</ol></section>';

    $html .= '<section class="admin-list-panel user-files-admin-ranking"><div class="admin-list-head"><div class="admin-plugin-summary"><strong>存储占用 TOP 10</strong><span>总占用最大的用户</span></div><a href="' . h(admin_url(['tab' => 'user_files', 'view' => 'users', 'sort' => 'size_desc'])) . '">查看全部</a></div><ol>';
    foreach ($top_size as $i => $row) {
        $id = (int)$row['id'];
        $html .= '<li><span class="user-files-admin-rank">' . h((string)($i + 1)) . '</span><a class="user-files-admin-rank-name" href="' . h(user_files_admin_user_url($id)) . '">' . h((string)$row['username']) . '</a><span>' . h(user_files_format_size((int)$row['total_size'])) . ' · ' . h((string)(int)$row['file_count']) . ' 个</span></li>';
    }
    if (!$top_size) $html .= '<li class="empty-state">暂无数据</li>';
    $html .= '</ol></section>';

    $html .= '</div>';

    $html .= '<section class="admin-list-panel user-files-admin-large-files"><div class="admin-list-head"><div class="admin-plugin-summary"><strong>单文件最大 TOP 10</strong><span>适合快速排查异常大附件</span></div><a href="' . h(admin_url(['tab' => 'user_files', 'view' => 'files', 'sort' => 'size_desc'])) . '">查看全部</a></div><ul class="admin-manage-list user-files-admin-list">';
    foreach ($top_large as $file) {
        $owner_id = (int)$file['user_id'];
        $owner = trim((string)($file['username'] ?? '')) ?: ('用户 #' . $owner_id);
        $preview_url = user_files_preview_url($file);
        $large_actions = ($preview_url !== '' ? '<a href="' . h($preview_url) . '" target="_blank" rel="noopener">预览</a>' : '') .
            '<a href="' . h(user_files_admin_user_url($owner_id)) . '">查看用户</a>';
        $html .= '<li class="admin-list-item admin-object-row"><div class="admin-row-main"><div class="user-files-admin-title-line"><strong class="admin-content-title" title="' . h(user_files_file_label($file)) . '">' . h(user_files_file_label($file)) . '</strong></div><div class="admin-row-meta"><span>' . h($owner) . '</span><span>' . h(user_files_format_size((int)$file['size'])) . '</span><span>' . h(date('Y-m-d H:i', (int)$file['created_at'])) . '</span></div></div><div class="admin-inline-ops user-files-admin-ops">' . $large_actions . '</div></li>';
    }
    if (!$top_large) $html .= '<li class="empty-state">暂无数据</li>';
    $html .= '</ul></section>';

    return $html;
}

function user_files_admin_file_page(): string
{
    $page = max(1, (int)($_GET['p'] ?? 1));
    $size = 40;

    $user_id = max(0, (int)($_GET['user_id'] ?? 0));
    $query = cut(trim((string)($_GET['q'] ?? '')), 100);
    $mime = cut(trim((string)($_GET['mime'] ?? '')), 100);
    $min_size = trim((string)($_GET['min_size'] ?? ''));
    $max_size = trim((string)($_GET['max_size'] ?? ''));
    $ref_state = (string)($_GET['ref'] ?? 'all');
    $date_from = trim((string)($_GET['date_from'] ?? ''));
    $date_to = trim((string)($_GET['date_to'] ?? ''));
    $sort = (string)($_GET['sort'] ?? 'time_desc');

    if (!in_array($ref_state, ['all', 'referenced', 'unreferenced'], true)) $ref_state = 'all';
    if (!in_array($sort, ['time_desc', 'size_desc', 'size_asc'], true)) $sort = 'time_desc';

    $where = 'WHERE 1=1';
    $params = [];

    if ($user_id > 0) { $where .= ' AND a.user_id=?'; $params[] = $user_id; }
    if ($query !== '') {
        $like = '%' . $query . '%';
        $where .= ' AND (a.original_name LIKE ? OR a.file_name LIKE ? OR a.ext LIKE ?)';
        array_push($params, $like, $like, $like);
    }
    if ($mime !== '') { $where .= ' AND a.mime LIKE ?'; $params[] = '%' . $mime . '%'; }
    if ($min_size !== '' && ctype_digit($min_size)) { $where .= ' AND a.size>=?'; $params[] = (int)$min_size; }
    if ($max_size !== '' && ctype_digit($max_size)) { $where .= ' AND a.size<=?'; $params[] = (int)$max_size; }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from) === 1) { $ts = strtotime($date_from . ' 00:00:00'); if ($ts !== false) { $where .= ' AND a.created_at>=?'; $params[] = $ts; } }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to) === 1) { $ts = strtotime($date_to . ' 23:59:59'); if ($ts !== false) { $where .= ' AND a.created_at<=?'; $params[] = $ts; } }

    $total = (int)val('SELECT COUNT(*) FROM app_attachments a ' . $where, $params);
    $offset = ($page - 1) * $size;
    $order = match ($sort) {
        'size_desc' => 'a.size DESC,a.id DESC',
        'size_asc' => 'a.size ASC,a.id ASC',
        default => 'a.created_at DESC,a.id DESC',
    };

    $rows = q(
        'SELECT a.id,a.user_id,a.hash,a.file_name,a.original_name,a.ext,a.mime,a.size,a.is_image,a.created_at,u.username
         FROM app_attachments a
         LEFT JOIN app_users u ON u.id=a.user_id
         ' . $where . ' ORDER BY ' . $order . ' LIMIT ? OFFSET ?',
        array_merge($params, [$size, $offset])
    )->fetchAll();

    $reference_map = user_files_collect_reference_map($rows);

    $stats_total = (int)val('SELECT COUNT(*) FROM app_attachments');
    $stats_size = (int)val('SELECT COALESCE(SUM(size),0) FROM app_attachments');
    $stats_users = (int)val('SELECT COUNT(DISTINCT user_id) FROM app_attachments');

    $base = ['tab' => 'user_files', 'view' => 'files'];
    $filters = [
        'user_id' => $user_id > 0 ? $user_id : null,
        'q' => $query !== '' ? $query : null,
        'mime' => $mime !== '' ? $mime : null,
        'min_size' => $min_size !== '' ? $min_size : null,
        'max_size' => $max_size !== '' ? $max_size : null,
        'ref' => $ref_state !== 'all' ? $ref_state : null,
        'date_from' => $date_from !== '' ? $date_from : null,
        'date_to' => $date_to !== '' ? $date_to : null,
        'sort' => $sort !== 'time_desc' ? $sort : null,
    ];
    $pagination_params = array_merge($base, $filters);

    $form = '<form class="user-files-admin-filters" method="get" action="' . h(route_url('admin')) . '">' .
        '<input type="hidden" name="a" value="admin"><input type="hidden" name="tab" value="user_files"><input type="hidden" name="view" value="files">' .
        '<div class="user-files-admin-filter-grid">' .
        '<label class="user-files-admin-filter-field"><span>用户 UID</span><input type="number" min="1" name="user_id" value="' . h($user_id > 0 ? (string)$user_id : '') . '" inputmode="numeric" placeholder="例如 12"></label>' .
        '<label class="user-files-admin-filter-field user-files-admin-filter-wide"><span>文件名 / 扩展名</span><input type="search" name="q" value="' . h($query) . '" placeholder="搜索原始文件名或存储文件名"></label>' .
        '<label class="user-files-admin-filter-field"><span>MIME 类型</span><input type="text" name="mime" value="' . h($mime) . '" placeholder="image/ 或 application/"></label>' .
        user_files_admin_size_input('最小大小（字节）', 'min_size', $min_size, '1048576') .
        user_files_admin_size_input('最大大小（字节）', 'max_size', $max_size, '10485760') .
        '<label class="user-files-admin-filter-field"><span>引用状态</span><select name="ref"><option value="all"' . ($ref_state === 'all' ? ' selected' : '') . '>全部</option><option value="referenced"' . ($ref_state === 'referenced' ? ' selected' : '') . '>有引用</option><option value="unreferenced"' . ($ref_state === 'unreferenced' ? ' selected' : '') . '>无引用</option></select></label>' .
        '<label class="user-files-admin-filter-field"><span>排序</span><select name="sort"><option value="time_desc"' . ($sort === 'time_desc' ? ' selected' : '') . '>最新上传</option><option value="size_desc"' . ($sort === 'size_desc' ? ' selected' : '') . '>文件最大</option><option value="size_asc"' . ($sort === 'size_asc' ? ' selected' : '') . '>文件最小</option></select></label>' .
        '<label class="user-files-admin-filter-field"><span>上传起始日期</span><input type="date" name="date_from" value="' . h($date_from) . '"></label>' .
        '<label class="user-files-admin-filter-field"><span>上传结束日期</span><input type="date" name="date_to" value="' . h($date_to) . '"></label>' .
        '</div><div class="user-files-admin-filter-actions"><button type="submit">应用筛选</button><a href="' . h(admin_url(['tab' => 'user_files', 'view' => 'files'])) . '">清除</a></div></form>';

    $html = user_files_admin_tabs('files');
    $html .= '<div class="user-files-admin-summary-grid"><div><strong>' . h((string)$stats_total) . '</strong><span>全部文件</span></div><div><strong>' . h(user_files_format_size($stats_size)) . '</strong><span>总存储</span></div><div><strong>' . h((string)$stats_users) . '</strong><span>有文件用户</span></div></div>' . $form;

    if ($user_id > 0) {
        $owner = one('SELECT id,username FROM app_users WHERE id=?', [$user_id]);
        if (is_array($owner)) {
            $html .= '<div class="user-files-admin-context"><strong>当前用户：</strong>' . h((string)$owner['username']) . ' · UID ' . h((string)$user_id) . '<a href="' . h(admin_url(['tab' => 'user_files', 'view' => 'users'])) . '">返回用户</a></div>';
        }
    }

    $html .= '<div class="admin-list-panel user-files-admin-panel"><div class="admin-list-head"><div class="admin-plugin-summary"><strong>文件列表</strong><span>共 ' . h((string)$total) . ' 个结果</span></div></div><ul class="admin-manage-list user-files-admin-list">';

    foreach ($rows as $file) {
        $name = user_files_file_label($file);
        $refs = $reference_map[(string)(int)$file['id']] ?? [];
        $ref_count = count($refs);
        $owner_id = (int)$file['user_id'];
        $owner = trim((string)($file['username'] ?? '')) ?: ('用户 #' . $owner_id);
        $ref_url = route_url('user_files_admin_references', ['id' => (int)$file['id']]);
        $preview_url = user_files_preview_url($file);
        $actions = ($preview_url !== '' ? '<a href="' . h($preview_url) . '" target="_blank" rel="noopener">预览</a>' : '') .
            '<a href="' . h($ref_url) . '">引用 ' . h((string)$ref_count) . '</a>';
        if ($ref_count === 0) {
            $actions .= '<form method="post" action="' . h(route_url('user_files_admin_delete')) . '" data-no-ajax="1" data-confirm="确定删除这个文件吗？删除后无法恢复。">' . form_token() . '<input type="hidden" name="id" value="' . (int)$file['id'] . '"><input type="hidden" name="user_id" value="' . $owner_id . '"><button type="submit" class="user-files-delete">删除</button></form>';
        }
        $file_path = user_files_file_absolute_path($file);
        $insert_markdown = user_files_insert_markdown($file);
        $html .= '<li class="admin-list-item admin-object-row user-files-admin-item"><div class="admin-row-main"><div class="user-files-admin-title-line"><strong class="admin-content-title" title="' . h($name) . '">' . h($name) . '</strong><span class="admin-flag' . ($ref_count > 0 ? ' on' : '') . '">' . h($ref_count > 0 ? $ref_count . ' 个引用' : '无引用') . '</span></div><div class="admin-row-meta"><span>用户 <a href="' . h(user_files_admin_user_url($owner_id)) . '">' . h($owner) . '</a> · UID ' . h((string)$owner_id) . '</span><span>' . h(user_files_format_size((int)$file['size'])) . '</span><span>' . h((string)($file['mime'] ?? '')) . '</span><span>' . h(date('Y-m-d H:i', (int)$file['created_at'])) . '</span></div><div class="user-files-admin-stored"><code data-user-files-path>' . h($file_path) . '</code></div></div><div class="admin-inline-ops user-files-admin-ops">' . $actions . '</div></li>';
    }

    if (!$rows) $html .= '<li class="empty-state">没有符合条件的文件。</li>';
    $html .= '</ul></div>';

    $pagination = paginate($total, $page, $size, admin_url($pagination_params));
    if ($pagination !== '') $html .= '<div class="pagination-bar">' . $pagination . '</div>';

    return $html;
}

function user_files_admin_users_page(): string
{
    $page = max(1, (int)($_GET['p'] ?? 1));
    $size = 40;
    $offset = ($page - 1) * $size;

    $query = cut(trim((string)($_GET['q'] ?? '')), 100);
    $min_count = trim((string)($_GET['min_count'] ?? ''));
    $max_count = trim((string)($_GET['max_count'] ?? ''));
    $min_size = trim((string)($_GET['min_total_size'] ?? ''));
    $max_size = trim((string)($_GET['max_total_size'] ?? ''));
    $sort = (string)($_GET['sort'] ?? 'count_desc');

    if (!in_array($sort, ['count_desc', 'size_desc', 'last_desc', 'id_asc'], true)) $sort = 'count_desc';

    $where = 'WHERE 1=1';
    $params = [];
    if ($query !== '') {
        $like = '%' . $query . '%';
        if (ctype_digit($query)) { $where .= ' AND (u.id=? OR u.username LIKE ?)'; $params[] = (int)$query; $params[] = $like; }
        else { $where .= ' AND u.username LIKE ?'; $params[] = $like; }
    }

    $having = [];
    $having_params = [];
    if ($min_count !== '' && ctype_digit($min_count)) { $having[] = 'COUNT(a.id)>=?'; $having_params[] = (int)$min_count; }
    if ($max_count !== '' && ctype_digit($max_count)) { $having[] = 'COUNT(a.id)<=?'; $having_params[] = (int)$max_count; }
    if ($min_size !== '' && ctype_digit($min_size)) { $having[] = 'COALESCE(SUM(a.size),0)>=?'; $having_params[] = (int)$min_size; }
    if ($max_size !== '' && ctype_digit($max_size)) { $having[] = 'COALESCE(SUM(a.size),0)<=?'; $having_params[] = (int)$max_size; }

    $having_sql = $having ? ' HAVING ' . implode(' AND ', $having) : '';
    $total = (int)val(
        'SELECT COUNT(*) FROM (SELECT u.id FROM app_users u LEFT JOIN app_attachments a ON a.user_id=u.id ' . $where . ' GROUP BY u.id ' . $having_sql . ') user_stats',
        array_merge($params, $having_params)
    );

    $order = match ($sort) {
        'size_desc' => 'total_size DESC,file_count DESC,u.id ASC',
        'last_desc' => 'last_upload DESC,file_count DESC,u.id ASC',
        'id_asc' => 'u.id ASC',
        default => 'file_count DESC,total_size DESC,u.id ASC',
    };

    $rows = q(
        'SELECT u.id,u.username,COUNT(a.id) AS file_count,COALESCE(SUM(a.size),0) AS total_size,COALESCE(SUM(CASE WHEN a.is_image=1 THEN 1 ELSE 0 END),0) AS image_count,COALESCE(MAX(a.created_at),0) AS last_upload
         FROM app_users u LEFT JOIN app_attachments a ON a.user_id=u.id ' . $where . ' GROUP BY u.id,u.username ' . $having_sql . ' ORDER BY ' . $order . ' LIMIT ? OFFSET ?',
        array_merge($params, $having_params, [$size, $offset])
    )->fetchAll();

    $html = user_files_admin_tabs('users');
    $html .= '<form class="user-files-admin-filters user-files-admin-user-filters" method="get" action="' . h(route_url('admin')) . '"><input type="hidden" name="a" value="admin"><input type="hidden" name="tab" value="user_files"><input type="hidden" name="view" value="users"><div class="user-files-admin-filter-grid">' .
        '<label class="user-files-admin-filter-field user-files-admin-filter-wide"><span>用户 / UID</span><input type="search" name="q" value="' . h($query) . '" placeholder="用户名或 UID"></label>' .
        user_files_admin_size_input('最少文件数', 'min_count', $min_count, '100') .
        user_files_admin_size_input('最多文件数', 'max_count', $max_count, '1000') .
        user_files_admin_size_input('最少总大小（字节）', 'min_total_size', $min_size, '104857600') .
        user_files_admin_size_input('最多总大小（字节）', 'max_total_size', $max_size, '1073741824') .
        '<label class="user-files-admin-filter-field"><span>排序</span><select name="sort"><option value="count_desc"' . ($sort === 'count_desc' ? ' selected' : '') . '>文件最多</option><option value="size_desc"' . ($sort === 'size_desc' ? ' selected' : '') . '>占用最大</option><option value="last_desc"' . ($sort === 'last_desc' ? ' selected' : '') . '>最近上传</option><option value="id_asc"' . ($sort === 'id_asc' ? ' selected' : '') . '>UID 正序</option></select></label>' .
        '</div><div class="user-files-admin-filter-actions"><button type="submit">应用筛选</button><a href="' . h(admin_url(['tab' => 'user_files', 'view' => 'users'])) . '">清除</a></div></form>';

    $html .= '<div class="admin-list-panel user-files-admin-panel"><div class="admin-list-head"><div class="admin-plugin-summary"><strong>用户文件统计</strong><span>共 ' . h((string)$total) . ' 个用户</span></div></div><ul class="admin-manage-list user-files-admin-list">';

    foreach ($rows as $row) {
        $id = (int)$row['id'];
        $count = (int)$row['file_count'];
        $total_size = (int)$row['total_size'];
        $images = (int)$row['image_count'];
        $last_upload = (int)$row['last_upload'];
        $html .= '<li class="admin-list-item admin-object-row user-files-admin-user-item"><div class="admin-row-main"><div class="user-files-admin-title-line"><strong class="admin-content-title">' . h((string)$row['username']) . '</strong><span class="admin-flag">UID ' . h((string)$id) . '</span></div><div class="admin-row-meta"><span>' . h((string)$count) . ' 个文件</span><span>' . h(user_files_format_size($total_size)) . '</span><span>' . h((string)$images) . ' 张图片</span><span>' . h($last_upload > 0 ? date('Y-m-d H:i', $last_upload) : '—') . '</span></div></div><div class="admin-inline-ops user-files-admin-ops"><a href="' . h(user_files_admin_user_url($id)) . '">查看文件</a></div></li>';
    }
    if (!$rows) $html .= '<li class="empty-state">没有符合条件的用户。</li>';
    $html .= '</ul></div>';

    $pagination = paginate($total, $page, $size, admin_url([
        'tab' => 'user_files', 'view' => 'users',
        'q' => $query !== '' ? $query : null,
        'min_count' => $min_count !== '' ? $min_count : null,
        'max_count' => $max_count !== '' ? $max_count : null,
        'min_total_size' => $min_size !== '' ? $min_size : null,
        'max_total_size' => $max_size !== '' ? $max_size : null,
        'sort' => $sort !== 'count_desc' ? $sort : null,
    ]));
    if ($pagination !== '') $html .= '<div class="pagination-bar">' . $pagination . '</div>';

    return $html;
}

function user_files_admin_references_route(): void
{
    $_GET['admin_reference'] = '1';
    user_files_references_view();
}

function user_files_admin_page(array $plugin = []): string
{
    need_admin();

    $view = (string)($_GET['view'] ?? 'overview');
    if ($view === 'files') return user_files_admin_file_page();
    if ($view === 'users') return user_files_admin_users_page();
    return user_files_admin_overview_page();
}

/* =========================================================
 * Manifest
 * ========================================================= */

return [
    'id' => 'user_files',

    'name' => '我的附件文件管理',

    'version' => '2.7.14',

    'description' =>
        '用户文件中心：管理个人文件、建立文件夹并整理附件；支持复制文件链接、上传到指定文件夹、安全在线预览和查看论坛引用位置；其他功能可在文件页提供独立入口。',

    'author' => 'bbc',

    'config' => [
        'user_center_enabled' => 1,
        'compat_link_exts' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    ],

    'assets' => [
        'css' => 'user_files_css',
        'js' => 'user_files_js',
    ],

    'admin_tabs' => [
        'user_files' => 'user_files_admin_page',
    ],

    'install' => 'user_files_install',
    'uninstall' => 'user_files_uninstall',

    'cron' => [
        'reference_rebuild' => [
            'callback' => 'user_files_reference_rebuild_cron',
            'interval' => 'user_files_reference_cron_interval',
        ],
    ],

    'hooks' => [
        /*
         * 加入核心个人主页：
         * 主题 | 回帖 | 通知 | 文件 | 设置 | 后台
         */
        'user.profile_tabs' =>
            'user_files_profile_tabs',

        /*
         * 加入核心个人卡片：
         * <div class="user-links" data-slot="user.menu_links">
         *
         * 同一个 Hook 也会被移动端菜单使用。
         */
        'user.menu_links' =>
            'user_files_menu_links',

        'sidebar.stack' =>
            'user_files_sidebar_stack',
        'page.before_render' =>
            'user_files_page_before_render',
        'topic.after_save' =>
            'user_files_topic_after_save',
        'reply.after_save' =>
            'user_files_reply_after_save',
        'content.before_delete' =>
            'user_files_content_before_delete',
        'user_files.api' =>
            'user_files_api_hook',
    ],

    'routes' => [
        /*
         * 文件列表 + 引用位置详情共用一个路由。
         *
         * 普通：
         *   a=user_files
         *
         * 引用：
         *   a=user_files&view=references&id=123
         */
        'user_files' =>
            'user_files_page',

        'user_files_recent' =>
            'user_files_recent_route',
        'user_files_api' =>
            'user_files_api_route',

        'user_files_upload' =>
            'user_files_upload_page',

        'user_file_upload' =>
            'user_files_upload_route',

        /*
         * 删除仍使用独立 POST 路由。
         */
        'user_file_folder_create' =>
            'user_files_folder_create_route',

        'user_file_folder_rename' =>
            'user_files_folder_rename_route',

        'user_file_folder_pin' =>
            'user_files_folder_pin_route',

        'user_file_folder_delete' =>
            'user_files_folder_delete_route',

        'user_file_move' =>
            'user_files_move_route',

        'user_file_delete' =>
            'user_files_delete_route',

        'user_file_preview' =>
            'user_files_preview_route',

        'user_files_admin_delete' =>
            'user_files_admin_delete_route',

        'user_files_admin_settings' =>
            'user_files_admin_settings_route',

        'user_files_admin_references' =>
            'user_files_admin_references_route',
    ],
];