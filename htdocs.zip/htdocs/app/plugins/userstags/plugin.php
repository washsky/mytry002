<?php
if (!defined('APP_ROOT')) exit;

// ============================================================
// userstags — 用户规则与标签
// 根据发帖量、积分、用户标签等规则自动确定用户分组
// 支持用户组标签、版面标签权限（AND/OR 模式）、标签管理和积分规则
// ============================================================

function userstags_install(array $plugin): void
{
    userstags_schema();
}

function userstags_uninstall(array $plugin): void
{
    app_db_drop_table('plugin_userstags_rules');
    app_db_drop_table('plugin_userstags_forum_tags');
    app_db_drop_table('plugin_userstags_tags');
    app_db_drop_column('app_users', 'plugin_userstags_tags');
    app_db_drop_column('app_groups', 'plugin_userstags_tags');
}

function userstags_schema(): void
{
    static $ready = false;
    if ($ready) return;

    $t = app_db_types();
    app_db_create_table('plugin_userstags_rules', "id {$t['id']},name {$t['string']} NOT NULL,min_topics {$t['uint']} NOT NULL,min_replies {$t['uint']} NOT NULL,min_points {$t['uint']} NOT NULL,required_tags {$t['text']} NOT NULL,target_group_id {$t['uint']} NOT NULL,priority {$t['uint']} NOT NULL,enabled INTEGER NOT NULL,created_at {$t['uint']} NOT NULL");
    app_db_create_index('idx_plugin_userstags_rules_priority', 'plugin_userstags_rules(priority DESC,id ASC)');
    app_db_create_table('plugin_userstags_forum_tags', "id {$t['id']},forum_id {$t['uint']} NOT NULL UNIQUE,view_tags {$t['text']} NOT NULL,post_tags {$t['text']} NOT NULL,reply_tags {$t['text']} NOT NULL");
    app_db_create_table('plugin_userstags_tags', "id {$t['id']},name {$t['key']} NOT NULL UNIQUE,created_at {$t['uint']} NOT NULL");
    app_db_ensure_columns('app_users', ['plugin_userstags_tags' => $t['text']]);
    app_db_ensure_columns('app_groups', ['plugin_userstags_tags' => $t['text']]);
    $ready = true;
}

const USERSTAGS_EVAL_THROTTLE_SECONDS = 300;

function userstags_config(): array
{
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = plugin_config('userstags', [
        'auto_promote' => '1',
        'protect_admins' => '1',
        'points_enabled' => '0',
        'points_per_topic' => '2',
        'points_per_reply' => '1',
        'tag_mode' => 'or',
    ]);
    $cache['auto_promote'] = (string)$cache['auto_promote'] === '1';
    $cache['protect_admins'] = (string)$cache['protect_admins'] === '1';
    $cache['points_enabled'] = (string)$cache['points_enabled'] === '1';
    $cache['points_per_topic'] = max(0, min(1000, (int)$cache['points_per_topic']));
    $cache['points_per_reply'] = max(0, min(1000, (int)$cache['points_per_reply']));
    $cache['tag_mode'] = ($cache['tag_mode'] ?? 'or') === 'and' ? 'and' : 'or';
    return $cache;
}

function userstags_cache_reset(): void
{
    unset($GLOBALS['__userstags_rules'], $GLOBALS['__userstags_effective'], $GLOBALS['__userstags_group_tags'], $GLOBALS['__userstags_forum_perms']);
}

function userstags_last_eval_cookie_name(): string
{
    return 'plugin_userstags_last_eval';
}

function userstags_last_eval_due(int $user_id): bool
{
    if ($user_id <= 0) return false;
    $raw = (string)($_COOKIE[userstags_last_eval_cookie_name()] ?? '');
    $parts = explode(':', $raw, 2);
    if (count($parts) !== 2 || (int)$parts[0] !== $user_id) return true;
    return time() - (int)$parts[1] >= USERSTAGS_EVAL_THROTTLE_SECONDS;
}

function userstags_last_eval_mark(int $user_id): void
{
    if ($user_id <= 0) return;
    $name = userstags_last_eval_cookie_name();
    $value = $user_id . ':' . time();
    setcookie($name, $value, ['expires' => time() + COOKIE_TTL, 'path' => '/', 'secure' => auth_cookie_secure(), 'httponly' => true, 'samesite' => 'Lax']);
    $_COOKIE[$name] = $value;
}

// ---------- 标签管理 ----------

function userstags_parse_tags(string $tags): array
{
    $parts = preg_split('/[,，、\s]+/u', trim($tags)) ?: [];
    $result = [];
    foreach ($parts as $t) {
        $t = trim($t);
        if ($t !== '') $result[$t] = true;
    }
    return array_keys($result);
}

function userstags_format_tags(array $tags): string
{
    return implode(', ', $tags);
}

function userstags_all_tags(): array
{
    $counts = [];
    // 注册表中的标签（未分配给任何对象的也算）
    foreach (q("SELECT name FROM plugin_userstags_tags ORDER BY name")->fetchAll() as $row) {
        $counts[(string)$row['name']] = 0;
    }
    // 用户标签
    foreach (q("SELECT plugin_userstags_tags FROM app_users WHERE plugin_userstags_tags IS NOT NULL AND plugin_userstags_tags != ''")->fetchAll() as $row) {
        foreach (userstags_parse_tags((string)$row['plugin_userstags_tags']) as $t) {
            $counts[$t] = ($counts[$t] ?? 0) + 1;
        }
    }
    // 用户组标签
    foreach (q("SELECT plugin_userstags_tags FROM app_groups WHERE plugin_userstags_tags IS NOT NULL AND plugin_userstags_tags != ''")->fetchAll() as $row) {
        foreach (userstags_parse_tags((string)$row['plugin_userstags_tags']) as $t) {
            if (!isset($counts[$t])) $counts[$t] = 0;
            $counts[$t]++;
        }
    }
    ksort($counts);
    return $counts;
}

function userstags_remove_tag_everywhere(string $tag): int
{
    $removed = 0;
    foreach (q("SELECT id,plugin_userstags_tags FROM app_users WHERE plugin_userstags_tags IS NOT NULL AND plugin_userstags_tags != ''")->fetchAll() as $u) {
        $tags = userstags_parse_tags((string)$u['plugin_userstags_tags']);
        if (!in_array($tag, $tags, true)) continue;
        $tags = array_values(array_filter($tags, fn($t) => $t !== $tag));
        q("UPDATE app_users SET plugin_userstags_tags=? WHERE id=?", [userstags_format_tags($tags), (int)$u['id']]);
        $removed++;
    }
    foreach (q("SELECT id,plugin_userstags_tags FROM app_groups WHERE plugin_userstags_tags IS NOT NULL AND plugin_userstags_tags != ''")->fetchAll() as $g) {
        $tags = userstags_parse_tags((string)$g['plugin_userstags_tags']);
        if (!in_array($tag, $tags, true)) continue;
        $tags = array_values(array_filter($tags, fn($t) => $t !== $tag));
        q("UPDATE app_groups SET plugin_userstags_tags=? WHERE id=?", [userstags_format_tags($tags), (int)$g['id']]);
        $removed++;
    }
    if ($removed > 0) {
        groups_cache(true);
        $GLOBALS['__userstags_effective'] = [];
        $GLOBALS['__userstags_group_tags'] = [];
    }
    return $removed;
}

function userstags_add_tag_everywhere(string $tag): int
{
    $added = 0;
    // 给所有已有标签的用户添加新标签（便于批量赋权）
    foreach (q("SELECT id,plugin_userstags_tags FROM app_users WHERE plugin_userstags_tags IS NOT NULL AND plugin_userstags_tags != ''")->fetchAll() as $u) {
        $tags = userstags_parse_tags((string)$u['plugin_userstags_tags']);
        if (in_array($tag, $tags, true)) continue;
        $tags[] = $tag;
        q("UPDATE app_users SET plugin_userstags_tags=? WHERE id=?", [userstags_format_tags($tags), (int)$u['id']]);
        $added++;
    }
    return $added;
}

// ---------- 有效标签（用户标签 + 用户组标签） ----------

function userstags_group_tags(int $group_id): array
{
    if ($group_id <= 0) return [];
    $cache = $GLOBALS['__userstags_group_tags'] ?? [];
    if (array_key_exists($group_id, $cache)) return $cache[$group_id];
    $tags = one("SELECT plugin_userstags_tags FROM app_groups WHERE id=?", [$group_id]);
    return $GLOBALS['__userstags_group_tags'][$group_id] = $tags ? userstags_parse_tags((string)$tags['plugin_userstags_tags']) : [];
}

function userstags_effective_tags(int $user_id): array
{
    if ($user_id <= 0) return [];
    $cache = $GLOBALS['__userstags_effective'] ?? [];
    if (array_key_exists($user_id, $cache)) return $cache[$user_id];
    $user = one("SELECT plugin_userstags_tags,group_id FROM app_users WHERE id=?", [$user_id]);
    if (!$user) return $GLOBALS['__userstags_effective'][$user_id] = [];
    $user_tags = userstags_parse_tags((string)$user['plugin_userstags_tags']);
    $group_tags = userstags_group_tags((int)$user['group_id']);
    return $GLOBALS['__userstags_effective'][$user_id] = array_values(array_unique(array_merge($user_tags, $group_tags)));
}

// ---------- 版面标签权限 ----------

function userstags_forum_tag_perms_all(): array
{
    return q("SELECT * FROM plugin_userstags_forum_tags ORDER BY forum_id")->fetchAll();
}

function userstags_forum_tag_perms(int $forum_id): ?array
{
    if ($forum_id <= 0) return null;
    $cache = $GLOBALS['__userstags_forum_perms'] ?? [];
    if (array_key_exists($forum_id, $cache)) return $cache[$forum_id];
    return $GLOBALS['__userstags_forum_perms'][$forum_id] = one("SELECT * FROM plugin_userstags_forum_tags WHERE forum_id=?", [$forum_id]);
}

function userstags_check_forum_tags(int $forum_id, string $perm_type): bool
{
    $perms = userstags_forum_tag_perms($forum_id);
    if (!$perms) return true;
    $required = userstags_parse_tags((string)($perms[$perm_type] ?? ''));
    if (!$required) return true;
    if (!uid()) return false;
    if (can_manage()) return true;
    $effective = userstags_effective_tags(uid());
    // OR 逻辑：用户拥有任一所需标签即可
    foreach ($required as $tag) {
        if (in_array($tag, $effective, true)) return true;
    }
    return false;
}

/**
 * 被 index.php forum_group_allowed() 调用（用户组检查失败时回退）。
 * perm_type 映射：allow_view_groups→view_tags, allow_post_groups→post_tags, allow_reply_groups→reply_tags
 * OR 模式：用户组不满足时，标签满足即可
 */
function userstags_tag_override(bool $allowed, array $ctx): ?bool
{
    if ($allowed) return null;
    if (can_manage()) return true;
    $forum_id = (int)($ctx['forum_id'] ?? 0);
    $field = (string)($ctx['field'] ?? '');
    $map = ['allow_view_groups' => 'view_tags', 'allow_post_groups' => 'post_tags', 'allow_reply_groups' => 'reply_tags'];
    $perm_type = $map[$field] ?? '';
    if ($forum_id <= 0 || $perm_type === '' || userstags_config()['tag_mode'] !== 'or') return null;
    $perms = userstags_forum_tag_perms($forum_id);
    $required = userstags_parse_tags((string)($perms[$perm_type] ?? ''));
    if (!$required || !uid()) return null;
    $effective = userstags_effective_tags(uid());
    foreach ($required as $tag) if (in_array($tag, $effective, true)) return true;
    return null;
}

// ---------- 规则管理 ----------

function userstags_rules(): array
{
    if (!is_array($GLOBALS['__userstags_rules'] ?? null)) {
        $GLOBALS['__userstags_rules'] = q("SELECT * FROM plugin_userstags_rules ORDER BY priority DESC, id ASC")->fetchAll();
    }
    return $GLOBALS['__userstags_rules'];
}

function userstags_rule_by_id(int $id): ?array
{
    return one("SELECT * FROM plugin_userstags_rules WHERE id=?", [$id]);
}

function userstags_group_options(int $selected = 0): string
{
    $html = '';
    foreach (groups_cache() as $g) {
        $html .= '<option value="' . (int)$g['id'] . '"' . ((int)$g['id'] === $selected ? ' selected' : '') . '>' . h($g['name']) . '</option>';
    }
    return $html;
}

function userstags_rule_conditions_text(array $rule): string
{
    $conditions = [];
    if ((int)$rule['min_topics'] > 0) $conditions[] = '发帖≥' . (int)$rule['min_topics'];
    if ((int)$rule['min_replies'] > 0) $conditions[] = '回复≥' . (int)$rule['min_replies'];
    if ((int)$rule['min_points'] > 0) $conditions[] = '积分≥' . (int)$rule['min_points'];
    $req_tags = userstags_parse_tags((string)$rule['required_tags']);
    if ($req_tags) $conditions[] = '标签:' . h(userstags_format_tags($req_tags));
    return $conditions ? implode(' / ', $conditions) : '无条件';
}

function userstags_rule_matches(array $rule, int $topic_count, int $reply_count, int $points, array $tags): bool
{
    if ((int)$rule['min_topics'] > 0 && $topic_count < (int)$rule['min_topics']) return false;
    if ((int)$rule['min_replies'] > 0 && $reply_count < (int)$rule['min_replies']) return false;
    if ((int)$rule['min_points'] > 0 && $points < (int)$rule['min_points']) return false;
    $required = userstags_parse_tags((string)$rule['required_tags']);
    if ($required) {
        foreach ($required as $tag) {
            if (!in_array($tag, $tags, true)) return false;
        }
    }
    return true;
}

function userstags_eval_user(int $user_id): ?array
{
    if ($user_id <= 0) return null;

    $user = one("SELECT id,username,group_id,points,plugin_userstags_tags FROM app_users WHERE id=?", [$user_id]);
    if (!$user) return null;

    $config = userstags_config();
    if ($config['protect_admins']) {
        $group = group_by_id((int)$user['group_id']);
        if ($group && ((int)$group['allow_manage'] === 1 || (int)$group['allow_admin'] === 1)) return null;
    }

    $topic_count = (int)val("SELECT COUNT(*) FROM app_topics WHERE user_id=?", [$user_id]);
    $reply_count = (int)val("SELECT COUNT(*) FROM app_replies WHERE user_id=?", [$user_id]);
    $points = (int)$user['points'];
    $tags = userstags_effective_tags($user_id);

    $matched = null;
    foreach (userstags_rules() as $rule) {
        if ((int)$rule['enabled'] !== 1) continue;
        if ((int)$rule['target_group_id'] <= 0) continue;
        if (!group_by_id((int)$rule['target_group_id'])) continue;
        if (userstags_rule_matches($rule, $topic_count, $reply_count, $points, $tags)) {
            $matched = $rule;
            break;
        }
    }

    $target_gid = $matched ? (int)$matched['target_group_id'] : (int)setting('default_group_id', '2');
    $current_gid = (int)$user['group_id'];

    if ($target_gid === $current_gid) {
        return ['user' => $user, 'changed' => false, 'old_group' => $current_gid, 'new_group' => $current_gid, 'rule' => $matched];
    }

    q("UPDATE app_users SET group_id=? WHERE id=?", [$target_gid, $user_id]);
    unset($GLOBALS['__userstags_effective'][$user_id]);
    if ($user_id === uid()) $GLOBALS['__me_cache'] = null;

    return ['user' => $user, 'changed' => true, 'old_group' => $current_gid, 'new_group' => $target_gid, 'rule' => $matched];
}

// ---------- Hooks ----------

function userstags_on_boot($value, array $ctx)
{
    $config = userstags_config();
    if ($config['auto_promote'] && uid() && userstags_last_eval_due(uid())) {
        userstags_eval_user(uid());
        userstags_last_eval_mark(uid());
    }
    userstags_check_view_access();
    return $value;
}

function userstags_check_view_access(): void
{
    $a = (string)($_GET['a'] ?? '');
    if ($a !== 'forum' && $a !== 'topic') return;
    if (can_manage()) return;
    $fid = 0;
    if ($a === 'forum') {
        $fid = (int)($_GET['id'] ?? 0);
    } else {
        $tid = (int)($_GET['id'] ?? 0);
        if ($tid > 0) {
            $topic = one("SELECT forum_id FROM app_topics WHERE id=?", [$tid]);
            $fid = $topic ? (int)$topic['forum_id'] : 0;
        }
    }
    if ($fid <= 0) return;
    $config = userstags_config();
    if ($config['tag_mode'] === 'or') {
        // OR 模式：仅当版面没有用户组限制时才独立检查标签
        // 有用户组限制时由 forum_group_allowed 的 userstags_tag_override 处理
        $forum = forum_by_id($fid);
        if ($forum && trim((string)($forum['allow_view_groups'] ?? '')) !== '') return;
    }
    if (!userstags_check_forum_tags($fid, 'view_tags')) err('无权限访问此版面');
}

function userstags_on_topic_before_save($value, array $ctx)
{
    if (!empty($ctx['id'])) return $value; // 编辑不检查
    $fid = (int)($ctx['forum_id'] ?? ($value['forum_id'] ?? 0));
    if ($fid <= 0) return $value;
    $config = userstags_config();
    if ($config['tag_mode'] === 'or') {
        $forum = forum_by_id($fid);
        if ($forum && trim((string)($forum['allow_post_groups'] ?? '')) !== '') return $value;
    }
    if (!userstags_check_forum_tags($fid, 'post_tags')) err('无权限在此版面发帖');
    return $value;
}

function userstags_on_reply_before_save($value, array $ctx)
{
    if (!empty($ctx['id'])) return $value; // 编辑不检查
    $tid = (int)($value['topic_id'] ?? ($ctx['topic_id'] ?? 0));
    if ($tid <= 0) return $value;
    $topic = one("SELECT forum_id FROM app_topics WHERE id=?", [$tid]);
    if (!$topic) return $value;
    $fid = (int)$topic['forum_id'];
    $config = userstags_config();
    if ($config['tag_mode'] === 'or') {
        $forum = forum_by_id($fid);
        if ($forum && trim((string)($forum['allow_reply_groups'] ?? '')) !== '') return $value;
    }
    if (!userstags_check_forum_tags($fid, 'reply_tags')) err('无权限在此版面回帖');
    return $value;
}

function userstags_on_topic_save($value, array $ctx)
{
    $config = userstags_config();
    if (!empty($ctx['editing'])) return $value;
    $user_id = (int)($ctx['user_id'] ?? 0);
    if ($user_id <= 0) return $value;
    if ($config['points_enabled'] && $config['points_per_topic'] > 0) {
        user_points_change($user_id, $config['points_per_topic'], '发表主题');
    }
    if ($config['auto_promote']) userstags_eval_user($user_id);
    return $value;
}

function userstags_on_reply_save($value, array $ctx)
{
    $config = userstags_config();
    if (!empty($ctx['editing'])) return $value;
    $user_id = (int)($ctx['user_id'] ?? 0);
    if ($user_id <= 0) return $value;
    if ($config['points_enabled'] && $config['points_per_reply'] > 0) {
        user_points_change($user_id, $config['points_per_reply'], '发表回复');
    }
    if ($config['auto_promote']) userstags_eval_user($user_id);
    return $value;
}

function userstags_on_user_save($value, array $ctx)
{
    if (userstags_config()['auto_promote']) {
        $user_id = (int)($ctx['id'] ?? 0);
        if ($user_id > 0) userstags_eval_user($user_id);
    }
    return $value;
}

function userstags_feature_links(array $links, array $ctx): array
{
    if (!empty($ctx['is_admin'])) return $links;
    if (!uid()) return $links;
    $links[] = ['text' => '用户标签', 'url' => route_url('userstags')];
    return $links;
}

// ---------- 前台页面 ----------

function userstags_page(array $plugin): void
{
    need_login();
    $my_id = uid();
    $user = one("SELECT id,username,group_id,points,plugin_userstags_tags FROM app_users WHERE id=?", [$my_id]);
    if (!$user) err('用户不存在');

    $topic_count = (int)val("SELECT COUNT(*) FROM app_topics WHERE user_id=?", [$my_id]);
    $reply_count = (int)val("SELECT COUNT(*) FROM app_replies WHERE user_id=?", [$my_id]);
    $points = (int)$user['points'];
    $tags = userstags_effective_tags($my_id);
    $current_group = group_by_id((int)$user['group_id']);
    $group_name = $current_group ? h($current_group['name']) : '未分组';

    $stats = '<div class="userstags-stats">'
        . '<div class="userstags-stat"><strong>' . $topic_count . '</strong><span>发帖</span></div>'
        . '<div class="userstags-stat"><strong>' . $reply_count . '</strong><span>回复</span></div>'
        . '<div class="userstags-stat"><strong>' . $points . '</strong><span>积分</span></div>'
        . '<div class="userstags-stat"><strong>' . h(userstags_format_tags($tags) ?: '—') . '</strong><span>标签</span></div>'
        . '</div>';

    $current = '<div class="userstags-current">'
        . '<div class="userstags-current-label">当前分组</div>'
        . '<div class="userstags-current-group">' . $group_name . '</div>'
        . '</div>';

    $rules_html = '<div class="admin-list-panel plugin-manage-panel">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>分组规则</strong><span>满足条件后自动晋升</span></div>', '')
        . '<ul class="admin-manage-list">';

    foreach (userstags_rules() as $rule) {
        $enabled = (int)$rule['enabled'] === 1;
        $group = group_by_id((int)$rule['target_group_id']);
        $group_label = $group ? h($group['name']) : '<span class="userstags-warn">目标组不存在</span>';
        $status_class = $enabled ? 'userstags-rule-active' : 'userstags-rule-disabled';

        $rules_html .= '<li class="admin-list-item admin-object-row ' . $status_class . '">'
            . '<div class="admin-row-main">'
            . '<strong class="admin-content-title">' . h($rule['name'] ?: '规则 #' . (int)$rule['id']) . ' → ' . $group_label . '</strong>'
            . '<div class="admin-row-meta"><span>' . userstags_rule_conditions_text($rule) . '</span><span>优先级 ' . (int)$rule['priority'] . '</span>'
            . ($enabled ? '<span class="userstags-badge-ok">启用</span>' : '<span class="userstags-badge-off">停用</span>')
            . '</div></div></li>';
    }
    if (!userstags_rules()) $rules_html .= '<li class="empty-state">暂无分组规则</li>';
    $rules_html .= '</ul></div>';

    $html = '<div class="userstags-page">'
        . '<div class="userstags-overview">' . $current . $stats . '</div>'
        . $rules_html
        . '</div>';

    page('用户规则与标签', shell_html($html, sidebar_stack_html([sidebar_user_card_html()])));
}

// ---------- 后台管理 ----------

function userstags_admin_page(array $plugin): string
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = (string)($_POST['userstags_action'] ?? '');
        switch ($action) {
            case 'save_config': userstags_admin_save_config(); break;
            case 'save_rule': userstags_admin_save_rule(); break;
            case 'delete_rule': userstags_admin_delete_rule(); break;
            case 'save_tags': userstags_admin_save_tags(); break;
            case 'save_group_tags': userstags_admin_save_group_tags(); break;
            case 'save_forum_tags': userstags_admin_save_forum_tags(); break;
            case 'add_tag': userstags_admin_add_tag(); break;
            case 'delete_tag': userstags_admin_delete_tag(); break;
            case 'eval_all': userstags_admin_eval_all(); break;
            case 'export': userstags_admin_export(); break;
            case 'import': userstags_admin_import(); break;
            case 'adjust_points': userstags_admin_adjust_points(); break;
            default: err('参数错误');
        }
        $anchor_map = [
            'save_config' => ($_POST['form_section'] ?? '') === 'points' ? 'ug-panel-points' : 'ug-panel-config',
            'save_rule' => 'ug-panel-rules',
            'delete_rule' => 'ug-panel-rules',
            'save_tags' => 'ug-panel-user-tags',
            'save_group_tags' => 'ug-panel-group-tags',
            'save_forum_tags' => 'ug-panel-forum-tags',
            'add_tag' => 'ug-panel-tag-mgmt',
            'delete_tag' => 'ug-panel-tag-mgmt',
            'eval_all' => 'ug-panel-batch',
            'import' => 'ug-panel-io',
            'adjust_points' => 'ug-panel-points',
        ];
        $anchor = $anchor_map[$action] ?? '';
        go(admin_url(['tab' => 'userstags']) . ($anchor ? '#' . $anchor : ''));
    }

    $config = userstags_config();
    $rules = userstags_rules();
    $tag_select_opts = '<option value="">+标签</option>';
    foreach (array_keys(userstags_all_tags()) as $tn) {
        $tag_select_opts .= '<option value="' . h($tn) . '">' . h($tn) . '</option>';
    }

    // ===== 1. 设置面板 =====
    $settings = '<form class="plugin-settings-form userstags-form-inline" method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
        . form_token() . hidden_inputs(['userstags_action' => 'save_config', 'form_section' => 'basic'])
        . '<div class="ug-options-row">'
        . '<div class="ug-opt-group">'
        . '<div class="ug-opt-group-label">功能开关</div>'
        . '<div class="ug-opt-group-body">'
        . '<label class="ug-opt-label"><input type="checkbox" name="auto_promote" value="1"' . ($config['auto_promote'] ? ' checked' : '') . '> 自动晋升</label>'
        . '<label class="ug-opt-label"><input type="checkbox" name="protect_admins" value="1"' . ($config['protect_admins'] ? ' checked' : '') . '> 保护管理员</label>'
        . '<label class="ug-opt-label"><input type="checkbox" name="points_enabled" value="1"' . ($config['points_enabled'] ? ' checked' : '') . '> 积分规则</label>'
        . '</div></div>'
        . '<div class="ug-opt-group ug-opt-group-right">'
        . '<div class="ug-opt-group-label">标签权限模式</div>'
        . '<div class="ug-opt-group-body ug-opt-group-body-right">'
        . '<label class="ug-opt-label"><input type="radio" name="tag_mode" value="or"' . ($config['tag_mode'] === 'or' ? ' checked' : '') . '> 满足任一即可（OR）</label>'
        . '<label class="ug-opt-label"><input type="radio" name="tag_mode" value="and"' . ($config['tag_mode'] === 'and' ? ' checked' : '') . '> 必须同时满足（AND）</label>'
        . '</div></div>'
        . '</div>'
        . '<div class="userstags-form-actions"><button>保存设置</button></div></form>';

    $html = '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-overview">'
        . admin_list_head('<div class="admin-plugin-summary"><div class="ug-head-row"><strong>用户规则与标签</strong><span class="admin-plugin-meta">v1.5.2 · 作者：elm</span></div><span>根据发帖量、积分、用户标签等规则自动管理用户分组</span></div>', '')
        . '</div>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-config">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>基本设置</strong><span>分组与积分规则配置</span></div>', '')
        . '<div class="plugin-panel-body">' . $settings . '</div></div>';

    // ===== 2. 分组规则列表 =====
    $rules_list = '<ul class="admin-manage-list">';
    foreach ($rules as $rule) {
        $enabled = (int)$rule['enabled'] === 1;
        $group = group_by_id((int)$rule['target_group_id']);
        $group_label = $group ? h($group['name']) : '<span class="userstags-warn">组不存在</span>';

        $rules_list .= '<li class="admin-list-item admin-object-row userstags-rule-row">'
            . '<div class="admin-row-main">'
            . '<strong class="admin-content-title">' . h($rule['name'] ?: '规则 #' . (int)$rule['id']) . ' → ' . $group_label . '</strong>'
            . '<div class="admin-row-meta"><span>' . userstags_rule_conditions_text($rule) . '</span><span>优先级 ' . (int)$rule['priority'] . '</span>'
            . ($enabled ? '<span class="userstags-badge-ok">启用</span>' : '<span class="userstags-badge-off">停用</span>')
            . '</div></div>'
            . '<div class="admin-inline-ops">'
            . '<a href="' . h(admin_url(['tab' => 'userstags', 'edit_rule' => (int)$rule['id']])) . '">编辑</a>'
            . '<form class="post-action-form" method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '" data-confirm="确定删除此规则？">' . form_token() . hidden_inputs(['userstags_action' => 'delete_rule', 'rule_id' => (int)$rule['id']]) . '<button type="submit" class="danger" onclick="return confirm(\'确定删除此规则？\')">删除</button></form>'
            . '</div></li>';
    }
    if (!$rules) $rules_list .= '<li class="empty-state">暂无分组规则</li>';
    $rules_list .= '</ul>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-rules">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>分组规则</strong><span>按优先级从高到低匹配，首个满足条件的规则生效</span></div>', '')
        . $rules_list . '</div>';

    // ===== 3. 规则编辑表单（紧凑布局）=====
    $edit_rule = null;
    $edit_id = (int)($_GET['edit_rule'] ?? 0);
    if ($edit_id > 0) $edit_rule = userstags_rule_by_id($edit_id);

    $rule_form = '<form class="plugin-settings-form userstags-rule-form" method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
        . form_token() . hidden_inputs(['userstags_action' => 'save_rule'])
        . ($edit_rule ? hidden_inputs(['rule_id' => (int)$edit_rule['id']]) : '')
        . '<div class="userstags-form-grid">'
        . '<label class="ug-field ug-field-wide"><span>规则名称</span><input type="text" name="name" value="' . h((string)($edit_rule['name'] ?? '')) . '" maxlength="100"></label>'
        . '<label class="ug-field"><span>最少发帖</span><input type="number" name="min_topics" value="' . (int)($edit_rule['min_topics'] ?? 0) . '" min="0"></label>'
        . '<label class="ug-field"><span>最少回复</span><input type="number" name="min_replies" value="' . (int)($edit_rule['min_replies'] ?? 0) . '" min="0"></label>'
        . '<label class="ug-field"><span>最少积分</span><input type="number" name="min_points" value="' . (int)($edit_rule['min_points'] ?? 0) . '" min="0"></label>'
        . '<label class="ug-field ug-field-wide"><span>所需标签（逗号分隔）</span><div class="ug-tag-input-row"><input type="text" name="required_tags" value="' . h((string)($edit_rule['required_tags'] ?? '')) . '" maxlength="200" class="ug-tag-input"><select class="ug-tag-select" onchange="ugTagAdd(this)">' . $tag_select_opts . '</select></div></label>'
        . '<label class="ug-field"><span>目标用户组</span><select name="target_group_id"><option value="0">— 选择 —</option>' . userstags_group_options((int)($edit_rule['target_group_id'] ?? 0)) . '</select></label>'
        . '<label class="ug-field"><span>优先级</span><input type="number" name="priority" value="' . (int)($edit_rule['priority'] ?? 0) . '" min="0" max="9999"></label>'
        . '<label class="ug-field ug-field-check"><input type="checkbox" name="enabled" value="1"' . (($edit_rule && (int)$edit_rule['enabled'] === 1) || !$edit_rule ? ' checked' : '') . '> 启用</label>'
        . '</div>'
        . '<div class="userstags-form-actions"><button>' . ($edit_rule ? '更新规则' : '添加规则') . '</button>'
        . ($edit_rule ? ' <a href="' . h(admin_url(['tab' => 'userstags'])) . '" class="userstags-cancel-link">取消</a>' : '')
        . '</div></form>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-rule-edit">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>' . ($edit_rule ? '编辑规则' : '添加规则') . '</strong><span>设置条件与目标分组</span></div>', '')
        . '<div class="plugin-panel-body">' . $rule_form . '</div></div>';

    // ===== 4. 积分管理 =====
    $points_reward_form = '<form class="plugin-settings-form userstags-rule-form" method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
        . form_token() . hidden_inputs(['userstags_action' => 'save_config', 'form_section' => 'points'])
        . '<div class="userstags-inline-row">'
        . '<label class="ug-field-inline"><span>发帖奖励</span><input type="number" name="points_per_topic" value="' . $config['points_per_topic'] . '" min="0" max="1000"></label>'
        . '<label class="ug-field-inline"><span>回复奖励</span><input type="number" name="points_per_reply" value="' . $config['points_per_reply'] . '" min="0" max="1000"></label>'
        . '<button>保存奖励配置</button>'
        . '</div></form>';

    $points_adjust_form = '<form class="plugin-settings-form userstags-rule-form" method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
        . form_token() . hidden_inputs(['userstags_action' => 'adjust_points'])
        . '<div class="userstags-inline-row">'
        . '<label class="ug-field-inline"><span>对象类型</span><select name="target_type" id="ug-points-target"><option value="user">单个用户</option><option value="group">整个用户组</option></select></label>'
        . '<label class="ug-field-inline ug-field-inline-grow"><span>用户名 / 组名</span><input type="text" name="target_name" maxlength="60" placeholder="输入用户名"></label>'
        . '<label class="ug-field-inline"><span>积分变动</span><input type="number" name="points_delta" value="0" step="1"></label>'
        . '</div>'
        . '<div class="userstags-inline-row">'
        . '<label class="ug-field-inline ug-field-inline-grow"><span>原因（可选）</span><input type="text" name="points_reason" maxlength="100" placeholder="如：活动奖励 / 违规扣分"></label>'
        . '<button>执行</button>'
        . '</div></form>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-points">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>积分管理</strong><span>积分奖励配置与手动调整</span></div>', '')
        . '<div class="plugin-panel-body">'
        . '<div class="ug-sub-section"><div class="ug-sub-section-label">积分奖励配置</div>' . $points_reward_form . '</div>'
        . '<div class="ug-sub-section"><div class="ug-sub-section-label">手动调整积分</div>' . $points_adjust_form . '</div>'
        . '</div></div>';

    // ===== 5. 用户标签管理 =====
    $search = trim((string)($_GET['uq'] ?? ''));
    if ($search !== '') {
        $tag_users = q("SELECT id,username,group_id,points,plugin_userstags_tags FROM app_users WHERE (plugin_userstags_tags IS NOT NULL AND plugin_userstags_tags != '') OR username LIKE ? ORDER BY (plugin_userstags_tags IS NOT NULL AND plugin_userstags_tags != '') DESC, id DESC LIMIT 200", ['%' . $search . '%'])->fetchAll();
    } else {
        $tag_users = q("SELECT id,username,group_id,points,plugin_userstags_tags FROM app_users WHERE plugin_userstags_tags IS NOT NULL AND plugin_userstags_tags != '' ORDER BY id DESC LIMIT 200")->fetchAll();
    }

    $tag_search = '<form class="userstags-search-inline" method="get" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
        . '<input type="hidden" name="a" value="admin"><input type="hidden" name="tab" value="userstags">'
        . '<input type="text" name="uq" placeholder="搜索用户名" value="' . h($search) . '">'
        . '<button>搜索</button></form>';

    $tag_list = '<ul class="admin-manage-list">';
    foreach ($tag_users as $u) {
        $group = group_by_id((int)$u['group_id']);
        $tags = userstags_format_tags(userstags_parse_tags((string)$u['plugin_userstags_tags']));
        $tag_list .= '<li class="admin-list-item admin-object-row userstags-tag-row">'
            . '<div class="admin-row-main">'
            . '<strong class="admin-content-title">' . h($u['username']) . '</strong>'
            . '<div class="admin-row-meta"><span>分组: ' . h($group ? $group['name'] : '—') . '</span><span>积分: ' . (int)$u['points'] . '</span></div>'
            . '<form class="userstags-tag-form" method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
            . form_token() . hidden_inputs(['userstags_action' => 'save_tags', 'tag_user_id' => (int)$u['id']])
. '<input type="text" name="tags" value="' . h($tags) . '" placeholder="标签1, 标签2" maxlength="200" class="ug-tag-input">'
. '<select class="ug-tag-select" onchange="ugTagAdd(this)">' . $tag_select_opts . '</select>'
. '<button>保存</button></form>'
            . '</div></li>';
    }
    if (!$tag_users) $tag_list .= '<li class="empty-state">暂无用户</li>';
    $tag_list .= '</ul>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-user-tags">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>用户标签</strong><span>为用户添加标签，用于规则匹配和版面权限</span></div>', $tag_search)
        . $tag_list . '</div>';

    // ===== 5b. 用户组标签管理 =====
    $groups_with_tags = q("SELECT id,name,plugin_userstags_tags FROM app_groups ORDER BY id")->fetchAll();
    $group_tag_list = '<ul class="admin-manage-list">';
    foreach ($groups_with_tags as $g) {
        $tags_str = userstags_format_tags(userstags_parse_tags((string)$g['plugin_userstags_tags']));
        $group_tag_list .= '<li class="admin-list-item admin-object-row userstags-tag-row">'
            . '<div class="admin-row-main">'
            . '<strong class="admin-content-title">' . h($g['name']) . '</strong>'
            . '<form class="userstags-tag-form" method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
            . form_token() . hidden_inputs(['userstags_action' => 'save_group_tags', 'group_id' => (int)$g['id']])
. '<input type="text" name="tags" value="' . h($tags_str) . '" placeholder="标签1, 标签2" maxlength="200" class="ug-tag-input">'
. '<select class="ug-tag-select" onchange="ugTagAdd(this)">' . $tag_select_opts . '</select>'
. '<button>保存</button></form>'
            . '</div></li>';
    }
    $group_tag_list .= '</ul>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-group-tags">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>用户组标签</strong><span>为用户组设置标签，组内用户自动继承</span></div>', '')
        . $group_tag_list . '</div>';

    // ===== 5c. 版面标签权限 =====
    $forums = forums_cache();
    $perms_map = [];
    foreach (userstags_forum_tag_perms_all() as $p) {
        $perms_map[(int)$p['forum_id']] = $p;
    }
    $forum_perms_html = '<div class="ug-tag-select-bar"><span class="muted">先点击表格中输入框，再从此处选择标签追加</span><select class="ug-tag-select" onchange="ugTagAdd(this)">' . $tag_select_opts . '</select></div>'
        . '<form class="plugin-settings-form userstags-form-wide" method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
        . form_token() . hidden_inputs(['userstags_action' => 'save_forum_tags'])
        . '<table class="list admin-bulk-list userstags-forum-tags-table"><tr><th>版面</th><th>浏览标签</th><th>发帖标签</th><th>回帖标签</th></tr>';
    foreach ($forums as $f) {
        $fid = (int)$f['id'];
        $p = $perms_map[$fid] ?? ['view_tags' => '', 'post_tags' => '', 'reply_tags' => ''];
$forum_perms_html .= '<tr><td><strong>' . h($f['name']) . '</strong></td>'
. '<td><input type="text" name="view_tags[' . $fid . ']" value="' . h((string)$p['view_tags']) . '" placeholder="逗号分隔" maxlength="200" class="ug-tag-input"></td>'
. '<td><input type="text" name="post_tags[' . $fid . ']" value="' . h((string)$p['post_tags']) . '" placeholder="逗号分隔" maxlength="200" class="ug-tag-input"></td>'
. '<td><input type="text" name="reply_tags[' . $fid . ']" value="' . h((string)$p['reply_tags']) . '" placeholder="逗号分隔" maxlength="200" class="ug-tag-input"></td></tr>';
    }
    $forum_perms_html .= '</table><div class="userstags-form-actions"><button>保存版面权限</button></div></form>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-forum-tags">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>版面标签权限</strong><span>设置版面访问所需标签，与用户组权限叠加生效（留空=不限制）</span></div>', '')
        . '<div class="plugin-panel-body">' . $forum_perms_html . '</div></div>';

    // ===== 5d. 标签管理（汇总 + 增删） =====
    $all_tags = userstags_all_tags();

    $tag_chips_html = '<div class="ug-tag-chips">';
    if ($all_tags) {
        foreach ($all_tags as $tag => $count) {
            $tag_chips_html .= '<span class="ug-tag-chip">' . h($tag)
                . '<span class="ug-tag-meta">' . $count . '人</span>'
                . '<form method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '" style="display:inline">'
                . form_token() . hidden_inputs(['userstags_action' => 'delete_tag', 'tag_name' => $tag])
                . '<button type="submit" class="ug-tag-chip-del" title="从所有用户和用户组中删除此标签" onclick="return confirm(\'确定删除标签「' . h($tag) . '」？将从所有用户和用户组中移除。\')">×</button>'
                . '</form>'
                . '</span>';
        }
    } else {
        $tag_chips_html .= '<span class="muted">暂无标签</span>';
    }
    $tag_chips_html .= '</div>';

    $tag_add_form = '<form method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '" class="ug-tag-add-row">'
        . form_token() . hidden_inputs(['userstags_action' => 'add_tag'])
        . '<input type="text" name="new_tag" maxlength="50" placeholder="输入新标签名称">'
        . '<button>添加标签</button></form>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-tag-mgmt">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>标签管理</strong><span>查看所有标签，可直接增删</span></div>', '')
        . '<div class="plugin-panel-body">' . $tag_chips_html . $tag_add_form . '</div></div>';

    // ===== 6. 批量操作 =====
    $eval_form = '<form method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '" class="ug-batch-form">'
        . form_token() . hidden_inputs(['userstags_action' => 'eval_all'])
        . '<p class="muted">手动对所有用户执行一次分组评估。正常情况下自动晋升会在用户下次访问时触发。</p>'
        . '<div class="userstags-form-actions"><button>立即评估全部用户</button></div></form>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-batch">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>批量操作</strong><span>手动触发全量分组评估</span></div>', '')
        . '<div class="plugin-panel-body">' . $eval_form . '</div></div>';

    // ===== 7. 导入导出 =====
    $io_body = '<div class="ug-io-row">'
        . '<div class="ug-io-block">'
        . '<div class="ug-io-block-title">导出配置</div>'
        . '<p class="muted">将当前插件的全部设置（基本配置、规则、版面权限、标签）导出为 JSON 文件。</p>'
        . '<form method="post" data-no-ajax="1" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
        . form_token() . hidden_inputs(['userstags_action' => 'export'])
        . '<div class="userstags-form-actions"><button>导出为 JSON</button></div>'
        . '</form>'
        . '</div>'
        . '<div class="ug-io-block">'
        . '<div class="ug-io-block-title">导入配置</div>'
        . '<form method="post" data-no-ajax="1" enctype="multipart/form-data" action="' . h(admin_url(['tab' => 'userstags'])) . '">'
        . form_token() . hidden_inputs(['userstags_action' => 'import'])
        . '<p class="muted">上传 JSON 文件或粘贴内容，导入将<strong>覆盖</strong>当前规则与版面权限。</p>'
        . '<label class="ug-io-file-label">选择文件：<input type="file" name="import_file" accept=".json,application/json"></label>'
        . '<textarea name="import_json" placeholder="或粘贴 JSON 内容…" rows="4"></textarea>'
        . '<div class="userstags-form-actions"><button>导入</button></div>'
        . '</form>'
        . '</div>'
        . '</div>';

    $html .= '<div class="admin-list-panel plugin-manage-panel" id="ug-panel-io">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>导入 / 导出</strong><span>备份与迁移插件配置</span></div>', '')
        . '<div class="plugin-panel-body">' . $io_body . '</div></div>';

    // ===== JS: 标签下拉追加逻辑 =====
    $picker_js = '<script>
var _ugLast=null;
document.addEventListener("focusin",function(e){
if(e.target&&e.target.classList&&e.target.classList.contains("ug-tag-input"))_ugLast=e.target;
});
function ugTagAdd(sel){
var tag=sel.value;if(!tag)return;sel.value="";
if(!_ugLast)return;
var v=_ugLast.value.trim();
if(v){var p=v.split(/[,，、\s]+/).map(function(s){return s.trim()}).filter(Boolean);if(p.indexOf(tag)>=0)return;_ugLast.value=v+", "+tag;}
else{_ugLast.value=tag;}
// ponytail: setTimeout 递延焦点切换，避免 Enter 键事件穿透到表单输入框导致提前提交
setTimeout(function(){_ugLast.focus();},0);
}
</script>';

    return $html . $picker_js;
}

// ---------- 后台 Action 函数 ----------

function userstags_admin_save_config(): void
{
    $old = userstags_config();
    $section = (string)($_POST['form_section'] ?? '');
    if ($section === 'points') {
        plugin_save_config('userstags', [
            'auto_promote' => $old['auto_promote'] ? '1' : '0',
            'protect_admins' => $old['protect_admins'] ? '1' : '0',
            'points_enabled' => $old['points_enabled'] ? '1' : '0',
            'points_per_topic' => (string)max(0, min(1000, (int)($_POST['points_per_topic'] ?? 0))),
            'points_per_reply' => (string)max(0, min(1000, (int)($_POST['points_per_reply'] ?? 0))),
            'tag_mode' => $old['tag_mode'],
        ]);
    } else {
        plugin_save_config('userstags', [
            'auto_promote' => isset($_POST['auto_promote']) ? '1' : '0',
            'protect_admins' => isset($_POST['protect_admins']) ? '1' : '0',
            'points_enabled' => isset($_POST['points_enabled']) ? '1' : '0',
            'points_per_topic' => (string)$old['points_per_topic'],
            'points_per_reply' => (string)$old['points_per_reply'],
            'tag_mode' => ($_POST['tag_mode'] ?? 'or') === 'and' ? 'and' : 'or',
        ]);
    }
    set_flash('设置已保存');
}

function userstags_admin_save_rule(): void
{
    $rule_id = (int)($_POST['rule_id'] ?? 0);
    $name = post('name', 100);
    $min_topics = max(0, (int)($_POST['min_topics'] ?? 0));
    $min_replies = max(0, (int)($_POST['min_replies'] ?? 0));
    $min_points = max(0, (int)($_POST['min_points'] ?? 0));
    $required_tags = post('required_tags', 200);
    $target_group_id = max(0, (int)($_POST['target_group_id'] ?? 0));
    $priority = max(0, min(9999, (int)($_POST['priority'] ?? 0)));
    $enabled = isset($_POST['enabled']) ? 1 : 0;

    if ($target_group_id <= 0) err('请选择目标用户组');
    if (!group_by_id($target_group_id)) err('目标用户组不存在');

    if ($rule_id > 0) {
        q("UPDATE plugin_userstags_rules SET name=?,min_topics=?,min_replies=?,min_points=?,required_tags=?,target_group_id=?,priority=?,enabled=? WHERE id=?",
            [$name, $min_topics, $min_replies, $min_points, $required_tags, $target_group_id, $priority, $enabled, $rule_id]);
        userstags_cache_reset();
        set_flash('规则已更新');
    } else {
        q("INSERT INTO plugin_userstags_rules(name,min_topics,min_replies,min_points,required_tags,target_group_id,priority,enabled,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            [$name, $min_topics, $min_replies, $min_points, $required_tags, $target_group_id, $priority, $enabled, now()]);
        userstags_cache_reset();
        set_flash('规则已添加');
    }
}

function userstags_admin_delete_rule(): void
{
    $rule_id = (int)($_POST['rule_id'] ?? 0);
    if ($rule_id <= 0) err('参数错误');
    q("DELETE FROM plugin_userstags_rules WHERE id=?", [$rule_id]);
    userstags_cache_reset();
    set_flash('规则已删除');
}

function userstags_admin_save_tags(): void
{
    $user_id = (int)($_POST['tag_user_id'] ?? 0);
    if ($user_id <= 0) err('参数错误');
    $tags = post('tags', 200);
    $normalized = userstags_format_tags(userstags_parse_tags($tags));
    q("UPDATE app_users SET plugin_userstags_tags=? WHERE id=?", [$normalized, $user_id]);
    unset($GLOBALS['__userstags_effective'][$user_id]);
    set_flash('用户标签已保存');
    if (userstags_config()['auto_promote']) userstags_eval_user($user_id);
}

function userstags_admin_save_group_tags(): void
{
    $group_id = (int)($_POST['group_id'] ?? 0);
    if ($group_id <= 0) err('参数错误');
    if (!group_by_id($group_id)) err('用户组不存在');
    $tags = post('tags', 200);
    $normalized = userstags_format_tags(userstags_parse_tags($tags));
    q("UPDATE app_groups SET plugin_userstags_tags=? WHERE id=?", [$normalized, $group_id]);
    groups_cache(true);
    unset($GLOBALS['__userstags_group_tags'][$group_id]);
    foreach (array_keys($GLOBALS['__userstags_effective'] ?? []) as $cached_uid) {
        unset($GLOBALS['__userstags_effective'][$cached_uid]);
    }
    set_flash('用户组标签已保存');
}

function userstags_admin_save_forum_tags(): void
{
    $view_tags = $_POST['view_tags'] ?? [];
    $post_tags = $_POST['post_tags'] ?? [];
    $reply_tags = $_POST['reply_tags'] ?? [];
    if (!is_array($view_tags)) $view_tags = [];
    if (!is_array($post_tags)) $post_tags = [];
    if (!is_array($reply_tags)) $reply_tags = [];

    foreach (forums_cache() as $f) {
        $fid = (int)$f['id'];
        $vt = userstags_format_tags(userstags_parse_tags((string)($view_tags[$fid] ?? '')));
        $pt = userstags_format_tags(userstags_parse_tags((string)($post_tags[$fid] ?? '')));
        $rt = userstags_format_tags(userstags_parse_tags((string)($reply_tags[$fid] ?? '')));
        app_db_upsert('plugin_userstags_forum_tags', [
            'forum_id' => $fid,
            'view_tags' => $vt,
            'post_tags' => $pt,
            'reply_tags' => $rt,
        ], ['forum_id']);
        unset($GLOBALS['__userstags_forum_perms'][$fid]);
    }
    set_flash('版面标签权限已保存');
}

function userstags_admin_add_tag(): void
{
    $tag = trim((string)($_POST['new_tag'] ?? ''));
    if ($tag === '') err('标签名称不能为空');
    $tags = userstags_parse_tags($tag);
    if (!$tags) err('标签名称无效');
    $tag = $tags[0];
    $existing = one("SELECT id FROM plugin_userstags_tags WHERE name=?", [$tag]);
    if ($existing) err('标签「' . $tag . '」已存在');
    q("INSERT INTO plugin_userstags_tags(name,created_at) VALUES(?,?)", [$tag, now()]);
    set_flash('标签「' . $tag . '」已添加，可在用户标签或用户组标签面板中分配');
}

function userstags_admin_delete_tag(): void
{
    $tag = trim((string)($_POST['tag_name'] ?? ''));
    if ($tag === '') err('标签名称不能为空');
    $removed = userstags_remove_tag_everywhere($tag);
    q("DELETE FROM plugin_userstags_tags WHERE name=?", [$tag]);
    set_flash('标签「' . $tag . '」已删除，从 ' . $removed . ' 个对象中移除');
}

function userstags_admin_eval_all(): void
{
    $users = q("SELECT id FROM app_users ORDER BY id")->fetchAll();
    $changed = 0;
    foreach ($users as $u) {
        $result = userstags_eval_user((int)$u['id']);
        if ($result && $result['changed']) $changed++;
    }
    set_flash('全量评估完成，共 ' . count($users) . ' 位用户，' . $changed . ' 位分组已更新');
}

// ponytail: 导入导出 — JSON 明文快照，足够备份迁移；无版本协商，导入即覆盖
function userstags_admin_export(): void
{
    $config = userstags_config();
    // 还原 config 为可存储的字符串形式
    $config_out = [
        'auto_promote' => $config['auto_promote'] ? '1' : '0',
        'protect_admins' => $config['protect_admins'] ? '1' : '0',
        'points_enabled' => $config['points_enabled'] ? '1' : '0',
        'points_per_topic' => (string)$config['points_per_topic'],
        'points_per_reply' => (string)$config['points_per_reply'],
        'tag_mode' => $config['tag_mode'],
    ];
    $rules = q("SELECT name,min_topics,min_replies,min_points,required_tags,target_group_id,priority,enabled FROM plugin_userstags_rules ORDER BY id")->fetchAll();
    $forum_tags = q("SELECT forum_id,view_tags,post_tags,reply_tags FROM plugin_userstags_forum_tags ORDER BY forum_id")->fetchAll();
    $tags = q("SELECT name FROM plugin_userstags_tags ORDER BY name")->fetchAll();
    $payload = [
        'version' => 1,
        'plugin' => 'userstags',
        'exported_at' => date('Y-m-d H:i:s'),
        'config' => $config_out,
        'rules' => $rules,
        'forum_tags' => $forum_tags,
        'tags' => array_map(fn($r) => $r['name'], $tags),
    ];
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $filename = 'userstags-' . date('Ymd-His') . '.json';
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($json));
    echo $json;
    exit;
}

function userstags_admin_import(): void
{
    $raw = (string)($_POST['import_json'] ?? '');
    if ($raw === '' && isset($_FILES['import_file']) && is_uploaded_file($_FILES['import_file']['tmp_name'])) {
        $raw = (string)file_get_contents($_FILES['import_file']['tmp_name']);
    }
    if ($raw === '') err('未提供导入数据');
    $data = json_decode($raw, true);
    if (!is_array($data) || ($data['plugin'] ?? '') !== 'userstags') err('JSON 格式无效或不是 userstags 导出文件');
    // 1. 导入 config
    if (!empty($data['config']) && is_array($data['config'])) {
        $cfg = $data['config'];
        $merged = userstags_config();
        foreach (['auto_promote', 'protect_admins', 'points_enabled', 'points_per_topic', 'points_per_reply', 'tag_mode'] as $k) {
            if (isset($cfg[$k])) $merged[$k] = $cfg[$k];
        }
        plugin_save_config('userstags', [
            'auto_promote' => $merged['auto_promote'] ? '1' : '0',
            'protect_admins' => $merged['protect_admins'] ? '1' : '0',
            'points_enabled' => $merged['points_enabled'] ? '1' : '0',
            'points_per_topic' => (string)$merged['points_per_topic'],
            'points_per_reply' => (string)$merged['points_per_reply'],
            'tag_mode' => $merged['tag_mode'] === 'and' ? 'and' : 'or',
        ]);
    }

    // 2. 导入规则（覆盖）
    if (isset($data['rules']) && is_array($data['rules'])) {
        q("DELETE FROM plugin_userstags_rules");
        $GLOBALS['__userstags_rules'] = [];
        foreach ($data['rules'] as $r) {
            q("INSERT INTO plugin_userstags_rules(name,min_topics,min_replies,min_points,required_tags,target_group_id,priority,enabled,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                [
                    (string)($r['name'] ?? ''),
                    (int)($r['min_topics'] ?? 0),
                    (int)($r['min_replies'] ?? 0),
                    (int)($r['min_points'] ?? 0),
                    (string)($r['required_tags'] ?? ''),
                    (int)($r['target_group_id'] ?? 0),
                    (int)($r['priority'] ?? 0),
                    (int)($r['enabled'] ?? 1),
                    now(),
                ]);
        }
    }

    // 3. 导入版面标签权限（覆盖）
    if (isset($data['forum_tags']) && is_array($data['forum_tags'])) {
        q("DELETE FROM plugin_userstags_forum_tags");
        $GLOBALS['__userstags_forum_perms'] = [];
        foreach ($data['forum_tags'] as $f) {
            q("INSERT INTO plugin_userstags_forum_tags(forum_id,view_tags,post_tags,reply_tags) VALUES(?,?,?,?)",
                [
                    (int)($f['forum_id'] ?? 0),
                    (string)($f['view_tags'] ?? ''),
                    (string)($f['post_tags'] ?? ''),
                    (string)($f['reply_tags'] ?? ''),
                ]);
        }
    }

    // 4. 导入标签注册表（合并，不覆盖已有）
    if (isset($data['tags']) && is_array($data['tags'])) {
        foreach ($data['tags'] as $tag) {
            $tag = trim((string)$tag);
            if ($tag === '') continue;
            $existing = one("SELECT id FROM plugin_userstags_tags WHERE name=?", [$tag]);
            if (!$existing) q("INSERT INTO plugin_userstags_tags(name,created_at) VALUES(?,?)", [$tag, now()]);
        }
    }

    $rules_count = isset($data['rules']) ? count($data['rules']) : 0;
    $forum_count = isset($data['forum_tags']) ? count($data['forum_tags']) : 0;
    $tags_count = isset($data['tags']) ? count($data['tags']) : 0;
    set_flash('导入完成：规则 ' . $rules_count . ' 条、版面权限 ' . $forum_count . ' 项、标签 ' . $tags_count . ' 个');
}

function userstags_admin_adjust_points(): void
{
    $target_type = (string)($_POST['target_type'] ?? 'user');
    $target_name = post('target_name', 60);
    $delta = (int)($_POST['points_delta'] ?? 0);
    $reason = post('points_reason', 100) ?: '管理员调整';

    if ($delta === 0) err('积分变动不能为 0');
    if ($delta > 1000000 || $delta < -1000000) err('积分变动范围超出限制');
    if ($target_name === '') err('请输入用户名或组名');

    if ($target_type === 'group') {
        $group = null;
        foreach (groups_cache() as $g) {
            if ($g['name'] === $target_name) { $group = $g; break; }
        }
        if (!$group) err('用户组「' . $target_name . '」不存在');
        $users = q("SELECT id FROM app_users WHERE group_id=?", [(int)$group['id']])->fetchAll();
        if (!$users) err('该用户组下没有用户');
        $count = 0;
        foreach ($users as $u) {
            user_points_change((int)$u['id'], $delta, $reason);
            $count++;
        }
        set_flash('已对「' . $group['name'] . '」组 ' . $count . ' 位用户' . ($delta > 0 ? '增加' : '扣除') . ' ' . abs($delta) . ' 积分');
    } else {
        $user = one("SELECT id,username FROM app_users WHERE username=?", [$target_name]);
        if (!$user) err('用户「' . $target_name . '」不存在');
        user_points_change((int)$user['id'], $delta, $reason);
        set_flash('已对「' . $user['username'] . '」' . ($delta > 0 ? '增加' : '扣除') . ' ' . abs($delta) . ' 积分');
    }
}

// ---------- CSS ----------

function userstags_css(): string
{
    return '
.userstags-page{display:grid;gap:14px}
.userstags-overview{display:grid;grid-template-columns:auto 1fr;gap:14px;align-items:center;padding:16px;border:1px solid var(--line);border-radius:var(--radius);background:var(--panel)}
.userstags-current{text-align:center}
.userstags-current-label{color:var(--muted2);font-size:12px;margin-bottom:4px}
.userstags-current-group{font-size:18px;font-weight:700;color:var(--brand)}
.userstags-stats{display:flex;gap:16px;flex-wrap:wrap}
.userstags-stat{display:flex;flex-direction:column;gap:2px}
.userstags-stat strong{font-size:16px;color:var(--text)}
.userstags-stat span{font-size:11px;color:var(--muted2)}
.userstags-rule-active{opacity:1}
.userstags-rule-disabled{opacity:.5}
.userstags-badge-ok{color:var(--brand)!important;font-weight:600}
.userstags-badge-off{color:var(--text-muted)!important}
.userstags-warn{color:var(--danger)!important}
.userstags-rule-row{grid-template-columns:minmax(0,1fr) auto}
.userstags-tag-row{grid-template-columns:minmax(0,1fr)}
.userstags-tag-row .admin-row-main{gap:8px}
.userstags-tag-form{display:flex;gap:8px;align-items:center;margin-top:6px}
.userstags-tag-form input{flex:1;min-width:0;height:32px;box-sizing:border-box;padding:6px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:13px}
.userstags-tag-form button{flex-shrink:0;white-space:nowrap}
.userstags-search-inline{display:flex;gap:6px;align-items:center}
.userstags-search-inline input{width:160px;padding:5px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:12px}
.userstags-search-inline button{flex-shrink:0;white-space:nowrap}
/* ===== 基本设置美化 ===== */
.userstags-form-inline{display:flex!important;flex-direction:column;gap:10px;max-width:none!important}
.ug-head-row{display:flex;align-items:baseline;justify-content:space-between;gap:12px}
.ug-head-row strong{font-size:14px}
.admin-plugin-meta{font-size:11px;color:var(--brand)!important;font-weight:600;white-space:nowrap}
/* 选项行：两组并排，每组一个外框 */
.ug-options-row{display:flex;gap:12px;align-items:stretch;padding:4px 0;flex-wrap:wrap}
.ug-opt-group{display:flex;flex-direction:column;gap:6px;padding:8px 12px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--line-soft)}
.ug-opt-group-right{flex:0 0 auto;margin-left:auto}
.ug-opt-group-label{font-size:12px;font-weight:600;color:var(--text-muted);letter-spacing:.3px}
.ug-opt-group-body{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.ug-opt-group-body-right{justify-content:flex-end}
.ug-opt-label{display:inline-flex;align-items:center;gap:5px;padding:4px 8px;color:var(--text);font-size:13px;cursor:pointer;white-space:nowrap;transition:color .15s}
.ug-opt-label:hover{color:var(--brand)}
.ug-opt-label:has(input:checked){color:var(--brand);font-weight:500}
.ug-opt-label input[type=checkbox],.ug-opt-label input[type=radio]{width:14px;height:14px;accent-color:var(--brand);flex-shrink:0}
.ug-opt-label input[type=checkbox]{width:38px;height:22px;accent-color:initial}
/* 内联行：radio / 字段 + 按钮同一行 */
.userstags-inline-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.userstags-inline-row button{margin-left:auto;justify-self:end!important}
.ug-field-inline{display:flex;align-items:center;gap:6px;font-size:13px;color:var(--text-muted);white-space:nowrap}
.ug-field-inline>span{font-size:12px;color:var(--text-muted);font-weight:500;flex-shrink:0}
.ug-field-inline input,.ug-field-inline select{width:auto;height:32px;box-sizing:border-box;padding:0 8px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:13px;transition:border-color .15s}
.ug-field-inline input:focus,.ug-field-inline select:focus{border-color:var(--brand);outline:none}
.ug-field-inline input[type=number]{width:70px}
.ug-field-inline-grow{flex:1;min-width:120px}
.ug-field-inline-grow input{flex:1;width:100%;min-width:0}
/* ===== 规则表单 / 积分管理 ===== */
.userstags-rule-form{display:grid;gap:12px;max-width:none!important}
.userstags-rule-form input,.userstags-rule-form select{max-width:none!important}
.ug-sub-section{margin-bottom:16px}
.ug-sub-section:last-child{margin-bottom:0}
.ug-sub-section-label{font-size:12px;font-weight:600;color:var(--text-muted);margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid var(--line-soft)}
.userstags-form-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px 12px}
.ug-field{display:flex;flex-direction:column;gap:4px}
.ug-field>span{font-size:12px;color:var(--text-muted);font-weight:500}
.ug-field input,.ug-field select{height:34px;box-sizing:border-box;padding:0 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:13px;transition:border-color .15s}
.ug-field input:focus,.ug-field select:focus{border-color:var(--brand);outline:none}
.ug-field input[type=number]{max-width:100%}
.ug-field-wide{grid-column:span 3}
.ug-field-check{flex-direction:row;align-items:center;gap:6px;padding:7px 0}
.ug-field-check input{width:15px;height:15px;accent-color:var(--brand)}
.ug-field-check input[type=checkbox]{width:38px;height:22px;accent-color:initial}
.userstags-form-actions{display:flex;gap:8px;align-items:center;justify-content:flex-end;padding-top:4px;width:100%}
.userstags-form-actions button{justify-self:end!important}
.ug-batch-form{display:flex;flex-direction:column;gap:8px}
.ug-batch-form .muted{margin:0}
/* ===== 导入导出 ===== */
.ug-io-row{display:flex;flex-direction:column;gap:16px}
.ug-io-block{display:flex;flex-direction:column;gap:8px;padding:12px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--line-soft)}
.ug-io-block-title{font-size:13px;font-weight:600;color:var(--text)}
.ug-io-block .muted{font-size:12px;margin:0}
.ug-io-file-label{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text-muted);cursor:pointer}
.ug-io-block textarea{width:100%;box-sizing:border-box;padding:6px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:12px;font-family:monospace;resize:vertical}
.ug-io-block textarea:focus{border-color:var(--brand);outline:none}
.userstags-cancel-link{font-size:13px;color:var(--text-muted)}
.userstags-form-wide{max-width:none!important}
.userstags-form-wide input{max-width:none!important}
.userstags-forum-tags-table{width:100%;table-layout:fixed;border-collapse:collapse;font-size:13px}
.userstags-forum-tags-table th{text-align:center!important;padding:6px 8px;border-bottom:2px solid var(--line);color:var(--text-muted);font-size:12px}
.userstags-forum-tags-table td{padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:middle}
.userstags-forum-tags-table th:first-child,.userstags-forum-tags-table td:first-child{text-align:left!important;white-space:nowrap;width:auto}
.userstags-forum-tags-table td:not(:first-child){text-align:center}
.ug-tag-input{width:100%;padding:5px 8px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:13px}
.ug-tag-chips{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.ug-tag-chip{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border:1px solid var(--line);border-radius:4px;background:var(--panel);color:var(--text);font-size:13px}
.ug-tag-chip-del{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;min-height:0!important;min-width:0!important;border:none;border-radius:3px;background:var(--danger);color:var(--inverse-text);font-size:13px;line-height:18px;text-align:center;cursor:pointer;padding:0;flex-shrink:0;box-sizing:border-box}
.ug-tag-chip-del:hover{opacity:.8}
.ug-tag-add-row{display:flex;gap:8px;align-items:center;margin-top:8px}
.ug-tag-add-row input{flex:1;min-width:0;padding:6px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:13px}
.ug-tag-meta{font-size:11px;color:var(--muted2);margin-left:4px}
.ug-tag-input-row{display:flex;gap:6px;align-items:center}
.ug-tag-input-row input{flex:1;min-width:0}
.ug-tag-select{height:32px;box-sizing:border-box;padding:5px 6px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:12px;flex-shrink:0;cursor:pointer;max-width:90px;width:90px}
.ug-tag-select-bar{display:flex;gap:8px;align-items:center;justify-content:space-between;margin-bottom:8px}
.ug-tag-select-bar .muted{font-size:12px;text-align:left;flex:0 1 auto}
.ug-tag-select-bar .ug-tag-select{margin-left:auto}
.userstags-tag-form .ug-tag-select{flex-shrink:0}
/* ===== 移动端响应式 ===== */
@media(max-width:768px){.userstags-form-grid{grid-template-columns:repeat(2,1fr)}.ug-field-wide{grid-column:span 2}.userstags-rule-row{grid-template-columns:minmax(0,1fr)}.userstags-rule-row .admin-inline-ops{grid-column:1;justify-content:flex-start;margin-left:0}.ug-setting-group{flex:1 1 100%}.userstags-checkbox-row label{flex:1;justify-content:center;min-width:120px}.userstags-inline-row{flex-wrap:wrap}.ug-field-inline{flex:1;min-width:140px}.userstags-forum-tags-table{font-size:12px}.userstags-forum-tags-table th,.userstags-forum-tags-table td{padding:4px 5px}.ug-options-row{flex-direction:column}}
@media(max-width:480px){.userstags-form-grid{grid-template-columns:1fr}.ug-field-wide{grid-column:span 1}.userstags-overview{grid-template-columns:1fr;text-align:center}.userstags-stats{justify-content:center}.userstags-checkbox-row{flex-direction:column}.userstags-checkbox-row label{width:100%;justify-content:flex-start}.userstags-inline-row{flex-direction:column;align-items:stretch}.userstags-inline-row button{width:100%}.ug-field-inline{width:100%}.ug-field-inline input,.ug-field-inline select{flex:1;width:100%}.userstags-form-actions{justify-content:center}.userstags-forum-tags-table thead{display:none}.userstags-forum-tags-table,.userstags-forum-tags-table tbody,.userstags-forum-tags-table tr,.userstags-forum-tags-table td{display:block;width:100%}.userstags-forum-tags-table tr{padding:6px 0;border-bottom:1px solid var(--line)}.userstags-forum-tags-table td{border:none;text-align:left!important;padding:3px 0}.userstags-forum-tags-table td:first-child{font-weight:600;color:var(--text)}.ug-opt-group-body-right{justify-content:flex-start}.ug-tag-select-bar{justify-content:flex-start}.ug-tag-select-bar .muted{text-align:left}}
';
}

return [
    'id' => 'userstags',
    'name' => '用户规则与标签',
    'version' => '1.6.3',
    'description' => '根据发帖量、积分和标签自动管理用户分组，并控制不同标签用户的版块权限。',
    'author' => 'elm',
    'assets' => ['css' => 'userstags_css', 'scope' => 'all'],
    'hooks' => [
        'app.boot' => 'userstags_on_boot',
        'topic.before_save' => 'userstags_on_topic_before_save',
        'reply.before_save' => 'userstags_on_reply_before_save',
        'topic.after_save' => 'userstags_on_topic_save',
        'reply.after_save' => 'userstags_on_reply_save',
        'user.after_save' => 'userstags_on_user_save',
        'forum_group_allowed' => 'userstags_tag_override',
        'sidebar.feature_links' => 'userstags_feature_links',
    ],
    'routes' => [
        'userstags' => 'userstags_page',
    ],
    'admin_tabs' => [
        'userstags' => 'userstags_admin_page',
    ],
    'install' => 'userstags_install',
    'uninstall' => 'userstags_uninstall',
];