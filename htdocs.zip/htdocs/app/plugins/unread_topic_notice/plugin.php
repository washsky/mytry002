<?php
if (!defined('APP_ROOT')) exit;

function unread_topic_notice_install(array $plugin): void
{
    app_db_drop_table('plugin_unread_topic_notice_views');
}

function unread_topic_notice_uninstall(array $plugin): void
{
    app_db_drop_table('plugin_unread_topic_notice_views');
    unread_topic_notice_viewed_clear();
}

function unread_topic_notice_cookie_name(): string
{
    return '__unread_topic_notice_views';
}

function unread_topic_notice_viewed_state(): array
{
    $uid = uid();
    $state = $GLOBALS['__unread_topic_notice_viewed_cache'] ?? [];
    $state = is_array($state) ? $state : [];
    if (!$uid) return ['uid' => 0, 'map' => []];
    if ((int)($state['uid'] ?? 0) === $uid) return $state + ['uid' => $uid, 'map' => []];

    $map = [];
    $raw = (string)($_COOKIE[unread_topic_notice_cookie_name()] ?? '');
    $items = array_slice(explode('.', $raw), 0, 100);
    for ($i = 0, $count = count($items); $i + 1 < $count; $i += 2) {
        if (!ctype_digit($items[$i]) || !ctype_digit($items[$i + 1])) continue;
        $topic_id = (int)$items[$i];
        if ($topic_id <= 0 || isset($map[$topic_id])) continue;
        $map[$topic_id] = ['reply_count' => (int)$items[$i + 1]];
    }
    return $GLOBALS['__unread_topic_notice_viewed_cache'] = ['uid' => $uid, 'map' => $map];
}

function unread_topic_notice_viewed_map(): array
{
    $state = unread_topic_notice_viewed_state();
    return is_array($state['map'] ?? null) ? $state['map'] : [];
}

function unread_topic_notice_viewed_write(array $map): void
{
    $uid = uid();
    if (!$uid) return;
    $map = array_slice($map, 0, 50, true);
    $items = [];
    foreach ($map as $topic_id => $view) {
        $items[] = (int)$topic_id;
        $items[] = max(0, (int)($view['reply_count'] ?? 0));
    }
    $value = implode('.', $items);
    $name = unread_topic_notice_cookie_name();
    setcookie($name, $value, ['expires' => time() + COOKIE_TTL, 'path' => '/', 'secure' => auth_cookie_secure(), 'httponly' => true, 'samesite' => 'Lax']);
    $_COOKIE[$name] = $value;
    $GLOBALS['__unread_topic_notice_viewed_cache'] = ['uid' => $uid, 'map' => $map];
}

function unread_topic_notice_viewed_clear(): void
{
    $name = unread_topic_notice_cookie_name();
    setcookie($name, '', ['expires' => time() - 3600, 'path' => '/', 'secure' => auth_cookie_secure(), 'httponly' => true, 'samesite' => 'Lax']);
    unset($_COOKIE[$name], $GLOBALS['__unread_topic_notice_viewed_cache']);
}

function unread_topic_notice_recorded_reply_count(int $topic_id): ?int
{
    $state = unread_topic_notice_viewed_state();
    $map = is_array($state['map'] ?? null) ? $state['map'] : [];
    if (array_key_exists($topic_id, $map) && is_array($map[$topic_id])) return $map[$topic_id]['reply_count'] === null ? null : (int)$map[$topic_id]['reply_count'];
    return null;
}

function unread_topic_notice_set_viewed(int $topic_id, int $reply_count): void
{
    $uid = uid();
    if (!$uid || $topic_id <= 0) return;

    $reply_count = max(0, $reply_count);
    $map = unread_topic_notice_viewed_map();
    unset($map[$topic_id]);
    unread_topic_notice_viewed_write([$topic_id => ['reply_count' => $reply_count]] + $map);
}

function unread_topic_notice_mark_all_read(int $uid): void
{
    if ($uid <= 0) return;
    unread_topic_notice_viewed_clear();
}

function unread_topic_notice_back_url(): string
{
    $back = (string)($_POST['back'] ?? '');
    return $back !== '' && str_starts_with($back, '/') && !str_starts_with($back, '//') ? $back : route_url('home');
}

function unread_topic_notice_css(): string
{
    return '
.unread-topic-notice{display:inline-flex;align-items:center;gap:4px;margin-left:6px;color:var(--brand);font-size:11px;font-weight:600;line-height:1;vertical-align:1px;white-space:nowrap}
.unread-topic-notice:hover{color:var(--brand-hover)}
.unread-topic-notice:before{content:"";width:5px;height:5px;border-radius:50%;background:currentColor}
.topic-toolbar .post-action-form{flex:0 0 auto!important}
.topic-toolbar button.unread-topic-read-all{min-height:0!important;padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;color:var(--text-disabled)!important;font-size:12px!important;font-weight:400!important;line-height:1.4!important;white-space:nowrap!important}
.topic-toolbar button.unread-topic-read-all:hover{background:transparent!important;color:var(--text-muted)!important}
';
}

function unread_topic_notice_title_suffix($html, array $ctx): string
{
    if (!uid() || trim((string)($_GET['q'] ?? '')) !== '' || empty($ctx['list']) || !is_array($ctx['row'] ?? null)) return (string)$html;

    $topic_id = (int)($ctx['row']['id'] ?? 0);
    $recorded_reply_count = unread_topic_notice_recorded_reply_count($topic_id);
    if ($topic_id <= 0 || $recorded_reply_count === null) return (string)$html;

    $reply_count = (int)($ctx['row']['reply_count'] ?? 0);
    if ($reply_count === $recorded_reply_count) return (string)$html;

    return (string)$html . '<a class="unread-topic-notice" href="' . h(unread_topic_notice_topic_url($ctx['row'], $recorded_reply_count)) . '">未读</a>';
}

function unread_topic_notice_list_columns($columns): array
{
    $columns = is_array($columns) ? $columns : [];
    $columns[] = 'reply_order';
    return $columns;
}

function unread_topic_notice_topic_url(array $topic, int $recorded_reply_count): string
{
    $params = ['id' => (int)($topic['id'] ?? 0)];
    if ((int)($topic['reply_order'] ?? 0) === 0) {
        $size = max(1, (int)setting('replies_per_page', '50'));
        $floor = $recorded_reply_count + 1;
        $params['p'] = max(1, (int)ceil($floor / $size));
        $params['floor'] = $floor;
    }
    return route_url('topic', $params);
}

function unread_topic_notice_after_render($html, array $ctx): string
{
    if (!uid() || trim((string)($_GET['q'] ?? '')) !== '' || empty($ctx['list']) || !is_array($ctx['row'] ?? null)) return (string)$html;
    $topic = $ctx['row'];
    $recorded_reply_count = unread_topic_notice_recorded_reply_count((int)($topic['id'] ?? 0));
    if ($recorded_reply_count === null || (int)($topic['reply_count'] ?? 0) === $recorded_reply_count) return (string)$html;

    $url = h(unread_topic_notice_topic_url($topic, $recorded_reply_count));
    return (string)preg_replace('/(<a class="post-title" href=")[^"]*(")/', '$1' . $url . '$2', (string)$html, 1);
}

function unread_topic_notice_index_tabs($items, array $ctx): array
{
    $items = is_array($items) ? $items : [];
    if (!uid() || !empty($ctx['forum_id']) || trim((string)($ctx['query'] ?? '')) !== '') return $items;
    $items['footprint'] = ['label' => '足迹', 'href' => route_url('unread_topic_notice_footprint')];
    return $items;
}

function unread_topic_notice_after_view($value, array $ctx): void
{
    if (!uid() || !is_array($ctx['topic'] ?? null)) return;
    unread_topic_notice_set_viewed((int)($ctx['topic']['id'] ?? 0), (int)($ctx['topic']['reply_count'] ?? 0));
}

function unread_topic_notice_reply_after_save($value, array $ctx): void
{
    if (!uid() || !empty($ctx['editing']) || (int)($ctx['user_id'] ?? 0) !== uid()) return;
    $topic_id = (int)($ctx['topic_id'] ?? 0);
    $reply_count = (int)(row('app_topics', 'id', $topic_id)['reply_count'] ?? 0);
    unread_topic_notice_set_viewed($topic_id, $reply_count);
}

function unread_topic_notice_mark_all_read_page(array $plugin): void
{
    need_login();
    require_post();
    unread_topic_notice_mark_all_read(uid());
    go(unread_topic_notice_back_url());
}

function unread_topic_notice_footprint_page(array $plugin): void
{
    need_login();
    $p = max(1, (int)($_GET['p'] ?? 1));
    $size = max(1, (int)setting('topics_per_page', '30'));
    $off = ($p - 1) * $size;
    $map = unread_topic_notice_viewed_map();
    $total = count($map);
    $footprints = array_slice($map, $off, $size, true);
    $topics = rows_by_ids('app_topics', array_keys($footprints), topic_list_select_columns());
    $rows = [];
    foreach (array_keys($footprints) as $topic_id) {
        $topic = $topics[(int)$topic_id] ?? null;
        if (!$topic) continue;
        $rows[] = $topic;
    }
    $rows = attach_topic_list_users($rows);
    hook('topic.index_data.loaded', ['rows' => $rows], ['source' => 'unread_topic_notice', 'sort' => 'footprint', 'page' => $p, 'page_size' => $size, 'offset' => $off]);

    $read_all_action = $total > 0 ? post_action_form(route_url('unread_topic_notice_mark_all_read'), '全部已读', ['back' => route_url('unread_topic_notice_footprint')], 'unread-topic-read-all') : '';
    $main = '<div class="topic-toolbar">' . tab_bar_html([
        'comment' => ['label' => '新评论', 'href' => route_url('home', ['sort' => 'comment'])],
        'post' => ['label' => '新帖子', 'href' => route_url('home', ['sort' => 'post'])],
        'footprint' => ['label' => '足迹', 'href' => route_url('unread_topic_notice_footprint')],
    ], 'footprint') . $read_all_action . '</div><ul class="post-list">';
    if (!$rows) {
        $main .= '<li class="empty-state">暂无足迹</li>';
    } else {
        foreach ($rows as $t) {
            $t['forum'] = forum_by_id((int)$t['forum_id']) ?: ['id' => 0, 'name' => ''];
            $main .= topic_list_row($t, 'footprint');
        }
    }
    $pagination = paginate($total, $p, $size, route_url('unread_topic_notice_footprint'));
    $main .= '</ul>' . ($pagination !== '' ? '<div class="pagination-bar">' . $pagination . '</div>' : '');
    page('足迹', shell_html($main, sidebar_stack_html([sidebar_user_card_html(null, true), quick_forums_html()])));
}

return [
    'id' => 'unread_topic_notice',
    'name' => '未读主题提醒',
    'version' => '2.2.7',
    'description' => '主题有新回复时显示未读提醒，帮助用户及时发现更新。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'unread_topic_notice_css'],
    'hooks' => [
        'topic.index_tabs' => 'unread_topic_notice_index_tabs',
        'topic.list_columns' => 'unread_topic_notice_list_columns',
        'topic.title_suffix' => 'unread_topic_notice_title_suffix',
        'topic.after_render' => 'unread_topic_notice_after_render',
        'topic.after_view' => 'unread_topic_notice_after_view',
        'reply.after_save' => 'unread_topic_notice_reply_after_save',
    ],
    'routes' => [
        'unread_topic_notice_footprint' => 'unread_topic_notice_footprint_page',
        'unread_topic_notice_mark_all_read' => 'unread_topic_notice_mark_all_read_page',
    ],
    'install' => 'unread_topic_notice_install',
    'uninstall' => 'unread_topic_notice_uninstall',
];