<?php
if (!defined('APP_ROOT')) exit;

const NB_EDITOR_QUOTE_MAX = 32;
const NB_EDITOR_PREVIEW_MAX = 100000;

function nb_editor_config(bool $refresh = false): array
{
    static $config = null;
    if ($config !== null && !$refresh) return $config;
    $raw = plugin_config('nb_editor', []);
    return $config = [
        'emoji' => (int)($raw['emoji'] ?? 1) === 1,
        'preview' => (int)($raw['preview'] ?? 1) === 1,
        'fullscreen' => (int)($raw['fullscreen'] ?? 1) === 1,
        'hotkey' => (int)($raw['hotkey'] ?? 1) === 1,
        'sidebar_help' => (int)($raw['sidebar_help'] ?? 1) === 1,
        'draft' => (int)($raw['draft'] ?? 1) === 1,
        'draft_days' => min(90, max(1, (int)($raw['draft_days'] ?? 7))),
        'paste_upload' => (int)($raw['paste_upload'] ?? 1) === 1,
    ];
}

function nb_editor_static_dirs(): array
{
    return ['app/upload/', 'app/avatars/', 'app/assets/', 'app/plugins/'];
}

function nb_editor_site_hosts(): array
{
    static $hosts = null;
    if ($hosts !== null) return $hosts;
    $list = [];
    foreach ([base_url(), '//' . (string)($_SERVER['HTTP_HOST'] ?? '')] as $url) {
        $host = strtolower((string)parse_url($url, PHP_URL_HOST));
        if ($host !== '') $list[$host] = true;
    }
    return $hosts = $list;
}

function nb_editor_static_path(string $path): bool
{
    if ($path === '' || str_contains($path, '..')) return false;
    $path = rawurldecode($path);
    if (str_contains($path, '..') || str_contains($path, "\0")) return false;
    foreach (nb_editor_static_dirs() as $dir) {
        if (str_starts_with($path, app_url($dir))) return true;
    }
    return false;
}

/**
 * 图片会在别人打开帖子时自动发出请求，站内地址必须限制在静态资源目录，
 * 否则 `![](/donate?topic_id=1)` 这类写法会带着访客的 Cookie 触发站内接口。
 */
function nb_editor_image_allowed(string $url): bool
{
    $url = trim($url);
    if ($url === '' || preg_match('/[\x00-\x20\x7F]/', $url) === 1) return false;
    // 协议相对地址指向别的站点，不会带上本站 Cookie。
    if (str_starts_with($url, '//')) return true;
    if (preg_match('#^https?://#i', $url) === 1) {
        $host = strtolower((string)parse_url($url, PHP_URL_HOST));
        if ($host === '') return false;
        if (!isset(nb_editor_site_hosts()[$host])) return true;
        return nb_editor_static_path((string)parse_url($url, PHP_URL_PATH));
    }
    if (!str_starts_with($url, '/')) return false;
    return nb_editor_static_path((string)parse_url($url, PHP_URL_PATH));
}

function nb_editor_token(array &$tokens, string $html): string
{
    $key = "\x1A" . count($tokens) . "\x1A";
    $tokens[$key] = $html;
    return $key;
}

function nb_editor_inline(string $text, int $topic_id = 0): string
{
    $has_url = stripos($text, 'http://') !== false || stripos($text, 'https://') !== false;
    if (!$has_url && strpbrk($text, '`*[@~') === false) return h($text);
    $has_markdown_url = $has_url || str_contains($text, '](/');
    $text = h($text);
    $tokens = [];
    if (str_contains($text, '`')) {
        $text = preg_replace_callback('/`([^`\n]+)`/u', function ($m) use (&$tokens) {
            return nb_editor_token($tokens, '<code>' . $m[1] . '</code>');
        }, $text) ?? $text;
    }
    if (str_contains($text, '~~')) {
        $text = preg_replace_callback('/~~([^~\n]+)~~/u', function ($m) {
            return '<del>' . $m[1] . '</del>';
        }, $text) ?? $text;
    }
    if (str_contains($text, '*')) {
        $text = preg_replace_callback('/\*\*\*([^*\n]+)\*\*\*|\*\*([^*\n]+)\*\*|(?<!\*)\*([^*\n]+)\*(?!\*)/u', function ($m) {
            if (($m[1] ?? '') !== '') return '<em><strong>' . $m[1] . '</strong></em>';
            if (($m[2] ?? '') !== '') return '<strong>' . $m[2] . '</strong>';
            return '<em>' . $m[3] . '</em>';
        }, $text) ?? $text;
    }
    if (str_contains($text, '[') && $has_markdown_url) {
        $text = preg_replace_callback('/!\[((?:\\\\.|[^\]\\\\\n])*)\]\(((?:https?:\/\/|\/)[^\s)<]+)\)|\[((?:\\\\.|[^\]\\\\\n])+)\]\(((?:https?:\/\/|\/)[^\s)<]+)\)/ui', function ($m) use (&$tokens) {
            $image = str_starts_with($m[0], '![');
            $label = (string)$m[$image ? 1 : 3];
            $label = str_replace(['\\]', '\\[', '\\\\'], [']', '[', '\\'], $label);
            $url = html_entity_decode((string)$m[$image ? 2 : 4], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            // 地址不允许作为图片时保留原样的文字，既不发请求，作者也能看出没生效。
            if ($image && !nb_editor_image_allowed($url)) return nb_editor_token($tokens, $m[0]);
            $html = $image
                ? '<img src="' . h($url) . '" alt="' . $label . '" loading="lazy" referrerpolicy="no-referrer">'
                : '<a href="' . h($url) . '" target="_blank" rel="nofollow noopener">' . $label . '</a>';
            return nb_editor_token($tokens, $html);
        }, $text) ?? $text;
    }
    $text = content_special_links_html($text, $topic_id);
    if ($has_url) {
        $text = preg_replace_callback('/(?<!["\'>=])(https?:\/\/[^\s<]+)/ui', function ($m) {
            $raw_url = rtrim($m[1], '.,;:!?');
            $url = html_entity_decode($raw_url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $tail = substr($m[1], strlen($raw_url));
            return '<a href="' . h($url) . '" target="_blank" rel="nofollow noopener">' . h($url) . '</a>' . h($tail);
        }, $text) ?? $text;
    }
    return strtr($text, $tokens);
}

function nb_editor_table_cells(string $line): array
{
    $line = trim($line);
    if (str_starts_with($line, '|')) $line = substr($line, 1);
    if (str_ends_with($line, '|')) $line = substr($line, 0, -1);
    $cells = [];
    $cell = '';
    $code = false;
    $escaped = false;
    for ($i = 0, $length = strlen($line); $i < $length; $i++) {
        $char = $line[$i];
        if ($escaped) {
            $cell .= $char;
            $escaped = false;
            continue;
        }
        if ($char === '\\') {
            $cell .= $char;
            $escaped = true;
            continue;
        }
        if ($char === '`') $code = !$code;
        if ($char === '|' && !$code) {
            $cells[] = trim(str_replace('\\|', '|', $cell));
            $cell = '';
            continue;
        }
        $cell .= $char;
    }
    $cells[] = trim(str_replace('\\|', '|', $cell));
    return $cells;
}

function nb_editor_table_html(array $lines, int $topic_id = 0): string
{
    if (count($lines) < 2) return '';
    $aligns = [];
    foreach (nb_editor_table_cells($lines[1]) as $cell) {
        if (!preg_match('/^:?-{3,}:?$/', trim($cell))) return '';
        $cell = trim($cell);
        $left = str_starts_with($cell, ':');
        $right = str_ends_with($cell, ':');
        $aligns[] = $left && $right ? 'center' : ($right ? 'right' : ($left ? 'left' : ''));
    }
    if (!$aligns) return '';
    $headers = nb_editor_table_cells($lines[0]);
    if (!$headers || count($headers) !== count($aligns)) return '';
    $cell_attr = fn(string $align) => $align !== '' ? ' style="text-align:' . $align . '"' : '';
    $html = '<div class="markdown-table-wrap"><table><thead><tr>';
    foreach ($headers as $i => $cell) $html .= '<th' . $cell_attr((string)($aligns[$i] ?? '')) . '>' . nb_editor_inline($cell, $topic_id) . '</th>';
    $html .= '</tr></thead><tbody>';
    foreach (array_slice($lines, 2) as $line) {
        if (trim($line) === '') continue;
        $cells = nb_editor_table_cells($line);
        if (!$cells) continue;
        $html .= '<tr>';
        for ($i = 0, $count = count($headers); $i < $count; $i++) {
            $html .= '<td' . $cell_attr((string)($aligns[$i] ?? '')) . '>' . nb_editor_inline((string)($cells[$i] ?? ''), $topic_id) . '</td>';
        }
        $html .= '</tr>';
    }
    return $html . '</tbody></table></div>';
}

function nb_editor_list_html(array $lines, int $topic_id): string
{
    $ordered = preg_match('/^\s*(\d{1,9})[.)]\s+/', $lines[0], $first) === 1;
    if (!$ordered && preg_match('/^\s*[-*]\s+/', $lines[0]) !== 1) return '';
    $pattern = $ordered ? '/^\s*\d{1,9}[.)]\s+(.*)$/u' : '/^\s*[-*]\s+(.*)$/u';
    $items = '';
    $tail = [];
    $open = true;
    foreach ($lines as $line) {
        if ($open && preg_match($pattern, $line, $m) === 1) {
            $items .= '<li>' . nb_editor_inline((string)$m[1], $topic_id) . '</li>';
            continue;
        }
        $open = false;
        $tail[] = $line;
    }
    if ($items === '') return '';
    if (!$ordered) return '<ul>' . $items . '</ul>' . ($tail ? nb_editor_plain_block_html($tail, $topic_id) : '');
    // 保持原生 ol 语义和站点默认样式，只保留起始序号。
    $start = max(1, (int)($first[1] ?? 1));
    $attr = $start !== 1 ? ' start="' . $start . '"' : '';
    return '<ol' . $attr . '>' . $items . '</ol>' . ($tail ? nb_editor_plain_block_html($tail, $topic_id) : '');
}

function nb_editor_plain_block_html(array $lines, int $topic_id = 0): string
{
    $block = trim(implode("\n", $lines));
    if ($block === '') return '';
    $lines = explode("\n", $block);
    if (count($lines) === 1 && preg_match('/^(#{1,6})\s+(.+)$/u', $lines[0], $m)) {
        $level = strlen($m[1]);
        return '<h' . $level . '>' . nb_editor_inline($m[2], $topic_id) . '</h' . $level . '>';
    }
    $table = nb_editor_table_html($lines, $topic_id);
    if ($table !== '') return $table;
    // 列表可以从段落中间开始，前面的普通文字仍按段落输出。
    foreach ($lines as $index => $line) {
        if (preg_match('/^\s*(?:[-*]|\d{1,9}[.)])\s+/', $line) !== 1) continue;
        $list = nb_editor_list_html(array_slice($lines, $index), $topic_id);
        if ($list === '') break;
        $head = array_slice($lines, 0, $index);
        return ($head ? nb_editor_plain_block_html($head, $topic_id) : '') . $list;
    }
    return '<p>' . str_replace("\n", '<br>', nb_editor_inline($block, $topic_id)) . '</p>';
}

function nb_editor_block_html(array $lines, int $quote_depth, int $topic_id): string
{
    $lines = explode("\n", trim(implode("\n", $lines)));
    $html = '';
    $chunk = [];
    $quote = false;
    $lines[] = null;
    foreach ($lines as $line) {
        $is_quote = $line !== null && preg_match('/^\s*>\s?/u', $line) === 1;
        if ($chunk && ($line === null || $is_quote !== $quote)) {
            if (!$quote) $html .= nb_editor_plain_block_html($chunk, $topic_id);
            else {
                $inner = trim(implode("\n", array_map(fn($item) => preg_replace('/^\s*>\s?/u', '', $item) ?? $item, $chunk)));
                $inner_html = $inner === '' ? '' : ($quote_depth + 1 >= NB_EDITOR_QUOTE_MAX
                    ? nb_editor_plain_block_html(explode("\n", $inner), $topic_id)
                    : nb_editor_render_html($inner, $quote_depth + 1, $topic_id));
                $html .= '<blockquote>' . $inner_html . '</blockquote>';
            }
            $chunk = [];
        }
        if ($line !== null) {
            $quote = $is_quote;
            $chunk[] = $line;
        }
    }
    return $html;
}

function nb_editor_code_block_html(array $lines, string $lang): string
{
    $lang = strtolower(trim($lang));
    $class = preg_match('/^[a-z0-9_-]{1,32}$/', $lang) === 1 ? ' class="language-' . h($lang) . '"' : '';
    return '<pre><code' . $class . '>' . h(rtrim(implode("\n", $lines), "\n")) . '</code></pre>';
}

function nb_editor_render_html(string $text, int $quote_depth = 0, int $topic_id = 0): string
{
    $html = [];
    $buffer = [];
    $state = 'text';
    $lang = '';
    foreach (explode("\n", $text) as $line) {
        $fence = preg_match('/^\s*```\s*([\w-]*)\s*$/u', $line, $m) === 1;
        if ($state === 'code') {
            if ($fence) {
                $html[] = nb_editor_code_block_html($buffer, $lang);
                $buffer = [];
                $state = 'text';
            } else $buffer[] = $line;
            continue;
        }
        if ($fence) {
            if ($buffer) $html[] = nb_editor_block_html($buffer, $quote_depth, $topic_id);
            $buffer = [];
            $state = 'code';
            $lang = (string)($m[1] ?? '');
            continue;
        }
        if (trim($line) === '') {
            if ($buffer) $html[] = nb_editor_block_html($buffer, $quote_depth, $topic_id);
            $buffer = [];
            continue;
        }
        if (preg_match('/^(#{1,6})\s+(.+)$/u', $line) === 1) {
            if ($buffer) $html[] = nb_editor_block_html($buffer, $quote_depth, $topic_id);
            $html[] = nb_editor_plain_block_html([$line], $topic_id);
            $buffer = [];
            continue;
        }
        if (preg_match('/^\s*(?:-{3,}|\*{3,})\s*$/u', $line) === 1) {
            if ($buffer) $html[] = nb_editor_block_html($buffer, $quote_depth, $topic_id);
            $html[] = '<hr>';
            $buffer = [];
            continue;
        }
        $buffer[] = $line;
    }
    if ($state === 'code') $html[] = nb_editor_code_block_html($buffer, $lang);
    elseif ($buffer) $html[] = nb_editor_block_html($buffer, $quote_depth, $topic_id);
    return implode('', $html);
}

function nb_editor_render(mixed $rendered, array $ctx): ?string
{
    if (is_string($rendered)) return null;
    return nb_editor_render_html(
        (string)($ctx['text'] ?? ''),
        (int)($ctx['quote_depth'] ?? 0),
        (int)($ctx['topic_id'] ?? 0)
    );
}

function nb_editor_icon(string $name): string
{
    static $icons = [
        'bold' => '<path d="M7 5h6a3.5 3.5 0 0 1 0 7H7z"/><path d="M7 12h7a3.5 3.5 0 0 1 0 7H7z"/>',
        'italic' => '<path d="M19 4h-9M14 20H5M15 4L9 20"/>',
        'strike' => '<path d="M16 5H9.5a3 3 0 0 0-2.6 4.5"/><path d="M14.5 14a3.5 3.5 0 0 1-2.5 6H7"/><path d="M4 12h16"/>',
        'heading' => '<path d="M6 4v16M18 4v16M6 12h12"/>',
        'quote' => '<path d="M7 7h4v5c0 2.2-1.6 4-4 4"/><path d="M15 7h4v5c0 2.2-1.6 4-4 4"/>',
        'code' => '<path d="M16 18l6-6-6-6"/><path d="M8 6l-6 6 6 6"/>',
        'code_block' => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9.5 10L7.5 12l2 2M14.5 10l2 2-2 2"/>',
        'ul' => '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
        'ol' => '<path d="M10 6h11M10 12h11M10 18h11"/><path d="M4 5h1v4M3.5 9h2M3.5 14.5c0-.8.7-1.5 1.5-1.5s1.5.6 1.5 1.4c0 1.4-3 1.7-3 4.1h3"/>',
        'link' => '<path d="M10 13a5 5 0 0 0 7.5.5l2.5-2.5a5 5 0 0 0-7-7L11.5 5.5"/><path d="M14 11a5 5 0 0 0-7.5-.5L4 13a5 5 0 0 0 7 7l1.4-1.4"/>',
        'image' => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
        'table' => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M10 10v10"/>',
        'hr' => '<path d="M3 12h18"/>',
        'emoji' => '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><path d="M9 9h.01M15 9h.01"/>',
        'preview' => '<path d="M1.5 12S5.5 5 12 5s10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/>',
        'fullscreen' => '<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/>',
    ];
    $path = (string)($icons[$name] ?? '');
    if ($path === '') return '';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}

function nb_editor_button(string $attribute, string $value, string $icon, string $label): string
{
    return '<button class="nb-editor-btn" type="button" ' . $attribute . '="' . h($value) . '" title="' . h($label) . '" aria-label="' . h($label) . '">' . nb_editor_icon($icon) . '</button>';
}

function nb_editor_action_button(string $action, string $icon, string $label): string
{
    return nb_editor_button('data-nb-editor-action', $action, $icon, $label);
}

function nb_editor_draft_scope(string $kind, array $ctx): string
{
    $uid = uid();
    if ($uid < 1) return '';
    if ($kind === 'topic') {
        $topic_id = (int)($ctx['topic']['id'] ?? 0);
        return 'u' . $uid . ':topic-' . ($topic_id > 0 ? $topic_id : 'new');
    }
    if (isset($ctx['reply'])) return 'u' . $uid . ':reply-edit-' . (int)($ctx['reply']['id'] ?? 0);
    return 'u' . $uid . ':reply-' . (int)($ctx['topic']['id'] ?? 0);
}

function nb_editor_topic_form_extra($html, array $ctx): string
{
    return nb_editor_form_extra($html, $ctx, 'topic');
}

function nb_editor_reply_form_extra($html, array $ctx): string
{
    return nb_editor_form_extra($html, $ctx, 'reply');
}

function nb_editor_form_extra($html, array $ctx, string $kind = 'topic'): string
{
    $config = nb_editor_config();
    $tools = nb_editor_action_button('bold', 'bold', '粗体')
        . nb_editor_action_button('italic', 'italic', '斜体')
        . nb_editor_action_button('strike', 'strike', '删除线')
        . nb_editor_action_button('heading', 'heading', '标题')
        . nb_editor_action_button('quote', 'quote', '引用')
        . '<span class="nb-editor-split"></span>'
        . nb_editor_action_button('code', 'code', '行内代码')
        . nb_editor_action_button('code_block', 'code_block', '代码块')
        . nb_editor_action_button('ul', 'ul', '无序列表')
        . nb_editor_action_button('ol', 'ol', '有序列表')
        . '<span class="nb-editor-split"></span>'
        . nb_editor_action_button('link', 'link', '插入链接')
        . nb_editor_action_button('image', 'image', '插入图片')
        . nb_editor_action_button('table', 'table', '插入表格')
        . nb_editor_action_button('hr', 'hr', '分割线');
    $right = '';
    if ($config['emoji']) $right .= nb_editor_button('data-nb-editor-emoji', '1', 'emoji', '表情');
    if ($config['preview']) $right .= nb_editor_action_button('preview', 'preview', '实时预览');
    if ($config['fullscreen']) $right .= nb_editor_action_button('fullscreen', 'fullscreen', '全屏');
    if ($right !== '') $right = '<span class="nb-editor-space"></span>' . $right;
    $attributes = ' data-nb-editor';
    if ($config['preview']) $attributes .= ' data-nb-editor-preview-url="' . h(route_url('nb_editor_preview')) . '"';
    if ($config['hotkey']) $attributes .= ' data-nb-editor-hotkey="1"';
    if ($config['paste_upload']) $attributes .= ' data-nb-editor-paste="1"';
    $topic_id = (int)($ctx['topic']['id'] ?? 0);
    if ($topic_id > 0) $attributes .= ' data-nb-editor-topic="' . $topic_id . '"';
    if ($config['draft']) {
        $scope = nb_editor_draft_scope($kind, $ctx);
        if ($scope !== '') $attributes .= ' data-nb-editor-draft="' . h($scope) . '" data-nb-editor-draft-days="' . $config['draft_days'] . '"';
    }
    return (string)$html . '<div class="nb-editor"' . $attributes . '><div class="nb-editor-bar" role="toolbar" aria-label="NB编辑器">' . $tools . $right . '</div></div>';
}

function nb_editor_form_sidebar($html, array $ctx): string
{
    if (!nb_editor_config()['sidebar_help']) return (string)$html;
    return (string)$html . sidebar_notice_card_html('排版速查', [
        '**粗体**，*斜体*，~~删除线~~',
        '# 一级标题，## 二级标题',
        '> 引用内容',
        '- 无序列表，1. 有序列表',
        '`行内代码`，``` 代码块',
        '[链接文字](https://example.com)',
        '![图片描述](https://example.com/a.jpg)',
    ]);
}

function nb_editor_preview_route(array $plugin): void
{
    need_login();
    require_post();
    if (!nb_editor_config()['preview']) json_response(['ok' => false, 'message' => '预览已关闭']);
    $body = (string)($_POST['body'] ?? '');
    if (strlen($body) > NB_EDITOR_PREVIEW_MAX) $body = substr($body, 0, NB_EDITOR_PREVIEW_MAX);
    $topic_id = max(0, (int)($_POST['topic_id'] ?? 0));
    $html = markdown_html($body, 0, $topic_id);
    json_response(['ok' => true, 'html' => $html]);
}

function nb_editor_admin_page(array $plugin): string
{
    need_admin();
    if (is_post_request()) {
        require_post();
        plugin_save_config('nb_editor', [
            'emoji' => isset($_POST['emoji']) ? 1 : 0,
            'preview' => isset($_POST['preview']) ? 1 : 0,
            'fullscreen' => isset($_POST['fullscreen']) ? 1 : 0,
            'hotkey' => isset($_POST['hotkey']) ? 1 : 0,
            'sidebar_help' => isset($_POST['sidebar_help']) ? 1 : 0,
            'draft' => isset($_POST['draft']) ? 1 : 0,
            'draft_days' => min(90, max(1, (int)($_POST['draft_days'] ?? 7))),
            'paste_upload' => isset($_POST['paste_upload']) ? 1 : 0,
        ]);
        set_flash('编辑器设置已保存');
        go(admin_url(['tab' => 'nb_editor']));
    }
    $config = nb_editor_config(true);
    $writing = checkbox('显示表情面板', 'emoji', $config['emoji'], '工具栏右侧出现表情按钮，可插入 Emoji 和颜文字。')
        . checkbox('显示预览按钮', 'preview', $config['preview'], '打开后编辑区旁边常驻预览，窄屏时改在正文框下方。')
        . checkbox('显示全屏按钮', 'fullscreen', $config['fullscreen'], '把编辑区放大到整个窗口，按 Esc 退出。')
        . checkbox('支持 Ctrl+Enter 发布', 'hotkey', $config['hotkey'], '在编辑区按 Ctrl+Enter 直接提交。');
    $assist = checkbox('发帖页显示排版速查', 'sidebar_help', $config['sidebar_help'], '在发帖页右侧列出常用排版写法。')
        . checkbox('自动保存草稿', 'draft', $config['draft'], '内容只存在本人浏览器里，刷新或误关页面后可以一键找回。')
        . number_input('草稿保留天数', 'draft_days', $config['draft_days'], 1, 90, true, '超过天数的草稿会自动清理。')
        . checkbox('粘贴截图自动上传', 'paste_upload', $config['paste_upload'], '在正文里直接粘贴截图就自动上传并插入图片，需要站点已开启附件上传。');
    $form = '<form class="plugin-settings-form nb-editor-admin-settings" method="post" action="' . h(admin_url(['tab' => 'nb_editor'])) . '">' . form_token()
        . '<div class="nb-editor-admin-grid"><section class="nb-editor-admin-section"><div class="nb-editor-admin-section-head"><strong>写作工具</strong><span>控制编辑器工具栏和发布快捷操作</span></div>' . $writing . '</section>'
        . '<section class="nb-editor-admin-section"><div class="nb-editor-admin-section-head"><strong>内容辅助</strong><span>管理草稿、排版提示和图片处理</span></div>' . $assist . '</section></div>'
        . '<div class="nb-editor-admin-actions"><button type="submit">保存设置</button><span>设置保存后立即在发帖和回帖页面生效。</span></div></form>';
    $version = h((string)($plugin['version'] ?? '1.6.0'));
    return '<section class="admin-list-panel plugin-manage-panel nb-editor-admin-page">' . admin_list_head('<div class="admin-plugin-summary"><strong>NB编辑器</strong><span>为发帖和回帖提供 Markdown 工具、实时预览与草稿能力 · v' . $version . '</span></div>', '') . '<div class="plugin-panel-body">' . $form . '</div></section>';
}

function nb_editor_css(): string
{
    return <<<'CSS'
.nb-editor-admin-settings{max-width:none;gap:16px}
.nb-editor-admin-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.nb-editor-admin-section{display:grid;align-content:start;gap:10px;min-width:0;padding:14px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--bg)}
.nb-editor-admin-section-head{display:grid;gap:3px;padding-bottom:2px}
.nb-editor-admin-section-head strong{color:var(--text);font-size:var(--font-size-md);line-height:1.4}
.nb-editor-admin-section-head span{color:var(--text-subtle);font-size:var(--font-size-sm);line-height:1.45}
.nb-editor-admin-settings .nb-editor-admin-section>.grid{grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;margin:0;padding:9px 0;border-top:1px solid var(--line-soft)}
.nb-editor-admin-settings .nb-editor-admin-section-head+.grid{border-top:0}
.nb-editor-admin-settings .nb-editor-admin-section>.grid>span{padding-top:0;color:var(--text-muted);font-size:var(--font-size-sm);line-height:1.45}
.nb-editor-admin-settings .nb-editor-admin-section>.grid>span small{margin-top:2px;color:var(--text-subtle);line-height:1.4}
.nb-editor-admin-settings .nb-editor-admin-section>.grid input[type=number]{width:100%;max-width:130px}
.nb-editor-admin-actions{display:flex;align-items:center;flex-wrap:wrap;gap:10px;padding-top:2px}
.nb-editor-admin-actions button{margin:0}
.nb-editor-admin-actions span{color:var(--text-subtle);font-size:var(--font-size-sm);line-height:1.45}
@media(max-width:720px){
.nb-editor-admin-grid{grid-template-columns:1fr}
.nb-editor-admin-section{padding:12px}
.nb-editor-admin-actions{align-items:stretch;flex-direction:column}
.nb-editor-admin-actions button{width:100%}
}
.nb-editor-field{position:relative;display:grid;row-gap:0;margin:8px 0}
.reply-panel .nb-editor-field{margin:0}
.nb-editor-field>.grid{display:contents}
.nb-editor-field>.grid>span{order:1;margin-bottom:6px;padding-top:0}
.nb-editor-field>.nb-editor{order:2}
/* 正文框固定白底，和主题色工具栏拉开层次；高度仍交给核心按场景决定。 */
.nb-editor-field>.grid>textarea[name=body]{order:3;border-top:0;border-radius:0 0 var(--radius-sm) var(--radius-sm);background:var(--panel);resize:vertical}
/* 分栏预览：左边写 Markdown，右边常驻渲染结果，随输入更新。 */
.nb-editor-field.nb-editor-live{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}
.nb-editor-field.nb-editor-live>.grid>span,.nb-editor-field.nb-editor-live>.nb-editor{grid-column:1/-1}
.nb-editor-field.nb-editor-live>.grid>textarea[name=body]{grid-column:1;border-bottom-right-radius:0}
.nb-editor-field.nb-editor-live>.nb-editor-preview{grid-column:2;max-height:60vh;overflow:auto;border-left:0;border-bottom-left-radius:0}
.nb-editor{min-width:0}
/* 工具栏跟随站点主题色，不写死中性灰。 */
.nb-editor-bar{display:flex;align-items:center;flex-wrap:wrap;gap:2px;padding:4px 6px;border:1px solid var(--line);border-bottom:0;border-radius:var(--radius-sm) var(--radius-sm) 0 0;background:var(--brand-soft)}
.nb-editor-field:focus-within>.nb-editor>.nb-editor-bar{border-color:var(--brand)}
/* 选择器带上根容器，避免被 .reply-panel button 之类的核心规则按特异性压过。 */
.nb-editor .nb-editor-btn{display:inline-flex;align-items:center;justify-content:center;width:30px;min-width:30px;min-height:28px;height:28px;padding:0;border:1px solid transparent;border-radius:var(--radius-sm);background:transparent;color:var(--brand-hover);cursor:pointer}
.nb-editor .nb-editor-btn svg{width:16px;height:16px}
.nb-editor .nb-editor-btn:hover{border-color:var(--line);background:var(--panel);color:var(--brand-hover)}
.nb-editor .nb-editor-btn:focus-visible{outline:2px solid var(--focus-ring);outline-offset:1px}
.nb-editor .nb-editor-btn.nb-editor-btn-active{border-color:var(--brand);background:var(--panel);color:var(--brand-hover)}
.nb-editor-split{width:1px;height:16px;margin:0 4px;background:var(--line)}
.nb-editor-space{flex:1 1 auto;min-width:0}
/* 面板用 fixed 浮层：既不挤占正文框空间，也不会被祖先的 overflow:hidden 裁掉。位置由 JS 计算，优先向上弹。 */
.nb-editor-panel{position:fixed;z-index:60;display:flex;flex-direction:column;width:min(360px,100%);max-height:min(60vh,340px);border:1px solid var(--line);border-radius:var(--radius);background:var(--panel);box-shadow:0 12px 32px var(--shadow-medium);overflow:hidden}
.nb-editor-panel[hidden]{display:none}
.nb-editor-panel-title{flex:0 0 auto;padding:8px 12px 0;color:var(--text-subtle);font-size:var(--font-size-xs);line-height:1.4}
.nb-editor-items{flex:1 1 auto;min-height:0;display:flex;align-items:flex-start;align-content:flex-start;flex-wrap:wrap;gap:3px;margin:0;padding:8px 10px;overflow-y:auto;list-style:none}
.nb-editor-items[hidden]{display:none}
.nb-editor-items li{padding:4px 7px;border-radius:var(--radius-sm);color:var(--text);font-size:var(--font-size-sm);line-height:1.4;cursor:pointer;user-select:none}
.nb-editor-items li:hover{background:var(--bg)}
.nb-editor-items-emoji li{padding:2px 5px;font-size:var(--font-size-xl)}
.nb-editor-tabs{flex:0 0 auto;display:flex;align-items:stretch;flex-wrap:wrap;border-top:1px solid var(--line);background:var(--brand-soft)}
.nb-editor .nb-editor-tab{min-width:0;min-height:34px;padding:0 12px;border:0;border-radius:0;background:transparent;color:var(--text-muted);font-size:var(--font-size-sm);font-weight:400;cursor:pointer}
.nb-editor .nb-editor-tab:hover{background:var(--panel);color:var(--text)}
.nb-editor .nb-editor-tab.nb-editor-tab-active{background:var(--panel);color:var(--brand-hover);font-weight:500}
/* 预览框借用核心 .post-content 的排版，但要去掉它的 margin-top，否则与正文框差 2px。 */
.nb-editor-preview{order:4;margin-top:0;min-height:120px;padding:12px 14px;border:1px solid var(--line);border-top:0;border-radius:0 0 var(--radius-sm) var(--radius-sm);background:var(--panel)}
.nb-editor-preview[hidden]{display:none}
.nb-editor-preview-empty{color:var(--text-subtle);font-size:var(--font-size-sm)}
.nb-editor-draft{order:2;display:flex;align-items:center;flex-wrap:wrap;gap:8px;padding:7px 10px;border:1px solid var(--line);border-top:0;background:var(--info-soft);color:var(--text-muted);font-size:var(--font-size-sm);line-height:1.5}
.nb-editor-draft[hidden]{display:none}
.nb-editor-draft-text{flex:1 1 auto;min-width:0}
.nb-editor-status{order:2;padding:6px 10px;border:1px solid var(--line);border-top:0;background:var(--brand-soft);color:var(--text-muted);font-size:var(--font-size-sm);line-height:1.5;overflow-wrap:anywhere}
.nb-editor-status[hidden]{display:none}
.nb-editor-draft .nb-editor-draft-action{min-width:0;min-height:26px;padding:0 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text);font-size:var(--font-size-sm);font-weight:500;cursor:pointer}
.nb-editor-draft .nb-editor-draft-action:hover{border-color:var(--brand);color:var(--brand-hover)}
.nb-editor-field.nb-editor-full{position:fixed;inset:0;z-index:60;align-content:start;margin:0;padding:14px;background:var(--panel);overflow:auto}
.nb-editor-field.nb-editor-full>.grid>textarea[name=body]{min-height:calc(100vh - 120px)}
.nb-editor-field.nb-editor-full>.nb-editor-preview{min-height:calc(100vh - 120px)}
.nb-editor-field.nb-editor-full.nb-editor-live>.nb-editor-preview{max-height:none}
.nb-editor-dialog-field{display:grid;gap:5px;color:var(--text-muted);font-size:var(--font-size-sm)}
.nb-editor-dialog-field .prompt-input{box-sizing:border-box}
.nb-editor-upload{display:grid;gap:7px;margin:2px 0 6px;text-align:center}
.nb-editor-upload .nb-editor-upload-pick{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-height:110px;padding:16px 14px;border:1px dashed var(--line-soft);border-radius:var(--radius-sm);background:var(--bg);color:var(--text-muted);cursor:pointer;transition:border-color .15s ease,color .15s ease,background .15s ease}
.nb-editor-upload .nb-editor-upload-pick:hover{border-color:var(--brand);background:var(--brand-soft);color:var(--text)}
.nb-editor-upload .nb-editor-upload-pick.is-busy{opacity:.6;pointer-events:none}
.nb-editor-upload-plus{font-size:36px;line-height:1;color:var(--brand)}
.nb-editor-upload-tip{font-size:var(--font-size-xs);line-height:1.5}
.nb-editor-upload-status{color:var(--text-muted);font-size:var(--font-size-xs);line-height:1.5;overflow-wrap:anywhere}
/* 窄屏放不下两栏，预览改到正文框下方，仍然实时更新。 */
@media(max-width:820px){
.nb-editor-field.nb-editor-live{grid-template-columns:minmax(0,1fr)}
.nb-editor-field.nb-editor-live>.grid>textarea[name=body]{grid-column:1;border-radius:0}
.nb-editor-field.nb-editor-live>.nb-editor-preview{grid-column:1;max-height:50vh;border-left:1px solid var(--line);border-radius:0 0 var(--radius-sm) var(--radius-sm)}
}
@media(max-width:480px){
.nb-editor-bar{gap:1px;padding:4px}
.nb-editor .nb-editor-btn{width:28px;min-width:28px}
.nb-editor-split{margin:0 2px}
}
CSS;
}

function nb_editor_js(): string
{
    return <<<'JS'
(function () {
    'use strict';
    if (window.__nbEditorReady) return;
    window.__nbEditorReady = true;

    var PACKS = [
        {
            name: '表情',
            items: [
                '😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '🙃', '😉', '😊',
                '😇', '🥰', '😍', '🤩', '😘', '😗', '😚', '😋', '😛', '😜', '🤪', '😝',
                '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄',
                '😬', '😌', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧',
                '🥵', '🥶', '😵', '🤯', '🤠', '🥳', '😎', '🤓', '🧐', '😕', '🙁', '😮',
                '😯', '😲', '🥺', '😦', '😨', '😰', '😥', '😢', '😭', '😱', '😖', '😣',
                '😞', '😓', '😩', '😫', '🥱', '😤', '😡', '😠', '🤬', '😈', '💀', '💩',
                '🤡', '👻', '👽', '🤖', '😺', '😹', '😻', '😼', '😽', '🙀', '😿', '😾'
            ]
        },
        {
            name: '手势',
            items: [
                '👍', '👎', '👌', '🤌', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆',
                '👇', '☝️', '✋', '🤚', '🖐️', '🖖', '👋', '🤝', '🙏', '💪', '🦾', '✍️',
                '💅', '👏', '🙌', '👐', '🤲', '👀', '🫶', '❤️', '🧡', '💛', '💚', '💙',
                '💜', '🤎', '🖤', '🤍', '💔', '❤️‍🔥', '💕', '💞', '💖', '💘', '💌', '💯'
            ]
        },
        {
            name: '符号',
            items: [
                '✨', '⭐', '🌟', '💫', '🔥', '💥', '💢', '💦', '💨', '🎉', '🎊', '🎁',
                '🏆', '🥇', '🎯', '🎈', '🎂', '🍰', '🍺', '🍻', '☕', '🍵', '🍎', '🍉',
                '🌹', '🌸', '🌻', '🍀', '🌈', '☀️', '⛅', '🌧️', '❄️', '⚡', '🌙', '🐶',
                '🐱', '🐼', '🐰', '🦊', '🐷', '🐔', '✅', '❌', '❗', '❓', '⚠️', '🔔',
                '💡', '📌', '🔍', '📖', '💰', '🎵', '🚀', '⏰', '🔗', '📎', '🛠️', '💻'
            ]
        },
        {
            name: '颜文字',
            type: 'text',
            items: [
                ['OωO', 'OwO'], ['|´・ω・)ノ', 'Hi'], ['ヾ(≧∇≦*)ゝ', '开心'], ['(☆ω☆)', '星星眼'],
                ['（╯‵□′）╯︵┴─┴', '掀桌'], ['￣﹃￣', '流口水'], ['(/ω＼)', '捂脸'], ['∠( ᐛ 」∠)＿', '给跪'],
                ['(๑•̀ㅁ•́ฅ)', '打招呼'], ['→_→', '斜眼'], ['୧(๑•̀⌄•́๑)૭', '加油'], ['٩(ˊᗜˋ*)و', '有木有'],
                ['(ノ°ο°)ノ', '前方高能'], ['(´இ皿இ｀)', '厚颜无耻'], ['⌇●﹏●⌇', '吓死宝宝'], ['(ฅ´ω`ฅ)', '已阅留爪'],
                ['(╯°A°)╯︵○○○', '去吧大师球'], ['φ(￣∇￣o)', '太萌惹'], ['ヾ(´･ ･｀｡)ノ"', '咦咦咦'], ['( ง ᵒ̌皿ᵒ̌)ง⁼³₌₃', '气呼呼'],
                ['(ó﹏ò｡)', '受到惊吓'], ['Σ(っ °Д °;)っ', '什么鬼'], ['( ,,´･ω･)ﾉ"(´っω･｀｡)', '摸摸头'], ['╮(╯▽╰)╭', '无奈'],
                ['o(*////▽////*)q', '脸红'], ['＞﹏＜', '委屈'], ['( ๑´•ω•) "(ㆆᴗㆆ)', '安慰'], ['(｡•ˇ‸ˇ•｡)', '不高兴']
            ]
        }
    ];

    var textareaOf = function (root) {
        var form = root.closest('form');
        return form ? form.querySelector('textarea[name="body"]') : null;
    };

    var fieldOf = function (root) {
        return root.parentElement && root.parentElement.matches('.nb-editor-field') ? root.parentElement : null;
    };

    var mount = function (root) {
        if (!root || !root.isConnected) return;
        var textarea = textareaOf(root);
        var label = textarea ? textarea.closest('label') : null;
        if (!label) return;
        var field = label.parentElement && label.parentElement.matches('.nb-editor-field') ? label.parentElement : null;
        if (!field) {
            field = document.createElement('div');
            field.className = 'nb-editor-field';
            label.before(field);
            field.appendChild(label);
        }
        if (root.parentElement !== field) field.appendChild(root);
        if (root.dataset.nbEditorDraft) offerDraft(root);
    };

    var dispatchInput = function (textarea) {
        textarea.dispatchEvent(new Event('input', {bubbles: true}));
    };

    var replaceRange = function (textarea, value, start, end, selectionStart, selectionEnd) {
        textarea.value = textarea.value.slice(0, start) + value + textarea.value.slice(end);
        textarea.focus();
        textarea.setSelectionRange(start + selectionStart, start + selectionEnd);
        dispatchInput(textarea);
    };

    var replaceSelection = function (textarea, value, selectionStart, selectionEnd) {
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        replaceRange(textarea, value, start, end, selectionStart, selectionEnd);
    };

    var selectedText = function (textarea) {
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        return textarea.value.slice(start, end);
    };

    var template = function (textarea, before, after, placeholder) {
        var content = selectedText(textarea) || placeholder;
        replaceSelection(textarea, before + content + after, before.length, before.length + content.length);
    };

    var linePrefix = function (textarea, prefix, placeholder, numbered) {
        var text = textarea.value;
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        // 行首标记要作用在整行上，光标停在行中间也不会把标记插进句子里。
        var lineStart = text.lastIndexOf('\n', start - 1) + 1;
        var lineEnd = text.indexOf('\n', end);
        if (lineEnd < 0) lineEnd = text.length;
        var content = text.slice(lineStart, lineEnd);
        if (content.trim() === '') content = placeholder;
        var lines = content.split('\n').map(function (line, index) {
            return numbered ? (index + 1) + '. ' + line : prefix + line;
        });
        var value = lines.join('\n');
        var head = numbered ? 3 : prefix.length;
        replaceRange(textarea, value, lineStart, lineEnd, head, value.length);
    };

    var insertBlock = function (textarea, block, selectionStart, selectionEnd) {
        var start = textarea.selectionStart || 0;
        var head = start > 0 && textarea.value[start - 1] !== '\n' ? '\n' : '';
        var value = head + block;
        replaceSelection(textarea, value, head.length + selectionStart, head.length + selectionEnd);
    };

    var dialogFinish = null;
    // 打开弹层时记住它对应的正文框：弹层开着时（焦点在弹层输入框）粘贴图片也能直接落到正文里。
    var lastDialogTextarea = null;

    var closeDialog = function (value) {
        var finish = dialogFinish;
        dialogFinish = null;
        var dialog = document.getElementById('notify-modal');
        var body = document.getElementById('notify-modal-body');
        if (dialog) dialog.hidden = true;
        if (body) body.innerHTML = '';
        if (finish) finish(value);
    };

    // 复用「附件上传」插件已有的上传通道，不另建端点，站点后台配置的类型与大小限制自动生效。
    var attachmentTarget = function (textarea) {
        var form = textarea ? textarea.closest('form') : null;
        var uploader = form ? form.querySelector('.attachment-uploader[data-upload-url]') : null;
        var input = uploader ? uploader.querySelector('[data-attachment-input]') : null;
        if (!uploader || !input || input.disabled) return null;
        return {uploader: uploader, input: input};
    };

    var markdownResult = function (markdown) {
        var text = String(markdown || '');
        var match = /\]\(([^)\s]+)/.exec(text);
        return {url: match ? match[1] : '', markdown: text, isImage: text.indexOf('!') === 0};
    };

    var uploadThroughAttachment = function (target, file) {
        return new Promise(function (resolve, reject) {
            var stamp = Date.now();
            var named = new File([file], file.name || ('image-' + stamp + '.png'), {
                type: file.type || 'image/png',
                lastModified: stamp
            });
            var key = [named.name, named.size, named.lastModified].join('\u001f');
            var transfer = new DataTransfer();
            transfer.items.add(named);
            var settled = false;
            var observer = null;
            var timer = 0;
            var finish = function (fn, value) {
                if (settled) return;
                settled = true;
                if (observer) observer.disconnect();
                clearTimeout(timer);
                fn(value);
            };
            var inspect = function () {
                var items = target.uploader.querySelectorAll('.attachment-upload-item');
                for (var i = 0; i < items.length; i++) {
                    if ((items[i].dataset.attachmentKey || '') !== key) continue;
                    var state = items[i].dataset.state || '';
                    if (state === 'success') {
                        var parsed = markdownResult(items[i].dataset.markdown);
                        parsed.item = items[i];
                        if (parsed.url) finish(resolve, parsed);
                        else finish(reject, new Error('missing-url'));
                        return true;
                    }
                    if (state === 'error') { finish(reject, new Error('upload-failed')); return true; }
                }
                return false;
            };
            observer = new MutationObserver(function () { inspect(); });
            observer.observe(target.uploader, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['data-state', 'data-markdown']
            });
            timer = setTimeout(function () { finish(reject, new Error('timeout')); }, 60000);
            target.input.files = transfer.files;
            target.input.dispatchEvent(new Event('change', {bubbles: true}));
            inspect();
        });
    };

    var releaseAttachment = function (item) {
        if (!item || !item.isConnected) return;
        var remove = item.querySelector('[data-attachment-remove]');
        if (remove) remove.click();
    };

    var imageUploadRow = function (textarea, urlInput, box) {
        var target = attachmentTarget(textarea);
        // 没装或没权限用附件上传时，不显示这一行。
        if (!target) return null;
        // 只有这张编辑区开了「粘贴图片自动上传」时，才提示也可以直接粘贴。
        var field = textarea.closest('.nb-editor-field');
        var root = field ? field.querySelector('.nb-editor') : null;
        var paste = !!(root && root.dataset.nbEditorPaste === '1');
        var row = document.createElement('div');
        row.className = 'nb-editor-upload';
        // 整个加号区域就是一个 label，点哪里都会触发文件选择。
        var pick = document.createElement('label');
        pick.className = 'nb-editor-upload-pick';
        var plus = document.createElement('span');
        plus.className = 'nb-editor-upload-plus';
        plus.setAttribute('aria-hidden', 'true');
        plus.textContent = '+';
        var tip = document.createElement('span');
        tip.className = 'nb-editor-upload-tip';
        tip.textContent = paste ? '点击加号上传本地图片，也可以在内容中直接粘贴图片' : '点击加号上传本地图片';
        var file = document.createElement('input');
        file.type = 'file';
        file.accept = 'image/*';
        file.hidden = true;
        var status = document.createElement('span');
        status.className = 'nb-editor-upload-status';
        pick.append(plus, tip, file);
        file.addEventListener('change', function () {
            var picked = file.files && file.files[0];
            if (!picked) return;
            status.textContent = '正在上传……';
            pick.classList.add('is-busy');
            uploadThroughAttachment(target, picked).then(function (result) {
                if (!result.isImage) {
                    // 附件插件没把它当图片（常见于站点 PHP 未启用 fileinfo），此时给出的是文件下载地址，插进正文也显示不出来。
                    status.textContent = '这个文件没有被识别为图片，无法作为图片插入';
                    return;
                }
                urlInput.value = result.url;
                releaseAttachment(result.item);
                // 上传成功直接提交表单：地址已自动填好，按“确定”的逻辑插入正文并关闭弹层，不再等用户手动确认。
                if (box && box.requestSubmit) box.requestSubmit();
                else status.textContent = '上传完成，可直接确定插入';
            }).catch(function (error) {
                status.textContent = error && error.message === 'timeout' ? '上传超时，请重试' : '上传失败，请换张图片试试';
            }).then(function () {
                pick.classList.remove('is-busy');
                file.value = '';
            });
        });
        row.append(pick, status);
        return row;
    };

    var openDialog = function (title, fields, decorate) {
        return new Promise(function (resolve) {
            var dialog = document.getElementById('notify-modal');
            var titleElement = document.getElementById('notify-modal-title');
            var body = document.getElementById('notify-modal-body');
            if (!dialog || !body) { resolve(null); return; }
            dialogFinish = resolve;
            if (titleElement) titleElement.textContent = title;
            body.innerHTML = '';
            var box = document.createElement('form');
            box.className = 'confirm-box';
            var inputs = {};
            fields.forEach(function (field) {
                var label = document.createElement('label');
                label.className = 'nb-editor-dialog-field';
                var caption = document.createElement('span');
                caption.textContent = field.label;
                var input = document.createElement('input');
                input.className = 'prompt-input';
                input.type = field.type || 'text';
                if (field.inputmode) input.inputMode = field.inputmode;
                input.value = field.value || '';
                input.autocomplete = 'off';
                inputs[field.name] = input;
                label.append(caption, input);
                box.appendChild(label);
            });
            if (decorate) decorate(box, inputs);
            var actions = document.createElement('div');
            actions.className = 'confirm-actions';
            var cancel = document.createElement('button');
            cancel.type = 'button';
            cancel.className = 'btn alt';
            cancel.textContent = '取消';
            var confirm = document.createElement('button');
            confirm.type = 'submit';
            confirm.textContent = '确定';
            cancel.addEventListener('click', function () { closeDialog(null); });
            box.addEventListener('submit', function (event) {
                event.preventDefault();
                var values = {};
                Object.keys(inputs).forEach(function (name) { values[name] = inputs[name].value; });
                closeDialog(values);
            });
            actions.append(cancel, confirm);
            box.appendChild(actions);
            body.appendChild(box);
            dialog.hidden = false;
            var first = inputs[fields[0].name];
            if (first) { first.focus(); first.select(); }
        });
    };

    var insertLink = function (textarea) {
        lastDialogTextarea = textarea;
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        var label = textarea.value.slice(start, end) || '链接文字';
        return openDialog('插入链接', [{name: 'url', label: '链接地址', type: 'text', inputmode: 'url', value: 'https://'}]).then(function (values) {
            if (!values) return;
            var target = String(values.url || '').trim();
            if (!target) return;
            replaceRange(textarea, '[' + label + '](' + target + ')', start, end, 1, 1 + label.length);
        });
    };

    var insertImage = function (textarea) {
        lastDialogTextarea = textarea;
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        var selected = textarea.value.slice(start, end);
        return openDialog('插入图片', [
            {name: 'url', label: '图片地址', type: 'text', inputmode: 'url', value: 'https://'},
            {name: 'alt', label: '图片描述', value: selected || '图片描述'}
        ], function (box, inputs) {
            var row = imageUploadRow(textarea, inputs.url, box);
            // 上传是主要入口，放在弹层最前面，选完图地址自动填好，再补描述。
            if (row) box.insertBefore(row, box.firstChild);
        }).then(function (values) {
            if (!values) return;
            var target = String(values.url || '').trim();
            if (!target) return;
            var alt = String(values.alt || '').trim() || '图片';
            replaceRange(textarea, '![' + alt + '](' + target + ')', start, end, 2, 2 + alt.length);
        });
    };

    var buildPanel = function (root) {
        var panel = root.querySelector('.nb-editor-panel');
        if (panel) return panel;
        panel = document.createElement('div');
        panel.className = 'nb-editor-panel';
        panel.hidden = true;
        var title = document.createElement('div');
        title.className = 'nb-editor-panel-title';
        title.textContent = '点一下插入到正文';
        panel.appendChild(title);
        var lists = [];
        PACKS.forEach(function (pack, index) {
            var text = pack.type === 'text';
            var list = document.createElement('ul');
            list.className = 'nb-editor-items' + (text ? '' : ' nb-editor-items-emoji');
            list.hidden = index !== 0;
            pack.items.forEach(function (item) {
                var icon = text ? item[0] : item;
                var li = document.createElement('li');
                li.textContent = icon;
                li.title = text ? item[1] : icon;
                li.dataset.nbEditorInsert = icon;
                list.appendChild(li);
            });
            panel.appendChild(list);
            lists.push(list);
        });
        var tabs = document.createElement('div');
        tabs.className = 'nb-editor-tabs';
        PACKS.forEach(function (pack, index) {
            var tab = document.createElement('button');
            tab.type = 'button';
            tab.className = 'nb-editor-tab' + (index === 0 ? ' nb-editor-tab-active' : '');
            tab.textContent = pack.name;
            tab.addEventListener('click', function () {
                lists.forEach(function (list, i) { list.hidden = i !== index; });
                tabs.querySelectorAll('.nb-editor-tab').forEach(function (item, i) {
                    item.classList.toggle('nb-editor-tab-active', i === index);
                });
            });
            tabs.appendChild(tab);
        });
        panel.appendChild(tabs);
        root.appendChild(panel);
        return panel;
    };

    var openPanel = null;

    // 优先在工具栏上方弹出，上方放不下才翻到下方；始终夹在视口内。
    var layoutPanel = function () {
        if (!openPanel) return;
        var panel = openPanel.panel;
        var bar = openPanel.root.querySelector('.nb-editor-bar');
        if (!bar) return;
        var barRect = bar.getBoundingClientRect();
        var anchor = openPanel.button.getBoundingClientRect();
        var width = Math.min(360, Math.max(220, barRect.width));
        panel.style.width = width + 'px';
        var height = panel.offsetHeight;
        var left = Math.min(anchor.right - width, barRect.right - width);
        left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
        var above = barRect.top - height - 6;
        var top = above >= 8 ? above : Math.min(barRect.bottom + 6, window.innerHeight - height - 8);
        panel.style.left = Math.round(left) + 'px';
        panel.style.top = Math.round(Math.max(8, top)) + 'px';
    };

    var closePanels = function () {
        document.querySelectorAll('.nb-editor-panel').forEach(function (panel) { panel.hidden = true; });
        document.querySelectorAll('[data-nb-editor-emoji]').forEach(function (button) {
            button.classList.remove('nb-editor-btn-active');
        });
        openPanel = null;
    };

    window.addEventListener('resize', layoutPanel);
    window.addEventListener('scroll', layoutPanel, true);

    var previewBox = function (field) {
        var box = field.querySelector('.nb-editor-preview');
        if (box) return box;
        box = document.createElement('div');
        box.className = 'nb-editor-preview post-content';
        box.hidden = true;
        field.appendChild(box);
        return box;
    };

    // 缩进、无序标记、序号、序号后的分隔符、正文
    var LIST_RE = /^([ \t]*)(?:([-*])[ \t]+|(\d{1,9})([.)])[ \t]+)(.*)$/;

    var insideCodeFence = function (text, position) {
        var lines = text.slice(0, position).split('\n');
        var fences = 0;
        for (var i = 0; i < lines.length - 1; i++) {
            if (/^\s*```/.test(lines[i])) fences++;
        }
        return fences % 2 === 1;
    };

    var lineOffsets = function (lines) {
        var offsets = [];
        var position = 0;
        for (var i = 0; i < lines.length; i++) {
            offsets.push(position);
            position += lines[i].length + 1;
        }
        return offsets;
    };

    // 让光标所在的这一段有序列表在源码里也保持连续编号。
    var renumberOrderedList = function (textarea, caret) {
        var lines = textarea.value.split('\n');
        var offsets = lineOffsets(lines);
        var index = 0;
        for (var i = 0; i < lines.length; i++) {
            if (offsets[i] <= caret) index = i;
        }
        var current = LIST_RE.exec(lines[index]);
        if (!current || !current[3]) return caret;
        var start = index;
        var end = index;
        while (start > 0) {
            var above = LIST_RE.exec(lines[start - 1]);
            if (!above || !above[3]) break;
            start--;
        }
        while (end < lines.length - 1) {
            var below = LIST_RE.exec(lines[end + 1]);
            if (!below || !below[3]) break;
            end++;
        }
        var first = parseInt(LIST_RE.exec(lines[start])[3], 10);
        var delta = 0;
        var changed = false;
        for (var j = start; j <= end; j++) {
            var item = LIST_RE.exec(lines[j]);
            var next = item[1] + (first + j - start) + item[4] + ' ' + item[5];
            if (next === lines[j]) continue;
            if (offsets[j] < caret) delta += next.length - lines[j].length;
            lines[j] = next;
            changed = true;
        }
        if (!changed) return caret;
        textarea.value = lines.join('\n');
        return caret + delta;
    };

    var handleListEnter = function (event, textarea) {
        var start = textarea.selectionStart || 0;
        if (start !== (textarea.selectionEnd || start)) return;
        var value = textarea.value;
        if (insideCodeFence(value, start)) return;
        var lineStart = value.lastIndexOf('\n', start - 1) + 1;
        var lineEnd = value.indexOf('\n', start);
        if (lineEnd < 0) lineEnd = value.length;
        var line = value.slice(lineStart, lineEnd);
        var match = LIST_RE.exec(line);
        if (!match) return;
        // 光标还在标记里面时按普通换行处理。
        if (start < lineStart + (line.length - match[5].length)) return;
        event.preventDefault();
        if (match[5].trim() === '') {
            // 空列表项上回车表示结束这个列表。
            replaceRange(textarea, '', lineStart, lineEnd, 0, 0);
            return;
        }
        var marker = match[2] ? match[2] + ' ' : (parseInt(match[3], 10) + 1) + match[4] + ' ';
        var insert = '\n' + match[1] + marker;
        replaceRange(textarea, insert, start, start, insert.length, insert.length);
        if (!match[3]) return;
        var caret = renumberOrderedList(textarea, textarea.selectionStart || 0);
        textarea.setSelectionRange(caret, caret);
        dispatchInput(textarea);
    };

    var DRAFT_PREFIX = 'nb_editor:draft:v1:';
    var DRAFT_MAX = 200000;
    var draftTimers = new WeakMap();

    var draftStore = function () {
        try {
            var store = window.localStorage;
            if (!store) return null;
            var probe = DRAFT_PREFIX + 'probe';
            store.setItem(probe, '1');
            store.removeItem(probe);
            return store;
        } catch (error) {
            return null;
        }
    };

    var draftKey = function (root) {
        var scope = root.dataset.nbEditorDraft || '';
        return scope === '' ? '' : DRAFT_PREFIX + scope;
    };

    var draftMaxAge = function (root) {
        return Math.max(1, parseInt(root.dataset.nbEditorDraftDays || '7', 10) || 7) * 86400000;
    };

    // 顺手清掉过期草稿，避免 localStorage 里越攒越多。
    var pruneDrafts = function (store, maxAge, now) {
        var stale = [];
        for (var i = 0; i < store.length; i++) {
            var key = store.key(i);
            if (!key || key.indexOf(DRAFT_PREFIX) !== 0) continue;
            try {
                var saved = JSON.parse(store.getItem(key) || '{}');
                if (!saved.at || now - saved.at > maxAge) stale.push(key);
            } catch (error) {
                stale.push(key);
            }
        }
        stale.forEach(function (key) { store.removeItem(key); });
    };

    var dropDraft = function (root) {
        var store = draftStore();
        var key = draftKey(root);
        if (store && key) store.removeItem(key);
    };

    var saveDraft = function (root) {
        var store = draftStore();
        var key = draftKey(root);
        var textarea = textareaOf(root);
        if (!store || !key || !textarea) return;
        var text = textarea.value;
        if (text.trim() === '') { store.removeItem(key); return; }
        if (text.length > DRAFT_MAX) text = text.slice(0, DRAFT_MAX);
        var record = JSON.stringify({text: text, at: Date.now()});
        try {
            store.setItem(key, record);
        } catch (error) {
            // 配额不足时先清过期草稿再试一次，仍失败就放弃，不打扰用户。
            try {
                pruneDrafts(store, draftMaxAge(root), Date.now());
                store.setItem(key, record);
            } catch (retryError) {}
        }
    };

    var scheduleDraft = function (root) {
        clearTimeout(draftTimers.get(root));
        draftTimers.set(root, setTimeout(function () { saveDraft(root); }, 500));
    };

    var draftAge = function (at) {
        var minutes = Math.floor((Date.now() - at) / 60000);
        if (minutes < 1) return '刚刚';
        if (minutes < 60) return minutes + ' 分钟前';
        var hours = Math.floor(minutes / 60);
        if (hours < 24) return hours + ' 小时前';
        return Math.floor(hours / 24) + ' 天前';
    };

    var offerDraft = function (root) {
        var store = draftStore();
        var key = draftKey(root);
        var textarea = textareaOf(root);
        var field = fieldOf(root);
        if (!store || !key || !textarea || !field) return;
        pruneDrafts(store, draftMaxAge(root), Date.now());
        var raw = store.getItem(key);
        if (!raw) return;
        var saved;
        try { saved = JSON.parse(raw); } catch (error) { store.removeItem(key); return; }
        var text = typeof saved.text === 'string' ? saved.text : '';
        if (text === '' || text === textarea.value) return;
        if (field.querySelector('.nb-editor-draft')) return;
        var bar = document.createElement('div');
        bar.className = 'nb-editor-draft';
        var label = document.createElement('span');
        label.className = 'nb-editor-draft-text';
        label.textContent = '发现' + draftAge(saved.at || Date.now()) + '未发布的草稿';
        var restore = document.createElement('button');
        restore.type = 'button';
        restore.className = 'nb-editor-draft-action';
        restore.textContent = '恢复';
        var discard = document.createElement('button');
        discard.type = 'button';
        discard.className = 'nb-editor-draft-action';
        discard.textContent = '丢弃';
        restore.addEventListener('click', function () {
            textarea.value = text;
            bar.remove();
            textarea.focus();
            dispatchInput(textarea);
        });
        discard.addEventListener('click', function () {
            store.removeItem(key);
            bar.remove();
        });
        bar.append(label, restore, discard);
        root.after(bar);
    };

    var previewTimers = new WeakMap();
    var previewState = new WeakMap();

    var previewMessage = function (box, text) {
        box.innerHTML = '';
        var line = document.createElement('p');
        line.className = 'nb-editor-preview-empty';
        line.textContent = text;
        box.appendChild(line);
    };

    // 预览一律由服务端渲染，保证所见即所得的那一栏和发布后的正文完全一致。
    var renderPreview = function (root) {
        var field = fieldOf(root);
        var textarea = textareaOf(root);
        var url = root.dataset.nbEditorPreviewUrl || '';
        if (!field || !textarea || !url) return;
        var box = previewBox(field);
        if (box.hidden) return;
        var text = textarea.value;
        var state = previewState.get(field) || {};
        if (state.text === text) return;
        state.text = text;
        if (state.controller) state.controller.abort();
        state.controller = null;
        previewState.set(field, state);
        if (text.trim() === '') {
            previewMessage(box, '还没有内容，写点什么就会显示在这里。');
            return;
        }
        var controller = window.AbortController ? new AbortController() : null;
        state.controller = controller;
        if (box.childElementCount === 0) previewMessage(box, '正在生成预览……');
        var form = root.closest('form');
        var token = form ? form.querySelector('input[name="_csrf"]') : null;
        var data = new FormData();
        data.append('body', text);
        data.append('topic_id', root.dataset.nbEditorTopic || '0');
        if (token) data.append('_csrf', token.value);
        var options = {method: 'POST', body: data, credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}};
        if (controller) options.signal = controller.signal;
        fetch(url, options)
            .then(function (response) { return response.json(); })
            .then(function (result) {
                if (box.hidden || previewState.get(field) !== state || state.controller !== controller) return;
                if (result && result.ok) box.innerHTML = result.html || '';
                else previewMessage(box, (result && result.message) || '预览失败，请稍后再试。');
            })
            .catch(function (error) {
                if (error && error.name === 'AbortError') return;
                if (!box.hidden) previewMessage(box, '预览失败，请稍后再试。');
            });
    };

    var schedulePreview = function (root) {
        var field = fieldOf(root);
        if (!field) return;
        clearTimeout(previewTimers.get(field));
        previewTimers.set(field, setTimeout(function () { renderPreview(root); }, 400));
    };

    var togglePreview = function (root, button) {
        var field = fieldOf(root);
        var textarea = textareaOf(root);
        if (!field || !textarea || !root.dataset.nbEditorPreviewUrl) return;
        var box = previewBox(field);
        var on = box.hidden;
        box.hidden = !on;
        field.classList.toggle('nb-editor-live', on);
        if (button) button.classList.toggle('nb-editor-btn-active', on);
        clearTimeout(previewTimers.get(field));
        if (on) {
            previewState.delete(field);
            renderPreview(root);
        }
        textarea.focus();
    };

    var toggleFullscreen = function (root, button) {
        var field = fieldOf(root);
        if (!field) return;
        var on = field.classList.toggle('nb-editor-full');
        if (button) button.classList.toggle('nb-editor-btn-active', on);
        var textarea = textareaOf(root);
        if (textarea) textarea.focus();
    };

    var applyAction = function (action, root, button) {
        var textarea = textareaOf(root);
        if (action === 'preview') { togglePreview(root, button); return; }
        if (action === 'fullscreen') { toggleFullscreen(root, button); return; }
        if (!textarea) return;
        switch (action) {
            case 'bold': template(textarea, '**', '**', '粗体文字'); break;
            case 'italic': template(textarea, '*', '*', '斜体文字'); break;
            case 'strike': template(textarea, '~~', '~~', '删除线文字'); break;
            case 'heading': linePrefix(textarea, '## ', '标题', false); break;
            case 'quote': linePrefix(textarea, '> ', '引用内容', false); break;
            case 'code': template(textarea, '`', '`', '代码'); break;
            case 'code_block': insertBlock(textarea, '```\n代码\n```\n', 4, 6); break;
            case 'ul': linePrefix(textarea, '- ', '列表项', false); break;
            case 'ol':
                linePrefix(textarea, '', '列表项', true);
                var olCaret = renumberOrderedList(textarea, textarea.selectionEnd || 0);
                if (olCaret !== (textarea.selectionEnd || 0)) { textarea.setSelectionRange(olCaret, olCaret); dispatchInput(textarea); }
                break;
            case 'link': insertLink(textarea); break;
            case 'image': insertImage(textarea); break;
            case 'table': insertBlock(textarea, '| 表头 | 表头 |\n| --- | --- |\n| 内容 | 内容 |\n', 2, 4); break;
            case 'hr': insertBlock(textarea, '\n---\n\n', 1, 4); break;
        }
    };

    document.addEventListener('click', function (event) {
        var target = event.target instanceof Element ? event.target : null;
        if (!target) return;
        if (dialogFinish) {
            var dialog = document.getElementById('notify-modal');
            if (target.closest('[data-modal-close]') || target === dialog) closeDialog(null);
        }
        var item = target.closest('[data-nb-editor-insert]');
        if (item) {
            var itemRoot = item.closest('.nb-editor');
            var itemTextarea = itemRoot ? textareaOf(itemRoot) : null;
            if (itemTextarea) {
                event.preventDefault();
                var value = item.dataset.nbEditorInsert || '';
                replaceSelection(itemTextarea, value, value.length, value.length);
                closePanels();
            }
            return;
        }
        var emoji = target.closest('[data-nb-editor-emoji]');
        if (emoji) {
            event.preventDefault();
            var emojiRoot = emoji.closest('.nb-editor');
            if (!emojiRoot) return;
            var panel = buildPanel(emojiRoot);
            var open = panel.hidden;
            closePanels();
            if (open) {
                panel.hidden = false;
                openPanel = {root: emojiRoot, panel: panel, button: emoji};
                layoutPanel();
                emoji.classList.add('nb-editor-btn-active');
            }
            return;
        }
        var button = target.closest('[data-nb-editor-action]');
        if (button) {
            var root = button.closest('.nb-editor');
            if (!root) return;
            event.preventDefault();
            applyAction(button.dataset.nbEditorAction || '', root, button);
            return;
        }
        if (!target.closest('.nb-editor-panel')) closePanels();
    });

    document.addEventListener('input', function (event) {
        var target = event.target instanceof Element ? event.target : null;
        var textarea = target ? target.closest('textarea[name="body"]') : null;
        if (!textarea) return;
        var host = textarea.closest('.nb-editor-field');
        var editor = host ? host.querySelector('.nb-editor') : null;
        if (!editor) return;
        if (editor.dataset.nbEditorDraft) scheduleDraft(editor);
        if (host.classList.contains('nb-editor-live')) schedulePreview(editor);
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            if (dialogFinish) { closeDialog(null); return; }
            var full = document.querySelector('.nb-editor-field.nb-editor-full');
            if (full) {
                var root = full.querySelector('.nb-editor');
                if (root) toggleFullscreen(root, root.querySelector('[data-nb-editor-action="fullscreen"]'));
                return;
            }
            closePanels();
            return;
        }
        if (event.key !== 'Enter') return;
        // 中文输入法回车是在选词，不能当成换行处理。
        if (event.isComposing || event.keyCode === 229) return;
        var textarea = event.target instanceof Element ? event.target.closest('textarea[name="body"]') : null;
        var field = textarea ? textarea.closest('.nb-editor-field') : null;
        if (!field) return;
        if (event.ctrlKey || event.metaKey) {
            if (!field.querySelector('.nb-editor[data-nb-editor-hotkey]')) return;
            var form = textarea.closest('form');
            if (!form) return;
            event.preventDefault();
            var submit = form.querySelector('button[type="submit"]');
            if (submit) form.requestSubmit(submit);
            else form.requestSubmit();
            return;
        }
        if (event.shiftKey || event.altKey) return;
        handleListEnter(event, textarea);
    });

    document.addEventListener('submit', function (event) {
        var form = event.target instanceof Element ? event.target : null;
        var textarea = form ? form.querySelector('textarea[name="body"]') : null;
        var field = textarea ? textarea.closest('.nb-editor-field') : null;
        var root = field ? field.querySelector('.nb-editor') : null;
        if (!root || !root.dataset.nbEditorDraft) return;
        clearTimeout(draftTimers.get(root));
        dropDraft(root);
    }, true);

    var statusTimers = new WeakMap();

    var editorStatus = function (field, text, sticky) {
        var bar = field.querySelector('.nb-editor-status');
        if (!bar) {
            bar = document.createElement('div');
            bar.className = 'nb-editor-status';
            var root = field.querySelector('.nb-editor');
            if (root) root.after(bar);
            else field.appendChild(bar);
        }
        bar.textContent = text;
        bar.hidden = false;
        clearTimeout(statusTimers.get(field));
        if (!sticky) statusTimers.set(field, setTimeout(function () { bar.hidden = true; }, 3000));
    };

    var pasteFileName = function (type, index, total) {
        var ext = ({'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp'})[String(type || '').toLowerCase()] || 'png';
        var now = new Date();
        var pad = function (value) { return String(value).length < 2 ? '0' + value : String(value); };
        var stamp = now.getFullYear() + pad(now.getMonth() + 1) + pad(now.getDate())
            + '-' + pad(now.getHours()) + pad(now.getMinutes()) + pad(now.getSeconds());
        return 'paste-' + stamp + (total > 1 ? '-' + (index + 1) : '') + '.' + ext;
    };

    // 逐张上传：附件插件的 input.files 每次都会被整体替换，并发会互相顶掉。
    var uploadPastedFiles = function (target, files, index, done, failed, items) {
        if (index >= files.length) return Promise.resolve({markdown: done.join('\n'), ok: done.length, failed: failed, items: items});
        var name = pasteFileName(files[index].type, index, files.length);
        var named = new File([files[index]], name, {type: files[index].type || 'image/png'});
        return uploadThroughAttachment(target, named).then(function (result) {
            done.push(result.markdown || ('![' + name + '](' + result.url + ')'));
            if (result.item) items.push(result.item);
        }).catch(function () {
            failed += 1;
        }).then(function () {
            return uploadPastedFiles(target, files, index + 1, done, failed, items);
        });
    };

    var replaceMarker = function (textarea, marker, markdown) {
        var index = textarea.value.indexOf(marker);
        if (index < 0) return;
        var before = textarea.value.slice(0, index);
        var after = textarea.value.slice(index + marker.length);
        var prefix = markdown !== '' && before !== '' && before.slice(-1) !== '\n' ? '\n' : '';
        var suffix = markdown !== '' && after !== '' && after.slice(0, 1) !== '\n' ? '\n' : '';
        var value = prefix + markdown + suffix;
        textarea.value = before + value + after;
        var caret = index + value.length;
        textarea.setSelectionRange(caret, caret);
        textarea.focus();
        dispatchInput(textarea);
    };

    document.addEventListener('paste', function (event) {
        var target = event.target instanceof Element ? event.target : null;
        var textarea = target ? target.closest('textarea[name="body"]') : null;
        var items = (event.clipboardData && event.clipboardData.items) || [];
        var files = [];
        for (var i = 0; i < items.length; i++) {
            if (items[i].kind !== 'file' || String(items[i].type || '').indexOf('image/') !== 0) continue;
            var blob = items[i].getAsFile();
            if (blob) files.push(blob);
        }
        // 粘的不是图片（比如往弹层的“图片地址”框里粘链接文本）就放行，交给输入框默认行为。
        if (!files.length) return;
        var field = textarea ? textarea.closest('.nb-editor-field') : null;
        var root = field ? field.querySelector('.nb-editor') : null;
        // 图片弹层开着时焦点在弹层输入框里，取不到正文框：识别到图片粘贴就关掉弹层，直接插进对应的正文。
        var dialog = document.getElementById('notify-modal');
        if ((!root || root.dataset.nbEditorPaste !== '1') && dialog && !dialog.hidden && dialog.contains(target) && lastDialogTextarea) {
            textarea = lastDialogTextarea;
            field = textarea.closest('.nb-editor-field');
            root = field ? field.querySelector('.nb-editor') : null;
            if (root && root.dataset.nbEditorPaste === '1') {
                if (dialogFinish) closeDialog(null);
            } else root = null;
        }
        if (!root || root.dataset.nbEditorPaste !== '1') return;
        // 独立的「粘贴图片上传」插件已经在处理时让给它，避免同一张图传两次。
        if (document.querySelector('[data-paste-image-upload-hint]')) return;
        var uploadTarget = attachmentTarget(textarea);
        if (!uploadTarget) return;
        event.preventDefault();
        var marker = '<!-- nb-editor-upload:' + Date.now().toString(36) + Math.random().toString(36).slice(2) + ' -->';
        replaceSelection(textarea, marker, marker.length, marker.length);
        editorStatus(field, files.length > 1 ? '正在上传 ' + files.length + ' 张粘贴的图片……' : '正在上传粘贴的图片……', true);
        uploadPastedFiles(uploadTarget, files, 0, [], 0, []).then(function (result) {
            replaceMarker(textarea, marker, result.markdown);
            (result.items || []).forEach(releaseAttachment);
            // 粘贴的图片都成功插入后，顺手关掉还开着的弹层（含插入图片弹层）。
            if (!result.failed && result.ok && dialogFinish) closeDialog(null);
            if (result.failed && !result.ok) editorStatus(field, '粘贴的图片上传失败', false);
            else if (result.failed) editorStatus(field, '已插入 ' + result.ok + ' 张，' + result.failed + ' 张上传失败', false);
            else editorStatus(field, '已插入 ' + result.ok + ' 张图片', false);
        });
    });

    var scan = function (node) {
        if (node.matches && node.matches('[data-nb-editor]')) mount(node);
        if (node.querySelectorAll) node.querySelectorAll('[data-nb-editor]').forEach(mount);
    };

    scan(document);
    if (document.body && window.MutationObserver) {
        new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1) scan(node);
                });
            });
        }).observe(document.body, {childList: true, subtree: true});
    }
}());
JS;
}

return [
    'id' => 'nb_editor',
    'name' => 'NB编辑器',
    'version' => '1.6.7',
    'description' => '发帖和回帖时多一条编辑工具栏，一键加粗、引用、插入表格和表情，图片可以直接上传本机文件或粘贴截图；旁边能开一栏边写边看的实时预览，也能全屏书写；内容会自动存在本机，刷新或误关页面后可一键找回。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'nb_editor_css', 'js' => 'nb_editor_js'],
    'hooks' => [
        'topic.form_extra' => 'nb_editor_topic_form_extra',
        'reply.form_extra' => 'nb_editor_reply_form_extra',
        'topic.form_sidebar' => 'nb_editor_form_sidebar',
        'markdown.render' => 'nb_editor_render',
    ],
    'routes' => ['nb_editor_preview' => 'nb_editor_preview_route'],
    'admin_tabs' => ['nb_editor' => 'nb_editor_admin_page'],
];
