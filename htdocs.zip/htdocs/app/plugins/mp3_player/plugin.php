<?php
if (!defined('APP_ROOT')) exit;

const MP3_PLAYER_RATE_DEFAULT = 1000;

function mp3_player_install(array $plugin): void
{
    $t = app_db_types();
    app_db_create_table('plugin_mp3_player_history', "id {$t['id']},user_id {$t['uint']} NOT NULL,track_key {$t['key']} NOT NULL,topic_id {$t['uint']} NOT NULL,attachment_file {$t['key']} NOT NULL,filename {$t['string']} NOT NULL,position_ms {$t['uint']} NOT NULL DEFAULT 0,duration_ms {$t['uint']} NOT NULL DEFAULT 0,rate_milli {$t['uint']} NOT NULL DEFAULT 1000,created_at {$t['uint']} NOT NULL,updated_at {$t['uint']} NOT NULL,UNIQUE(user_id,track_key)");
    app_db_create_index('idx_plugin_mp3_player_history_user', 'plugin_mp3_player_history(user_id,updated_at DESC)');
    app_db_create_index('idx_plugin_mp3_player_history_topic', 'plugin_mp3_player_history(topic_id,updated_at DESC)');
}

function mp3_player_uninstall(array $plugin): void
{
    app_db_drop_table('plugin_mp3_player_history');
}

function mp3_player_config(): array
{
    static $config;
    if (is_array($config)) return $config;
    $raw = plugin_config('mp3_player', ['forum_ids' => '']);
    $value = $raw['forum_ids'] ?? '';
    $values = is_array($value) ? $value : preg_split('/\s*,\s*/', (string)$value, -1, PREG_SPLIT_NO_EMPTY);
    $ids = array_values(array_unique(array_filter(array_map('intval', is_array($values) ? $values : []), fn(int $id): bool => $id > 0)));
    return $config = ['forum_ids' => $ids];
}

function mp3_player_forum_enabled(int $forum_id): bool
{
    return $forum_id > 0 && in_array($forum_id, mp3_player_config()['forum_ids'], true);
}

function mp3_player_track_key(int $topic_id, string $attachment_file): string
{
    return hash('sha256', $topic_id . '|' . $attachment_file);
}

function mp3_player_clean_filename(string $filename): string
{
    $filename = trim(preg_replace('~[\x00-\x1F\x7F\r\n"\\\\/]+~', ' ', basename($filename)) ?? '');
    return cut($filename !== '' ? $filename : '音频附件.mp3', 180);
}

function mp3_player_attachment_url(string $url): ?array
{
    $url = html_entity_decode(trim($url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '' || preg_match('/[\s<>"\']/', $url)) return null;
    $parts = parse_url($url);
    if (!is_array($parts)) return null;
    $query = [];
    parse_str((string)($parts['query'] ?? ''), $query);
    $file = rawurldecode((string)($query['f'] ?? ''));
    if (preg_match('/^[a-f0-9]{64}\.mp3$/', $file) !== 1) return null;
    $name = mp3_player_clean_filename((string)($query['name'] ?? '音频附件.mp3'));
    return ['file' => $file, 'name' => $name];
}

function mp3_player_extract_tracks(string $body, int $topic_id, string $html = ''): array
{
    if ($body === '' || $topic_id <= 0) return [];
    $candidates = [];
    $collect = static function (string $url) use (&$candidates): void {
        $attachment = mp3_player_attachment_url($url);
        if ($attachment) $candidates[$attachment['file']] = $attachment;
    };
    $in_code = false;
    foreach (explode("\n", str_replace(["\r\n", "\r"], "\n", $body)) as $line) {
        if (preg_match('/^\s*```/', $line) === 1) {
            $in_code = !$in_code;
            continue;
        }
        if ($in_code) continue;
        if (preg_match_all('/\[[^\]\r\n]{1,255}\]\(([^)\s]+)\)/u', $line, $matches)) {
            foreach ($matches[1] as $url) $collect((string)$url);
        }
    }
    if ($html !== '' && preg_match_all('~<a\b[^>]*\bhref\s*=\s*(["' . "'" . '])(.*?)\1[^>]*>~is', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) $collect((string)$match[2]);
    }
    if (!$candidates) return [];
    $tracks = [];
    foreach ($candidates as $file => $candidate) {
        $path = UPLOAD_DIR . '/' . upload_hash_dir(substr($file, 0, 64)) . '/' . $file;
        if (!is_file($path) || !is_readable($path)) continue;
        $tracks[] = [
            'file' => $file,
            'name' => mp3_player_clean_filename((string)($candidate['name'] ?? '音频附件.mp3')),
            'mime' => 'audio/mpeg',
            'size' => max(0, (int)filesize($path)),
            'track_key' => mp3_player_track_key($topic_id, $file),
        ];
    }
    return $tracks;
}

function mp3_player_stream_page(array $plugin): never
{
    $file = (string)($_GET['f'] ?? '');
    if (preg_match('/^[a-f0-9]{64}\.mp3$/', $file) !== 1) err('音频附件不存在', 404);
    $path = UPLOAD_DIR . '/' . upload_hash_dir(substr($file, 0, 64)) . '/' . $file;
    if (!is_file($path) || !is_readable($path)) err('音频文件不可读', 404);
    $size = (int)filesize($path);
    if ($size <= 0) err('音频文件为空', 404);
    $start = 0;
    $end = $size - 1;
    $status = 200;
    $range = (string)($_SERVER['HTTP_RANGE'] ?? '');
    if ($range !== '') {
        if (preg_match('/^bytes=(\d*)-(\d*)$/', trim($range), $match) !== 1 || ($match[1] === '' && $match[2] === '')) {
            header('Content-Range: bytes */' . $size, true, 416);
            exit;
        }
        if ($match[1] === '') {
            $suffix = min($size, (int)$match[2]);
            $start = $size - $suffix;
        } else {
            $start = (int)$match[1];
            $end = $match[2] === '' ? $end : (int)$match[2];
        }
        if ($start < 0 || $start >= $size || $end < $start) {
            header('Content-Range: bytes */' . $size, true, 416);
            exit;
        }
        $end = min($end, $size - 1);
        $status = 206;
    }
    $length = $end - $start + 1;
    $name = mp3_player_clean_filename((string)($_GET['name'] ?? '音频附件.mp3'));
    header('Content-Type: audio/mpeg');
    header('Accept-Ranges: bytes');
    header('Content-Length: ' . $length);
    header('Content-Disposition: inline; filename="download"; filename*=UTF-8\'\'' . rawurlencode($name));
    header('Cache-Control: public, max-age=3600');
    header('X-Content-Type-Options: nosniff');
    if ($status === 206) header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
    http_response_code($status);
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'HEAD') exit;
    $handle = @fopen($path, 'rb');
    if (!$handle || fseek($handle, $start) !== 0) {
        if (is_resource($handle)) fclose($handle);
        exit;
    }
    $remaining = $length;
    while ($remaining > 0 && !feof($handle)) {
        $chunk = fread($handle, min(8192, $remaining));
        if ($chunk === false || $chunk === '') break;
        echo $chunk;
        $remaining -= strlen($chunk);
        if (function_exists('flush')) flush();
    }
    fclose($handle);
    exit;
}

function mp3_player_history_for_tracks(array $tracks, int $topic_id): array
{
    if (uid() <= 0 || $topic_id <= 0 || !$tracks) return [];
    $keys = array_values(array_unique(array_filter(array_map(static fn(array $track): string => (string)($track['track_key'] ?? ''), $tracks))));
    if (!$keys) return [];
    $marks = sql_marks(count($keys));
    $rows = q('SELECT track_key,position_ms,duration_ms,rate_milli FROM plugin_mp3_player_history WHERE user_id=? AND topic_id=? AND track_key IN (' . $marks . ')', array_merge([uid(), $topic_id], $keys))->fetchAll();
    $history = [];
    foreach ($rows as $row) $history[(string)$row['track_key']] = [
        'position_ms' => max(0, (int)($row['position_ms'] ?? 0)),
        'duration_ms' => max(0, (int)($row['duration_ms'] ?? 0)),
        'rate_milli' => min(2000, max(500, (int)($row['rate_milli'] ?? 1000))),
    ];
    return $history;
}

function mp3_player_card(array $tracks, int $topic_id, array $history = []): string
{
    if (!$tracks) return '';
    $items = '';
    foreach ($tracks as $index => $track) {
        $stream_url = route_url('mp3_player_stream', ['f' => $track['file'], 'name' => $track['name']]);
        $saved = (array)($history[$track['track_key']] ?? []);
        $duration = max(0, (int)($saved['duration_ms'] ?? 0));
        $position = min($duration > 0 ? $duration : PHP_INT_MAX, max(0, (int)($saved['position_ms'] ?? 0)));
        $completed = $duration > 0 && $position >= $duration - 2000;
        $percent = $duration > 0 ? min(100, (int)round($position * 100 / $duration)) : 0;
        $summary = $completed ? '已听完' : ($position > 0 ? '已听 ' . mp3_player_format_duration($position) . ($duration > 0 ? ' / ' . mp3_player_format_duration($duration) : '') : '未播放');
        $items .= '<li class="mp3-player-track' . ($index === 0 ? ' is-current' : '') . '" data-mp3-track data-index="' . (int)$index . '" data-track-key="' . h($track['track_key']) . '" data-attachment-file="' . h($track['file']) . '" data-filename="' . h($track['name']) . '" data-stream-url="' . h($stream_url) . '" data-position-ms="' . $position . '" data-duration-ms="' . $duration . '" data-rate-milli="' . (int)($saved['rate_milli'] ?? 1000) . '" data-completed="' . ($completed ? '1' : '0') . '"><button type="button" class="mp3-player-track-button"><span class="mp3-player-track-index">' . str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT) . '</span><span class="mp3-player-track-copy"><strong>' . h($track['name']) . '</strong><span data-mp3-track-summary>' . h($summary) . '</span></span><span class="mp3-player-track-progress"><span data-mp3-track-percent>' . $percent . '%</span><span class="mp3-player-track-bar"><span data-mp3-track-fill style="width:' . $percent . '%"></span></span></span></button></li>';
    }
    $first = $tracks[0];
    $first_url = route_url('mp3_player_stream', ['f' => $first['file'], 'name' => $first['name']]);
    $history_url = route_url('mp3_player_history_save');
    return '<div class="mp3-player-card" data-mp3-player data-topic-id="' . $topic_id . '" data-history-url="' . h($history_url) . '" data-csrf="' . h(csrf_token()) . '" data-user-id="' . (uid() > 0 ? '1' : '0') . '"><div class="mp3-player-head"><div class="mp3-player-file"><span class="mp3-player-type">MP3</span><div><strong data-mp3-current-name>' . h($first['name']) . '</strong><span class="mp3-player-count">' . count($tracks) . ' 个文件</span></div></div><span class="mp3-player-status" data-mp3-status>未播放</span></div><audio class="mp3-player-audio-element" preload="metadata" data-mp3-audio src="' . h($first_url) . '"></audio><div class="mp3-player-audio"><button type="button" class="mp3-player-toggle" data-mp3-toggle aria-label="播放"><svg viewBox="0 0 24 24" aria-hidden="true" data-mp3-play-icon><path d="M8 5.5v13l10-6.5L8 5.5z"/></svg></button><div class="mp3-player-seek"><input type="range" min="0" max="1000" value="0" data-mp3-seek aria-label="播放进度" disabled><span><i data-mp3-elapsed>00:00</i><i data-mp3-duration>--:--</i></span></div></div><div class="mp3-player-controls"><span data-mp3-position>准备播放</span><span class="mp3-player-volume"><button type="button" class="mp3-player-volume-toggle" data-mp3-volume-toggle aria-label="音量" aria-expanded="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4zm12.5 3a4.5 4.5 0 0 0-2.2-3.9v7.8a4.5 4.5 0 0 0 2.2-3.9zm0-8.1v2.1a8 8 0 0 1 0 12v2.1a10 10 0 0 0 0-16.2z"/></svg></button><span class="mp3-player-volume-panel" data-mp3-volume-panel hidden><input type="range" min="0" max="1" step="0.05" value="1" data-mp3-volume aria-label="音量"></span></span><label class="mp3-player-rate"><span>倍速</span><select data-mp3-rate><option value="0.5">0.5x</option><option value="0.75">0.75x</option><option value="1" selected>1x</option><option value="1.25">1.25x</option><option value="1.5">1.5x</option><option value="1.75">1.75x</option><option value="2">2x</option></select></label></div><ol class="mp3-player-playlist" data-mp3-playlist>' . $items . '</ol></div>';
}

function mp3_player_render_topic($html, array $ctx): string
{
    $row = is_array($ctx['row'] ?? null) ? $ctx['row'] : [];
    $topic_id = (int)($row['id'] ?? 0);
    $forum_id = (int)($row['forum_id'] ?? 0);
    $body = (string)($ctx['body'] ?? '');
    if ($topic_id <= 0 || !mp3_player_forum_enabled($forum_id) || $body === '') return (string)$html;
    $tracks = mp3_player_extract_tracks($body, $topic_id, (string)$html);
    if (!$tracks) return (string)$html;
    // 列表循环内不做 DB 读取：播放历史仅在主题查看页（单次）取回，避免 N+1。
    $history = empty($ctx['list'] ?? null) ? mp3_player_history_for_tracks($tracks, $topic_id) : [];
    $card = mp3_player_card($tracks, $topic_id, $history);
    $marker = "\x1Fmp3-player\x1F";
    foreach ($tracks as $track) {
        $replaced = false;
        $pattern = '~<a\b[^>]*\bhref\s*=\s*(["' . "'" . '])(.*?)\1[^>]*>.*?</a>~is';
        $html = preg_replace_callback($pattern, static function (array $match) use ($track, $marker, &$replaced): string {
            if ($replaced) return $match[0];
            $attachment = mp3_player_attachment_url((string)$match[2]);
            if (!$attachment || $attachment['file'] !== $track['file']) return $match[0];
            $replaced = true;
            return $marker;
        }, (string)$html) ?? $html;
    }
    if (!str_contains((string)$html, $marker)) return (string)$html;
    $html = preg_replace_callback('~<p\b[^>]*>(.*?)</p>~is', static function (array $match) use ($marker): string {
        if (!str_contains($match[1], $marker)) return $match[0];
        $content = str_replace($marker, '', $match[1]);
        $visible = preg_replace('~(?:\s|&nbsp;|<br\s*/?>)+~i', '', $content) ?? $content;
        if (trim($visible) === '') {
            $content = '';
        } else {
            $content = preg_replace('~^(?:\s*<br\s*/?>\s*)+|(?:\s*<br\s*/?>\s*)+$~i', '', $content) ?? $content;
            $content = trim($content);
        }
        $block = $content !== '' ? '<p>' . $content . '</p>' : '';
        return $block;
    }, (string)$html) ?? $html;
    $html = str_replace($marker, '', (string)$html);
    if (preg_match('~<div\b(?=[^>]*\bclass\s*=\s*"post-content")[^>]*>~i', (string)$html) !== 1) return (string)$html;
    return preg_replace_callback('~</div>(\s*</li>\s*)$~i', static fn(array $match): string => $card . '</div>' . $match[1], (string)$html, 1) ?? (string)$html;
}

function mp3_player_json(array $data): never
{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function mp3_player_history_save_page(array $plugin): never
{
    require_post();
    need_login();
    $topic_id = max(1, (int)($_POST['topic_id'] ?? 0));
    $file = (string)($_POST['attachment_file'] ?? '');
    if (preg_match('/^[a-f0-9]{64}\.mp3$/', $file) !== 1) mp3_player_json(['ok' => 0, 'message' => '音频参数无效']);
    $path = UPLOAD_DIR . '/' . upload_hash_dir(substr($file, 0, 64)) . '/' . $file;
    if (!is_file($path) || !is_readable($path)) mp3_player_json(['ok' => 0, 'message' => '音频附件不存在']);
    $filename = mp3_player_clean_filename((string)($_POST['filename'] ?? '音频附件.mp3'));
    $duration = is_numeric($_POST['duration'] ?? null) ? (float)$_POST['duration'] : 0.0;
    $position = is_numeric($_POST['position'] ?? null) ? (float)$_POST['position'] : 0.0;
    if (!is_finite($duration) || $duration < 0) $duration = 0.0;
    if (!is_finite($position) || $position < 0) $position = 0.0;
    if ($duration > 0) $position = min($position, $duration);
    $rate = is_numeric($_POST['rate'] ?? null) ? (float)$_POST['rate'] : 1.0;
    if (!is_finite($rate)) $rate = 1.0;
    $rate_milli = min(2000, max(500, (int)round($rate * 1000 / 25) * 25));
    $track_key = mp3_player_track_key($topic_id, $file);
    app_db_upsert('plugin_mp3_player_history', [
        'user_id' => uid(),
        'track_key' => $track_key,
        'topic_id' => $topic_id,
        'attachment_file' => $file,
        'filename' => $filename,
        'position_ms' => (int)round($position * 1000),
        'duration_ms' => (int)round($duration * 1000),
        'rate_milli' => $rate_milli,
        'created_at' => now(),
        'updated_at' => now(),
    ], ['user_id', 'track_key']);
    mp3_player_json(['ok' => 1]);
}

function mp3_player_format_duration(int $milliseconds): string
{
    $seconds = max(0, intdiv($milliseconds, 1000));
    return sprintf('%02d:%02d', intdiv($seconds, 60), $seconds % 60);
}

function mp3_player_history_page(array $plugin): void
{
    need_login();
    $rows = q('SELECT * FROM plugin_mp3_player_history WHERE user_id=? ORDER BY updated_at DESC LIMIT 100', [uid()])->fetchAll();
    $topics = rows_by_ids('app_topics', array_column($rows, 'topic_id'), 'id,title');
    $items = '<ul class="mp3-player-history-list">';
    foreach ($rows as $row) {
        $topic_id = (int)$row['topic_id'];
        $topic = $topics[$topic_id] ?? null;
        if (!$topic) continue;
        $duration = (int)$row['duration_ms'];
        $position = min($duration, (int)$row['position_ms']);
        $completed = $duration > 0 && $position >= $duration - 2000;
        $progress = $duration > 0 ? (int)round($position * 100 / $duration) : 0;
        $icon = $completed ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg> ' : '';
        $status_class = $completed ? ' is-completed' : ($position > 0 ? ' is-in-progress' : '');
        $items .= '<li class="mp3-player-history-item' . $status_class . '"><div class="mp3-player-history-main"><a href="' . h(route_url('topic', ['id' => $topic_id])) . '">' . h((string)$topic['title']) . '</a><strong>' . h((string)$row['filename']) . '</strong><div class="mp3-player-history-meta"><span>' . $icon . ($completed ? '已听完' : '已听 ' . h(mp3_player_format_duration($position)) . ($duration > 0 ? ' / ' . h(mp3_player_format_duration($duration)) : '')) . '</span><span class="mp3-player-history-bar"><span class="mp3-player-history-fill" style="width:' . $progress . '%"></span></span><span>' . $progress . '%</span><span>' . h(date('Y-m-d H:i', (int)$row['updated_at'])) . '</span><span>' . ((int)$row['rate_milli'] / 1000) . 'x</span></div></div></li>';
    }
    if ($items === '<ul class="mp3-player-history-list">') $items .= '<li class="mp3-player-history-empty">暂无播放记录</li>';
    $items .= '</ul>';
    $clear = '<form class="mp3-player-history-clear" method="post" action="' . h(route_url('mp3_player_history_clear')) . '" data-confirm="确定清空全部播放记录？">' . form_token() . '<button type="submit">清空记录</button></form>';
    $body = '<div class="mp3-player-history-page"><div class="mp3-player-history-head"><div><span class="mp3-player-kicker">MP3 PLAYER</span><h2>播放记录</h2><p>登录后保存的音频断点和播放历史。</p></div>' . ($rows ? $clear : '') . '</div>' . $items . '</div>';
    page('播放记录', shell_html($body, sidebar_stack_html([sidebar_user_card_html()])));
}

function mp3_player_history_clear_page(array $plugin): never
{
    require_post();
    need_login();
    q('DELETE FROM plugin_mp3_player_history WHERE user_id=?', [uid()]);
    set_flash('播放记录已清空');
    go(route_url('mp3_player_history'));
}

function mp3_player_before_delete($value, array $ctx): void
{
    $topic_id = (int)($ctx['id'] ?? 0);
    if ($topic_id > 0) q('DELETE FROM plugin_mp3_player_history WHERE topic_id=?', [$topic_id]);
}

function mp3_player_feature_links(array $links, array $ctx): array
{
    if (uid()) $links[] = ['text' => '播放记录', 'url' => route_url('mp3_player_history')];
    return $links;
}

function mp3_player_admin_page(array $plugin): string
{
    need_admin();
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        require_post();
        $allowed = [];
        foreach (forums_cache() as $forum) $allowed[(int)$forum['id']] = true;
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['forum_ids'] ?? [])), fn(int $id): bool => isset($allowed[$id]))));
        plugin_save_config('mp3_player', ['forum_ids' => implode(',', $ids)]);
        set_flash('MP3 播放器版块设置已保存');
        go(admin_url(['tab' => 'mp3_player']));
    }
    $selected = mp3_player_config()['forum_ids'];
    $options = '';
    foreach (forums_cache() as $forum) {
        $id = (int)$forum['id'];
        $options .= '<label class="mp3-player-forum-option"><input type="checkbox" name="forum_ids[]" value="' . $id . '"' . (in_array($id, $selected, true) ? ' checked' : '') . '><span><strong>' . h((string)$forum['name']) . '</strong><small>版块 ID ' . $id . '</small></span></label>';
    }
    if ($options === '') $options = '<div class="empty-state">暂无可配置版块</div>';
    $summary = $selected ? '已选择 ' . count($selected) . ' 个版块' : '未选择版块，当前不解析任何主题';
    $form = '<form class="mp3-player-admin-form" method="post" action="' . h(admin_url(['tab' => 'mp3_player'])) . '">' . form_token() . '<div class="mp3-player-admin-note"><strong>解析范围</strong><span>只有选定版块的主题会识别 MP3 附件并显示播放器，其他版块不会查询附件或修改内容。</span></div><div class="mp3-player-forum-head"><span>' . h($summary) . '</span><button type="button" data-mp3-select-all>全选</button></div><div class="mp3-player-forum-options">' . $options . '</div><div class="mp3-player-admin-actions"><button type="submit">保存设置</button></div></form>';
    return '<div class="admin-list-panel plugin-manage-panel mp3-player-admin"><div class="admin-list-head"><div class="admin-plugin-summary"><strong>MP3 附件播放器</strong><span>断点续听、播放历史与倍速播放</span></div></div><div class="plugin-panel-body">' . $form . '</div></div>';
}

function mp3_player_css(): string
{
    return '.mp3-player-count{display:block;margin-top:2px;color:var(--text-subtle);font-size:10px}.mp3-player-playlist{display:grid;gap:5px;max-height:300px;margin:0;padding:8px 0 0;border-top:1px solid var(--line-soft);overflow:auto;list-style:none}.mp3-player-track{min-width:0}.mp3-player-track-button{display:grid;grid-template-columns:minmax(0,1fr) 92px;align-items:center;gap:12px;width:100%;min-height:54px;padding:8px 10px;border:1px solid transparent;border-radius:6px;background:transparent;color:var(--text);font:inherit;text-align:left;cursor:pointer}.mp3-player-track-button:hover{border-color:var(--line);background:var(--bg)}.mp3-player-track.is-current .mp3-player-track-button{border-color:var(--brand);background:var(--brand-soft)}.mp3-player-track-copy{display:grid;gap:3px;min-width:0}.mp3-player-track-copy strong{overflow-wrap:anywhere;color:var(--text);font-size:12px;line-height:1.45}.mp3-player-track-copy span{color:var(--text-muted);font-size:11px}.mp3-player-track-progress{display:grid;gap:4px;justify-items:end;color:var(--text-subtle);font-size:10px}.mp3-player-track-bar{display:block;width:88px;height:3px;overflow:hidden;border-radius:3px;background:var(--line)}.mp3-player-track-bar span{display:block;height:100%;background:var(--brand);transition:width .15s ease}.mp3-player-card{display:grid;gap:10px;margin:12px 0;padding:12px 14px;border:1px solid var(--line);border-radius:8px;background:var(--panel);box-shadow:0 4px 14px var(--shadow-base)}.mp3-player-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;min-width:0}.mp3-player-file{display:flex;align-items:flex-start;gap:8px;min-width:0}.mp3-player-file strong{display:block;min-width:0;overflow-wrap:anywhere;color:var(--text);font-size:13px;line-height:1.4}.mp3-player-type{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;min-width:30px;height:22px;border-radius:5px;background:var(--brand-soft);color:var(--brand);font-size:10px;font-weight:800}.mp3-player-status{flex:0 0 auto;color:var(--text-muted);font-size:11px;white-space:nowrap}.mp3-player-card audio{display:block;width:100%;min-width:0}.mp3-player-controls{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:nowrap;min-width:0;color:var(--text-muted);font-size:11px}.mp3-player-controls>span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mp3-player-rate{display:inline-flex;align-items:center;gap:6px;flex:0 0 auto;white-space:nowrap}.mp3-player-rate select{min-height:28px;padding:0 24px 0 7px;border:1px solid var(--line);border-radius:5px;background:var(--bg);color:var(--text);font-size:11px}.mp3-player-history-page{max-width:860px;margin:0 auto}.mp3-player-history-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:14px}.mp3-player-kicker{display:block;margin-bottom:5px;color:var(--brand);font-size:11px;font-weight:800;letter-spacing:1.4px}.mp3-player-history-head h2{margin:0;color:var(--text);font-size:26px;line-height:1.2}.mp3-player-history-head p{margin:7px 0 0;color:var(--text-muted);font-size:13px}.mp3-player-history-clear{flex:0 0 auto}.mp3-player-history-clear button{margin:0}.mp3-player-history-list{display:grid;gap:8px;margin:0;padding:0;list-style:none}.mp3-player-history-item{min-width:0;padding:13px 14px;border:1px solid var(--line);border-radius:7px;background:var(--panel)}.mp3-player-history-main{display:grid;gap:6px;min-width:0}.mp3-player-history-main>a{overflow-wrap:anywhere;color:var(--text);font-weight:700}.mp3-player-history-main strong{overflow-wrap:anywhere;color:var(--text-muted);font-size:12px;font-weight:500}.mp3-player-history-meta{display:flex;flex-wrap:wrap;gap:6px}.mp3-player-history-meta span{padding:4px 7px;border:1px solid var(--line-soft);border-radius:5px;background:var(--bg);color:var(--text-subtle);font-size:11px}.mp3-player-history-empty{padding:24px;text-align:center;color:var(--text-muted);border:1px dashed var(--line);border-radius:7px}.mp3-player-admin{max-width:none}.mp3-player-admin-form{display:grid;gap:14px}.mp3-player-admin-note{display:grid;gap:4px;padding:12px 14px;border:1px solid var(--line-soft);border-radius:7px;background:var(--bg)}.mp3-player-admin-note strong{color:var(--text);font-size:13px}.mp3-player-admin-note span{color:var(--text-muted);font-size:12px;line-height:1.6}.mp3-player-forum-head{display:flex;align-items:center;justify-content:space-between;gap:10px;color:var(--text-muted);font-size:12px}.mp3-player-forum-head button{margin:0;padding:5px 9px;background:var(--bg);color:var(--text-muted);border:1px solid var(--line)}.mp3-player-forum-options{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.mp3-player-forum-option{display:grid;grid-template-columns:16px minmax(0,1fr);align-items:start;gap:8px;min-width:0;padding:11px 12px;border:1px solid var(--line);border-radius:7px;background:var(--panel);cursor:pointer}.mp3-player-forum-option:has(input:checked){border-color:var(--brand);background:var(--brand-soft)}.mp3-player-forum-option input{width:15px;height:15px;margin:1px 0 0;accent-color:var(--brand)}.mp3-player-forum-option span{display:grid;gap:2px;min-width:0}.mp3-player-forum-option strong{overflow-wrap:anywhere;color:var(--text);font-size:12px}.mp3-player-forum-option small{color:var(--text-subtle);font-size:10px}.mp3-player-admin-actions{display:flex;justify-content:flex-start;gap:8px}.mp3-player-admin-actions button{margin:0}@media(max-width:760px){.mp3-player-track-button{grid-template-columns:minmax(0,1fr) 76px;padding:8px}.mp3-player-track-bar{width:72px}.mp3-player-forum-options{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:560px){.mp3-player-card{padding:11px}.mp3-player-head,.mp3-player-history-head{display:grid;gap:7px}.mp3-player-status{justify-self:start}.mp3-player-history-clear,.mp3-player-history-clear button{width:100%}.mp3-player-forum-options{grid-template-columns:1fr}.mp3-player-admin-actions button{width:100%}}';
}

function mp3_player_js(): string
{
    return <<<'JS'
(function(){
var prefix='mp3_player_';
function formatTime(value){value=Math.max(0,Math.floor(value||0));var minutes=Math.floor(value/60),seconds=value%60;return String(minutes).padStart(2,'0')+':'+String(seconds).padStart(2,'0')}
function readState(key){try{var value=localStorage.getItem(prefix+key);return value?JSON.parse(value):{}}catch(e){return {}}}
function writeState(key,state){try{localStorage.setItem(prefix+key,JSON.stringify(state))}catch(e){}}
function saveRemote(card,item,audio,state){if(card.dataset.userId!=='1')return;var data=new URLSearchParams();data.set('_csrf',card.dataset.csrf||'');data.set('topic_id',card.dataset.topicId||'0');data.set('attachment_file',item.dataset.attachmentFile||'');data.set('filename',item.dataset.filename||'音频附件.mp3');data.set('position',String(state.position||0));data.set('duration',String(state.duration||0));data.set('rate',String(state.rate||1));fetch(card.dataset.historyUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest'},body:data.toString(),keepalive:true}).catch(function(){})}
function mp3PlayerSetup(card){if(card.dataset.mp3Ready==='1')return;card.dataset.mp3Ready='1';var audio=card.querySelector('[data-mp3-audio]'),position=card.querySelector('[data-mp3-position]'),status=card.querySelector('[data-mp3-status]'),rate=card.querySelector('[data-mp3-rate]'),currentName=card.querySelector('[data-mp3-current-name]'),items=Array.from(card.querySelectorAll('[data-mp3-track]'));if(!audio||!items.length)return;var current=null,state={},currentIndex=0,lastSave=0,pendingPlay=false;
function mp3PlayerLoadState(item){var local=readState(item.dataset.trackKey),saved={position:Number(item.dataset.positionMs||0)/1000,duration:Number(item.dataset.durationMs||0)/1000,rate:Number(item.dataset.rateMilli||1000)/1000,completed:item.dataset.completed==='1'};if(local&&typeof local==='object'){if(local.position!=null)saved.position=Math.max(0,Number(local.position)||0);if(local.duration!=null)saved.duration=Math.max(0,Number(local.duration)||0);if(local.rate!=null)saved.rate=Math.min(2,Math.max(.5,Number(local.rate)||1));if(local.completed!=null)saved.completed=local.completed===true}return saved}
function mp3PlayerUpdateItem(item,itemState){var total=itemState.duration||0,currentValue=itemState.completed?total:itemState.position||0,percent=total?Math.min(100,Math.round(currentValue*100/total)):0,summary=itemState.completed?'已听完':currentValue>0?'已听 '+formatTime(currentValue)+(total?' / '+formatTime(total):''):'未播放';item.classList.toggle('is-current',item===current);item.querySelector('[data-mp3-track-summary]').textContent=summary;item.querySelector('[data-mp3-track-percent]').textContent=percent+'%';item.querySelector('[data-mp3-track-fill]').style.width=percent+'%'}
function mp3PlayerUpdate(){if(!current)return;var total=audio.duration||state.duration||0,currentValue=audio.currentTime||0;if(!audio.paused||currentValue>0)state.position=currentValue;state.duration=total;position.textContent=total?'已听 '+formatTime(currentValue)+' / '+formatTime(total):'准备播放';status.textContent=state.completed?'已听完':audio.paused?(currentValue>0?'已暂停':'未播放'):'播放中';mp3PlayerUpdateItem(current,state)}
function persist(remote){if(!current)return;state.position=state.completed?(audio.duration||state.duration||0):(audio.currentTime||0);state.duration=audio.duration||state.duration||0;state.rate=audio.playbackRate||state.rate||1;writeState(current.dataset.trackKey,state);mp3PlayerUpdateItem(current,state);if(remote)saveRemote(card,current,audio,state)}
function mp3PlayerSelect(index,autoplay){var item=items[index];if(!item)return;if(current&&current!==item)persist(true);current=item;currentIndex=index;state=mp3PlayerLoadState(item);pendingPlay=autoplay;currentName.textContent=item.querySelector('.mp3-player-track-copy strong').textContent;rate.value=String(state.rate);audio.src=item.dataset.streamUrl;audio.load();items.forEach(function(entry){mp3PlayerUpdateItem(entry,entry===item?state:mp3PlayerLoadState(entry))});mp3PlayerUpdate();}
audio.addEventListener('loadedmetadata',function(){state.duration=audio.duration||state.duration||0;if(state.completed){state.position=0;state.completed=false}else if(state.position>0)try{audio.currentTime=Math.min(state.position,Math.max(0,audio.duration-1))}catch(e){}mp3PlayerUpdate();if(pendingPlay){pendingPlay=false;var result=audio.play();if(result&&result.catch)result.catch(function(){})}});audio.addEventListener('timeupdate',function(){mp3PlayerUpdate();if(Date.now()-lastSave>2000){lastSave=Date.now();persist(false)}});audio.addEventListener('play',function(){state.completed=false;status.textContent='播放中';mp3PlayerUpdate()});audio.addEventListener('pause',function(){persist(true);mp3PlayerUpdate()});audio.addEventListener('ended',function(){state.completed=true;state.position=audio.duration||state.duration;writeState(current.dataset.trackKey,state);mp3PlayerUpdate();saveRemote(card,current,audio,state);if(items[currentIndex+1])mp3PlayerSelect(currentIndex+1,true)});audio.addEventListener('error',function(){status.textContent='音频加载失败'});rate.addEventListener('change',function(){audio.playbackRate=Number(rate.value)||1;state.rate=audio.playbackRate;writeState(current.dataset.trackKey,state);if(!audio.paused)saveRemote(card,current,audio,state);mp3PlayerUpdate()});items.forEach(function(item,index){item.addEventListener('click',function(){mp3PlayerSelect(index,true)})});mp3PlayerSelect(0,false)}
function mp3PlayerInit(){document.querySelectorAll('[data-mp3-player]').forEach(mp3PlayerSetup);document.querySelectorAll('[data-mp3-mp3PlayerSelect-all]').forEach(function(button){if(button.dataset.ready==='1')return;button.dataset.ready='1';button.addEventListener('click',function(){var boxes=document.querySelectorAll('.mp3-player-forum-option input[type="checkbox"]'),all=Array.from(boxes).some(function(box){return !box.checked});boxes.forEach(function(box){box.checked=all})})})}
function persistVisible(){document.querySelectorAll('[data-mp3-player]').forEach(function(card){var audio=card.querySelector('[data-mp3-audio]');if(audio&&!audio.paused)audio.dispatchEvent(new Event('pause'))})}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mp3PlayerInit);else mp3PlayerInit();document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')persistVisible()});window.addEventListener('beforeunload',persistVisible);
})();
JS;
}

function mp3_player_css_custom(): string
{
    return <<<'CSS'
/* ========== 播放器卡片 - 主容器 ========== */
.mp3-player-card {
    display: grid;
    gap: 0;
    margin: 16px 0;
    padding: 0;
    overflow: hidden;
    border: 1px solid var(--line);
    border-radius: 10px;
    background: var(--panel);
    box-shadow:
        0 4px 24px color-mix(in srgb, var(--shadow-base) 60%, transparent),
        0 1px 3px color-mix(in srgb, var(--shadow-base) 30%, transparent);
    transition: box-shadow 0.3s ease, border-color 0.3s ease;
}
.mp3-player-card.is-playing {
    border-color: color-mix(in srgb, var(--brand) 30%, var(--line));
    box-shadow:
        0 8px 32px color-mix(in srgb, var(--brand) 15%, var(--shadow-base) 60%),
        0 1px 4px color-mix(in srgb, var(--brand) 10%, var(--shadow-base) 30%);
}

/* ========== 头部区域 ========== */
.mp3-player-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    padding: 20px 20px 16px;
    min-width: 0;
}
.mp3-player-file {
    display: flex;
    align-items: center;
    gap: 14px;
    min-width: 0;
}
.mp3-player-file strong {
    display: block;
    min-width: 0;
    overflow-wrap: anywhere;
    color: var(--text);
    font-size: 15px;
    font-weight: 700;
    line-height: 1.4;
    letter-spacing: 0;
}
.mp3-player-file > div {
    min-width: 0;
}
.mp3-player-type {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    min-width: 42px;
    height: 42px;
    border-radius: 9px;
    background: var(--brand);
    color: var(--inverse-text);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0;
    box-shadow: 0 4px 12px color-mix(in srgb, var(--brand) 35%, transparent);
}
.mp3-player-count {
    display: block;
    margin-top: 3px;
    color: var(--text-subtle);
    font-size: 11px;
    letter-spacing: 0;
}
.mp3-player-status {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    flex: 0 0 auto;
    padding: 5px 12px;
    border: 1px solid var(--line-soft);
    border-radius: 99px;
    background: var(--bg);
    color: var(--text-muted);
    font-size: 11px;
    font-weight: 500;
    white-space: nowrap;
    transition: all 0.25s ease;
}
.mp3-player-card.is-playing .mp3-player-status {
    border-color: color-mix(in srgb, var(--brand) 30%, var(--line-soft));
    color: var(--brand);
}
.mp3-player-status::before {
    display: block;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--line);
    content: "";
    transition: background 0.25s ease, box-shadow 0.25s ease;
}
.mp3-player-card.is-playing .mp3-player-status::before {
    background: var(--brand);
    box-shadow: 0 0 8px color-mix(in srgb, var(--brand) 50%, transparent);
    animation: mp3-player-pulse-dot 1.6s ease-in-out infinite;
}
@keyframes mp3-player-pulse-dot {
    0%, 100% { box-shadow: 0 0 4px color-mix(in srgb, var(--brand) 30%, transparent); }
    50% { box-shadow: 0 0 14px color-mix(in srgb, var(--brand) 60%, transparent); }
}

/* ========== 音频播放条区域 ========== */
.mp3-player-audio-element {
    display: none;
}
.mp3-player-audio {
    display: grid;
    grid-template-columns: 52px minmax(0, 1fr) auto;
    align-items: center;
    gap: 14px;
    margin: 2px 20px 10px;
    padding: 14px 16px;
    border: 1px solid var(--line);
    border-radius: 14px;
    background: var(--bg);
    transition: border-color 0.25s ease;
}
.mp3-player-card.is-playing .mp3-player-audio {
    border-color: color-mix(in srgb, var(--brand) 25%, var(--line));
}

/* 播放/暂停按钮 */
.mp3-player-toggle {
    display: grid;
    place-items: center;
    width: 52px;
    min-width: 52px;
    height: 52px;
    min-height: 52px;
    padding: 0;
    border: 3px solid color-mix(in srgb, var(--brand) 20%, transparent);
    border-radius: 50%;
    background: var(--brand);
    color: var(--inverse-text);
    box-shadow:
        0 4px 16px color-mix(in srgb, var(--brand) 40%, transparent),
        0 1px 3px color-mix(in srgb, var(--brand) 20%, transparent),
        inset 0 1px 0 rgba(255,255,255,0.2);
    cursor: pointer;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}
.mp3-player-toggle:hover {
    transform: translateY(-1px);
    box-shadow:
        0 6px 20px color-mix(in srgb, var(--brand) 50%, transparent),
        0 2px 6px color-mix(in srgb, var(--brand) 25%, transparent),
        inset 0 1px 0 rgba(255,255,255,0.2);
}
.mp3-player-toggle:active {
    transform: scale(0.93);
    box-shadow:
        0 2px 8px color-mix(in srgb, var(--brand) 30%, transparent);
}
.mp3-player-toggle:focus-visible {
    outline: 3px solid var(--focus-ring);
    outline-offset: 3px;
}
.mp3-player-toggle svg {
    width: 22px;
    height: 22px;
    fill: currentColor;
    filter: drop-shadow(0 1px 2px rgba(0,0,0,0.15));
    transition: transform 0.2s ease;
}
.mp3-player-card.is-playing .mp3-player-toggle {
    box-shadow:
        0 4px 20px color-mix(in srgb, var(--brand) 50%, transparent),
        0 0 0 6px color-mix(in srgb, var(--brand) 12%, transparent),
        inset 0 1px 0 rgba(255,255,255,0.2);
    animation: none;
}
@keyframes mp3-player-glow {
    0%, 100% { box-shadow: 0 4px 20px color-mix(in srgb, var(--brand) 50%, transparent), 0 0 0 6px color-mix(in srgb, var(--brand) 12%, transparent), inset 0 1px 0 rgba(255,255,255,0.2); }
    50% { box-shadow: 0 4px 26px color-mix(in srgb, var(--brand) 65%, transparent), 0 0 0 10px color-mix(in srgb, var(--brand) 18%, transparent), inset 0 1px 0 rgba(255,255,255,0.25); }
}
.mp3-player-toggle span {
    display: grid;
    place-items: center;
    width: 100%;
    height: 100%;
}

/* 进度条 */
.mp3-player-seek {
    display: grid;
    gap: 6px;
    min-width: 0;
}
.mp3-player-seek input {
    -webkit-appearance: none;
    appearance: none;
    width: 100%;
    height: 6px;
    margin: 0;
    border-radius: 6px;
    background: linear-gradient(to right, var(--brand) var(--mp3-progress, 0%), var(--line) var(--mp3-progress, 0%));
    outline: 0;
    cursor: pointer;
    transition: background 0.1s linear;
}
.mp3-player-seek input:hover {
    background: linear-gradient(to right, var(--brand) var(--mp3-progress, 0%), var(--line-soft) var(--mp3-progress, 0%));
}
.mp3-player-seek input::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 18px;
    height: 18px;
    border: 3px solid var(--panel);
    border-radius: 50%;
    background: var(--brand);
    box-shadow: 0 2px 8px color-mix(in srgb, var(--brand) 40%, transparent), 0 0 0 2px var(--brand);
    cursor: pointer;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.mp3-player-seek input::-webkit-slider-thumb:hover {
    transform: scale(1.15);
    box-shadow: 0 3px 12px color-mix(in srgb, var(--brand) 50%, transparent), 0 0 0 3px var(--brand);
}
.mp3-player-seek input::-moz-range-thumb {
    width: 14px;
    height: 14px;
    border: 3px solid var(--panel);
    border-radius: 50%;
    background: var(--brand);
    box-shadow: 0 2px 8px color-mix(in srgb, var(--brand) 40%, transparent), 0 0 0 2px var(--brand);
    cursor: pointer;
    transition: transform 0.15s ease;
}
.mp3-player-seek input::-moz-range-thumb:hover {
    transform: scale(1.15);
}
.mp3-player-seek input:disabled {
    opacity: 0.45;
    cursor: default;
}
.mp3-player-seek input:disabled::-webkit-slider-thumb {
    transform: none;
}
.mp3-player-seek input:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 4px;
}
.mp3-player-seek span {
    display: flex;
    justify-content: space-between;
    color: var(--text-subtle);
    font-size: 11px;
    font-variant-numeric: tabular-nums;
    font-weight: 500;
    letter-spacing: 0;
}
.mp3-player-seek i {
    font-style: normal;
}

/* ========== 底部控制栏 ========== */
.mp3-player-controls {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: nowrap;
    min-width: 0;
    padding: 6px 20px 16px;
    color: var(--text-muted);
    font-size: 12px;
}
.mp3-player-controls > span[data-mp3-position] {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: 500;
}
.mp3-player-controls > .mp3-player-volume {
    margin-left: auto;
}

/* 音量控件 */
.mp3-player-volume {
    position: relative;
    display: inline-flex;
    align-items: center;
    flex: 0 0 auto;
}
.mp3-player-volume-toggle {
    display: grid;
    place-items: center;
    width: 34px;
    min-width: 34px;
    height: 34px;
    min-height: 34px;
    padding: 0;
    border: 0;
    border-radius: 8px;
    background: transparent;
    color: var(--text-muted);
    box-shadow: none;
    cursor: pointer;
    transition: all 0.2s ease;
}
.mp3-player-volume-toggle:hover {
    background: var(--line-soft);
    color: var(--brand);
}
.mp3-player-volume-toggle:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
}
.mp3-player-volume-toggle svg {
    width: 18px;
    height: 18px;
    fill: currentColor;
    transition: color 0.2s ease;
}
.mp3-player-volume-panel {
    position: absolute;
    left: 50%;
    bottom: calc(100% + 12px);
    z-index: 5;
    display: grid;
    place-items: center;
    width: 42px;
    height: 138px;
    padding: 12px 9px;
    border: 1px solid var(--line);
    border-radius: 10px;
    background: var(--panel);
    transform: translateX(-50%);
    box-shadow:
        0 12px 32px color-mix(in srgb, var(--shadow-base) 70%, transparent),
        0 2px 8px color-mix(in srgb, var(--shadow-base) 40%, transparent);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    animation: mp3-player-volume-in 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}
@keyframes mp3-player-volume-in {
    from { opacity: 0; transform: translateX(-50%) translateY(8px) scale(0.92); }
    to { opacity: 1; transform: translateX(-50%) translateY(0) scale(1); }
}
.mp3-player-volume-panel[hidden] {
    display: none;
}
.mp3-player-volume-panel input {
    width: 6px;
    height: 108px;
    margin: 0;
    accent-color: var(--brand);
    writing-mode: vertical-lr;
    direction: rtl;
    cursor: pointer;
}

/* 倍速选择 */
.mp3-player-rate {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    flex: 0 0 auto;
    white-space: nowrap;
}
.mp3-player-rate > span {
    color: var(--text-muted);
    font-size: 11px;
    font-weight: 500;
}
.mp3-player-rate select {
    min-width: 58px;
    min-height: 32px;
    padding: 0 28px 0 10px;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: var(--bg);
    color: var(--text);
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    appearance: none;
    -webkit-appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' fill='none'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%2394a3b8' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 9px center;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
.mp3-player-rate select:hover {
    border-color: var(--brand);
}
.mp3-player-rate select:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
    border-color: var(--brand);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--brand) 15%, transparent);
}

/* ========== 播放列表 ========== */
.mp3-player-playlist {
    display: grid;
    gap: 4px;
    max-height: none;
    margin: 0;
    padding: 14px 14px 16px;
    border-top: 1px solid var(--line-soft);
    background: var(--bg);
    overflow: visible;
    list-style: none;
    scroll-behavior: auto;
}
.mp3-player-playlist::-webkit-scrollbar {
    width: 4px;
}
.mp3-player-playlist::-webkit-scrollbar-track {
    background: transparent;
}
.mp3-player-playlist::-webkit-scrollbar-thumb {
    border-radius: 4px;
    background: var(--line);
}
.mp3-player-playlist::-webkit-scrollbar-thumb:hover {
    background: var(--line-soft);
}
.mp3-player-track {
    min-width: 0;
}
.mp3-player-track-button {
    display: grid;
    grid-template-columns: 36px minmax(0, 1fr) 100px;
    align-items: center;
    gap: 12px;
    width: 100%;
    min-height: 60px;
    padding: 10px 12px;
    border: 1px solid transparent;
    border-radius: 8px;
    background: transparent;
    color: var(--text);
    font: inherit;
    text-align: left;
    cursor: pointer;
    transition: all 0.2s ease;
}
.mp3-player-track-button:hover {
    border-color: var(--line);
    background: var(--panel);
    transform: none;
}
.mp3-player-track.is-current .mp3-player-track-button {
    border-color: color-mix(in srgb, var(--brand) 40%, var(--line));
    background: color-mix(in srgb, var(--brand) 6%, var(--panel));
    box-shadow: inset 3px 0 0 var(--brand);
}
.mp3-player-track-index {
    display: grid;
    place-items: center;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: var(--line-soft);
    color: var(--text-subtle);
    font-size: 11px;
    font-weight: 700;
    font-variant-numeric: tabular-nums;
    transition: all 0.25s ease;
}
.mp3-player-track.is-current .mp3-player-track-index {
    background: var(--brand);
    color: var(--inverse-text);
    box-shadow: 0 2px 8px color-mix(in srgb, var(--brand) 30%, transparent);
}
.mp3-player-track-copy {
    display: grid;
    gap: 4px;
    min-width: 0;
}
.mp3-player-track-copy strong {
    overflow-wrap: anywhere;
    color: var(--text);
    font-size: 13px;
    font-weight: 600;
    line-height: 1.45;
    letter-spacing: 0;
}
.mp3-player-track-copy span {
    color: var(--text-subtle);
    font-size: 11px;
    font-weight: 500;
}
.mp3-player-track-progress {
    display: grid;
    gap: 5px;
    justify-items: end;
    color: var(--text-subtle);
    font-size: 11px;
    font-weight: 500;
}
.mp3-player-track-bar {
    display: block;
    width: 90px;
    height: 4px;
    overflow: hidden;
    border-radius: 4px;
    background: var(--line-soft);
}
.mp3-player-track-bar span {
    display: block;
    height: 100%;
    border-radius: inherit;
    background: linear-gradient(90deg, var(--brand) 0%, color-mix(in srgb, var(--brand) 70%, #7c3aed) 100%);
    transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* ========== 历史页面 ========== */
.mp3-player-history-page {
    max-width: 860px;
    margin: 0 auto;
}
.mp3-player-history-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 20px;
}
.mp3-player-history-head > div:first-child {
    min-width: 0;
}
.mp3-player-kicker {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 8px;
    padding: 3px 10px;
    border-radius: 6px;
    background: color-mix(in srgb, var(--brand) 12%, transparent);
    color: var(--brand);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.8px;
}
.mp3-player-history-head h2 {
    margin: 0;
    color: var(--text);
    font-size: 30px;
    font-weight: 800;
    line-height: 1.15;
    letter-spacing: 0;
}
.mp3-player-history-head p {
    margin: 8px 0 0;
    color: var(--text-muted);
    font-size: 14px;
    line-height: 1.5;
}
.mp3-player-history-clear {
    flex: 0 0 auto;
}
.mp3-player-history-clear button {
    margin: 0;
    padding: 9px 18px;
    border: 1px solid var(--line);
    border-radius: 10px;
    background: var(--panel);
    color: var(--text-muted);
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
}
.mp3-player-history-clear button:hover {
    border-color: #ef4444;
    color: #ef4444;
    background: #fef2f2;
}
.mp3-player-history-list {
    display: grid;
    gap: 10px;
    margin: 0;
    padding: 0;
    list-style: none;
}
.mp3-player-history-item {
    min-width: 0;
    padding: 16px 18px;
    border: 1px solid var(--line);
    border-radius: 14px;
    background: var(--panel);
    transition: all 0.2s ease;
}
.mp3-player-history-item:hover {
    border-color: var(--brand);
    box-shadow: 0 4px 16px color-mix(in srgb, var(--brand) 8%, transparent);
    transform: translateY(-1px);
}
.mp3-player-history-main {
    display: grid;
    gap: 8px;
    min-width: 0;
}
.mp3-player-history-main > a {
    overflow-wrap: anywhere;
    color: var(--text);
    font-size: 15px;
    font-weight: 700;
    line-height: 1.4;
    text-decoration: none;
    transition: color 0.2s ease;
}
.mp3-player-history-main > a:hover {
    color: var(--brand);
}
.mp3-player-history-main strong {
    overflow-wrap: anywhere;
    color: var(--text-muted);
    font-size: 13px;
    font-weight: 500;
}
.mp3-player-history-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: center;
}
.mp3-player-history-meta span {
    display: inline-flex;
    align-items: center;
    padding: 5px 10px;
    border: 1px solid var(--line-soft);
    border-radius: 8px;
    background: var(--bg);
    color: var(--text-subtle);
    font-size: 11px;
    font-weight: 500;
    transition: all 0.15s ease;
}
.mp3-player-history-meta span:first-child {
    color: var(--brand);
    border-color: color-mix(in srgb, var(--brand) 20%, var(--line-soft));
    background: color-mix(in srgb, var(--brand) 6%, var(--bg));
}
.mp3-player-history-bar {
    display: block;
    width: 60px;
    height: 4px;
    border-radius: 4px;
    background: var(--line);
    overflow: hidden;
}
.mp3-player-history-fill {
    display: block;
    height: 100%;
    border-radius: inherit;
    background: linear-gradient(90deg, var(--brand) 0%, color-mix(in srgb, var(--brand) 70%, #7c3aed) 100%);
    transition: width 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}
.mp3-player-history-item.is-completed .mp3-player-history-fill {
    background: linear-gradient(90deg, #22c55e 0%, #16a34a 100%);
}
.mp3-player-history-item.is-completed .mp3-player-history-meta span:first-child {
    color: #16a34a;
    border-color: #bbf7d0;
    background: #f0fdf4;
}
.mp3-player-history-item.is-in-progress .mp3-player-history-meta span:first-child {
    color: var(--brand);
}
.mp3-player-history-item.is-completed:hover {
    border-color: #22c55e;
    box-shadow: 0 4px 16px rgba(34, 197, 94, 0.08);
}
.mp3-player-history-empty {
    padding: 48px 24px;
    text-align: center;
    color: var(--text-muted);
    font-size: 14px;
    border: 2px dashed var(--line);
    border-radius: 14px;
}

/* ========== 管理页面 ========== */
.mp3-player-admin {
    max-width: none !important;
}
.mp3-player-admin-form {
    display: grid;
    gap: 18px;
}
.mp3-player-admin-note {
    display: grid;
    gap: 5px;
    padding: 16px 18px;
    border: 1px solid var(--line-soft);
    border-radius: 8px;
    background: linear-gradient(135deg, var(--bg) 0%, color-mix(in srgb, var(--bg) 98%, var(--brand) 2%) 100%);
}
.mp3-player-admin-note strong {
    color: var(--text);
    font-size: 14px;
    font-weight: 700;
}
.mp3-player-admin-note span {
    color: var(--text-muted);
    font-size: 13px;
    line-height: 1.6;
}
.mp3-player-forum-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    color: var(--text-muted);
    font-size: 13px;
    font-weight: 500;
}
.mp3-player-forum-head button {
    margin: 0;
    padding: 6px 14px;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: var(--panel);
    color: var(--text-muted);
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
}
.mp3-player-forum-head button:hover {
    border-color: var(--brand);
    color: var(--brand);
    background: color-mix(in srgb, var(--brand) 6%, var(--panel));
}
.mp3-player-forum-options {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 10px;
}
.mp3-player-forum-option {
    display: grid;
    grid-template-columns: 18px minmax(0, 1fr);
    align-items: start;
    gap: 10px;
    min-width: 0;
    padding: 14px 16px;
    border: 1px solid var(--line);
    border-radius: 12px;
    background: var(--panel);
    cursor: pointer;
    transition: all 0.2s ease;
}
.mp3-player-forum-option:hover {
    border-color: var(--brand);
    box-shadow: 0 2px 10px color-mix(in srgb, var(--brand) 8%, transparent);
}
.mp3-player-forum-option:has(input:checked) {
    border-color: var(--brand);
    background: linear-gradient(135deg, color-mix(in srgb, var(--brand) 6%, var(--panel)) 0%, color-mix(in srgb, var(--brand) 3%, var(--panel)) 100%);
    box-shadow: 0 2px 12px color-mix(in srgb, var(--brand) 12%, transparent);
}
.mp3-player-forum-option input {
    width: 17px;
    height: 17px;
    margin: 1px 0 0;
    accent-color: var(--brand);
}
.mp3-player-forum-option span {
    display: grid;
    gap: 3px;
    min-width: 0;
}
.mp3-player-forum-option strong {
    overflow-wrap: anywhere;
    color: var(--text);
    font-size: 13px;
    font-weight: 600;
}
.mp3-player-forum-option small {
    color: var(--text-subtle);
    font-size: 11px;
}
.mp3-player-admin-actions {
    display: flex;
    justify-content: flex-start;
    gap: 10px;
}
.mp3-player-admin-actions button {
    margin: 0;
    padding: 10px 24px;
    border: 0;
    border-radius: 8px;
    background: var(--brand);
    color: var(--inverse-text);
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
}
.mp3-player-admin-actions button:hover {
    background: color-mix(in srgb, var(--brand) 85%, #000);
    box-shadow: 0 4px 14px color-mix(in srgb, var(--brand) 30%, transparent);
}

/* ========== 响应式 ========== */
@media (max-width: 760px) {
    .mp3-player-head {
        padding: 16px 14px 14px;
    }
    .mp3-player-audio {
        margin: 2px 14px 8px;
        padding: 12px 14px;
    }
    .mp3-player-controls {
        padding: 4px 14px 14px;
    }
    .mp3-player-playlist {
        padding: 12px 10px 14px;
    }
    .mp3-player-track-button {
        grid-template-columns: 32px minmax(0, 1fr) 80px;
        min-height: 56px;
        padding: 9px 10px;
    }
    .mp3-player-track-bar {
        width: 72px;
    }
    .mp3-player-track-index {
        width: 28px;
        height: 28px;
    }
    .mp3-player-forum-options {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 560px) {
    .mp3-player-card {
        margin: 12px 0;
        border-radius: 8px;
    }
    .mp3-player-head {
        display: grid;
        gap: 10px;
        padding: 14px 12px 12px;
    }
    .mp3-player-status {
        justify-self: start;
    }
    .mp3-player-type {
        min-width: 36px;
        height: 36px;
        border-radius: 10px;
        font-size: 10px;
    }
    .mp3-player-file strong {
        font-size: 14px;
    }
    .mp3-player-audio {
        grid-template-columns: 48px minmax(0, 1fr);
        margin: 1px 10px 6px;
        padding: 10px 12px;
    }
    .mp3-player-toggle {
        width: 48px;
        min-width: 48px;
        height: 48px;
        min-height: 48px;
    }
    .mp3-player-toggle svg {
        width: 20px;
        height: 20px;
    }
    .mp3-player-volume {
        grid-column: auto;
        margin-left: auto;
    }
    .mp3-player-controls {
        flex-wrap: nowrap;
        padding: 2px 12px 12px;
        gap: 8px;
    }
    .mp3-player-controls > span[data-mp3-position] {
        flex: 1 1 auto;
        min-width: 0;
        font-size: 11px;
    }
    .mp3-player-playlist {
        padding: 10px 8px 12px;
        max-height: none;
    }
    .mp3-player-track-button {
        grid-template-columns: 28px minmax(0, 1fr) 64px;
        min-height: 52px;
        padding: 8px;
        gap: 8px;
    }
    .mp3-player-track-index {
        width: 26px;
        height: 26px;
        border-radius: 8px;
        font-size: 10px;
    }
    .mp3-player-track-bar {
        width: 60px;
    }
    .mp3-player-track-copy strong {
        font-size: 12px;
    }
    .mp3-player-volume-panel {
        left: 50%;
    }
    .mp3-player-history-head {
        display: grid;
        gap: 12px;
    }
    .mp3-player-history-head h2 {
        font-size: 24px;
    }
    .mp3-player-history-clear,
    .mp3-player-history-clear button {
        width: 100%;
    }
    .mp3-player-history-item {
        padding: 14px;
    }
    .mp3-player-forum-options {
        grid-template-columns: 1fr;
    }
    .mp3-player-admin-actions button {
        width: 100%;
    }
}
CSS;
}

function mp3_player_css_refined(): string
{
    return mp3_player_css() . <<<'CSS'

/* Refined frontend player */
.mp3-player-card {
    --mp3-control-size: 48px;
    position: relative;
    isolation: isolate;
    display: grid;
    gap: 0;
    margin: 16px 0;
    padding: 0;
    overflow: visible;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: var(--panel);
    box-shadow: 0 8px 24px var(--shadow-base);
}
.mp3-player-card.is-playing {
    border-color: color-mix(in srgb, var(--brand) 35%, var(--line));
    box-shadow: 0 10px 28px var(--shadow-medium);
}
.mp3-player-card .mp3-player-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    min-width: 0;
    padding: 17px 16px 13px;
}
.mp3-player-card .mp3-player-file {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 0;
}
.mp3-player-card .mp3-player-file > div {
    min-width: 0;
}
.mp3-player-card .mp3-player-file strong {
    display: block;
    min-width: 0;
    overflow: hidden;
    color: var(--text);
    font-size: 14px;
    font-weight: 700;
    line-height: 1.4;
    letter-spacing: 0;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.mp3-player-card .mp3-player-type {
    display: grid;
    place-items: center;
    flex: 0 0 38px;
    width: 38px;
    height: 38px;
    border: 1px solid color-mix(in srgb, var(--brand) 28%, var(--line));
    border-radius: 8px;
    background: var(--brand-soft);
    color: var(--brand);
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0;
    box-shadow: none;
}
.mp3-player-card .mp3-player-count {
    display: block;
    margin-top: 2px;
    color: var(--text-subtle);
    font-size: 11px;
    line-height: 1.3;
    letter-spacing: 0;
}
.mp3-player-card .mp3-player-status {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    flex: 0 0 auto;
    padding: 4px 8px;
    border: 1px solid var(--line-soft);
    border-radius: 999px;
    background: var(--bg);
    color: var(--text-muted);
    font-size: 10px;
    font-weight: 600;
    line-height: 1.2;
    white-space: nowrap;
}
.mp3-player-card .mp3-player-status::before {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--text-disabled);
    box-shadow: none;
    content: "";
}
.mp3-player-card.is-playing .mp3-player-status {
    border-color: color-mix(in srgb, var(--brand) 28%, var(--line-soft));
    background: var(--brand-soft);
    color: var(--brand);
}
.mp3-player-card.is-playing .mp3-player-status::before {
    background: var(--brand);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--brand) 14%, transparent);
    animation: none;
}
.mp3-player-card .mp3-player-audio-element {
    display: none;
}
.mp3-player-card .mp3-player-audio {
    display: grid;
    grid-template-columns: var(--mp3-control-size) minmax(0, 1fr);
    align-items: center;
    gap: 14px;
    margin: 0 16px 8px;
    padding: 13px 14px;
    border: 1px solid var(--line-soft);
    border-radius: 8px;
    background: var(--bg);
    box-shadow: inset 0 1px 0 color-mix(in srgb, var(--panel) 80%, transparent);
}
.mp3-player-card.is-playing .mp3-player-audio {
    border-color: color-mix(in srgb, var(--brand) 26%, var(--line-soft));
}
.mp3-player-card .mp3-player-toggle {
    display: grid;
    place-items: center;
    width: var(--mp3-control-size);
    min-width: var(--mp3-control-size);
    height: var(--mp3-control-size);
    min-height: var(--mp3-control-size);
    padding: 0;
    border: 0;
    border-radius: 50%;
    background: var(--brand);
    color: var(--inverse-text);
    box-shadow: 0 4px 12px color-mix(in srgb, var(--brand) 30%, transparent);
    cursor: pointer;
    transition: background .16s ease, box-shadow .16s ease, transform .16s ease;
}
.mp3-player-card .mp3-player-toggle:hover {
    background: var(--brand-hover);
    box-shadow: 0 6px 16px color-mix(in srgb, var(--brand) 36%, transparent);
    transform: translateY(-1px);
}
.mp3-player-card .mp3-player-toggle:active {
    box-shadow: 0 2px 7px color-mix(in srgb, var(--brand) 24%, transparent);
    transform: scale(.96);
}
.mp3-player-card .mp3-player-toggle:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 3px;
}
.mp3-player-card .mp3-player-toggle svg {
    width: 20px;
    height: 20px;
    fill: currentColor;
    filter: none;
}
.mp3-player-card.is-playing .mp3-player-toggle {
    box-shadow: 0 4px 12px color-mix(in srgb, var(--brand) 32%, transparent);
    animation: none;
}
.mp3-player-card .mp3-player-seek {
    display: grid;
    grid-template-columns: 40px minmax(0, 1fr) 40px;
    align-items: center;
    gap: 8px;
    min-width: 0;
    min-height: 24px;
}
.mp3-player-card .mp3-player-seek input {
    grid-row: 1;
    grid-column: 2;
    -webkit-appearance: none;
    appearance: none;
    width: 100%;
    height: 5px;
    margin: 0;
    border: 0;
    border-radius: 5px;
    background: linear-gradient(to right, var(--brand) var(--mp3-progress, 0%), var(--line) var(--mp3-progress, 0%));
    outline: 0;
    cursor: pointer;
}
.mp3-player-card .mp3-player-seek input:hover {
    height: 5px;
    background: linear-gradient(to right, var(--brand) var(--mp3-progress, 0%), var(--line-soft) var(--mp3-progress, 0%));
}
.mp3-player-card .mp3-player-seek input::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 15px;
    height: 15px;
    border: 3px solid var(--panel);
    border-radius: 50%;
    background: var(--brand);
    box-shadow: 0 0 0 1px var(--brand), 0 2px 5px var(--shadow-base);
    cursor: grab;
}
.mp3-player-card .mp3-player-seek input::-webkit-slider-thumb:active {
    cursor: grabbing;
}
.mp3-player-card .mp3-player-seek input::-moz-range-thumb {
    width: 11px;
    height: 11px;
    border: 3px solid var(--panel);
    border-radius: 50%;
    background: var(--brand);
    box-shadow: 0 0 0 1px var(--brand), 0 2px 5px var(--shadow-base);
    cursor: grab;
}
.mp3-player-card .mp3-player-seek input:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 4px;
}
.mp3-player-card .mp3-player-seek input:disabled {
    opacity: .5;
    cursor: default;
}
.mp3-player-card .mp3-player-seek span {
    display: contents;
}
.mp3-player-card .mp3-player-seek i {
    grid-row: 1;
    color: var(--text-subtle);
    font-size: 10px;
    font-variant-numeric: tabular-nums;
    font-weight: 600;
    line-height: 1;
    letter-spacing: 0;
    font-style: normal;
    white-space: nowrap;
}
.mp3-player-card .mp3-player-seek i:first-child {
    grid-column: 1;
    text-align: left;
}
.mp3-player-card .mp3-player-seek i:last-child {
    grid-column: 3;
    text-align: right;
}
.mp3-player-card .mp3-player-controls {
    display: flex;
    align-items: center;
    gap: 7px;
    min-width: 0;
    padding: 0 16px 12px;
    color: var(--text-muted);
    font-size: 11px;
}
.mp3-player-card .mp3-player-controls > span[data-mp3-position] {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
    font-variant-numeric: tabular-nums;
    font-weight: 500;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.mp3-player-card .mp3-player-volume {
    position: relative;
    display: inline-flex;
    align-items: center;
    flex: 0 0 auto;
    margin-left: auto;
    overflow: visible;
    text-overflow: clip;
}
.mp3-player-card .mp3-player-volume-toggle {
    display: grid;
    place-items: center;
    width: 32px;
    min-width: 32px;
    height: 32px;
    min-height: 32px;
    padding: 0;
    border: 1px solid transparent;
    border-radius: 6px;
    background: transparent;
    color: var(--text-muted);
    box-shadow: none;
    cursor: pointer;
}
.mp3-player-card .mp3-player-volume-toggle:hover,
.mp3-player-card .mp3-player-volume-toggle[aria-expanded="true"] {
    border-color: var(--line-soft);
    background: var(--bg);
    color: var(--brand);
}
.mp3-player-card .mp3-player-volume-toggle:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
}
.mp3-player-card .mp3-player-volume-toggle svg {
    width: 17px;
    height: 17px;
    fill: currentColor;
}
.mp3-player-card .mp3-player-volume-panel {
    position: absolute;
    bottom: calc(100% + 8px);
    left: 50%;
    z-index: 10;
    display: grid;
    place-items: center;
    width: 40px;
    height: 132px;
    padding: 11px 8px;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: var(--panel);
    box-shadow: 0 10px 24px var(--shadow-medium);
    transform: translateX(-50%);
    animation: mp3-player-refined-volume-in .14s ease-out;
}
.mp3-player-card .mp3-player-volume-panel[hidden] {
    display: none;
}
.mp3-player-card .mp3-player-volume-panel input {
    width: 6px;
    height: 108px;
    margin: 0;
    accent-color: var(--brand);
    direction: rtl;
    writing-mode: vertical-lr;
    cursor: pointer;
}
@keyframes mp3-player-refined-volume-in {
    from { opacity: 0; transform: translateX(-50%) translateY(4px); }
    to { opacity: 1; transform: translateX(-50%) translateY(0); }
}
.mp3-player-card .mp3-player-rate {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    flex: 0 0 auto;
    white-space: nowrap;
}
.mp3-player-card .mp3-player-rate > span {
    color: var(--text-muted);
    font-size: 10px;
    font-weight: 600;
}
.mp3-player-card .mp3-player-rate select {
    min-width: 56px;
    min-height: 32px;
    padding: 0 24px 0 8px;
    border: 1px solid var(--line-soft);
    border-radius: 6px;
    background-color: var(--bg);
    background-position: right 7px center;
    color: var(--text);
    font-size: 11px;
    font-weight: 700;
}
.mp3-player-card .mp3-player-rate select:hover {
    border-color: var(--line);
}
.mp3-player-card .mp3-player-rate select:focus-visible {
    border-color: var(--brand);
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
    box-shadow: none;
}
.mp3-player-card .mp3-player-playlist {
    display: grid;
    gap: 3px;
    max-height: none;
    margin: 0;
    padding: 8px;
    overflow: visible;
    border-top: 1px solid var(--line-soft);
    border-radius: 0 0 8px 8px;
    background: var(--bg);
    list-style: none;
}
.mp3-player-card .mp3-player-track {
    min-width: 0;
}
.mp3-player-card .mp3-player-track-button {
    display: grid;
    grid-template-columns: 30px minmax(0, 1fr) 76px;
    align-items: center;
    gap: 10px;
    width: 100%;
    min-height: 54px;
    padding: 7px 9px;
    border: 1px solid transparent;
    border-radius: 6px;
    background: transparent;
    color: var(--text);
    font: inherit;
    text-align: left;
    cursor: pointer;
    transition: border-color .14s ease, background .14s ease, box-shadow .14s ease;
}
.mp3-player-card .mp3-player-track-button:hover {
    border-color: var(--line-soft);
    background: var(--panel);
    transform: none;
}
.mp3-player-card .mp3-player-track.is-current .mp3-player-track-button {
    border-color: color-mix(in srgb, var(--brand) 32%, var(--line-soft));
    background: var(--brand-soft);
    box-shadow: none;
}
.mp3-player-card .mp3-player-track-index {
    display: grid;
    place-items: center;
    width: 28px;
    height: 28px;
    border-radius: 6px;
    background: var(--panel);
    color: var(--text-subtle);
    font-size: 10px;
    font-variant-numeric: tabular-nums;
    font-weight: 700;
}
.mp3-player-card .mp3-player-track.is-current .mp3-player-track-index {
    background: var(--brand);
    color: var(--inverse-text);
    box-shadow: none;
}
.mp3-player-card .mp3-player-track[data-completed="1"]:not(.is-current) .mp3-player-track-index {
    background: var(--success-soft);
    color: var(--success);
}
.mp3-player-card .mp3-player-track-copy {
    display: grid;
    gap: 3px;
    min-width: 0;
}
.mp3-player-card .mp3-player-track-copy strong {
    overflow: hidden;
    color: var(--text);
    font-size: 12px;
    font-weight: 650;
    line-height: 1.4;
    letter-spacing: 0;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.mp3-player-card .mp3-player-track-copy span {
    color: var(--text-subtle);
    font-size: 10px;
    font-weight: 500;
}
.mp3-player-card .mp3-player-track-progress {
    display: grid;
    gap: 5px;
    justify-items: end;
    color: var(--text-subtle);
    font-size: 10px;
    font-variant-numeric: tabular-nums;
    font-weight: 600;
}
.mp3-player-card .mp3-player-track-bar {
    display: block;
    width: 72px;
    height: 3px;
    overflow: hidden;
    border-radius: 3px;
    background: var(--line);
}
.mp3-player-card .mp3-player-track-bar span {
    display: block;
    height: 100%;
    border-radius: inherit;
    background: var(--brand);
    transition: width .18s linear;
}
@media (max-width: 560px) {
    .mp3-player-card {
        --mp3-control-size: 44px;
        margin: 12px 0;
    }
    .mp3-player-card .mp3-player-head {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 8px;
        padding: 15px 10px 11px;
    }
    .mp3-player-card .mp3-player-file {
        gap: 8px;
    }
    .mp3-player-card .mp3-player-type {
        flex-basis: 34px;
        width: 34px;
        height: 34px;
    }
    .mp3-player-card .mp3-player-file strong {
        font-size: 13px;
    }
    .mp3-player-card .mp3-player-status {
        justify-self: end;
        padding: 4px 7px;
    }
    .mp3-player-card .mp3-player-audio {
        gap: 11px;
        margin: 0 10px 7px;
        padding: 11px;
    }
    .mp3-player-card .mp3-player-controls {
        flex-wrap: nowrap;
        gap: 6px;
        padding: 0 10px 10px;
    }
    .mp3-player-card .mp3-player-controls > span[data-mp3-position] {
        flex: 1 1 auto;
        min-width: 0;
        font-size: 10px;
    }
    .mp3-player-card .mp3-player-volume {
        grid-column: auto;
        margin-left: auto;
    }
    .mp3-player-card .mp3-player-rate > span {
        display: none;
    }
    .mp3-player-card .mp3-player-rate select {
        min-width: 52px;
        padding-right: 22px;
    }
    .mp3-player-card .mp3-player-playlist {
        max-height: none;
        padding: 6px;
    }
    .mp3-player-card .mp3-player-track-button {
        grid-template-columns: 28px minmax(0, 1fr) 56px;
        gap: 8px;
        min-height: 50px;
        padding: 7px;
    }
    .mp3-player-card .mp3-player-track-index {
        width: 26px;
        height: 26px;
    }
    .mp3-player-card .mp3-player-track-bar {
        width: 52px;
    }
}
@media (prefers-reduced-motion: reduce) {
    .mp3-player-card,
    .mp3-player-card *,
    .mp3-player-card *::before,
    .mp3-player-card *::after {
        scroll-behavior: auto;
        animation-duration: .01ms;
        animation-iteration-count: 1;
        transition-duration: .01ms;
    }
}
CSS . '.mp3-player-forum-option{grid-template-columns:38px minmax(0,1fr)}.mp3-player-forum-option input[type=checkbox]{width:38px;height:22px;margin:0}';
}

function mp3_player_js_custom(): string
{
    return mp3_player_js() . <<<'JS'
(function(){
function format(value){value=Math.max(0,Math.floor(value||0));return String(Math.floor(value/60)).padStart(2,'0')+':'+String(value%60).padStart(2,'0')}
function mp3PlayerControlsSetup(card){if(card.dataset.mp3ControlsReady==='1')return;card.dataset.mp3ControlsReady='1';var audio=card.querySelector('[data-mp3-audio]'),toggle=card.querySelector('[data-mp3-toggle]'),icon=card.querySelector('[data-mp3-play-icon]'),seek=card.querySelector('[data-mp3-seek]'),elapsed=card.querySelector('[data-mp3-elapsed]'),duration=card.querySelector('[data-mp3-duration]'),volume=card.querySelector('[data-mp3-volume]'),volumeControl=card.querySelector('.mp3-player-volume'),volumeToggle=card.querySelector('[data-mp3-volume-toggle]'),volumePanel=card.querySelector('[data-mp3-volume-panel]');if(!audio||!toggle||!seek)return;function mp3PlayerControlsUpdate(){var total=audio.duration||0,current=audio.currentTime||0,percent=total?Math.min(100,current*100/total):0;seek.disabled=!total;seek.value=total?String(Math.round(Math.min(total,current)*1000/total)):'0';seek.style.setProperty('--mp3-progress',percent+'%');card.classList.toggle('is-playing',!audio.paused);if(elapsed)elapsed.textContent=format(current);if(duration)duration.textContent=total?format(total):'--:--';if(icon)icon.innerHTML=audio.paused?'<path d="M8 5.5v13l10-6.5L8 5.5z"/>':'<path d="M7 5h3v14H7V5zm7 0h3v14h-3V5z"/>';toggle.setAttribute('aria-label',audio.paused?'播放':'暂停')}toggle.addEventListener('click',function(){if(audio.paused){var result=audio.play();if(result&&result.catch)result.catch(function(){})}else audio.pause()});seek.addEventListener('input',function(){if(audio.duration)audio.currentTime=Number(seek.value||0)*audio.duration/1000});if(volume){audio.volume=Number(volume.value||1);volume.addEventListener('input',function(){audio.volume=Number(volume.value||1)})}if(volumeToggle&&volumePanel&&volumeControl){volumeToggle.addEventListener('click',function(event){event.stopPropagation();volumePanel.hidden=!volumePanel.hidden;volumeToggle.setAttribute('aria-expanded',volumePanel.hidden?'false':'true')});document.addEventListener('click',function(event){if(!volumeControl.contains(event.target)){volumePanel.hidden=true;volumeToggle.setAttribute('aria-expanded','false')}})}['loadedmetadata','timeupdate','play','pause','ended','emptied'].forEach(function(name){audio.addEventListener(name,mp3PlayerControlsUpdate)});mp3PlayerControlsUpdate()}
function mp3PlayerControlsInit(){document.querySelectorAll('[data-mp3-player]').forEach(mp3PlayerControlsSetup)}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mp3PlayerControlsInit);else mp3PlayerControlsInit();
})();
JS;
}

return [
    'id' => 'mp3_player',
    'name' => 'MP3 附件播放器',
    'version' => '1.0.26',
    'description' => '在主题中直接播放 MP3 附件，支持播放列表、倍速播放和断点续听。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'mp3_player_css_refined', 'js' => 'mp3_player_js_custom'],
    'hooks' => [
        'topic.after_render' => 'mp3_player_render_topic',
        'topic.before_delete' => 'mp3_player_before_delete',
        'sidebar.feature_links' => 'mp3_player_feature_links',
    ],
    'routes' => [
        'mp3_player_stream' => 'mp3_player_stream_page',
        'mp3_player_history_save' => 'mp3_player_history_save_page',
        'mp3_player_history' => 'mp3_player_history_page',
        'mp3_player_history_clear' => 'mp3_player_history_clear_page',
    ],
    'admin_tabs' => ['mp3_player' => 'mp3_player_admin_page'],
    'install' => 'mp3_player_install',
    'uninstall' => 'mp3_player_uninstall',
];