<?php
if (!defined('APP_ROOT')) exit;

const AVATAR_LIBRARY_VERSION = '1.5.11';
const AVATAR_LIBRARY_MAX_ZIP_BYTES = 52428800;
const AVATAR_LIBRARY_MAX_FILES = 500;
const AVATAR_LIBRARY_MAX_SVG_BYTES = 2097152;
const AVATAR_LIBRARY_MAX_IMAGE_BYTES = 10485760;
const AVATAR_LIBRARY_MAX_IMAGE_DIMENSION = 8192;
const AVATAR_LIBRARY_MAX_TOTAL_BYTES = 52428800;
const AVATAR_LIBRARY_REMOTE_SEEDS = 48;
const AVATAR_LIBRARY_UPLOAD_SIZE = 200;
const AVATAR_LIBRARY_UPLOAD_MAX_BYTES = 1048576;
const AVATAR_LIBRARY_UPLOAD_RATE_WINDOW = 600;
const AVATAR_LIBRARY_UPLOAD_USER_RATE_LIMIT = 5;
const AVATAR_LIBRARY_UPLOAD_IP_RATE_LIMIT = 20;
const AVATAR_LIBRARY_UPLOAD_CHANGE_INTERVAL = 86400;

class AvatarLibraryActionException extends RuntimeException {}

function avatar_library_config(): array
{
    $raw = (string)setting('avatar_library_default_style', 'remote:dylan');
    if (!str_contains($raw, ':')) $raw = 'remote:' . $raw;
    [$source, $group] = array_pad(explode(':', $raw, 2), 2, '');
    if ($source === 'remote') {
        $group = avatar_style($group);
        return ['default_source' => 'remote', 'default_group' => $group, 'default_key' => 'remote:' . $group];
    }
    if ($source === 'local') {
        $group = avatar_library_slug($group);
        $pack = $group !== '' ? avatar_library_pack_by_key($group) : null;
        if ($pack && (int)$pack['enabled'] === 1) {
            return ['default_source' => 'local', 'default_group' => $group, 'default_key' => 'local:' . $group];
        }
    }
    return ['default_source' => 'remote', 'default_group' => 'dylan', 'default_key' => 'remote:dylan'];
}

function avatar_library_upload_root(): string
{
    return UPLOAD_DIR . '/avatar_library';
}

function avatar_library_public_root(): string
{
    return 'app/upload/avatar_library';
}

function avatar_library_logo_candidates(): array
{
    return [
        'svg' => UPLOAD_DIR . '/avatar_library/avatar_library_logo.svg',
        'png' => UPLOAD_DIR . '/avatar_library/avatar_library_logo.png',
    ];
}

function avatar_library_logo_file(string $type = 'svg'): string
{
    $files = avatar_library_logo_candidates();
    return $files[$type] ?? $files['svg'];
}

function avatar_library_logo_current(): ?array
{
    foreach (avatar_library_logo_candidates() as $type => $file) {
        if (!is_file($file)) continue;
        return [
            'type' => $type,
            'mime_type' => $type === 'png' ? 'image/png' : 'image/svg+xml',
            'file' => $file,
        ];
    }
    return null;
}

function avatar_library_logo_version(): ?string
{
    $logo = avatar_library_logo_current();
    if (!$logo) return null;

    // 不能再使用 filemtime + filesize：
    // 两张同大小图片如果在同一秒内替换，缓存参数会完全相同，
    // Chrome/Edge 的 favicon 可能继续显示上一张甚至 index.svg。
    // 使用文件内容 SHA-256，图片内容一变，URL 一定变化。
    $hash = @hash_file('sha256', $logo['file']);
    return is_string($hash) && $hash !== '' ? $hash : null;
}

function avatar_library_logo_url(?string $version = null): string
{
    $logo = avatar_library_logo_current();
    if (!$logo) return '';
    $version ??= avatar_library_logo_version() ?? '0';
    $relative = 'app/upload/avatar_library/avatar_library_logo.' . $logo['type'];
    return asset_url($relative) . '?v=' . rawurlencode($version);
}


function avatar_library_page_head($html, array $ctx): string
{
    $html = (string)$html;
    $version = avatar_library_logo_version();
    if ($version === null) return $html;

    $logo = avatar_library_logo_current();
    $url = avatar_library_logo_url($version);
    $mime = (string)($logo['mime_type'] ?? 'image/png');

    /*
     * 这里不能只依赖“删除核心 link”：
     * 你的截图已经证明核心 index.svg 仍会被 FaviconLoader 请求。
     * 因此 1.5.9 同时做三层覆盖：
     *
     * 1. 服务端删除所有明显指向 index.svg / icon 的 favicon link；
     * 2. 立即把现有 favicon link 改成插件 Logo；
     * 3. 用 MutationObserver 监视 document.head，核心如果随后再次插入
     *    index.svg，就立刻替换掉。这样不会再被核心的 index.svg 抢回去。
     */
    $html = preg_replace(
        '/<link\b[^>]*\b(?:href|src)\s*=\s*["\'][^"\']*(?:index\.svg|favicon\.svg)[^"\']*["\'][^>]*>/i',
        '',
        $html
    ) ?? $html;

    $html = preg_replace(
        '/<link\b(?=[^>]*\brel\s*=\s*["\'][^"\']*\b(?:icon|shortcut\s+icon|apple-touch-icon)\b[^"\']*["\'])[^>]*>/i',
        '',
        $html
    ) ?? $html;

    $jsUrl = json_encode($url, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $jsMime = json_encode($mime, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

    $script = '<script data-avatar-library-favicon>'.
        '(function(){'.
        'var u='.$jsUrl.',m='.$jsMime.';'.
        'function fix(){'.
            'if(!document.head)return;'.
            'document.querySelectorAll("link[rel]").forEach(function(x){'.
                'var r=(x.getAttribute("rel")||"").toLowerCase();'.
                'if(/(?:^|\\s)(?:icon|shortcut\\s+icon|apple-touch-icon)(?:\\s|$)/.test(r)){'.
                    'x.setAttribute("href",u);'.
                    'if(m)x.setAttribute("type",m);'.
                '}'.
            '});'.
            'var icons=document.querySelectorAll("link[rel~=\\"icon\\"],link[rel=\\"shortcut icon\\"],link[rel=\\"apple-touch-icon\\"]");'.
            'if(!icons.length){'.
                'var x=document.createElement("link");x.rel="icon";x.type=m;x.href=u;document.head.appendChild(x);'.
            '}'.
        '}'.
        'fix();'.
        'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",fix,{once:true});}'.
        'else{setTimeout(fix,0);}'.
        'new MutationObserver(function(){fix();}).observe(document.documentElement||document,{subtree:true,childList:true});'.
        '})();'.
        '</script>';

    return $html
        .'<link rel="icon" type="'.h($mime).'" href="'.h($url).'">'
        .'<link rel="shortcut icon" type="'.h($mime).'" href="'.h($url).'">'
        .'<link rel="apple-touch-icon" type="'.h($mime).'" href="'.h($url).'">'
        .'<style data-avatar-library-logo-style>.brand:before{background-image:url("'.h($url).'")}</style>'
        .$script;
}
function avatar_library_schema(): void
{
    $t = app_db_types();
    app_db_create_table('plugin_avatar_library_packs',
        "id {$t['id']},group_key {$t['key']} NOT NULL UNIQUE,name {$t['string']} NOT NULL,sort {$t['uint']} NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,created_at {$t['uint']} NOT NULL DEFAULT 0"
    );
    app_db_create_table('plugin_avatar_library_items',
        "id {$t['id']},pack_id {$t['uint']} NOT NULL,seed {$t['uint']} NOT NULL,filename {$t['string']} NOT NULL,relative_path {$t['string']} NOT NULL,mime_type {$t['key']} NOT NULL DEFAULT 'image/svg+xml',width {$t['uint']} NOT NULL DEFAULT 0,height {$t['uint']} NOT NULL DEFAULT 0,file_size {$t['uint']} NOT NULL DEFAULT 0,sort_order {$t['uint']} NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,created_at {$t['uint']} NOT NULL DEFAULT 0,UNIQUE(pack_id,seed)"
    );
    app_db_ensure_columns('plugin_avatar_library_items', [
        'mime_type' => "{$t['key']} NOT NULL DEFAULT 'image/svg+xml'",
        'width' => "{$t['uint']} NOT NULL DEFAULT 0",
        'height' => "{$t['uint']} NOT NULL DEFAULT 0",
        'file_size' => "{$t['uint']} NOT NULL DEFAULT 0",
        'sort_order' => "{$t['uint']} NOT NULL DEFAULT 0",
        'enabled' => 'INTEGER NOT NULL DEFAULT 1',
        'created_at' => "{$t['uint']} NOT NULL DEFAULT 0",
    ]);
    app_db_create_table('plugin_avatar_library_users',
        "user_id {$t['uint']} NOT NULL PRIMARY KEY,source {$t['key']} NOT NULL,group_key {$t['key']} NOT NULL,seed {$t['uint']} NOT NULL DEFAULT 1,updated_at {$t['uint']} NOT NULL DEFAULT 0"
    );
    app_db_create_table('plugin_avatar_library_upload_changes', "user_id {$t['uint']} NOT NULL PRIMARY KEY,last_changed_at {$t['uint']} NOT NULL DEFAULT 0");
    app_db_create_table('plugin_avatar_library_upload_rates', "rate_key {$t['key']} NOT NULL PRIMARY KEY,hit_count {$t['uint']} NOT NULL DEFAULT 0,window_started_at {$t['uint']} NOT NULL DEFAULT 0,updated_at {$t['uint']} NOT NULL DEFAULT 0");
    app_db_create_index('plugin_avatar_library_items_pack', 'plugin_avatar_library_items(pack_id)');
    app_db_create_index('plugin_avatar_library_users_group', 'plugin_avatar_library_users(group_key)');
}

function avatar_library_install(array $plugin): void
{
    avatar_library_schema();
    if (setting('avatar_library_default_style', '') === '') {
        save_settings_values(['avatar_library_default_style' => 'remote:dylan', 'avatar_library_points_cost' => '10', 'avatar_library_change_interval' => '86400']);
    }
}

function avatar_library_uninstall(array $plugin): void
{
    app_db_drop_index('plugin_avatar_library_items_pack', 'plugin_avatar_library_items');
    app_db_drop_index('plugin_avatar_library_users_group', 'plugin_avatar_library_users');
    app_db_drop_table('plugin_avatar_library_upload_rates');
    app_db_drop_table('plugin_avatar_library_upload_changes');
    app_db_drop_table('plugin_avatar_library_users');
    app_db_drop_table('plugin_avatar_library_items');
    app_db_drop_table('plugin_avatar_library_packs');
    save_settings_values(['avatar_library_default_style' => '', 'avatar_library_points_cost' => '', 'avatar_library_change_interval' => '']);
    avatar_library_delete_tree(avatar_library_upload_root());
    unset($GLOBALS['__avatar_library_user_map'], $GLOBALS['__avatar_library_item_map'], $GLOBALS['__avatar_library_pack_map'], $GLOBALS['__avatar_library_placeholder_token'], $GLOBALS['__avatar_library_placeholder_ids'], $GLOBALS['__avatar_library_fallbacks'], $GLOBALS['__avatar_library_default_cache']);
}

function avatar_library_boot($value = null, array $ctx = []): void
{
    $GLOBALS['__avatar_library_placeholder_token'] ??= bin2hex(random_bytes(8));
    $GLOBALS['__avatar_library_placeholder_ids'] ??= [];
    $GLOBALS['__avatar_library_fallbacks'] ??= [];
    $GLOBALS['__avatar_library_user_map'] ??= null;

    /*
     * 1.3.0: 自动修复“plugin.php 已更新，但 app_plugins.manifest_json 仍是旧版”
     * 的情况。v9.1 的 hook_registry() 使用数据库里的运行时 manifest；仅替换
     * plugin.php 并不会让新 hook 立即进入 registry。
     *
     * app.boot 本身在旧 manifest 中已经存在，所以可以利用它完成一次自修复。
     * 只有 code_hash / version 不一致时才同步，正常请求不会反复执行完整同步。
     */
    if (!empty($GLOBALS['__avatar_library_manifest_repaired'])) return;
    $GLOBALS['__avatar_library_manifest_repaired'] = true;

    try {
        $row = one('SELECT version,code_hash,enabled FROM app_plugins WHERE id=?', ['avatar_library']) ?: [];
        $file = __FILE__;
        $hash = is_file($file) ? (hash_file('sha256', $file) ?: '') : '';
        $stale = (int)($row['enabled'] ?? 0) === 1
            && (string)($row['version'] ?? '') !== AVATAR_LIBRARY_VERSION
            || ((string)($row['code_hash'] ?? '') !== '' && (string)($row['code_hash'] ?? '') !== $hash);

        if ($stale && class_exists('Plugin') && method_exists('Plugin', 'plugin_registry_sync')) {
            Plugin::plugin_registry_sync();
            unset($GLOBALS['__hook_registry']);
        }
    } catch (Throwable $e) {
        // 自修复失败不能阻断正常页面；debug 模式下由核心日志记录。
        debug_log_write('头像库运行时 manifest 同步失败', $e);
    }

    /*
     * avatar_library 是头像最终解析器。若服务器同时启用了旧头像插件，
     * 它们也可能注册 avatar.url/avatar.picker。把本插件的条目放到最后，
     * 确保核心 hook 的“后一个非 null 返回值覆盖前值”规则不会把本插件结果
     * 再改回核心默认头像。
     */
    $registry = $GLOBALS['__hook_registry'] ?? hook_registry();
    foreach (['avatar.url', 'avatar.picker'] as $hook_name) {
        if (empty($registry[$hook_name]) || !is_array($registry[$hook_name])) continue;
        $mine = [];
        $others = [];
        foreach ($registry[$hook_name] as $entry) {
            if ((string)($entry['plugin']['id'] ?? '') === 'avatar_library') $mine[] = $entry;
            else $others[] = $entry;
        }
        if ($mine) $registry[$hook_name] = array_merge($others, $mine);
    }
    $GLOBALS['__hook_registry'] = $registry;
}

function avatar_library_delete_tree(string $dir): void
{
    if (!is_dir($dir)) return;
    $items = scandir($dir) ?: [];
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . '/' . $item;
        if (is_dir($path) && !is_link($path)) avatar_library_delete_tree($path);
        else @unlink($path);
    }
    @rmdir($dir);
}

function avatar_library_slug(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9_-]+/', '-', $value) ?? '';
    $value = trim($value, '-_');
    return cut($value, 80);
}

function avatar_library_label(string $key): string
{
    return ucwords(str_replace(['-', '_'], ' ', $key));
}

function avatar_library_packs(bool $enabled_only = true): array
{
    $sql = 'SELECT id,group_key,name,sort,enabled,created_at FROM plugin_avatar_library_packs';
    if ($enabled_only) $sql .= ' WHERE enabled=1';
    $sql .= ' ORDER BY sort ASC,id ASC';
    return q($sql)->fetchAll();
}

function avatar_library_pack_by_key(string $key): ?array
{
    return one('SELECT id,group_key,name,sort,enabled,created_at FROM plugin_avatar_library_packs WHERE group_key=?', [$key]) ?: null;
}

function avatar_library_items(int $pack_id): array
{
    if ($pack_id < 1) return [];
    return q('SELECT id,pack_id,seed,filename,relative_path,mime_type,width,height,file_size,sort_order,enabled,created_at FROM plugin_avatar_library_items WHERE pack_id=? ORDER BY seed ASC', [$pack_id])->fetchAll();
}

function avatar_library_user_selection(int $uid): ?array
{
    if ($uid < 1) return null;
    return one('SELECT user_id,source,group_key,seed,updated_at FROM plugin_avatar_library_users WHERE user_id=?', [$uid]) ?: null;
}

function avatar_library_user_map(array $uids): array
{
    $uids = array_values(array_unique(array_filter(array_map('intval', $uids), static fn(int $id): bool => $id > 0)));
    if (!$uids) return [];
    $map = [];
    foreach (array_chunk($uids, 500) as $chunk) {
        $rows = q('SELECT user_id,source,group_key,seed,updated_at FROM plugin_avatar_library_users WHERE user_id IN (' . sql_marks(count($chunk)) . ')', $chunk)->fetchAll();
        foreach ($rows as $row) $map[(int)$row['user_id']] = $row;
    }
    return $map;
}

function avatar_library_all_pack_map(): array
{
    if (is_array($GLOBALS['__avatar_library_pack_map'] ?? null)) return $GLOBALS['__avatar_library_pack_map'];
    $map = [];
    $rows = q('SELECT id,group_key,name,sort,enabled,created_at FROM plugin_avatar_library_packs')->fetchAll();
    foreach ($rows as $row) $map[(string)$row['group_key']] = $row;
    return $GLOBALS['__avatar_library_pack_map'] = $map;
}

function avatar_library_all_item_map(): array
{
    if (is_array($GLOBALS['__avatar_library_item_map'] ?? null)) return $GLOBALS['__avatar_library_item_map'];
    $map = [];
    $rows = q('SELECT id,pack_id,seed,filename,relative_path,mime_type,width,height,file_size,sort_order,enabled,created_at FROM plugin_avatar_library_items WHERE enabled=1')->fetchAll();
    foreach ($rows as $row) $map[(int)$row['pack_id']][(int)$row['seed']] = $row;
    return $GLOBALS['__avatar_library_item_map'] = $map;
}

function avatar_library_core_fallback_style(array $user = []): string
{
    $style = avatar_style((string)($user['avatar_style'] ?? ''));
    if ($style !== '') return $style;
    $config = avatar_library_config();
    if (($config['default_source'] ?? '') === 'remote') {
        $style = avatar_style((string)($config['default_group'] ?? ''));
        if ($style !== '') return $style;
    }
    return 'dylan';
}

function avatar_library_item_by_pack_seed(int $pack_id, int $seed): ?array
{
    if ($pack_id < 1 || $seed < 1) return null;
    return one('SELECT id,pack_id,seed,filename,relative_path,mime_type,width,height,file_size,sort_order,enabled,created_at FROM plugin_avatar_library_items WHERE pack_id=? AND seed=?', [$pack_id, $seed]) ?: null;
}

function avatar_library_item_url(array $item, string $version = ''): string
{
    $relative = ltrim(str_replace('\\', '/', (string)($item['relative_path'] ?? '')), '/');
    if ($relative === '') return '';
    $parts = array_map('rawurlencode', explode('/', $relative));
    $url = asset_url(avatar_library_public_root() . '/' . implode('/', $parts));
    return $version !== '' ? $url . '?v=' . rawurlencode($version) : $url;
}

function avatar_library_validate_raster_file(string $path): array
{
    if (!is_file($path)) throw new AvatarLibraryActionException('图片文件不存在');
    $size = (int)@filesize($path);
    if ($size < 1 || $size > AVATAR_LIBRARY_MAX_IMAGE_BYTES) throw new AvatarLibraryActionException('图片文件过大');
    $info = @getimagesize($path);
    if (!is_array($info)) throw new AvatarLibraryActionException('图片无法解析');
    $width = (int)($info[0] ?? 0); $height = (int)($info[1] ?? 0);
    $mime = strtolower((string)($info['mime'] ?? ''));
    if (!in_array($mime, ['image/jpeg','image/png','image/webp'], true)) throw new AvatarLibraryActionException('仅支持 JPG、PNG、WebP 图片');
    if ($width < 1 || $height < 1 || $width > AVATAR_LIBRARY_MAX_IMAGE_DIMENSION || $height > AVATAR_LIBRARY_MAX_IMAGE_DIMENSION) throw new AvatarLibraryActionException('图片尺寸超出限制');
    return ['mime_type'=>$mime,'width'=>$width,'height'=>$height,'file_size'=>$size];
}

function avatar_library_extension_for_mime(string $mime): string
{
    return match (strtolower($mime)) {
        'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/svg+xml' => 'svg', default => 'bin'
    };
}

function avatar_library_resolve_default(): array
{
    if (is_array($GLOBALS['__avatar_library_default_cache'] ?? null)) return $GLOBALS['__avatar_library_default_cache'];
    $config = avatar_library_config();
    if (($config['default_source'] ?? '') === 'local') {
        $group = avatar_library_slug((string)($config['default_group'] ?? ''));
        $pack = $group !== '' ? avatar_library_pack_by_key($group) : null;
        if ($pack && (int)$pack['enabled'] === 1) {
            $item = one('SELECT seed,relative_path,mime_type,width,height,file_size FROM plugin_avatar_library_items WHERE pack_id=? AND enabled=1 ORDER BY seed ASC LIMIT 1', [(int)$pack['id']]);
            if ($item) return $GLOBALS['__avatar_library_default_cache'] = ['source'=>'local','group_key'=>$group,'seed'=>(int)$item['seed'],'url'=>avatar_library_item_url($item, (string)$item['file_size'])];
        }
    } else {
        $style = avatar_style((string)($config['default_group'] ?? '')) ?: 'dylan';
        return $GLOBALS['__avatar_library_default_cache'] = ['source'=>'remote','group_key'=>$style,'seed'=>1,'url'=>avatar_library_remote_url($style,1)];
    }
    return $GLOBALS['__avatar_library_default_cache'] = ['source'=>'remote','group_key'=>'dylan','seed'=>1,'url'=>avatar_library_remote_url('dylan',1)];
}

function avatar_library_default_label(): string
{
    $config = avatar_library_config();
    if (($config['default_source'] ?? '') === 'local') {
        $pack = avatar_library_pack_by_key((string)($config['default_group'] ?? ''));
        return '默认 ' . ($pack ? (string)$pack['name'] : '头像');
    }
    $style = avatar_style((string)($config['default_group'] ?? '')) ?: 'dylan';
    $styles = avatar_styles();
    return '默认 ' . (string)($styles[$style] ?? $style);
}

function avatar_library_local_url(string $group_key, int $seed, string $version = ''): string
{
    $group_key = avatar_library_slug($group_key);
    $seed = max(1, min(100000, $seed));
    $pack = avatar_library_pack_by_key($group_key);
    if ($pack) {
        $item = avatar_library_item_by_pack_seed((int)$pack['id'], $seed);
        if ($item) return avatar_library_item_url($item, $version !== '' ? $version : (string)($item['file_size'] ?? ''));
    }
    return '';
}

function avatar_library_remote_url(string $style, int $seed): string
{
    $style = avatar_style($style) ?: 'dylan';
    $seed = max(1, min(AVATAR_LIBRARY_REMOTE_SEEDS, $seed));
    return avatar_remote_url($style, (string)$seed);
}

function avatar_library_placeholder(int $uid, string $fallback): string
{
    $token = (string)($GLOBALS['__avatar_library_placeholder_token'] ??= bin2hex(random_bytes(8)));
    $GLOBALS['__avatar_library_placeholder_ids'][$uid] = true;
    $GLOBALS['__avatar_library_fallbacks'][$uid] = $fallback;
    return '<!--avatar_library-' . $token . '-' . $uid . '-->';
}

function avatar_library_all_user_map(): array
{
    if (is_array($GLOBALS['__avatar_library_user_map'] ?? null)) return $GLOBALS['__avatar_library_user_map'];
    $map = [];
    $rows = q('SELECT user_id,source,group_key,seed,updated_at FROM plugin_avatar_library_users')->fetchAll();
    foreach ($rows as $row) $map[(int)$row['user_id']] = $row;
    return $GLOBALS['__avatar_library_user_map'] = $map;
}

function avatar_library_picker($picker, array $ctx): array
{
    $picker = is_array($picker) ? $picker : [];
    $user = is_array($ctx['user'] ?? null) ? $ctx['user'] : [];
    $uid = (int)($user['id'] ?? 0);

    /*
     * 核心 avatar_picker_html() 会把 avatar_style/avatar_seed 作为表单默认值。
     * 本地头像没有对应的核心 style，因此这里必须给核心字段一个“有效的远程
     * fallback”。否则用户选择本地头像后再次保存资料时，核心会把虚拟/空值写回
     * app_users，导致本地选择看起来像被默认远程头像“挤掉”。
     *
     * 注意：这只是表单字段的 fallback，不改变 avatar.url 的最终渲染优先级。
     * 真正显示头像时仍由 avatar_library_avatar_url() 决定：
     *   上传 JPG > 本地 SVG > 远程 DiceBear。
     */
    if ($uid < 1) return $picker;

    $selection = avatar_library_user_selection($uid);
    $upload_version = avatar_library_upload_version($uid);

    $fallback_style = avatar_style((string)($user['avatar_style'] ?? '')) ?: 'dylan';
    $fallback_seed = avatar_seed(
        $fallback_style,
        (string)($user['avatar_seed'] ?? ''),
        $uid
    );

    if ($selection && (string)($selection['source'] ?? '') === 'local') {
        $fallback_style = avatar_library_core_fallback_style($user);
        $fallback_seed = '1';
    } elseif ($selection && (string)($selection['source'] ?? '') === 'remote') {
        $fallback_style = avatar_style((string)($selection['group_key'] ?? '')) ?: $fallback_style;
        $fallback_seed = avatar_seed(
            $fallback_style,
            (string)($selection['seed'] ?? ''),
            $uid
        );
    } elseif ($upload_version !== null) {
        # 上传头像也必须保留一个有效的核心远程 fallback。
        $fallback_style = avatar_style((string)($user['avatar_style'] ?? '')) ?: 'dylan';
        $fallback_seed = avatar_seed(
            $fallback_style,
            (string)($user['avatar_seed'] ?? ''),
            $uid
        );
    }

    $picker['style'] = $fallback_style;
    $picker['seed'] = $fallback_seed;
    $picker['styles'] = avatar_styles();
    $picker['local_only'] = true;
    $picker['base_url'] = '';

    return $picker;
}

function avatar_library_avatar_url($url, array $ctx): string
{
    $uid = (int)($ctx['uid'] ?? 0);
    if ($uid < 1) return (string)$url;

    // avatar_upload 的关键做法是：所有 avatar_tag() 最终都会经过 avatar.url。
    // 本插件也在这里统一决定最终地址。为避免 N+1，不逐头像查库，而是在
    // 本次请求第一次进入这里时一次性读取全部已选择头像的映射。
    $version = avatar_library_upload_version($uid);
    if ($version !== null) return avatar_library_upload_url($uid, $version);

    $map = avatar_library_all_user_map();
    $selection = $map[$uid] ?? null;
    if (!is_array($selection)) return (string)$url;

    $source = strtolower(trim((string)($selection['source'] ?? '')));
    $group = (string)($selection['group_key'] ?? '');
    $seed = max(1, (int)($selection['seed'] ?? 1));

    // “default” 是特殊来源：不固化当前组，而是始终解析后台当前默认头像组。
    if ($source === 'default') {
        $resolved = avatar_library_resolve_default();
        return (string)($resolved['url'] ?? $url);
    }

    // 混合来源时，plugin row 是“头像来源”的唯一真相；app_users 中的
    // avatar_style/avatar_seed 只负责提供核心兼容的远程 fallback。
    if ($source === 'local') {
        $group = avatar_library_slug($group);
        if ($group === '') return (string)$url;

        $pack = avatar_library_all_pack_map()[$group] ?? null;
        $item_map = avatar_library_all_item_map();
        $item = $pack ? ($item_map[(int)$pack['id']][$seed] ?? null) : null;
        if (!$item) return (string)$url;
        $relative = ltrim(str_replace('\\', '/', (string)($item['relative_path'] ?? '')), '/');
        $file = avatar_library_upload_root() . '/' . $relative;
        if (!is_file($file)) return (string)$url;
        return avatar_library_item_url($item, (string)($selection['updated_at'] ?? $item['file_size'] ?? ''));
    }

    if ($source === 'remote') {
        $style = avatar_style($group);
        if ($style === '') return (string)$url;
        return avatar_library_remote_url($style, min(AVATAR_LIBRARY_REMOTE_SEEDS, $seed));
    }

    return (string)$url;
}

function avatar_library_page_before_render($html, array $ctx): string
{
    $html = (string)$html;
    $ids = array_keys((array)($GLOBALS['__avatar_library_placeholder_ids'] ?? []));
    if (!$ids) return $html;
    $map = avatar_library_user_map($ids);
    $fallbacks = (array)($GLOBALS['__avatar_library_fallbacks'] ?? []);
    $local_groups = [];
    foreach ($map as $selection) {
        if ((string)($selection['source'] ?? '') === 'local') {
            $group = avatar_library_slug((string)($selection['group_key'] ?? ''));
            if ($group !== '') $local_groups[$group] = true;
        }
    }
    $packs = [];
    if ($local_groups) {
        $keys = array_keys($local_groups);
        foreach (array_chunk($keys, 200) as $chunk) {
            $rows = q('SELECT id,group_key,name,enabled FROM plugin_avatar_library_packs WHERE group_key IN (' . sql_marks(count($chunk)) . ')', $chunk)->fetchAll();
            foreach ($rows as $row) $packs[(string)$row['group_key']] = $row;
        }
    }
    $items = [];
    $pack_ids = array_values(array_unique(array_map(static fn(array $row): int => (int)$row['id'], $packs)));
    if ($pack_ids) {
        foreach (array_chunk($pack_ids, 200) as $chunk) {
            $rows = q('SELECT pack_id,seed,relative_path,mime_type,width,height,file_size FROM plugin_avatar_library_items WHERE enabled=1 AND pack_id IN (' . sql_marks(count($chunk)) . ')', $chunk)->fetchAll();
            foreach ($rows as $row) $items[(int)$row['pack_id']][(int)$row['seed']] = $row;
        }
    }
    $token = (string)($GLOBALS['__avatar_library_placeholder_token'] ?? '');
    if ($token === '') return preg_replace('/<!--avatar_library-[a-f0-9]+-(\d+)-->/', '', $html) ?? $html;
    $pattern = '/<!--avatar_library-' . preg_quote($token, '/') . '-(\d+)-->/';
    $result = preg_replace_callback($pattern, static function (array $match) use ($map, $packs, $items, $fallbacks): string {
        $uid = (int)$match[1];
        $fallback = (string)($fallbacks[$uid] ?? '');
        $selection = $map[$uid] ?? null;
        if (!$selection || (string)($selection['source'] ?? '') === 'default') return h((string)(avatar_library_resolve_default()['url'] ?? $fallback));
        $source = (string)($selection['source'] ?? '');
        $group = (string)($selection['group_key'] ?? '');
        $seed = max(1, (int)($selection['seed'] ?? 1));
        if ($source === 'remote') return h(avatar_library_remote_url($group, $seed));
        if ($source === 'local') {
            $pack = $packs[$group] ?? null;
            if (!$pack || (int)$pack['enabled'] !== 1) return h($fallback);
            $item = $items[(int)$pack['id']][$seed] ?? null;
            if (!$item) return h($fallback);
            return h(avatar_library_item_url($item, (string)($selection['updated_at'] ?? $item['file_size'] ?? '')));
        }
        return h($fallback);
    }, $html);
    $result = $result ?? $html;

    return $result;
}

function avatar_library_profile_current(array $user): array
{
    $uid = (int)($user['id'] ?? 0);
    $upload_version = avatar_library_upload_version($uid);
    if ($upload_version !== null) return ['source'=>'upload','group_key'=>'','seed'=>0,'url'=>avatar_library_upload_url($uid,$upload_version)];
    $selection = avatar_library_user_selection($uid);
    if (!$selection || (string)($selection['source'] ?? '') === 'default') { $resolved=avatar_library_resolve_default(); $resolved['source']='default'; return $resolved; }
    $source = (string)($selection['source'] ?? 'remote'); $group = (string)($selection['group_key'] ?? 'dylan'); $seed=max(1,(int)($selection['seed']??1));
    if ($source==='local') {
        $pack=avatar_library_pack_by_key($group);
        if ($pack && (int)$pack['enabled']===1) {
            $item=avatar_library_item_by_pack_seed((int)$pack['id'],$seed);
            if ($item && (int)$item['enabled']===1) return ['source'=>'local','group_key'=>$group,'seed'=>(int)$item['seed'],'url'=>avatar_library_item_url($item,(string)($selection['updated_at']??$item['file_size']??''))];
        }
    } elseif ($source==='remote') {
        $style=avatar_style($group); if ($style!=='') return ['source'=>'remote','group_key'=>$style,'seed'=>min(AVATAR_LIBRARY_REMOTE_SEEDS,$seed),'url'=>avatar_library_remote_url($style,$seed)];
    }
    return avatar_library_resolve_default();
}

function avatar_library_upload_relative_file(int $uid): string
{
    $hash = hash('sha256', 'avatar-library-upload:' . max(1, $uid));
    return 'avatar_library/' . upload_hash_dir($hash) . '/' . max(1, $uid) . '.jpg';
}

function avatar_library_upload_file(int $uid): string
{
    return UPLOAD_DIR . '/' . avatar_library_upload_relative_file($uid);
}

function avatar_library_upload_version(int $uid): ?int
{
    if ($uid < 1) return null;
    $file = avatar_library_upload_file($uid);
    if (!is_file($file)) return null;
    return ((int)@filemtime($file) * 1000000) + (int)@filesize($file);
}

function avatar_library_upload_url(int $uid, ?int $version = null): string
{
    $version ??= avatar_library_upload_version($uid) ?? 0;
    return asset_url('app/upload/' . avatar_library_upload_relative_file($uid)) . '?v=' . $version;
}

function avatar_library_points_cost(): int
{
    return max(0, min(100000, (int)setting('avatar_library_points_cost', '10')));
}

function avatar_library_upload_last_changed_at(int $uid): int
{
    return (int)(val('SELECT last_changed_at FROM plugin_avatar_library_upload_changes WHERE user_id=?', [$uid]) ?: 0);
}

function avatar_library_change_interval(): int
{
    return max(0, min(31536000, (int)setting('avatar_library_change_interval', (string)AVATAR_LIBRARY_UPLOAD_CHANGE_INTERVAL)));
}

function avatar_library_upload_change_error(int $last_changed_at, int $points): string
{
    $interval = avatar_library_change_interval();
    if ($interval < 1) {
        $cost = avatar_library_points_cost();
        if ($points < $cost) return '积分不足，更新头像需要 ' . $cost . ' 积分';
        return '';
    }
    $available_at = $last_changed_at + $interval;
    if ($last_changed_at > 0 && $available_at > time()) {
        $hours = max(1, (int)ceil(avatar_library_change_interval() / 3600));
        return '头像每 ' . $hours . ' 小时只能更新一次，下次可更新时间：' . date('Y-m-d H:i', $available_at);
    }
    $cost = avatar_library_points_cost();
    if ($points < $cost) return '积分不足，更新头像需要 ' . $cost . ' 积分';
    return '';
}

function avatar_library_upload_assert_can_change(int $uid): void
{
    $user = one('SELECT points FROM app_users WHERE id=?', [$uid]) ?: [];
    $error = avatar_library_upload_change_error(avatar_library_upload_last_changed_at($uid), (int)($user['points'] ?? 0));
    if ($error !== '') err($error);
}

function avatar_library_upload_rate_hit(string $key, int $limit, int $time): array
{
    $expired = $time - AVATAR_LIBRARY_UPLOAD_RATE_WINDOW;
    if (db_driver() === 'mysql') {
        q('INSERT INTO plugin_avatar_library_upload_rates(rate_key,hit_count,window_started_at,updated_at) VALUES(?,1,?,?) ON DUPLICATE KEY UPDATE hit_count=IF(window_started_at<?,1,hit_count+1),window_started_at=IF(window_started_at<?,VALUES(window_started_at),window_started_at),updated_at=VALUES(updated_at)', [$key, $time, $time, $expired, $expired]);
    } else {
        q('INSERT INTO plugin_avatar_library_upload_rates(rate_key,hit_count,window_started_at,updated_at) VALUES(?,1,?,?) ON CONFLICT(rate_key) DO UPDATE SET hit_count=CASE WHEN plugin_avatar_library_upload_rates.window_started_at<? THEN 1 ELSE plugin_avatar_library_upload_rates.hit_count+1 END,window_started_at=CASE WHEN plugin_avatar_library_upload_rates.window_started_at<? THEN excluded.window_started_at ELSE plugin_avatar_library_upload_rates.window_started_at END,updated_at=excluded.updated_at', [$key, $time, $time, $expired, $expired]);
    }
    $row = one('SELECT hit_count,window_started_at FROM plugin_avatar_library_upload_rates WHERE rate_key=?', [$key]) ?: [];
    return ['allowed' => (int)($row['hit_count'] ?? ($limit + 1)) <= $limit, 'retry_after' => max(1, (int)($row['window_started_at'] ?? $time) + AVATAR_LIBRARY_UPLOAD_RATE_WINDOW - $time)];
}

function avatar_library_upload_enforce_rate_limit(int $uid): void
{
    $time = time();
    $checks = [['user:' . $uid, AVATAR_LIBRARY_UPLOAD_USER_RATE_LIMIT], ['ip:' . hash('sha256', ip_addr()), AVATAR_LIBRARY_UPLOAD_IP_RATE_LIMIT]];
    $retry = 0;
    foreach ($checks as [$key, $limit]) {
        $result = avatar_library_upload_rate_hit($key, $limit, $time);
        if (!$result['allowed']) $retry = max($retry, (int)$result['retry_after']);
    }
    if ($retry < 1) return;
    header('Retry-After: ' . $retry);
    err('头像更新过于频繁，请稍后再试', 429);
}

function avatar_library_upload_commit_change(int $uid, string $reason, callable $apply): mixed
{
    $user = one('SELECT points FROM app_users WHERE id=?', [$uid]);
    if (!$user) throw new AvatarLibraryActionException('用户不存在');
    $error = avatar_library_upload_change_error(avatar_library_upload_last_changed_at($uid), (int)($user['points'] ?? 0));
    if ($error !== '') throw new AvatarLibraryActionException($error);

    // user_points_change() 自带事务，不能嵌套在 tx() 中。
    $result = $apply();
    $cost = avatar_library_points_cost();
    if ($cost > 0) {
        $actual = user_points_change($uid, -$cost, $reason);
        if ($actual !== -$cost) throw new AvatarLibraryActionException('积分扣除失败，请重试');
    }
    app_db_upsert('plugin_avatar_library_upload_changes', ['user_id' => $uid, 'last_changed_at' => time()], ['user_id']);
    unset($GLOBALS['__me_cache']);
    return $result;
}

function avatar_library_user_after_save($value, array $ctx): void
{
    $uid = (int)($ctx['id'] ?? 0);
    if ($uid < 1) return;

    // 新用户：沿用插件配置的默认头像来源。
    if (!empty($ctx['creating'])) {
        $config = $GLOBALS['__avatar_library_creating_default'] ?? avatar_library_config();
        unset($GLOBALS['__avatar_library_creating_default']);

        app_db_upsert('plugin_avatar_library_users', [
            'user_id' => $uid, 'source' => 'default', 'group_key' => '', 'seed' => 1, 'updated_at' => time(),
        ], ['user_id']);
        unset($GLOBALS['__avatar_library_user_map']);
        return;
    }

    // 现有用户：profile 表单本身就是头像来源的最终提交。
    // 不再依赖前端额外 AJAX；HAR 已证明实际请求只有 profile POST。
    $source = strtolower(trim((string)($_POST['avatar_library_form_source'] ?? '')));
    if (!in_array($source, ['local', 'remote', 'default'], true)) return;

    if ($source === 'default') {
        $old = avatar_library_user_selection($uid);
        if (is_array($old) && (string)($old['source'] ?? '') === 'default') return;
        $file = avatar_library_upload_file($uid);
        if (is_file($file)) @unlink($file);
        app_db_upsert('plugin_avatar_library_users', ['user_id'=>$uid,'source'=>'default','group_key'=>'','seed'=>1,'updated_at'=>time()], ['user_id']);
        unset($GLOBALS['__me_cache'], $GLOBALS['__avatar_library_user_map']);
        return;
    }

    $group = trim((string)($_POST['avatar_library_form_group'] ?? ''));
    $seed = (int)($_POST['avatar_library_form_seed'] ?? 0);

    if ($source === 'local') {
        $group = avatar_library_slug($group);
        if ($group === '' || $seed < 1) return;
        $pack = avatar_library_pack_by_key($group);
        if (!$pack || (int)$pack['enabled'] !== 1) return;
        $item = one('SELECT seed FROM plugin_avatar_library_items WHERE pack_id=? AND seed=?', [(int)$pack['id'], $seed]);
        if (!$item) return;
        $seed = (int)$item['seed'];
    } else {
        $group = avatar_style($group !== '' ? $group : (string)($_POST['avatar_style'] ?? ''));
        if ($group === '') return;
        $seed = (int)avatar_seed($group, (string)max(1, $seed), $uid);
    }

    $old = avatar_library_user_selection($uid);
    $same = is_array($old)
        && (string)($old['source'] ?? '') === $source
        && (string)($old['group_key'] ?? '') === $group
        && (int)($old['seed'] ?? 0) === $seed;
    if ($same) return;

    // 来源切换时，旧的自定义 JPG 不再继续抢占 avatar.url。
    $upload_file = avatar_library_upload_file($uid);
    if (is_file($upload_file)) @unlink($upload_file);

    app_db_upsert('plugin_avatar_library_users', [
        'user_id' => $uid, 'source' => $source,
        'group_key' => $group, 'seed' => $seed, 'updated_at' => time(),
    ], ['user_id']);

    unset($GLOBALS['__me_cache'], $GLOBALS['__avatar_library_user_map']);
}

function avatar_library_delete_user_selection($value, array $ctx): void
{
    if (($ctx['table'] ?? '') !== 'users') return;
    $row = is_array($ctx['row'] ?? null) ? $ctx['row'] : [];
    $uid = (int)($row['id'] ?? 0);
    if ($uid > 0) q('DELETE FROM plugin_avatar_library_users WHERE user_id=?', [$uid]);
}

function avatar_library_save_selection(int $uid, string $source, string $group_key, int $seed): void
{
    if ($uid < 1) throw new AvatarLibraryActionException('用户不存在');
    if (!in_array($source, ['remote', 'local', 'default'], true)) throw new AvatarLibraryActionException('头像来源无效');
    $upload_file = avatar_library_upload_file($uid);
    $source = trim($source);

    if ($source === 'default') {
        $file = avatar_library_upload_file($uid);
        if (is_file($file) && !@unlink($file)) throw new AvatarLibraryActionException('头像切换失败');
        app_db_upsert('plugin_avatar_library_users', ['user_id'=>$uid,'source'=>'default','group_key'=>'','seed'=>1,'updated_at'=>time()], ['user_id']);
        unset($GLOBALS['__me_cache'], $GLOBALS['__avatar_library_user_map']);
        return;
    }
    if ($source === 'remote') {
        $group_key = avatar_style($group_key);
        if ($group_key === '') throw new AvatarLibraryActionException('远程头像组不存在');
        $seed = (int)avatar_seed($group_key, (string)max(1, $seed), $uid);
        q('UPDATE app_users SET avatar_style=?,avatar_seed=? WHERE id=?', [$group_key, (string)$seed, $uid]);
    } else {
        $group_key = avatar_library_slug($group_key);
        $pack = avatar_library_pack_by_key($group_key);
        if (!$pack || (int)$pack['enabled'] !== 1) throw new AvatarLibraryActionException('本地头像组不存在或已停用');
        $item = one('SELECT seed FROM plugin_avatar_library_items WHERE pack_id=? AND seed=?', [(int)$pack['id'], $seed]);
        if (!$item) throw new AvatarLibraryActionException('头像不存在');
        $seed = (int)$item['seed'];
        // 本地头像不伪装成核心 avatar_style；核心字段只保存一个有效的远程 fallback。
        $fallback = avatar_library_core_fallback_style();
        q('UPDATE app_users SET avatar_style=?,avatar_seed=? WHERE id=?', [$fallback, '1', $uid]);
    }

    if (is_file($upload_file) && !@unlink($upload_file)) throw new AvatarLibraryActionException('头像切换失败');
    app_db_upsert('plugin_avatar_library_users', [
        'user_id' => $uid,
        'source' => $source,
        'group_key' => $group_key,
        'seed' => $seed,
        'updated_at' => time(),
    ], ['user_id']);
    unset($GLOBALS['__me_cache'], $GLOBALS['__avatar_library_user_map']);
}

function avatar_library_user_before_save($user, array $ctx): array
{
    if (!is_array($user)) return [];
    $uid = (int)($ctx['id'] ?? 0);
    if ($uid < 1 || !empty($ctx['creating'])) return $user;

    /*
     * 关键修复：
     *
     * save_user() 在调用 hook 之前已经执行：
     *   $avatar_style = avatar_style(post('avatar_style', 40));
     *
     * 因此本地头像的虚拟 select 值到达这里时已经被核心变成了空字符串。
     * 不能只依赖 $_POST['avatar_library_form_source'] 判断来源。
     *
     * plugin_avatar_library_users 才是本地/远程混合头像的真实来源。
     * 如果数据库当前仍是 local，而本次表单没有明确选择 remote，就必须把
     * app_users 的核心 fallback 保留下来，绝不能让核心的空默认值覆盖它。
     */

    $selection = avatar_library_user_selection($uid);
    $posted_source = strtolower(trim((string)($_POST['avatar_library_form_source'] ?? '')));

    if ($posted_source === 'default') {
        $user['avatar_style'] = avatar_library_core_fallback_style();
        $user['avatar_seed'] = '1';
        return $user;
    }

    // 明确选择本地，或当前已经是本地且本次没有明确选择远程：
    // 保留一个有效的核心远程 fallback。
    if ($posted_source === 'local' || (
        $posted_source !== 'remote'
        && is_array($selection)
        && (string)($selection['source'] ?? '') === 'local'
    )) {
        $old = one('SELECT avatar_style,avatar_seed FROM app_users WHERE id=?', [$uid]) ?: [];
        $style = avatar_style((string)($old['avatar_style'] ?? '')) ?: 'dylan';
        $seed = avatar_seed($style, (string)($old['avatar_seed'] ?? ''), $uid);

        $user['avatar_style'] = $style;
        $user['avatar_seed'] = (string)$seed;
        return $user;
    }

    // 没有头像字段：这是普通的资料保存，不允许动现有头像来源。
    if (!array_key_exists('avatar_style', $_POST) && !array_key_exists('avatar_seed', $_POST)) {
        return $user;
    }

    $raw_style = trim((string)($_POST['avatar_style'] ?? ''));
    $raw_seed = trim((string)($_POST['avatar_seed'] ?? ''));

    // 核心把本地虚拟 style 规范化为空值时，如果数据库仍是 local，
    // 上面的分支已经拦截；这里的空值只能视为“不要改变当前头像”。
    if ($raw_style === '' || avatar_style($raw_style) === '') return $user;

    $style = avatar_style($raw_style);
    $seed = (int)avatar_seed($style, $raw_seed, $uid);

    $old = one('SELECT avatar_style,avatar_seed FROM app_users WHERE id=?', [$uid]) ?: [];
    $old_style = avatar_style((string)($old['avatar_style'] ?? '')) ?: 'dylan';
    $old_seed = (int)avatar_seed($old_style, (string)($old['avatar_seed'] ?? ''), $uid);

    $user['avatar_style'] = $style;
    $user['avatar_seed'] = (string)$seed;

    // 只有真正选择了远程头像才清除插件来源。
    if ($style === $old_style && $seed === $old_seed && $posted_source !== 'remote') return $user;

    $file = avatar_library_upload_file($uid);
    if (is_file($file)) @unlink($file);
    q('DELETE FROM plugin_avatar_library_users WHERE user_id=?', [$uid]);
    unset($GLOBALS['__avatar_library_user_map']);
    return $user;
}

function avatar_library_route(array $plugin): void
{
    need_login();
    require_post();
    $uid = uid();
    $action = (string)($_POST['avatar_library_action'] ?? 'select');
    if ($action === 'select') {
        $source = (string)($_POST['avatar_library_source'] ?? '');
        $group = (string)($_POST['avatar_library_group'] ?? '');
        $seed = (int)($_POST['avatar_library_seed'] ?? 0);
        try {
            if (!in_array($source, ['remote', 'local', 'default'], true)) throw new AvatarLibraryActionException('头像来源无效');
            if ($source === 'default') { avatar_library_upload_enforce_rate_limit($uid); avatar_library_upload_assert_can_change($uid); avatar_library_save_selection($uid, 'default', '', 1); avatar_library_json(['ok'=>true,'message'=>'已恢复默认头像','redirect'=>route_url('profile')]); }
            $normalized = $source === 'remote' ? avatar_style($group) : avatar_library_slug($group);
            if ($normalized === '') throw new AvatarLibraryActionException('头像组无效');
            $current = avatar_library_profile_current(one('SELECT * FROM app_users WHERE id=?', [$uid]) ?: ['id' => $uid]);
            if ($current['source'] === $source && (string)$current['group_key'] === $normalized && (int)$current['seed'] === $seed) {
                avatar_library_json(['ok' => true, 'message' => '当前头像已经是这个头像', 'redirect' => route_url('profile')]);
            }
            avatar_library_upload_enforce_rate_limit($uid);
            avatar_library_upload_assert_can_change($uid);
            avatar_library_save_selection($uid, $source, $group, $seed);
        } catch (AvatarLibraryActionException $e) { err($e->getMessage()); }
        avatar_library_json(['ok' => true, 'message' => '头像已应用', 'redirect' => route_url('profile')]);
    }
    if (in_array($action, ['upload', 'delete_upload'], true)) {
        avatar_library_upload_enforce_rate_limit($uid);
        avatar_library_upload_assert_can_change($uid);
        $file = avatar_library_upload_file($uid);
        if ($action === 'delete_upload') {
            try {
                avatar_library_upload_commit_change($uid, '恢复预置头像', function () use ($file): void {
                    if (is_file($file) && !@unlink($file)) throw new AvatarLibraryActionException('头像删除失败');
                });
            } catch (AvatarLibraryActionException $e) { err($e->getMessage()); }
            avatar_library_json(['ok' => true, 'message' => '已恢复头像库头像', 'redirect' => route_url('profile')]);
        }
        $upload = (array)($_FILES['avatar'] ?? []);
        if ((int)($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) err('请选择头像图片');
        $tmp = (string)($upload['tmp_name'] ?? ''); $bytes = (int)($upload['size'] ?? 0);
        if ($tmp === '' || !is_uploaded_file($tmp) || $bytes < 1 || $bytes > AVATAR_LIBRARY_UPLOAD_MAX_BYTES) err('裁切后的头像不能超过 1MB');
        $info = @getimagesize($tmp);
        if (!is_array($info) || (int)($info[0] ?? 0) !== AVATAR_LIBRARY_UPLOAD_SIZE || (int)($info[1] ?? 0) !== AVATAR_LIBRARY_UPLOAD_SIZE || (string)($info['mime'] ?? '') !== 'image/jpeg') err('头像格式无效，请重新裁切');
        $dir = dirname($file);
        if (!is_dir($dir) && !mkdir($dir, 0755, true)) err('头像目录创建失败');
        require_writable_dir($dir, '头像目录不可写');
        $target = $file . '.tmp.' . bin2hex(random_bytes(4));
        if (!move_uploaded_file($tmp, $target)) err('头像保存失败');
        @chmod($target, 0644);
        try {
            $version = avatar_library_upload_commit_change($uid, '上传本地头像', function () use ($target, $file): int {
                if (!@rename($target, $file)) throw new AvatarLibraryActionException('头像保存失败');
                return avatar_library_upload_version(uid()) ?? time();
            });
        } catch (AvatarLibraryActionException $e) { @unlink($target); err($e->getMessage()); }
        avatar_library_json(['ok' => true, 'message' => '头像已更新，已扣除 ' . avatar_library_points_cost() . ' 积分', 'url' => avatar_library_upload_url($uid, (int)$version), 'redirect' => route_url('profile')]);
    }
    err('头像操作无效');
}

function avatar_library_json(array $data): never
{
    json_response($data);
}

function avatar_library_profile_html($html, array $ctx): string
{
    $user = is_array($ctx['user'] ?? null) ? $ctx['user'] : [];
    $uid = (int)($user['id'] ?? 0);
    if ($uid < 1 || $uid !== uid()) return (string)$html;

    $packs = avatar_library_packs(true);
    $groups = [];
    $pack_ids = [];
    foreach ($packs as $pack) {
        $id = (int)$pack['id'];
        if ($id > 0) $pack_ids[] = $id;
        $groups[(string)$pack['group_key']] = [
            'name' => (string)$pack['name'],
            'seeds' => [],
            'items' => [],
        ];
    }
    if ($pack_ids) {
        foreach (array_chunk($pack_ids, 200) as $chunk) {
            $rows = q('SELECT pack_id,seed,relative_path,mime_type,file_size FROM plugin_avatar_library_items WHERE enabled=1 AND pack_id IN (' . sql_marks(count($chunk)) . ') ORDER BY seed ASC', $chunk)->fetchAll();
            $pack_keys = [];
            foreach ($packs as $pack) $pack_keys[(int)$pack['id']] = (string)$pack['group_key'];
            foreach ($rows as $row) {
                $key = $pack_keys[(int)$row['pack_id']] ?? '';
                if ($key !== '') {
                    $seed = (int)$row['seed'];
                    $groups[$key]['seeds'][] = $seed;
                    $groups[$key]['items'][$seed] = [
                        'url' => avatar_library_item_url($row, (string)($row['file_size'] ?? '')),
                        'mime' => (string)($row['mime_type'] ?? ''),
                    ];
                }
            }
        }
    }
    foreach ($groups as $key => $group) if (!$group['seeds']) unset($groups[$key]);

    $current = avatar_library_profile_current($user);
    $route = route_url('avatar_library');
    $payload = htmlspecialchars((string)json_encode($groups, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $current_payload = htmlspecialchars((string)json_encode([
        'source' => (string)$current['source'],
        'group' => (string)$current['group_key'],
        'seed' => (int)$current['seed'],
        'url' => (string)$current['url'],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $upload_version = avatar_library_upload_version($uid);
    $restore = $upload_version !== null
        ? '<button type="button" class="btn alt" data-avatar-library-delete-upload>恢复头像库</button>'
        : '';
    $upload_text = $upload_version !== null ? '当前正在使用你上传的头像。' : '上传图片后可裁切为 200×200 JPG 并立即应用。';

    // 不再创建第二套头像选择器；这里只提供配置，让 JS 把本地头像组拼进核心 avatar-picker。
    $default_config = avatar_library_config();
    $default_label = avatar_library_default_label();

    $config = '<div class="avatar-library-config" data-avatar-library-config'
        . ' data-avatar-library-url="' . h($route) . '"'
        . ' data-avatar-library-groups="' . $payload . '"'
        . ' data-avatar-library-current="' . $current_payload . '"'
        . ' data-avatar-library-default-label="' . h($default_label) . '"'
        . ' data-avatar-library-default-url="' . h((string)avatar_library_resolve_default()['url']) . '"'
        . ' data-avatar-library-default-source="' . h((string)($default_config['default_source'] ?? 'remote')) . '"'
        . ' data-avatar-library-default-group="' . h((string)($default_config['default_group'] ?? 'dylan')) . '"'
        . ' data-avatar-library-local-root="' . h(asset_url(avatar_library_public_root())) . '"'
        . ' hidden></div>';

    // 上传面板由 JS 移入核心头像 picker 的 profile-disclosure-detail，
    // 这样只有点击“修改”展开头像编辑区后才显示，不再单独占用页面底部空间。
    $upload_panel = '<section class="avatar-library-upload-panel" data-avatar-library-upload-panel hidden>'
        . '<div class="avatar-library-upload-head"><div><strong>自定义头像</strong><small>' . h($upload_text) . '</small></div><div class="avatar-library-upload-actions">'
        . '<label class="avatar-library-upload-button">选择图片<input type="file" accept="image/jpeg,image/png,image/webp" data-avatar-library-upload-input hidden></label>'
        . $restore . '</div></div>'
        . '<div class="avatar-library-status" data-avatar-library-status></div>'
        . '<div class="modal-backdrop avatar-library-crop-modal" data-avatar-library-crop-modal hidden><div class="modal-panel avatar-library-crop-dialog"><div class="modal-head"><strong>调整头像</strong><button type="button" class="modal-close" data-avatar-library-crop-close aria-label="关闭">×</button></div><div class="modal-body"><canvas width="280" height="280" data-avatar-library-crop-canvas></canvas><label class="avatar-library-crop-zoom"><span>缩放</span><input type="range" min="100" max="300" value="100" data-avatar-library-crop-zoom></label><div class="confirm-actions"><button type="button" class="btn alt" data-avatar-library-crop-close>取消</button><button type="button" data-avatar-library-crop-save>上传并应用</button></div></div></div></div>'
        . '</section>';
    return (string)$html . $config . $upload_panel;
}

function avatar_library_pack_groups_from_zip(string $zip_path): array
{
    if(!class_exists('ZipArchive')) throw new AvatarLibraryActionException('服务器未启用 ZIP 扩展，无法上传头像包');
    $zip=new ZipArchive(); if($zip->open($zip_path)!==true) throw new AvatarLibraryActionException('头像包不是有效的 ZIP 文件'); $groups=[]; $count=$zip->numFiles;
    if($count<1||$count>AVATAR_LIBRARY_MAX_FILES){$zip->close();throw new AvatarLibraryActionException('头像包文件数量超出限制');} $total=0;
    for($i=0;$i<$count;$i++){$stat=$zip->statIndex($i);$name=str_replace('\\','/',(string)($stat['name']??''));if($name===''||str_ends_with($name,'/'))continue;if(str_contains($name,'\0')||preg_match('#(^|/)\.\.?(/|$)#',$name)||str_starts_with($name,'/')||preg_match('/^[a-z]:/i',$name)){ $zip->close();throw new AvatarLibraryActionException('头像包包含非法路径'); }if(substr_count($name,'/')>1){$zip->close();throw new AvatarLibraryActionException('头像包最多允许一层目录');}$base=basename($name);if(!preg_match('/^([a-z0-9][a-z0-9_-]*)_(\d+)\.(svg|png|jpe?g|webp)$/i',$base,$m)){ $zip->close();throw new AvatarLibraryActionException('文件名必须符合 group_数字.扩展名，例如 coc_1.svg、coc_2.webp'); }$group=avatar_library_slug($m[1]);$seed=(int)$m[2];if($group===''||$seed<1||$seed>100000){$zip->close();throw new AvatarLibraryActionException('头像组或编号无效');}$size=(int)($stat['size']??0);$limit=strtolower($m[3])==='svg'?AVATAR_LIBRARY_MAX_SVG_BYTES:AVATAR_LIBRARY_MAX_IMAGE_BYTES;if($size<1||$size>$limit){$zip->close();throw new AvatarLibraryActionException('头像文件过大：'.$base);}$total+=$size;if($total>AVATAR_LIBRARY_MAX_TOTAL_BYTES){$zip->close();throw new AvatarLibraryActionException('头像包解压后总大小过大');}if(isset($groups[$group][$seed])){$zip->close();throw new AvatarLibraryActionException('头像编号重复：'.$base);}$groups[$group][$seed]=['index'=>$i,'filename'=>$base,'size'=>$size,'extension'=>strtolower($m[3])];}
    $zip->close(); if(!$groups)throw new AvatarLibraryActionException('头像包中没有符合 group_数字.扩展名规则的头像'); return $groups;
}

function avatar_library_validate_svg(string $data): void
{
    if ($data === '' || strlen($data) > AVATAR_LIBRARY_MAX_SVG_BYTES) throw new AvatarLibraryActionException('SVG 文件无效或过大');
    if (stripos($data, '<svg') === false) throw new AvatarLibraryActionException('SVG 文件缺少 svg 根元素');
    if (preg_match('/<\s*(script|foreignObject)\b/i', $data)
        || preg_match('/<\s*(iframe|object|embed|audio|video|form)\b/i', $data)
        || preg_match('/\bon[a-z][a-z0-9_-]*\s*=\s*["\']/i', $data)) {
        throw new AvatarLibraryActionException('SVG 包含不允许的脚本或元素');
    }

    // 头像包常见做法是在 SVG 的 <image> 中内嵌 PNG/JPEG/WebP。
    // 仅放行这三种 data:image Base64，其余 data:、脚本协议和外部资源全部拒绝。
    $allowed_data = '/^data:image\/(?:png|jpe?g|webp);base64,([a-z0-9+\/\r\n]+={0,2})$/i';
    if (preg_match_all('/(?:href|xlink:href)\s*=\s*["\']([^"\']+)["\']/i', $data, $matches)) {
        foreach ($matches[1] as $href) {
            $href = trim(html_entity_decode((string)$href, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            if (preg_match($allowed_data, $href)) continue;
            if (preg_match('/^(?:https?:)?\/\//i', $href) || preg_match('/^(?:file|javascript|vbscript):/i', $href) || preg_match('/^data:/i', $href)) {
                throw new AvatarLibraryActionException('SVG 包含不允许的外部资源');
            }
        }
    }
    if (preg_match('/(?:javascript:|vbscript:)/i', $data)) throw new AvatarLibraryActionException('SVG 包含不允许的协议');
    if (preg_match_all('/url\(\s*["\']?([^"\')]+)["\']?\s*\)/i', $data, $urls)) {
        foreach ($urls[1] as $url) {
            $url = trim(html_entity_decode((string)$url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            if (preg_match($allowed_data, $url)) continue;
            if (preg_match('/^(?:https?:)?\/\//i', $url) || preg_match('/^(?:file|javascript|vbscript):/i', $url) || preg_match('/^data:/i', $url)) {
                throw new AvatarLibraryActionException('SVG 包含不允许的 CSS 外部资源');
            }
        }
    }
}

function avatar_library_process_zip(string $zip_path, string $display_name): int
{
    $groups=avatar_library_pack_groups_from_zip($zip_path);$zip=new ZipArchive();if($zip->open($zip_path)!==true)throw new AvatarLibraryActionException('头像包无法读取');$created_files=[];$created_dirs=[];$created_pack_ids=[];
    try{return tx(function()use($zip,$groups,$display_name,&$created_files,&$created_dirs,&$created_pack_ids):int{$first=0;foreach($groups as $group=>$items){if(avatar_library_pack_by_key($group))throw new AvatarLibraryActionException('头像组已存在：'.$group);$name=count($groups)===1&&trim($display_name)!==''?cut(trim($display_name),80):avatar_library_label($group);q('INSERT INTO plugin_avatar_library_packs(group_key,name,sort,enabled,created_at) VALUES(?,?,?,?,?)',[$group,$name,0,1,time()]);$pack_id=app_db_last_insert_id('plugin_avatar_library_packs');if($pack_id<1)throw new AvatarLibraryActionException('创建头像组失败');$created_pack_ids[]=$pack_id;if($first<1)$first=$pack_id;$dir=avatar_library_upload_root().'/'.$group;require_writable_dir($dir,'头像包目录不可写');$created_dirs[]=$dir;foreach($items as $seed=>$meta){$data=$zip->getFromIndex((int)$meta['index']);if($data===false)throw new AvatarLibraryActionException('无法读取头像文件：'.$meta['filename']);$ext=strtolower((string)$meta['extension']);if($ext==='svg'){avatar_library_validate_svg((string)$data);$mime='image/svg+xml';$width=0;$height=0;}else{$tmp=$dir.'/.zipcheck.'.bin2hex(random_bytes(4));if(@file_put_contents($tmp,$data,LOCK_EX)===false)throw new AvatarLibraryActionException('头像临时文件保存失败');try{$meta2=avatar_library_validate_raster_file($tmp);$mime=$meta2['mime_type'];$width=$meta2['width'];$height=$meta2['height'];}finally{@unlink($tmp);}}$filename=sprintf('%04d.%s',(int)$seed,avatar_library_extension_for_mime($mime));$path=$dir.'/'.$filename;$tmpPath=$path.'.tmp.'.bin2hex(random_bytes(4));if(@file_put_contents($tmpPath,$data,LOCK_EX)===false||!@rename($tmpPath,$path)){@unlink($tmpPath);throw new AvatarLibraryActionException('保存头像失败：'.$meta['filename']);}@chmod($path,0644);$created_files[]=$path;app_db_upsert('plugin_avatar_library_items',['pack_id'=>$pack_id,'seed'=>(int)$seed,'filename'=>(string)$meta['filename'],'relative_path'=>$group.'/'.$filename,'mime_type'=>$mime,'width'=>$width,'height'=>$height,'file_size'=>strlen($data),'sort_order'=>(int)$seed,'enabled'=>1,'created_at'=>time()],['pack_id','seed']);}}return $first;});}catch(Throwable $e){foreach($created_files as $f)@unlink($f);foreach($created_dirs as $d)@rmdir($d);foreach($created_pack_ids as $id){q('DELETE FROM plugin_avatar_library_items WHERE pack_id=?',[$id]);q('DELETE FROM plugin_avatar_library_packs WHERE id=?',[$id]);}throw $e;}finally{$zip->close();}
}

function avatar_library_admin_pack(int $id): ?array
{
    return $id > 0 ? (one('SELECT id,group_key,name,sort,enabled,created_at FROM plugin_avatar_library_packs WHERE id=?', [$id]) ?: null) : null;
}

function avatar_library_admin_next_seed(int $pack_id): int
{
    return max(1, (int)(val('SELECT MAX(seed) FROM plugin_avatar_library_items WHERE pack_id=?', [$pack_id]) ?: 0) + 1);
}

function avatar_library_admin_save_image_item(int $pack_id, string $tmp, string $original_name): int
{
    $pack=avatar_library_admin_pack($pack_id); if(!$pack || (int)$pack['enabled']!==1) throw new AvatarLibraryActionException('头像组不存在或已停用');
    $info=@getimagesize($tmp); $mime=strtolower((string)($info['mime']??''));
    if($mime==='' && preg_match('/\.svg$/i', $original_name)){ $data=@file_get_contents($tmp); if($data===false) throw new AvatarLibraryActionException('无法读取 SVG'); avatar_library_validate_svg($data); $mime='image/svg+xml'; $width=0; $height=0; $size=(int)filesize($tmp); }
    elseif($mime==='image/svg+xml'){ $data=@file_get_contents($tmp); if($data===false) throw new AvatarLibraryActionException('无法读取 SVG'); avatar_library_validate_svg($data); $width=(int)($info[0]??0); $height=(int)($info[1]??0); $size=(int)filesize($tmp); }
    else { $meta=avatar_library_validate_raster_file($tmp); $mime=$meta['mime_type']; $width=$meta['width']; $height=$meta['height']; $size=$meta['file_size']; $data=@file_get_contents($tmp); if($data===false) throw new AvatarLibraryActionException('无法读取图片'); }
    if($size<1 || $size > ($mime==='image/svg+xml'?AVATAR_LIBRARY_MAX_SVG_BYTES:AVATAR_LIBRARY_MAX_IMAGE_BYTES)) throw new AvatarLibraryActionException('图片文件过大');
    $seed=avatar_library_admin_next_seed($pack_id); $ext=avatar_library_extension_for_mime($mime); $group=avatar_library_slug((string)$pack['group_key']);
    $dir=avatar_library_upload_root().'/'.$group; require_writable_dir($dir,'头像组目录不可写');
    $filename=sprintf('%04d.%s',$seed,$ext); $path=$dir.'/'.$filename; $tmpPath=$path.'.tmp.'.bin2hex(random_bytes(4));
    if(@file_put_contents($tmpPath,$data,LOCK_EX)===false || !@rename($tmpPath,$path)){ @unlink($tmpPath); throw new AvatarLibraryActionException('头像保存失败'); } @chmod($path,0644);
    try{ app_db_upsert('plugin_avatar_library_items',['pack_id'=>$pack_id,'seed'=>$seed,'filename'=>cut(basename($original_name),160),'relative_path'=>$group.'/'.$filename,'mime_type'=>$mime,'width'=>$width,'height'=>$height,'file_size'=>$size,'sort_order'=>$seed,'enabled'=>1,'created_at'=>time()],['pack_id','seed']); }
    catch(Throwable $e){ @unlink($path); throw $e; }
    unset($GLOBALS['__avatar_library_item_map'],$GLOBALS['__avatar_library_default_cache']); return $seed;
}

function avatar_library_admin_delete_item(int $item_id): void
{
    $item=one('SELECT id,pack_id,relative_path FROM plugin_avatar_library_items WHERE id=?',[$item_id]); if(!$item) throw new AvatarLibraryActionException('头像不存在');
    $pack=avatar_library_admin_pack((int)$item['pack_id']); if(!$pack) throw new AvatarLibraryActionException('头像组不存在');
    q('DELETE FROM plugin_avatar_library_items WHERE id=?',[$item_id]);
    $path=avatar_library_upload_root().'/'.ltrim(str_replace('\\','/',(string)$item['relative_path']),'/'); if(is_file($path)) @unlink($path);
    unset($GLOBALS['__avatar_library_item_map']);
}

function avatar_library_admin_toggle_item(int $item_id): void
{
    $item=one('SELECT id,enabled FROM plugin_avatar_library_items WHERE id=?',[$item_id]); if(!$item) throw new AvatarLibraryActionException('头像不存在');
    q('UPDATE plugin_avatar_library_items SET enabled=? WHERE id=?',[(int)$item['enabled']===1?0:1,$item_id]); unset($GLOBALS['__avatar_library_item_map'],$GLOBALS['__avatar_library_default_cache']);
}

function avatar_library_admin_delete_pack(int $pack_id): void
{
    $pack=avatar_library_admin_pack($pack_id); if(!$pack) throw new AvatarLibraryActionException('头像组不存在');
    $group=(string)$pack['group_key']; $fallback=avatar_library_core_fallback_style();
    tx(function()use($pack,$group,$fallback):void{ q('UPDATE app_users SET avatar_style=?,avatar_seed=? WHERE id IN (SELECT user_id FROM plugin_avatar_library_users WHERE source=? AND group_key=?)',[$fallback,'1','local',$group]); q('DELETE FROM plugin_avatar_library_users WHERE source=? AND group_key=?',['local',$group]); q('DELETE FROM plugin_avatar_library_items WHERE pack_id=?',[(int)$pack['id']]); q('DELETE FROM plugin_avatar_library_packs WHERE id=?',[(int)$pack['id']]); });
    avatar_library_delete_tree(avatar_library_upload_root().'/'.$group); unset($GLOBALS['__avatar_library_item_map'],$GLOBALS['__avatar_library_user_map'],$GLOBALS['__avatar_library_default_cache']);
}

function avatar_library_admin_page(array $plugin): string
{
    need_admin();
    if(is_post_request()){
        require_post(); $action=(string)($_POST['avatar_library_admin_action']??'settings');
        try{
            if($action==='settings'){
                $key=(string)($_POST['default_remote_style']??'remote:dylan'); $parts=array_pad(explode(':',$key,2),2,''); $source=$parts[0]; $group=$source==='remote'?avatar_style(cut($parts[1],40)):avatar_library_slug($parts[1]);
                if($source==='local'){ $pack=avatar_library_pack_by_key($group); if(!$pack||(int)$pack['enabled']!==1) throw new AvatarLibraryActionException('请选择有效的本地头像组'); }
                if(!in_array($source,['remote','local'],true)||$group==='') throw new AvatarLibraryActionException('默认头像组无效');
                $cost=max(0,min(100000,(int)($_POST['points_cost']??10))); $interval=max(0,min(31536000,(int)($_POST['change_interval_hours']??24)*3600));
                save_settings_values(['avatar_library_default_style'=>$source.':'.$group,'avatar_library_points_cost'=>(string)$cost,'avatar_library_change_interval'=>(string)$interval]); unset($GLOBALS['__avatar_library_default_cache']); set_flash('头像库设置已保存'); go(admin_url(['tab'=>'avatar_library']));
            }
            if($action==='create_pack'){
                $group=avatar_library_slug((string)($_POST['group_key']??'')); $name=cut(trim((string)($_POST['pack_name']??'')),80); $sort=max(0,min(100000,(int)($_POST['pack_sort']??0)));
                if($group===''||$name==='') throw new AvatarLibraryActionException('请填写头像组名称和唯一标识'); if(avatar_library_pack_by_key($group)) throw new AvatarLibraryActionException('头像组标识已存在');
                q('INSERT INTO plugin_avatar_library_packs(group_key,name,sort,enabled,created_at) VALUES(?,?,?,?,?)',[$group,$name,$sort,1,time()]); set_flash('头像组已创建'); go(admin_url(['tab'=>'avatar_library']));
            }
            if($action==='edit_pack'){
                $id=(int)($_POST['pack_id']??0); $pack=avatar_library_admin_pack($id); if(!$pack) throw new AvatarLibraryActionException('头像组不存在'); $name=cut(trim((string)($_POST['pack_name']??'')),80); $sort=max(0,min(100000,(int)($_POST['pack_sort']??0))); $enabled=isset($_POST['pack_enabled'])?1:0; if($name==='') throw new AvatarLibraryActionException('头像组名称不能为空'); q('UPDATE plugin_avatar_library_packs SET name=?,sort=?,enabled=? WHERE id=?',[$name,$sort,$enabled,$id]); set_flash('头像组设置已更新'); go(admin_url(['tab'=>'avatar_library']));
            }
            if($action==='upload_logo'){
                if ((string)($_POST['avatar_library_logo_action'] ?? '') === 'delete') {
                    foreach (avatar_library_logo_candidates() as $file) {
                        if (is_file($file) && !@unlink($file)) {
                            throw new AvatarLibraryActionException('论坛图标删除失败');
                        }
                    }
                    set_flash('已恢复论坛原始图标');
                    go(admin_url(['tab'=>'avatar_library']));
                }
                $upload=(array)($_FILES['avatar_library_logo']??[]);
                if((int)($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) throw new AvatarLibraryActionException('请选择论坛图标');
                $tmp=(string)($upload['tmp_name']??''); $size=(int)($upload['size']??0);
                if($tmp===''||!is_uploaded_file($tmp)||$size<1) throw new AvatarLibraryActionException('图标文件无效');
                // Chrome/Edge/Firefox 对 SVG 的 multipart MIME 标记并不值得作为唯一依据，
                // 更重要的是：PHP 的 getimagesize() 在很多环境下本来就不会识别 SVG。
                // 因此 SVG 必须优先按“扩展名 / 浏览器 MIME / 实际 MIME”识别，再交给
                // avatar_library_validate_svg() 做内容安全校验；不能要求 getimagesize() 成功。
                $original_name=basename((string)($upload['name']??''));
                $upload_mime=strtolower((string)($upload['type']??''));
                $is_svg=preg_match('/\.svg$/i',$original_name)===1 || $upload_mime==='image/svg+xml';
                if($is_svg){
                    if($size>AVATAR_LIBRARY_MAX_SVG_BYTES) throw new AvatarLibraryActionException('SVG 图标不能超过 2MB');
                    $data=@file_get_contents($tmp);
                    if(!is_string($data)||$data==='') throw new AvatarLibraryActionException('图标文件读取失败');
                    avatar_library_validate_svg($data);
                    $type='svg';
                } else {
                    $info=@getimagesize($tmp);
                    $actual_mime=is_array($info)?strtolower((string)($info['mime']??'')):'';
                    if(in_array($actual_mime,['image/png','image/jpeg','image/webp'],true)){
                        if($size>AVATAR_LIBRARY_MAX_IMAGE_BYTES) throw new AvatarLibraryActionException('PNG、JPG、WebP 图标原图不能超过 10MB');
                        $width=(int)($info[0]??0); $height=(int)($info[1]??0);
                        if($width<1||$height<1||$width>AVATAR_LIBRARY_MAX_IMAGE_DIMENSION||$height>AVATAR_LIBRARY_MAX_IMAGE_DIMENSION) throw new AvatarLibraryActionException('图标尺寸超出限制');
                        $data=@file_get_contents($tmp);
                        if(!is_string($data)||$data==='') throw new AvatarLibraryActionException('图标文件读取失败');
                        $type='png';
                    } else {
                        throw new AvatarLibraryActionException('仅支持 SVG、PNG、JPG、WebP 图标');
                    }
                }
                $dir=dirname(avatar_library_logo_file());
                if(!is_dir($dir)&&!mkdir($dir,0755,true)) throw new AvatarLibraryActionException('图标目录创建失败');
                require_writable_dir($dir,'图标目录不可写');
                $target=avatar_library_logo_file($type).'.tmp.'.bin2hex(random_bytes(4));
                if(@file_put_contents($target,$data,LOCK_EX)!==strlen($data)){@unlink($target);throw new AvatarLibraryActionException('图标保存失败');}
                @chmod($target,0644);

                $destination=avatar_library_logo_file($type);
                // Windows 下 rename() 不能稳定覆盖已存在的同名文件。
                // 先尝试原子 rename；失败时再用 copy 覆盖，避免“第二次上传才生效”。
                if(!@rename($target,$destination)){
                    if(!@copy($target,$destination)){
                        @unlink($target);
                        throw new AvatarLibraryActionException('图标保存失败');
                    }
                    @unlink($target);
                }

                // 确保下一次请求看到的是新文件内容。
                clearstatcache(true,$destination);

                $other=$type==='svg'?'png':'svg';
                if(is_file(avatar_library_logo_file($other))) @unlink(avatar_library_logo_file($other));
                set_flash('论坛图标已更新'); go(admin_url(['tab'=>'avatar_library']));
            }
            if($action==='delete_logo'){
                foreach(avatar_library_logo_candidates() as $file){
                    if(is_file($file)&&!@unlink($file)) throw new AvatarLibraryActionException('论坛图标删除失败');
                }
                set_flash('已恢复论坛原始图标'); go(admin_url(['tab'=>'avatar_library']));
            }
            if($action==='upload_item'){
                $upload=(array)($_FILES['avatar_library_image']??[]); if((int)($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) throw new AvatarLibraryActionException('请选择图片'); $tmp=(string)($upload['tmp_name']??''); if($tmp===''||!is_uploaded_file($tmp)) throw new AvatarLibraryActionException('上传文件无效'); avatar_library_admin_save_image_item((int)($_POST['pack_id']??0),$tmp,(string)($upload['name']??'avatar')); set_flash('头像已上传并自动编号'); go(admin_url(['tab'=>'avatar_library','pack_id'=>(int)$_POST['pack_id']]));
            }
            if($action==='delete_item'){ avatar_library_admin_delete_item((int)($_POST['item_id']??0)); set_flash('头像已删除'); go(admin_url(['tab'=>'avatar_library','pack_id'=>(int)($_POST['pack_id']??0)])); }
            if($action==='toggle_item'){ avatar_library_admin_toggle_item((int)($_POST['item_id']??0)); set_flash('头像状态已更新'); go(admin_url(['tab'=>'avatar_library','pack_id'=>(int)($_POST['pack_id']??0)])); }
            if($action==='delete_pack'){ avatar_library_admin_delete_pack((int)($_POST['pack_id']??0)); set_flash('头像组已删除，相关用户已回退'); go(admin_url(['tab'=>'avatar_library'])); }
            if($action==='upload_zip'){
                $upload=(array)($_FILES['avatar_library_zip']??[]); if((int)($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) throw new AvatarLibraryActionException('请选择 ZIP 头像包'); $tmp=(string)($upload['tmp_name']??''); $size=(int)($upload['size']??0); if($tmp===''||!is_uploaded_file($tmp)||$size<1||$size>AVATAR_LIBRARY_MAX_ZIP_BYTES) throw new AvatarLibraryActionException('头像包不能超过 50MB'); avatar_library_process_zip($tmp,cut(trim((string)($_POST['pack_name']??'')),80)); set_flash('头像包导入成功'); go(admin_url(['tab'=>'avatar_library']));
            }
            throw new AvatarLibraryActionException('操作无效');
        }catch(Throwable $e){ err($e instanceof AvatarLibraryActionException?$e->getMessage():'头像库操作失败'); }
    }
    $config=avatar_library_config(); $default_options=[]; foreach(avatar_styles() as $style=>$label)$default_options['remote:'.$style]=(string)$label; foreach(avatar_library_packs(true) as $pack)$default_options['local:'.$pack['group_key']]='本地：'.$pack['name'];
    $packs=avatar_library_packs(false); $counts=[]; $pack_ids=array_values(array_map(static fn(array $p):int=>(int)$p['id'],$packs));
    if($pack_ids)foreach(array_chunk($pack_ids,200) as $chunk){$rows2=q('SELECT pack_id,COUNT(*) AS item_count FROM plugin_avatar_library_items WHERE enabled=1 AND pack_id IN ('.sql_marks(count($chunk)).') GROUP BY pack_id',$chunk)->fetchAll();foreach($rows2 as $r) $counts[(int)$r['pack_id']] = (int)($r['item_count'] ?? 0);}
    $selected=(int)($_GET['pack_id']??0); $selected_pack=$selected>0?avatar_library_admin_pack($selected):null;
    $rows=''; foreach($packs as $pack){$id=(int)$pack['id']; $rows.='<tr><td><strong class="admin-name">'.h((string)$pack['name']).'</strong><small>'.h((string)$pack['group_key']).'</small></td><td>'.(int)($counts[$id]??0).'</td><td>'.((int)$pack['enabled']===1?'启用':'停用').'</td><td class="ops"><a class="btn alt" href="'.h(admin_url(['tab'=>'avatar_library','pack_id'=>$id])).'">管理</a> <form method="post" action="'.h(admin_url(['tab'=>'avatar_library'])).'" style="display:inline">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="delete_pack"><input type="hidden" name="pack_id" value="'.$id.'"><button class="danger" type="submit" onclick="return confirm(\'确定删除这个头像组？\')">删除</button></form></td></tr>';}
    if($rows==='')$rows='<tr><td colspan="4" class="empty-state">暂无本地头像组</td></tr>';
    $logo_version=avatar_library_logo_version();
    $logo_url=$logo_version!==null?avatar_library_logo_url($logo_version):'';
    $logo_current=avatar_library_logo_current();
    $logo_restore=$logo_version!==null
        ? '<button class="btn alt" type="submit" name="avatar_library_logo_action" value="delete" formnovalidate>恢复原始图标</button>'
        : '';
    $logo_type=$logo_current?(string)$logo_current['type']:'';
    $logo='<section class="avatar-library-logo-settings"><div class="avatar-library-logo-preview">'
        .($logo_version!==null?'<img src="'.h($logo_url).'" loading="lazy" alt="当前论坛图标">':'<div class="empty-state">当前使用源码自带的 index.svg</div>')
        .'</div><form class="plugin-settings-form" method="post" enctype="multipart/form-data" action="'.h(admin_url(['tab'=>'avatar_library'])).'">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="upload_logo"><label class="grid"><span>论坛图标<small>同时替换浏览器标签图标和左上角论坛图标；支持 SVG、PNG、JPG、WebP。PNG/JPG/WebP 可直接上传原图，也可在浏览器中自由拖动、缩放并裁剪为 512×512 透明 PNG；SVG 最大 2MB，位图原图最大 10MB。论坛名称不会改变。</small></span><input type="file" name="avatar_library_logo" accept="image/svg+xml,.svg,image/png,image/jpeg,image/webp" data-avatar-library-logo-upload required></label><div class="avatar-library-logo-actions"><button type="submit" data-avatar-library-logo-submit>直接上传并应用</button>'.$logo_restore.'</div></form><div class="avatar-library-logo-editor" data-avatar-library-logo-editor hidden><div class="avatar-library-logo-editor-head"><strong>调整图标</strong><small>拖动位置、自由缩放后生成 512×512 透明 PNG</small></div><canvas width="320" height="320" data-avatar-library-logo-canvas></canvas><label class="avatar-library-logo-zoom"><span>缩放</span><input type="range" min="10" max="500" value="100" data-avatar-library-logo-zoom></label><button type="button" class="btn" data-avatar-library-logo-apply>裁剪并上传应用</button></div></section>';
    $settings='<form class="plugin-settings-form" method="post" action="'.h(admin_url(['tab'=>'avatar_library'])).'">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="settings">'.select_input('新用户默认头像组','default_remote_style',$config['default_key'],$default_options,'这里选择的头像组就是个人资料中的“默认头像”。').number_input('头像更新消耗积分','points_cost',avatar_library_points_cost(),0,100000,true,'设为0则不扣积分。').number_input('头像更换间隔（小时）','change_interval_hours',(int)ceil(avatar_library_change_interval()/3600),0,8760,true,'设为0表示不限制间隔。').'<button type="submit">保存设置</button></form>';
    $create='<form class="plugin-settings-form" method="post" action="'.h(admin_url(['tab'=>'avatar_library'])).'">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="create_pack"><label class="grid"><span>头像组名称</span><input name="pack_name" maxlength="80" required placeholder="例如：可爱动物"></label><label class="grid"><span>唯一标识<small>创建后不建议修改。</small></span><input name="group_key" maxlength="80" pattern="[A-Za-z0-9_-]+" required placeholder="cute_animals"></label><label class="grid"><span>排序</span><input name="pack_sort" type="number" min="0" max="100000" value="0"></label><button type="submit">创建头像组</button></form>';
    $zip='<form class="plugin-settings-form" method="post" enctype="multipart/form-data" action="'.h(admin_url(['tab'=>'avatar_library'])).'">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="upload_zip"><label class="grid"><span>ZIP 头像包<small>支持 SVG、JPG、PNG、WebP；格式仍要求 group_数字.扩展名。</small></span><input type="file" name="avatar_library_zip" accept=".zip,application/zip" required></label><label class="grid"><span>单组名称</span><input name="pack_name" maxlength="80" placeholder="可选"></label><button type="submit">上传并导入</button></form>';
    $manage=''; if($selected_pack){$items=avatar_library_items((int)$selected_pack['id']);$manage.='<section class="avatar-library-admin-editor"><div class="avatar-library-admin-editor-head"><div><h3>'.h((string)$selected_pack['name']).'</h3><small>'.h((string)$selected_pack['group_key']).'</small></div><a class="btn alt" href="'.h(admin_url(['tab'=>'avatar_library'])).'">返回</a></div><form class="plugin-settings-form" method="post" action="'.h(admin_url(['tab'=>'avatar_library'])).'">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="edit_pack"><input type="hidden" name="pack_id" value="'.(int)$selected_pack['id'].'"><label class="grid"><span>头像组名称</span><input name="pack_name" maxlength="80" value="'.h((string)$selected_pack['name']).'" required></label><label class="grid"><span>排序</span><input name="pack_sort" type="number" min="0" max="100000" value="'.(int)$selected_pack['sort'].'"></label><label class="grid"><span>状态</span><span><input type="checkbox" name="pack_enabled" '.((int)$selected_pack['enabled']===1?'checked':'').'> 启用</span></label><button type="submit">保存头像组</button></form><form class="plugin-settings-form" method="post" enctype="multipart/form-data" action="'.h(admin_url(['tab'=>'avatar_library'])).'">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="upload_item"><input type="hidden" name="pack_id" value="'.(int)$selected_pack['id'].'"><label class="grid"><span>上传单张头像<small>JPG/PNG/WebP 会先在浏览器裁剪成正方形；SVG 原样安全校验。上传后自动编号。</small></span><input type="file" name="avatar_library_image" accept="image/jpeg,image/png,image/webp,image/svg+xml" data-avatar-library-admin-upload required></label><button type="submit">上传头像</button></form>';
        $cards=''; foreach($items as $item){$url=avatar_library_item_url($item,(string)($item['file_size']??''));$on=(int)($item['enabled']??1)===1;$cards.='<article class="avatar-library-admin-item"><img src="'.h($url).'" loading="lazy" alt=""><div><strong>'.h(sprintf('%04d',(int)$item['seed'])).'</strong><small>'.h((string)($item['mime_type']??'')).' · '.(int)$item['width'].'×'.(int)$item['height'].' · '.($on?'启用':'停用').'</small></div><div class="avatar-library-admin-item-actions"><form method="post" action="'.h(admin_url(['tab'=>'avatar_library'])).'">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="toggle_item"><input type="hidden" name="item_id" value="'.(int)$item['id'].'"><input type="hidden" name="pack_id" value="'.(int)$selected_pack['id'].'"><button class="btn alt" type="submit">'.($on?'停用':'启用').'</button></form><form method="post" action="'.h(admin_url(['tab'=>'avatar_library'])).'">'.form_token().'<input type="hidden" name="avatar_library_admin_action" value="delete_item"><input type="hidden" name="item_id" value="'.(int)$item['id'].'"><input type="hidden" name="pack_id" value="'.(int)$selected_pack['id'].'"><button class="danger" type="submit" onclick="return confirm(\'确定删除这个头像？\')">删除</button></form></div></article>';}
        if($cards==='')$cards='<div class="empty-state">这个头像组还没有头像。</div>';$manage.='<div class="avatar-library-admin-grid">'.$cards.'</div></section>';}
    return '<section class="admin-list-panel plugin-manage-panel"><div class="admin-plugin-summary"><strong>头像库</strong><span>统一管理远程头像、本地头像组、默认头像和用户自定义头像。</span></div><div class="plugin-panel-body"><h3>论坛图标</h3>'.$logo.'<h3>默认头像</h3>'.$settings.'<h3>创建头像组</h3>'.$create.'<h3>导入头像包</h3>'.$zip.'<h3>本地头像组</h3><table class="list admin-bulk-list"><tr><th>头像组</th><th>头像数</th><th>状态</th><th>操作</th></tr>'.$rows.'</table>'.$manage.'</div></section>';
}

function avatar_library_css(): string
{
    return '.avatar-library-logo-settings{margin-bottom:18px;padding-bottom:18px;border-bottom:1px solid var(--line-soft)}.avatar-library-logo-preview{display:flex;align-items:center;justify-content:center;min-height:96px;margin-bottom:12px;padding:12px;border:1px solid var(--line);border-radius:var(--radius);background:var(--bg)}.avatar-library-logo-preview img{display:block;max-width:240px;max-height:96px;width:auto;height:auto}.avatar-library-logo-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.avatar-library-logo-actions form{margin:0}.avatar-library-logo-actions button{width:auto}.avatar-library-logo-editor{margin-top:12px;padding:12px;border:1px solid var(--line);border-radius:var(--radius);background:var(--bg)}.avatar-library-logo-editor-head strong,.avatar-library-logo-editor-head small{display:block}.avatar-library-logo-editor-head small{margin-top:3px;color:var(--text-muted)}.avatar-library-logo-editor canvas{display:block;width:min(320px,100%);height:auto;margin:12px auto;border-radius:var(--radius);background:var(--bg);cursor:grab;touch-action:none}.avatar-library-logo-editor canvas.dragging{cursor:grabbing}.avatar-library-logo-zoom{display:grid;grid-template-columns:42px minmax(0,1fr);gap:10px;align-items:center;margin:10px 0}.avatar-library-logo-zoom input{padding:0}.avatar-library-config{display:none!important}.avatar-library-upload-panel{margin-top:16px;padding:12px;border:1px solid var(--line);border-radius:var(--radius);background:var(--bg)}.avatar-library-upload-head{display:flex;align-items:center;justify-content:space-between;gap:12px}.avatar-library-upload-head strong,.avatar-library-upload-head small{display:block}.avatar-library-upload-head small{margin-top:3px;color:var(--text-muted)}.avatar-library-upload-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.avatar-library-upload-button{width:auto;display:inline-flex;align-items:center;justify-content:center}.avatar-library-status{min-height:0;margin-top:10px;color:var(--text-muted)}.avatar-library-status.error{color:var(--danger)}.avatar-library-crop-modal{z-index:1200}.avatar-library-crop-dialog{width:min(420px,calc(100vw - 24px))}.avatar-library-crop-dialog canvas{display:block;width:min(320px,100%);height:auto;margin:0 auto;border-radius:var(--radius);background:var(--bg);cursor:grab;touch-action:none}.avatar-library-crop-dialog canvas.dragging{cursor:grabbing}.avatar-library-crop-zoom{display:grid;grid-template-columns:42px minmax(0,1fr);gap:10px;align-items:center;margin-top:14px}.avatar-library-crop-zoom input{padding:0}.avatar-library-admin-editor{margin-top:18px;padding-top:18px;border-top:1px solid var(--line-soft)}.avatar-library-admin-editor-head{display:flex;justify-content:space-between;align-items:center;gap:12px}.avatar-library-admin-editor-head h3{margin:0}.avatar-library-admin-editor-head small{color:var(--text-muted)}.avatar-library-admin-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin-top:14px}.avatar-library-admin-item{min-width:0;border:1px solid var(--line);border-radius:var(--radius);padding:8px;background:var(--bg)}.avatar-library-admin-item>img{display:block;width:100%;aspect-ratio:1;object-fit:cover;border-radius:calc(var(--radius) - 2px);background:var(--line-soft)}.avatar-library-admin-item>div{margin-top:7px}.avatar-library-admin-item strong,.avatar-library-admin-item small{display:block}.avatar-library-admin-item small{margin-top:3px;color:var(--text-muted);word-break:break-word}.avatar-library-admin-item-actions{display:flex;gap:6px;flex-wrap:wrap}.avatar-library-admin-item-actions form{margin:0}.avatar-library-admin-item-actions button{width:auto}@media(max-width:900px){.avatar-library-admin-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:600px){.avatar-library-upload-head{align-items:stretch;flex-direction:column}.avatar-library-upload-actions{width:100%}.avatar-library-admin-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.avatar-library-admin-editor-head{align-items:flex-start;flex-direction:column}}
';
}

function avatar_library_js(): string
{
    return <<<'JS'
(() => {
    const cfg = document.querySelector('[data-avatar-library-config]');
    const profileSlot = cfg ? (cfg.closest('[data-slot~="profile.after_form"]') || document) : document;
    const picker = profileSlot.querySelector('.avatar-picker');

    if (!cfg || !picker) {
        const logoInput = document.querySelector('[data-avatar-library-logo-upload]');
        const logoForm = logoInput?.closest('form');
        const logoSubmit = logoForm?.querySelector('[data-avatar-library-logo-submit]');
        const logoEditor = document.querySelector('[data-avatar-library-logo-editor]');
        if (logoInput && logoEditor && logoForm) {
            const logoCanvas = logoEditor.querySelector('[data-avatar-library-logo-canvas]');
            const logoZoom = logoEditor.querySelector('[data-avatar-library-logo-zoom]');
            const logoApply = logoEditor.querySelector('[data-avatar-library-logo-apply]');
            const logoCtx = logoCanvas?.getContext('2d');
            let logoImage=null, logoObjectUrl='', logoScale=1, logoMinScale=1, logoX=0, logoY=0, logoDrag=false, logoPX=0, logoPY=0;
            const logoClamp=()=>{if(!logoImage||!logoCanvas)return;const w=logoImage.naturalWidth*logoScale,h=logoImage.naturalHeight*logoScale;logoX=w<=logoCanvas.width?Math.min(logoCanvas.width-w,Math.max(0,logoX)):Math.min(0,Math.max(logoCanvas.width-w,logoX));logoY=h<=logoCanvas.height?Math.min(logoCanvas.height-h,Math.max(0,logoY)):Math.min(0,Math.max(logoCanvas.height-h,logoY));};
            const logoDraw=()=>{if(!logoCtx||!logoCanvas||!logoImage)return;logoClamp();logoCtx.clearRect(0,0,logoCanvas.width,logoCanvas.height);logoCtx.drawImage(logoImage,logoX,logoY,logoImage.naturalWidth*logoScale,logoImage.naturalHeight*logoScale);};
            const logoRelease=()=>{if(logoObjectUrl)URL.revokeObjectURL(logoObjectUrl);logoObjectUrl='';logoImage=null;};
            const logoClose=(clearInput=true)=>{logoEditor.hidden=true;logoRelease();if(clearInput)logoInput.value='';};
            const logoSubmitForm=()=>{
                if (typeof logoForm.requestSubmit === 'function') {
                    logoForm.requestSubmit(logoSubmit || undefined);
                } else {
                    logoForm.submit();
                }
            };
            logoInput.addEventListener('change',()=>{
                const file=logoInput.files?.[0];
                if(!file)return;
                // SVG 不需要裁剪，保留原 SVG，直接交给下面的“直接上传并应用”。
                if(file.type==='image/svg+xml' || /\.svg$/i.test(file.name||'')) { logoClose(false); return; }
                if(!/^image\/(?:png|jpeg|webp)$/i.test(file.type)){logoInput.value='';alert('仅支持 SVG、PNG、JPG、WebP');return;}
                if(file.size>10*1024*1024){logoInput.value='';alert('位图图标不能超过 10MB');return;}
                logoRelease();
                logoObjectUrl=URL.createObjectURL(file);
                logoImage=new Image();
                logoImage.onload=()=>{
                    logoEditor.hidden=false;
                    // 初始状态保证整张图片完整落在裁剪框内；随后用户可以继续缩放到 500%。
                    logoMinScale=Math.min(logoCanvas.width/logoImage.naturalWidth,logoCanvas.height/logoImage.naturalHeight);
                    if(!isFinite(logoMinScale)||logoMinScale<=0)logoMinScale=1;
                    logoScale=logoMinScale;
                    logoX=(logoCanvas.width-logoImage.naturalWidth*logoScale)/2;
                    logoY=(logoCanvas.height-logoImage.naturalHeight*logoScale)/2;
                    if(logoZoom)logoZoom.value='100';
                    logoDraw();
                };
                logoImage.onerror=()=>{logoClose();alert('图标图片无法读取');};
                logoImage.src=logoObjectUrl;
            });
            logoZoom?.addEventListener('input',()=>{if(!logoImage)return;const old=logoScale;logoScale=logoMinScale*Number(logoZoom.value||100)/100;const cx=logoCanvas.width/2,cy=logoCanvas.height/2;logoX=cx-(cx-logoX)*logoScale/old;logoY=cy-(cy-logoY)*logoScale/old;logoDraw();});
            logoCanvas?.addEventListener('pointerdown',e=>{if(!logoImage)return;logoDrag=true;logoPX=e.clientX;logoPY=e.clientY;logoCanvas.setPointerCapture(e.pointerId);logoCanvas.classList.add('dragging');});
            logoCanvas?.addEventListener('pointermove',e=>{if(!logoDrag)return;const r=logoCanvas.width/logoCanvas.getBoundingClientRect().width;logoX+=(e.clientX-logoPX)*r;logoY+=(e.clientY-logoPY)*r;logoPX=e.clientX;logoPY=e.clientY;logoDraw();});
            const logoStop=()=>{logoDrag=false;logoCanvas?.classList.remove('dragging')};logoCanvas?.addEventListener('pointerup',logoStop);logoCanvas?.addEventListener('pointercancel',logoStop);
            logoApply?.addEventListener('click',()=>{
                if(!logoImage)return;
                logoApply.disabled=true;
                const out=document.createElement('canvas');out.width=out.height=512;
                const oc=out.getContext('2d');
                oc.clearRect(0,0,512,512);
                // 把当前 320×320 预览框对应的原图区域输出到 512×512，透明背景保持不变。
                const sx=-logoX/logoScale, sy=-logoY/logoScale, sw=logoCanvas.width/logoScale, sh=logoCanvas.height/logoScale;
                oc.drawImage(logoImage,sx,sy,sw,sh,0,0,512,512);
                out.toBlob(blob=>{
                    if(!blob){logoApply.disabled=false;alert('裁剪失败');return;}
                    try{
                        const dt=new DataTransfer();
                        dt.items.add(new File([blob],'avatar_library_logo.png',{type:'image/png'}));
                        logoInput.files=dt.files;
                        // 不清空 file input，也不再停留在“选中了但没有提交”的中间状态。
                        // 直接提交，确保第一次裁剪就真正保存并刷新 favicon/顶部图标。
                        logoEditor.hidden=true;
                        logoRelease();
                        logoSubmitForm();
                    }catch(_){
                        logoApply.disabled=false;
                        alert('浏览器不支持裁剪结果回填，请改用“直接上传并应用”上传原图');
                    }
                },'image/png');
            });
        }
        document.querySelectorAll('[data-avatar-library-admin-upload]').forEach(input => {
            input.addEventListener('change', () => {
                const file=input.files?.[0]; if(!file || file.type==='image/svg+xml') return;
                if(!/^image\/(?:jpeg|png|webp)$/i.test(file.type)){input.value='';alert('仅支持 JPG、PNG、WebP、SVG');return;}
                if(file.size>10*1024*1024){input.value='';alert('原图不能超过 10MB');return;}
                const modal=document.createElement('div'); modal.className='modal-backdrop avatar-library-crop-modal';
                modal.innerHTML='<div class="modal-panel avatar-library-crop-dialog"><div class="modal-head"><strong>调整头像</strong><button type="button" class="modal-close" data-close>×</button></div><div class="modal-body"><canvas width="320" height="320"></canvas><label class="avatar-library-crop-zoom"><span>缩放</span><input type="range" min="100" max="300" value="100"></label><div class="confirm-actions"><button type="button" class="btn alt" data-close>取消</button><button type="button" data-save>确认并使用</button></div></div></div>';
                document.body.appendChild(modal); const canvas=modal.querySelector('canvas'), zoom=modal.querySelector('input[type=range]'), save=modal.querySelector('[data-save]'), ctx=canvas.getContext('2d'); let image=null,scale=1,minScale=1,x=0,y=0,drag=false,px=0,py=0,objectUrl='';
                const clamp=()=>{if(!image)return;x=Math.min(0,Math.max(canvas.width-image.naturalWidth*scale,x));y=Math.min(0,Math.max(canvas.height-image.naturalHeight*scale,y));}; const draw=()=>{if(!image)return;clamp();ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,x,y,image.naturalWidth*scale,image.naturalHeight*scale);}; const close=()=>{if(objectUrl)URL.revokeObjectURL(objectUrl);modal.remove();};
                modal.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',close)); objectUrl=URL.createObjectURL(file); image=new Image(); image.onload=()=>{minScale=Math.max(canvas.width/image.naturalWidth,canvas.height/image.naturalHeight);scale=minScale;x=(canvas.width-image.naturalWidth*scale)/2;y=(canvas.height-image.naturalHeight*scale)/2;draw();}; image.src=objectUrl;
                zoom.addEventListener('input',()=>{const old=scale;scale=minScale*Number(zoom.value||100)/100;const cx=canvas.width/2,cy=canvas.height/2;x=cx-(cx-x)*scale/old;y=cy-(cy-y)*scale/old;draw();}); canvas.addEventListener('pointerdown',e=>{drag=true;px=e.clientX;py=e.clientY;canvas.setPointerCapture(e.pointerId);canvas.classList.add('dragging');}); canvas.addEventListener('pointermove',e=>{if(!drag)return;const r=canvas.width/canvas.getBoundingClientRect().width;x+=(e.clientX-px)*r;y+=(e.clientY-py)*r;px=e.clientX;py=e.clientY;draw();}); const stop=()=>{drag=false;canvas.classList.remove('dragging')}; canvas.addEventListener('pointerup',stop);canvas.addEventListener('pointercancel',stop);
                save.addEventListener('click',()=>{if(!image)return;const out=document.createElement('canvas');out.width=out.height=512;const oc=out.getContext('2d');oc.drawImage(image,-x/scale,-y/scale,canvas.width/scale,canvas.height/scale,0,0,512,512);out.toBlob(blob=>{if(!blob){alert('裁剪失败');return;}try{const dt=new DataTransfer();dt.items.add(new File([blob],'avatar.jpg',{type:'image/jpeg'}));input.files=dt.files;close();}catch(_){alert('浏览器不支持裁剪结果回填，请直接上传原图');close();}},'image/jpeg',.9);});
            });
        });
        return;
    }

    let groups = {}, current = {};
    try { groups = JSON.parse(cfg.dataset.avatarLibraryGroups || '{}'); } catch (_) {}
    try { current = JSON.parse(cfg.dataset.avatarLibraryCurrent || '{}'); } catch (_) {}

    const route = cfg.dataset.avatarLibraryUrl || '';
    const localRoot = cfg.dataset.avatarLibraryLocalRoot || '';
    const defaultSource = cfg.dataset.avatarLibraryDefaultSource === 'local' ? 'local' : 'remote';
    const defaultGroup = String(cfg.dataset.avatarLibraryDefaultGroup || 'dylan');
    const defaultLabel = String(cfg.dataset.avatarLibraryDefaultLabel || '默认头像');
    const form = picker.closest('form');
    const select = picker.querySelector('select[name="avatar_style"]');
    const seedInput = picker.querySelector('input[name="avatar_seed"]');
    const options = picker.querySelector('.avatar-options');
    const preview = picker.querySelector('.avatar-picker-preview img');
    const summary = picker.querySelector('.profile-avatar-summary img');
    if (!select || !seedInput || !options) return;

    const LOCAL_PREFIX = '__avatar_library_local__:';
    const localUrl = (group, seed) => { const meta=groups[group]; const item=meta?.items?.[String(seed)] || meta?.items?.[Number(seed)] || {}; return item.url || '';  };
    const hidden = name => form?.querySelector(`input[name="${name}"]`);
    const ensureHidden = (name, value) => {
        if (!form) return null;
        let input = hidden(name);
        if (!input) { input = document.createElement('input'); input.type = 'hidden'; input.name = name; form.appendChild(input); }
        input.value = value;
        return input;
    };
    const removeHidden = name => hidden(name)?.remove();
    const setImages = url => {
        if (!url) return;
        if (preview) preview.src = url;
        if (summary) summary.src = url;
    };
    const remoteStyle = () => {
        const value = String(select.value || '');
        if (value === DEFAULT_VALUE) return defaultSource === 'remote' ? defaultGroup : 'dylan';
        return value.startsWith(LOCAL_PREFIX) ? (defaultSource === 'remote' ? defaultGroup : 'dylan') : value;
    };
    const remoteSeed = () => String(seedInput.value || '1');

    let source = current.source === 'local' ? 'local' : (current.source === 'default' ? 'default' : 'remote');
    let localGroup = source === 'local' ? String(current.group || '') : '';
    let localSeed = source === 'local' ? Number(current.seed || 1) : 1;
    let remoteOptionsHtml = options.innerHTML;

    // 核心的空 value“默认”固定等价于 Dylan；插件的“默认”必须表示
    // “后台当前配置的新用户默认头像”，因此使用独立的虚拟值，避免被核心
    // avatar_style 逻辑误认为 Dylan。提交时仍由 hidden source=default 告诉服务端
    // 真实来源是动态默认头像。
    const DEFAULT_VALUE = '__avatar_library_default__';
    const coreDefaultOption = [...select.options].find(option => option.value === '');
    if (coreDefaultOption) coreDefaultOption.remove();
    const defaultOption = document.createElement('option');
    defaultOption.value = DEFAULT_VALUE;
    defaultOption.textContent = defaultLabel;
    defaultOption.dataset.avatarLibraryDefault = '1';
    select.insertBefore(defaultOption, select.firstChild);

    Object.entries(groups).forEach(([key, meta]) => {
        const opt = document.createElement('option');
        opt.value = LOCAL_PREFIX + key;
        opt.textContent = String(meta.name || key);
        opt.dataset.avatarLibraryLocal = '1';
        opt.dataset.avatarLibraryGroup = key;
        select.appendChild(opt);
    });

    const clearLocalFields = () => {
        removeHidden('avatar_library_form_source');
        removeHidden('avatar_library_form_group');
        removeHidden('avatar_library_form_seed');
    };
    const setLocalFields = (group, seed) => {
        ensureHidden('avatar_library_form_source', 'local');
        ensureHidden('avatar_library_form_group', group);
        ensureHidden('avatar_library_form_seed', String(seed));
    };

    const renderRemoteOptions = () => {
        options.innerHTML = remoteOptionsHtml;
        const active = options.querySelector(`.avatar-option[data-seed="${CSS.escape(remoteSeed())}"]`) || options.querySelector('.avatar-option.active');
        options.querySelectorAll('.avatar-option').forEach(x => x.classList.toggle('active', x === active));
    };

    const renderLocalOptions = group => {
        options.innerHTML = '';
        const meta = groups[group];
        if (!meta) return;
        (meta.seeds || []).forEach(seed => {
            const n = Number(seed);
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'avatar-option' + (n === localSeed ? ' active' : '');
            button.dataset.seed = String(n);
            const img = document.createElement('img');
            img.className = 'avatar-img';
            img.src = localUrl(group, n);
            img.alt = '';
            img.loading = 'lazy';
            button.appendChild(img);
            button.addEventListener('click', () => {
                source = 'local';
                localGroup = group;
                localSeed = n;
                select.value = LOCAL_PREFIX + group;
                seedInput.value = String(n);
                setLocalFields(localGroup, localSeed);
                options.querySelectorAll('.avatar-option').forEach(x => x.classList.toggle('active', x === button));
                setImages(img.src);
            });
            options.appendChild(button);
        });
    };

    const chooseLocal = (group, seed) => {
        const meta = groups[group];
        if (!meta) return;
        source = 'local';
        localGroup = group;
        localSeed = Number(seed || meta.seeds?.[0] || 1);
        select.value = LOCAL_PREFIX + group;
        seedInput.value = String(localSeed);
        setLocalFields(localGroup, localSeed);
        renderLocalOptions(localGroup);
        setImages(localUrl(localGroup, localSeed));
    };

    const chooseRemote = () => {
        source = 'remote';
        localGroup = '';
        // 明确告诉服务端：这次是用户主动切换到远程。
        // 这里不能再由 renderRemoteOptions() 清理 hidden，否则“本地 -> 远程”
        // 时 after_save 无法确认这是一次真实的远程来源切换。
        ensureHidden('avatar_library_form_source', 'remote');
        ensureHidden('avatar_library_form_group', String(select.value || 'dylan'));
        ensureHidden('avatar_library_form_seed', remoteSeed());
        renderRemoteOptions();
    };

    // 捕获阶段接管本地头像格子的点击，必须阻止核心脚本继续执行 refreshAvatarPicker()；
    // 否则核心会把 __avatar_library_local__:group 当作 DiceBear style，产生幽灵 URL。
    options.addEventListener('click', event => {
        if (source !== 'local') return;
        const button = event.target.closest('.avatar-option');
        if (!button || !options.contains(button)) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        const seed = Number(button.dataset.seed || 1);
        localSeed = seed;
        seedInput.value = String(seed);
        setLocalFields(localGroup, localSeed);
        options.querySelectorAll('.avatar-option').forEach(x => x.classList.toggle('active', x === button));
        setImages(localUrl(localGroup, localSeed));
    }, true);

    // 捕获阶段拦截本地选项，避免核心脚本把虚拟值当作 DiceBear style。
    select.addEventListener('change', event => {
        const value = String(select.value || '');

        // “默认”是插件自己的动态默认值，不能使用核心空 value，因为核心会把
        // 空 value 当作 Dylan。这里在捕获阶段接管，保证后台改成任意远程/本地组后，
        // 用户选择器中的“默认”始终明确表示“当前后台默认头像”。
        if (value === DEFAULT_VALUE) {
            event.preventDefault();
            event.stopImmediatePropagation();
            source = 'default';
            localGroup = '';
            clearLocalFields();
            ensureHidden('avatar_library_form_source', 'default');
            removeHidden('avatar_library_form_group');
            removeHidden('avatar_library_form_seed');
            seedInput.value = '1';
            const defaultIsLocal = defaultSource === 'local' && groups[defaultGroup];
            if (defaultIsLocal) {
                localGroup = defaultGroup;
                localSeed = 1;
                renderLocalOptions(defaultGroup);
            } else {
                renderRemoteOptions();
                options.querySelectorAll('.avatar-option').forEach(x => x.classList.remove('active'));
            }
            setImages(String(cfg.dataset.avatarLibraryDefaultUrl || ''));
            return;
        }

        if (!value.startsWith(LOCAL_PREFIX)) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        const group = value.slice(LOCAL_PREFIX.length);
        chooseLocal(group, groups[group]?.seeds?.[0] || 1);
    }, true);

    // 远程选择仍然使用核心选择器；这里显式记录 remote 来源。
    select.addEventListener('change', () => {
        const value = String(select.value || '');
        if (value === DEFAULT_VALUE || value.startsWith(LOCAL_PREFIX)) return;
        chooseRemote();
    });

    // 远程头像格子点击时，核心会只更新 avatar_seed。
    // 插件同时把当前来源明确记为 remote，避免 local hidden 状态残留。
    options.addEventListener('click', event => {
        const button = event.target.closest('.avatar-option');
        if (!button || !options.contains(button)) return;
        if (source === 'local') return;
        source = 'remote';
        localGroup = '';
        ensureHidden('avatar_library_form_source', 'remote');
        ensureHidden('avatar_library_form_group', remoteStyle());
        ensureHidden('avatar_library_form_seed', String(button.dataset.seed || '1'));
    });

    // 页面首次打开：
    // 1. local：显示本地组；
    // 2. remote：显示远程组；
    // 3. default：明确选中“默认”，并把后台当前配置的默认头像作为预览。
    //    hidden source=default 保证保存后仍跟随后台默认头像组，而不是固化当前组。
    if (source === 'local' && localGroup && groups[localGroup]) {
        chooseLocal(localGroup, localSeed);
    } else if (source === 'default') {
        const defaultGroupKey = String(defaultGroup || '');
        const defaultIsLocal = defaultSource === 'local' && groups[defaultGroupKey];

        source = 'default';
        localGroup = defaultIsLocal ? defaultGroupKey : '';
        localSeed = 1;
        select.value = DEFAULT_VALUE;
        ensureHidden('avatar_library_form_source', 'default');
        removeHidden('avatar_library_form_group');
        removeHidden('avatar_library_form_seed');
        seedInput.value = '1';

        if (defaultIsLocal) {
            renderLocalOptions(defaultGroupKey);
        } else {
            renderRemoteOptions();
            options.querySelectorAll('.avatar-option').forEach(x => x.classList.remove('active'));
        }
        setImages(String(cfg.dataset.avatarLibraryDefaultUrl || ''));
    } else {
        source = 'remote';
        const style = String(current.group || select.value || 'dylan');
        if (style && [...select.options].some(o => o.value === style)) select.value = style;
        const seed = Number(current.seed || seedInput.value || 1);
        seedInput.value = String(seed);
        ensureHidden('avatar_library_form_source', 'remote');
        ensureHidden('avatar_library_form_group', style || 'dylan');
        ensureHidden('avatar_library_form_seed', String(seed));
        renderRemoteOptions();
    }

    // 不再依赖额外 AJAX。
    // 核心 save_user() 只接受合法的远程 avatar_style；本地头像的真实来源
    // 由下面三个 hidden 字段保存，user.before_save 保留 fallback，
    // user.after_save 再把 local/group/seed 写入插件表。
    if (form) form.addEventListener('submit', event => {
        if (source === 'default') {
            // 当前仍是默认来源时，不需要提交一个不存在的“默认”option。
            // 核心字段使用后台默认对应的有效远程 fallback。
            ensureHidden('avatar_library_form_source', 'default');
            removeHidden('avatar_library_form_group');
            removeHidden('avatar_library_form_seed');
            if (defaultSource === 'remote' && [...select.options].some(o => o.value === defaultGroup)) {
                select.value = defaultGroup;
            } else if (defaultSource === 'local') {
                const fallback = String(current.group || 'dylan');
                if ([...select.options].some(o => o.value === fallback)) select.value = fallback;
                else select.value = 'dylan';
            }
            seedInput.value = '1';
            return;
        }
        if (source !== 'local' || !localGroup) return;

        setLocalFields(localGroup, localSeed);

        let fallback = String(current.group || '');
        if (!fallback || fallback.startsWith(LOCAL_PREFIX) || ![...select.options].some(o => o.value === fallback)) {
            fallback = defaultSource === 'remote' ? defaultGroup : 'dylan';
        }

        // 关键：POST 给核心的 avatar_style 永远不能是 __avatar_library_local__:*。
        // 只在提交瞬间替换，页面上的本地头像选择状态仍由插件变量维护。
        if (String(select.value || '').startsWith(LOCAL_PREFIX)) {
            select.value = fallback;
        }
    });

    // 上传头像功能保持原有能力。
    // 把自定义上传面板放进核心头像选择器的“修改”展开区域。
    // 这样它会跟随 data-profile-edit 的展开/收起状态显示。
    const uploadPanel = profileSlot.querySelector('[data-avatar-library-upload-panel]');
    const profileDetail = profileSlot.querySelector('[data-profile-edit]');
    if (uploadPanel && profileDetail) {
        profileDetail.appendChild(uploadPanel);
        uploadPanel.hidden = false;
    }

    const uploadInput = document.querySelector('[data-avatar-library-upload-input]');
    const deleteUpload = document.querySelector('[data-avatar-library-delete-upload]');
    const panel = document.querySelector('[data-avatar-library-upload-panel]');
    const modal = panel?.querySelector('[data-avatar-library-crop-modal]');
    const canvas = modal?.querySelector('[data-avatar-library-crop-canvas]');
    const zoom = modal?.querySelector('[data-avatar-library-crop-zoom]');
    const save = modal?.querySelector('[data-avatar-library-crop-save]');
    const status = panel?.querySelector('[data-avatar-library-status]');
    const ctx2d = canvas?.getContext('2d');
    let image=null, objectUrl='', scale=1, minScale=1, x=0, y=0, dragging=false, px=0, py=0;
    const setStatus = (text, error=false) => { if(status){status.textContent=text;status.classList.toggle('error',error);} };
    const clamp=()=>{if(!image||!canvas)return;x=Math.min(0,Math.max(canvas.width-image.naturalWidth*scale,x));y=Math.min(0,Math.max(canvas.height-image.naturalHeight*scale,y));};
    const draw=()=>{if(!ctx2d||!canvas||!image)return;clamp();ctx2d.clearRect(0,0,canvas.width,canvas.height);ctx2d.drawImage(image,x,y,image.naturalWidth*scale,image.naturalHeight*scale);};
    const closeCrop=()=>{if(modal)modal.hidden=true;if(uploadInput)uploadInput.value='';if(objectUrl)URL.revokeObjectURL(objectUrl);objectUrl='';image=null;};
    uploadInput?.addEventListener('change',()=>{const file=uploadInput.files?.[0];if(!file||!file.type.startsWith('image/'))return setStatus('请选择图片文件',true);if(file.size>10*1024*1024)return setStatus('原图不能超过10MB',true);objectUrl=URL.createObjectURL(file);const next=new Image();next.onload=()=>{image=next;minScale=Math.max(canvas.width/image.naturalWidth,canvas.height/image.naturalHeight);scale=minScale;x=(canvas.width-image.naturalWidth*scale)/2;y=(canvas.height-image.naturalHeight*scale)/2;zoom.value='100';draw();modal.hidden=false;};next.onerror=()=>{closeCrop();setStatus('图片读取失败',true)};next.src=objectUrl;});
    zoom?.addEventListener('input',()=>{if(!image)return;const old=scale;scale=minScale*Number(zoom.value||100)/100;const cx=canvas.width/2,cy=canvas.height/2;x=cx-(cx-x)*scale/old;y=cy-(cy-y)*scale/old;draw();});
    canvas?.addEventListener('pointerdown',e=>{if(!image)return;dragging=true;px=e.clientX;py=e.clientY;canvas.classList.add('dragging');canvas.setPointerCapture(e.pointerId);});
    canvas?.addEventListener('pointermove',e=>{if(!dragging)return;const ratio=canvas.width/canvas.getBoundingClientRect().width;x+=(e.clientX-px)*ratio;y+=(e.clientY-py)*ratio;px=e.clientX;py=e.clientY;draw();});
    const stopDrag=()=>{dragging=false;canvas?.classList.remove('dragging')};canvas?.addEventListener('pointerup',stopDrag);canvas?.addEventListener('pointercancel',stopDrag);
    modal?.querySelectorAll('[data-avatar-library-crop-close]').forEach(button=>button.addEventListener('click',closeCrop));
    save?.addEventListener('click',()=>{if(!image)return;const output=document.createElement('canvas');output.width=output.height=200;const out=output.getContext('2d');out.fillStyle='#fff';out.fillRect(0,0,200,200);out.drawImage(image,-x/scale,-y/scale,canvas.width/scale,canvas.height/scale,0,0,200,200);save.disabled=true;output.toBlob(async blob=>{try{if(!blob)throw new Error('头像生成失败');const body=new FormData();body.append('_csrf',form?.querySelector('input[name="_csrf"]')?.value||'');body.append('avatar_library_action','upload');body.append('avatar',blob,'avatar.jpg');const response=await fetch(route,{method:'POST',body,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});const data=await response.json();if(!data.ok)throw new Error(data.message||'头像上传失败');window.location.href=data.redirect||window.location.href}catch(error){setStatus(error?.message||'头像上传失败',true);closeCrop()}finally{save.disabled=false}},'image/jpeg',.9);});
    deleteUpload?.addEventListener('click',async()=>{deleteUpload.disabled=true;setStatus('正在恢复头像库…');try{const body=new FormData();body.append('_csrf',form?.querySelector('input[name="_csrf"]')?.value||'');body.append('avatar_library_action','delete_upload');const response=await fetch(route,{method:'POST',body,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});const data=await response.json();if(!data.ok)throw new Error(data.message||'恢复失败');window.location.href=data.redirect||window.location.href}catch(error){setStatus(error?.message||'恢复失败',true);deleteUpload.disabled=false}});




})();
JS;
}


return [
    'id' => 'avatar_library',
    'name' => '本地头像plus',
    'version' => AVATAR_LIBRARY_VERSION,
    'description' => '统一管理远程头像、本地头像组、用户自定义头像，并可在后台更换论坛图标。',
    'author' => 'bbc',
    'install' => 'avatar_library_install',
    'uninstall' => 'avatar_library_uninstall',
    'assets' => ['css' => 'avatar_library_css', 'js' => 'avatar_library_js'],
    'hooks' => [
        'app.boot' => 'avatar_library_boot',
        'avatar.url' => 'avatar_library_avatar_url',
        'avatar.picker' => 'avatar_library_picker',
        'user.before_save' => 'avatar_library_user_before_save',
        'page.before_render' => 'avatar_library_page_before_render',
        'page.head' => 'avatar_library_page_head',
        'user.after_save' => 'avatar_library_user_after_save',
        'content.before_delete' => 'avatar_library_delete_user_selection',
        'profile.after_form' => 'avatar_library_profile_html',
    ],
    'routes' => ['avatar_library' => 'avatar_library_route'],
    'admin_tabs' => ['avatar_library' => 'avatar_library_admin_page'],
];