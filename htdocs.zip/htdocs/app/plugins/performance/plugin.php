<?php
if (!defined('APP_ROOT')) exit;

function performance_config_defaults(): array
{
    return [
        'page_cache_enabled' => '1',
        'page_cache_ttl' => '300',
        'greedy_cache_enabled' => '1',
        'stale_cache_seconds' => '15',
        'query_cache_enabled' => '1',
        'query_cache_ttl' => '600',
        'cache_max_files' => '500',
        'cache_wait_ms' => '150',
        'compression_enabled' => '1',
        'image_optimization_enabled' => '1',
        'render_optimization_enabled' => '1',
        'resource_hints_enabled' => '1',
        'sqlite_tuning_enabled' => '1',
        'sqlite_cache_mb' => '8',
    ];
}

function performance_config(): array
{
    static $config;
    if (is_array($config)) return $config;
    $raw = plugin_config('performance', []);
    return $config = [
        'page_cache_enabled' => (string)($raw['page_cache_enabled'] ?? '1') === '1',
        'page_cache_ttl' => max(30, min(3600, (int)($raw['page_cache_ttl'] ?? 300))),
        'greedy_cache_enabled' => (string)($raw['greedy_cache_enabled'] ?? '1') === '1',
        'stale_cache_seconds' => max(0, min(60, (int)($raw['stale_cache_seconds'] ?? 15))),
        'query_cache_enabled' => (string)($raw['query_cache_enabled'] ?? '1') === '1',
        'query_cache_ttl' => max(30, min(3600, (int)($raw['query_cache_ttl'] ?? 600))),
        'cache_max_files' => max(50, min(5000, (int)($raw['cache_max_files'] ?? 500))),
        'cache_wait_ms' => max(0, min(500, (int)($raw['cache_wait_ms'] ?? 150))),
        'compression_enabled' => (string)($raw['compression_enabled'] ?? '1') === '1',
        'image_optimization_enabled' => (string)($raw['image_optimization_enabled'] ?? '1') === '1',
        'render_optimization_enabled' => (string)($raw['render_optimization_enabled'] ?? '1') === '1',
        'resource_hints_enabled' => (string)($raw['resource_hints_enabled'] ?? '1') === '1',
        'sqlite_tuning_enabled' => (string)($raw['sqlite_tuning_enabled'] ?? '1') === '1',
        'sqlite_cache_mb' => max(2, min(64, (int)($raw['sqlite_cache_mb'] ?? 8))),
    ];
}

function performance_cache_dir(): string
{
    static $dir;
    return $dir ??= DATA_DIR . '/plugin-performance-cache';
}

function performance_cache_protect_dir(): void
{
    $dir = performance_cache_dir();
    $files = [
        '/index.html' => '',
        '/.htaccess' => "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n",
        '/web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><security><authorization><remove users=\"*\" roles=\"\" verbs=\"\"/><add accessType=\"Deny\" users=\"*\"/></authorization></security></system.webServer></configuration>\n",
    ];
    foreach ($files as $suffix => $content) {
        $file = $dir . $suffix;
        if (!is_file($file)) @file_put_contents($file, $content, LOCK_EX);
    }
}

function performance_cache_format(): string
{
    return 'performance-cache-format-13';
}

function performance_cache_version_key(string $scope = 'global', int $id = 0): string
{
    if (!in_array($scope, ['global', 'query', 'home', 'forum', 'topic', 'route'], true)) throw new InvalidArgumentException('缓存版本范围无效');
    if (in_array($scope, ['forum', 'topic', 'route'], true)) {
        if ($id < 1) throw new InvalidArgumentException('缓存版本对象无效');
        return $scope . '-' . $id;
    }
    return $scope;
}

function performance_cache_version_file(string $scope = 'global', int $id = 0): string
{
    $key = performance_cache_version_key($scope, $id);
    return performance_cache_dir() . ($key === 'global' ? '/version' : '/version-' . $key);
}

function performance_cache_dir_ready(): bool
{
    $dir = performance_cache_dir();
    $created = !is_dir($dir);
    $ready = (!$created || @mkdir($dir, 0755, true)) && is_writable($dir);
    if ($ready && $created) performance_cache_protect_dir();
    return $ready;
}

function performance_cache_files(): array
{
    $files =& $GLOBALS['__performance_cache_files'];
    if (is_array($files)) return $files;
    $files = [];
    foreach (['/public-*.html', '/private-*.html', '/query-*.json'] as $pattern) {
        foreach (glob(performance_cache_dir() . $pattern, GLOB_NOSORT) ?: [] as $file) $files[$file] = true;
    }
    return $files;
}

function performance_cache_file_remember(string $file): void
{
    $files =& $GLOBALS['__performance_cache_files'];
    if (is_array($files)) $files[$file] = true;
}

function performance_cache_file_forget(string $file): void
{
    $files =& $GLOBALS['__performance_cache_files'];
    if (is_array($files)) unset($files[$file]);
}

function performance_cache_files_reset(): void
{
    unset($GLOBALS['__performance_cache_files']);
}

function performance_cache_make_room(string $target): bool
{
    $dir = rtrim(str_replace('\\', '/', performance_cache_dir()), '/');
    if (dirname(str_replace('\\', '/', $target)) !== $dir) return false;
    if (is_file($target)) {
        performance_cache_file_remember($target);
        return true;
    }
    $files = performance_cache_files();
    $limit = (int)performance_config()['cache_max_files'];
    if (count($files) < $limit) return true;
    $oldest = [];
    foreach (array_keys($files) as $file) {
        if (!is_file($file)) {
            unset($files[$file]);
            performance_cache_file_forget($file);
            continue;
        }
        if ($file !== $target) $oldest[$file] = (int)@filemtime($file);
    }
    if (count($files) < $limit) return true;
    asort($oldest, SORT_NUMERIC);
    foreach (array_keys($oldest) as $file) {
        if (@unlink($file)) {
            performance_cache_file_forget($file);
            return true;
        }
    }
    return false;
}

function performance_cache_version(string $scope = 'global', int $id = 0, bool $refresh = false): string
{
    $key = performance_cache_version_key($scope, $id);
    $versions =& $GLOBALS['__performance_cache_versions'];
    if (!is_array($versions)) $versions = [];
    if (!$refresh && is_string($versions[$key] ?? null)) return $versions[$key];
    $value = trim((string)@file_get_contents(performance_cache_version_file($scope, $id)));
    if (!preg_match('/^[a-zA-Z0-9._-]{1,80}$/D', $value)) $value = '1';
    return $versions[$key] = $value;
}

function performance_cache_invalidate(string $scope = 'global', int $id = 0): void
{
    $key = performance_cache_version_key($scope, $id);
    $invalidated =& $GLOBALS['__performance_cache_invalidated'];
    if (!is_array($invalidated)) $invalidated = [];
    if (!empty($invalidated[$key])) return;
    $invalidated[$key] = true;
    if (!performance_cache_dir_ready()) return;
    try {
        $version = time() . '-' . bin2hex(random_bytes(6));
    } catch (Throwable) {
        $version = time() . '-' . mt_rand(100000, 999999);
    }
    $file = performance_cache_version_file($scope, $id);
    $tmp = $file . '.tmp.' . substr(hash('sha256', $version), 0, 12);
    if (@file_put_contents($tmp, $version, LOCK_EX) !== false) {
        if (!@rename($tmp, $file)) {
            if (is_file($file)) @unlink($file);
            if (!@rename($tmp, $file)) @unlink($tmp);
        }
    }
    $GLOBALS['__performance_cache_versions'][$key] = $version;
}

function performance_cache_invalidate_many(array $targets): void
{
    $seen = [];
    foreach ($targets as $target) {
        if (!is_array($target)) continue;
        $scope = (string)($target[0] ?? '');
        $id = max(0, (int)($target[1] ?? 0));
        $key = $scope . ':' . $id;
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        performance_cache_invalidate($scope, $id);
    }
}

function performance_page_version(string $action, int $id): string
{
    $parts = [performance_cache_format(), performance_cache_version('global')];
    if ($action === 'home') $parts[] = performance_cache_version('home');
    elseif ($action === 'forum') $parts[] = performance_cache_version('forum', $id);
    else $parts[] = performance_cache_version('topic', $id);
    return hash('sha256', implode('|', $parts));
}

function performance_query_cache_version(string $key, bool $refresh = false): string
{
    $parts = [performance_cache_format(), performance_cache_version('query', 0, $refresh)];
    if (preg_match('/^topic-(\d+)$/D', $key, $match)) {
        $parts[] = performance_cache_version('route', (int)$match[1], $refresh);
    } elseif (preg_match('/^data-index-home-0-[a-f0-9]{32}$/D', $key)) {
        $parts[] = performance_cache_version('global', 0, $refresh);
        $parts[] = performance_cache_version('home', 0, $refresh);
    } elseif (preg_match('/^data-index-forum-(\d+)-[a-f0-9]{32}$/D', $key, $match)) {
        $parts[] = performance_cache_version('global', 0, $refresh);
        $parts[] = performance_cache_version('forum', (int)$match[1], $refresh);
    } elseif (preg_match('/^data-replies-(\d+)-[a-f0-9]{32}$/D', $key, $match)) {
        $parts[] = performance_cache_version('global', 0, $refresh);
        $parts[] = performance_cache_version('topic', (int)$match[1], $refresh);
    }
    return hash('sha256', implode('|', $parts));
}

function performance_cache_clear(): int
{
    $removed = 0;
    $dir = performance_cache_dir();
    performance_cache_files_reset();
    unset($GLOBALS['__performance_cache_invalidated']);
    performance_cache_invalidate_many([['global'], ['query']]);
    foreach (['/public-*.html', '/private-*.html', '/query-*.json'] as $pattern) {
        foreach (glob($dir . $pattern, GLOB_NOSORT) ?: [] as $file) {
            if (is_file($file) && @unlink($file)) $removed++;
        }
    }
    foreach (glob($dir . '/*.tmp*', GLOB_NOSORT) ?: [] as $file) {
        if (is_file($file)) @unlink($file);
    }
    foreach (glob($dir . '/*.lock', GLOB_NOSORT) ?: [] as $file) {
        if (performance_cache_lock_remove_if_unused($file)) $removed++;
    }
    return $removed;
}

function performance_remove_cache_dir(): void
{
    $dir = performance_cache_dir();
    if (!is_dir($dir)) {
        performance_cache_files_reset();
        return;
    }
    foreach (scandir($dir, SCANDIR_SORT_NONE) ?: [] as $name) {
        if ($name === '.' || $name === '..') continue;
        $file = $dir . '/' . $name;
        if (is_file($file)) @unlink($file);
    }
    @rmdir($dir);
    performance_cache_files_reset();
}

function performance_remove_obsolete_private_cache(): void
{
    foreach (glob(performance_cache_dir() . '/private-*.html', GLOB_NOSORT) ?: [] as $file) {
        if (is_file($file)) @unlink($file);
    }
    foreach (glob(performance_cache_dir() . '/private-*.html.lock', GLOB_NOSORT) ?: [] as $file) {
        performance_cache_lock_remove_if_unused($file);
    }
    performance_cache_files_reset();
}

function performance_remove_obsolete_data_cache(): void
{
    foreach (glob(performance_cache_dir() . '/query-data-*.json', GLOB_NOSORT) ?: [] as $file) {
        if (is_file($file)) @unlink($file);
    }
    foreach (glob(performance_cache_dir() . '/query-data-*.json.lock', GLOB_NOSORT) ?: [] as $file) {
        performance_cache_lock_remove_if_unused($file);
    }
    performance_cache_files_reset();
}

function performance_install(array $plugin): void
{
    if (!performance_cache_dir_ready()) throw new RuntimeException('性能优化缓存目录不可写。');
    performance_cache_protect_dir();
    $current = is_array($plugin['config'] ?? null) ? $plugin['config'] : [];
    $config = performance_config_defaults();
    foreach ($config as $name => $default) {
        if (array_key_exists($name, $current)) $config[$name] = (string)$current[$name];
    }
    if ($config !== $current) plugin_update_row('performance', ['config_json' => $config]);
    performance_remove_obsolete_private_cache();
    performance_remove_obsolete_data_cache();
    if (!is_file(performance_cache_version_file())) performance_cache_invalidate();
    if (!is_file(performance_cache_version_file('query'))) performance_cache_invalidate('query');
}

function performance_uninstall(array $plugin): void
{
    performance_remove_cache_dir();
}

function performance_debug_mode(): bool
{
    return setting('debug_mode', '0') === '1';
}

function performance_query_cache_file(string $key): string
{
    if (preg_match('/^[a-z0-9][a-z0-9-]{0,80}$/D', $key) !== 1) throw new InvalidArgumentException('查询缓存键无效');
    return performance_cache_dir() . '/query-' . $key . '.json';
}

function performance_query_cache_get(string $key): ?array
{
    $config = performance_config();
    if (performance_debug_mode()) {
        $GLOBALS['__performance_query_cache_status'] = 'BYPASS-DEBUG';
        return null;
    }
    if (!$config['query_cache_enabled']) {
        $GLOBALS['__performance_query_cache_status'] = 'BYPASS';
        return null;
    }
    $file = performance_query_cache_file($key);
    if (!performance_cache_fresh($file, (int)$config['query_cache_ttl'], (bool)$config['greedy_cache_enabled'])) {
        $GLOBALS['__performance_query_cache_status'] = 'MISS';
        return null;
    }
    $payload = json_decode((string)@file_get_contents($file), true);
    if (!is_array($payload) || !hash_equals(performance_query_cache_version($key), (string)($payload['version'] ?? '')) || !is_array($payload['data'] ?? null)) {
        $GLOBALS['__performance_query_cache_status'] = 'MISS';
        return null;
    }
    $GLOBALS['__performance_query_cache_status'] = 'HIT';
    return $payload['data'];
}

function performance_cache_sanitize_data(array $data): array
{
    foreach ($data as $key => $value) {
        if (is_string($key)) {
            $name = strtolower($key);
            if (preg_match('/(?:^|_)(?:password|passwd|email|auth_token|access_token|refresh_token|session_token|cookie|secret)(?:_|$)/D', $name)) {
                unset($data[$key]);
                continue;
            }
        }
        if (is_array($value)) $data[$key] = performance_cache_sanitize_data($value);
    }
    return $data;
}

function performance_query_cache_set(string $key, array $data, ?string $expected_version = null): void
{
    if (performance_debug_mode() || !performance_config()['query_cache_enabled'] || !performance_cache_dir_ready()) return;
    $file = performance_query_cache_file($key);
    if (!performance_cache_make_room($file)) return;
    try {
        $suffix = bin2hex(random_bytes(4));
        $version = performance_query_cache_version($key, $expected_version !== null);
        if ($expected_version !== null && !hash_equals($expected_version, $version)) return;
        $data = performance_cache_sanitize_data($data);
        $json = plugin_json_encode(['version' => $version, 'data' => $data]);
    } catch (Throwable) {
        return;
    }
    $tmp = $file . '.tmp.' . $suffix;
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return;
    if (@rename($tmp, $file)) {
        performance_cache_file_remember($file);
        return;
    }
    if (is_file($file)) @unlink($file);
    if (@rename($tmp, $file)) performance_cache_file_remember($file);
    else @unlink($tmp);
}

function performance_normalize_vary_state(mixed $state): array
{
    if (!is_array($state)) return [];
    $normalized = [];
    foreach (array_slice($state, 0, 32, true) as $name => $value) {
        $name = substr((string)$name, 0, 80);
        if ($name === '') continue;
        if (is_scalar($value) || $value === null) $serialized = (string)$value;
        elseif (is_array($value)) $serialized = serialize($value);
        else continue;
        $normalized[$name] = hash('sha256', $serialized);
    }
    ksort($normalized);
    return $normalized;
}

function performance_data_hooks_exclusive(array $names): bool
{
    $registry = is_array($GLOBALS['__hook_registry'] ?? null) ? $GLOBALS['__hook_registry'] : hook_registry();
    foreach ($names as $name) {
        foreach ((array)($registry[$name] ?? []) as $entry) {
            if ((string)($entry['plugin']['id'] ?? '') !== 'performance') return false;
        }
    }
    return true;
}

function performance_member_data_cache_context(string $kind, array $ctx): ?array
{
    if (uid() < 1 || performance_debug_mode() || !performance_config()['query_cache_enabled']) return null;
    $hooks = $kind === 'index'
        ? ['topic.index_data.load', 'topic.index_data.loaded']
        : ['topic.replies_data.load', 'topic.replies_data.loaded'];
    if (!performance_data_hooks_exclusive($hooks)) return null;
    $context = ['scope' => 'member_data', 'kind' => $kind, 'user_id' => uid()] + $ctx;
    if (hook('performance.data_cacheable', true, $context) !== true) return null;
    $context['vary'] = performance_normalize_vary_state(hook('performance.data_cache_vary', [], $context));
    return $context;
}

function performance_index_data_cache_base(array $ctx): ?array
{
    if (($ctx['user'] ?? null) !== null || trim((string)($ctx['query'] ?? '')) !== '') return null;
    $forum_id = max(0, (int)($ctx['forum_id'] ?? 0));
    $sort = (string)($ctx['sort'] ?? 'comment');
    $page = max(1, (int)($ctx['page'] ?? 1));
    $size = max(1, (int)($ctx['page_size'] ?? 0));
    $offset = max(0, (int)($ctx['offset'] ?? 0));
    if (!in_array($sort, ['comment', 'post'], true) || $page > 1000 || $size > 200 || $offset !== ($page - 1) * $size) return null;
    return ['forum_id' => $forum_id, 'sort' => $sort, 'page' => $page, 'page_size' => $size, 'offset' => $offset];
}

function performance_index_data_cache_identity(array $ctx): ?array
{
    $base = performance_index_data_cache_base($ctx);
    if ($base === null) return null;
    $context = performance_member_data_cache_context('index', $base);
    if ($context === null) return null;
    $forum_id = (int)$base['forum_id'];
    $scope = $forum_id > 0 ? 'forum' : 'home';
    $identity = [
        'format' => performance_cache_format(),
        'app_version' => APP_VERSION,
        'pinned_topic_ids' => (string)setting('pinned_topic_ids'),
        'data' => $base,
        'vary' => $context['vary'],
    ];
    $hash = substr(hash('sha256', serialize($identity)), 0, 32);
    $token = 'index-' . hash('sha256', serialize([$base, uid()]));
    return ['key' => 'data-index-' . $scope . '-' . $forum_id . '-' . $hash, 'token' => $token];
}

function performance_replies_data_cache_base(array $ctx): ?array
{
    $topic = is_array($ctx['topic'] ?? null) ? $ctx['topic'] : [];
    $topic_id = max(0, (int)($topic['id'] ?? 0));
    $page = max(1, (int)($ctx['page'] ?? 1));
    $size = max(1, (int)($ctx['page_size'] ?? 0));
    $offset = max(0, (int)($ctx['offset'] ?? 0));
    $order = (int)($ctx['reply_order'] ?? 0) === 1 ? 1 : 0;
    if ($topic_id < 1 || $page > 1000 || $size > 500 || $offset !== ($page - 1) * $size) return null;
    return ['topic_id' => $topic_id, 'page' => $page, 'page_size' => $size, 'offset' => $offset, 'reply_order' => $order];
}

function performance_replies_data_cache_identity(array $ctx): ?array
{
    $base = performance_replies_data_cache_base($ctx);
    if ($base === null) return null;
    $context = performance_member_data_cache_context('replies', $base);
    if ($context === null) return null;
    $topic_id = (int)$base['topic_id'];
    $identity = [
        'format' => performance_cache_format(),
        'app_version' => APP_VERSION,
        'data' => $base,
        'vary' => $context['vary'],
    ];
    $hash = substr(hash('sha256', serialize($identity)), 0, 32);
    $token = 'replies-' . hash('sha256', serialize([$base, uid()]));
    return ['key' => 'data-replies-' . $topic_id . '-' . $hash, 'token' => $token];
}

function performance_index_data_valid(array $data): bool
{
    if (!is_array($data['rows'] ?? null)) return false;
    foreach (['total', 'profile_empty', 'unread_total', 'simple_pagination', 'has_next_page'] as $field) {
        if (!array_key_exists($field, $data)) return false;
    }
    return true;
}

function performance_replies_data_valid(array $data): bool
{
    return is_array($data['topic'] ?? null) && is_array($data['replies'] ?? null);
}

function performance_data_cache_register_shutdown(): void
{
    static $registered = false;
    if ($registered) return;
    $registered = true;
    register_shutdown_function(static function (): void {
        foreach ((array)($GLOBALS['__performance_data_cache_writers'] ?? []) as $pending) {
            performance_cache_lock_release($pending['lock'] ?? null, true);
        }
        unset($GLOBALS['__performance_data_cache_writers']);
    });
}

function performance_data_cache_load(string $token, string $key, callable $valid): ?array
{
    $data = performance_query_cache_get($key);
    if (is_array($data) && $valid($data)) return $data;
    if (is_array($data)) {
        $file = performance_query_cache_file($key);
        @unlink($file);
        performance_cache_file_forget($file);
    }
    if (!performance_cache_dir_ready()) return null;
    $file = performance_query_cache_file($key);
    $lock = @fopen($file . '.lock', 'c');
    if (!is_resource($lock)) return null;
    if (@flock($lock, LOCK_EX | LOCK_NB)) {
        $GLOBALS['__performance_data_cache_writers'][$token] = [
            'key' => $key,
            'version' => performance_query_cache_version($key, true),
            'lock' => $lock,
        ];
        performance_data_cache_register_shutdown();
        return null;
    }
    $wait_ms = (int)performance_config()['cache_wait_ms'];
    $deadline = microtime(true) + $wait_ms / 1000;
    while ($wait_ms > 0 && microtime(true) < $deadline) {
        usleep(25000);
        $data = performance_query_cache_get($key);
        if (is_array($data) && $valid($data)) break;
    }
    performance_cache_lock_release($lock);
    return is_array($data) && $valid($data) ? $data : null;
}

function performance_data_cache_store(string $token, array $data): void
{
    $pending =& $GLOBALS['__performance_data_cache_writers'];
    if (!is_array($pending) || !is_array($pending[$token] ?? null)) return;
    $writer = $pending[$token];
    unset($pending[$token]);
    performance_query_cache_set((string)$writer['key'], $data, (string)$writer['version']);
    performance_cache_lock_release($writer['lock'] ?? null, true);
}

function performance_topic_index_data_load(mixed $value = null, array $ctx = []): mixed
{
    if ($value !== null) return null;
    $identity = performance_index_data_cache_identity($ctx);
    if ($identity === null) return null;
    return performance_data_cache_load((string)$identity['token'], (string)$identity['key'], 'performance_index_data_valid');
}

function performance_topic_index_data_loaded(mixed $value = null, array $ctx = []): mixed
{
    if (!is_array($value) || !performance_index_data_valid($value)) return $value;
    $base = performance_index_data_cache_base($ctx);
    if ($base !== null) performance_data_cache_store('index-' . hash('sha256', serialize([$base, uid()])), $value);
    return $value;
}

function performance_topic_replies_data_load(mixed $value = null, array $ctx = []): mixed
{
    if ($value !== null) return null;
    $identity = performance_replies_data_cache_identity($ctx);
    if ($identity === null) return null;
    $data = performance_data_cache_load((string)$identity['token'], (string)$identity['key'], 'performance_replies_data_valid');
    if (!is_array($data)) return null;
    $current_topic = is_array($ctx['topic'] ?? null) ? $ctx['topic'] : [];
    $data['topic'] = $current_topic + $data['topic'];
    return $data;
}

function performance_topic_replies_data_loaded(mixed $value = null, array $ctx = []): mixed
{
    if (!is_array($value) || !performance_replies_data_valid($value)) return $value;
    $base = performance_replies_data_cache_base($ctx);
    if ($base !== null) performance_data_cache_store('replies-' . hash('sha256', serialize([$base, uid()])), $value);
    return $value;
}

function performance_route_context(string $action, int $id): ?array
{
    if ($action === 'home') return ['forum_id' => 0];
    if ($action === 'forum') {
        $forum = forum_by_id($id);
        if (!$forum || !forum_group_allowed($forum, 'allow_view_groups')) return null;
        return ['forum_id' => $id];
    }
    $query = performance_query_cache_get('topic-' . $id);
    $forum_id = max(0, (int)($query['forum_id'] ?? 0));
    if ($forum_id < 1) {
        $topic = row('app_topics', 'id', $id);
        if (!$topic) return null;
        $forum_id = (int)$topic['forum_id'];
        performance_query_cache_set('topic-' . $id, ['forum_id' => $forum_id]);
    }
    $forum = forum_by_id($forum_id);
    if (!$forum || !forum_group_allowed($forum, 'allow_view_groups')) return null;
    return ['forum_id' => (int)$forum['id']];
}

function performance_cache_vary_state(string $action, int $id, int $forum_id): array
{
    $state = hook('performance.cache_vary', [], [
        'scope' => 'public',
        'action' => $action,
        'id' => $id,
        'forum_id' => $forum_id,
        'user_id' => 0,
    ]);
    return performance_normalize_vary_state($state);
}

function performance_effective_cookie_state(string $action, int $id, int $forum_id, string $sort): array
{
    $cookies = [];
    if (in_array($action, ['home', 'forum'], true)) {
        $cookies['topic_sort'] = in_array($sort, ['comment', 'post'], true)
            ? $sort
            : (((string)($_COOKIE['__topic_index_sort'] ?? 'comment') === 'post') ? 'post' : 'comment');
    }
    $vary = performance_cache_vary_state($action, $id, $forum_id);
    if ($vary) $cookies['plugins'] = $vary;
    ksort($cookies);
    return $cookies;
}

function performance_render_version(): string
{
    static $version;
    if (is_string($version)) return $version;
    $settings = [];
    foreach (['site_name', 'site_name_title', 'site_base_url', 'site_description', 'site_keywords', 'allow_register', 'pretty_url', 'pc_nav_forum_count', 'topics_per_page', 'replies_per_page', 'pinned_topic_ids', 'cache_forums', 'cache_groups', 'cache_plugins', 'plugin_assets_css_hash', 'plugin_assets_js_hash'] as $name) {
        $settings[$name] = setting($name);
    }
    return $version = hash('sha256', APP_VERSION . '|' . serialize($settings));
}

function performance_later_boot_plugin(): string
{
    if (!function_exists('hook_registry')) return '';
    $registry = is_array($GLOBALS['__hook_registry'] ?? null) ? $GLOBALS['__hook_registry'] : hook_registry();
    $seen = false;
    foreach ((array)($registry['app.boot'] ?? []) as $entry) {
        $plugin_id = (string)($entry['plugin']['id'] ?? '');
        if ($plugin_id === 'performance') {
            $seen = true;
            continue;
        }
        if ($seen && $plugin_id !== '') return $plugin_id;
    }
    return '';
}

function performance_cache_request(): ?array
{
    if (PHP_SAPI === 'cli' || strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') return null;
    if (headers_sent()) return null;
    if (performance_debug_mode()) return null;
    if (ajax_request() || isset($_SERVER['HTTP_AUTHORIZATION']) || trim((string)($_GET['q'] ?? '')) !== '') return null;
    $action = (string)($_GET['a'] ?? 'home');
    if (!in_array($action, ['home', 'forum', 'topic'], true)) return null;
    $allowed = ['a' => true, 'id' => true, 'p' => true, 'replyid' => true, 'floor' => true, 'sort' => true];
    foreach (array_keys($_GET) as $key) if (!isset($allowed[(string)$key])) return null;
    $id = max(0, (int)($_GET['id'] ?? 0));
    $page = max(1, (int)($_GET['p'] ?? 1));
    $reply_id = max(0, (int)($_GET['replyid'] ?? 0));
    $floor = max(0, (int)($_GET['floor'] ?? 0));
    $sort = (string)($_GET['sort'] ?? '');
    if ($page > 1000 || ($sort !== '' && !in_array($sort, ['comment', 'post'], true))) return null;
    if (in_array($action, ['forum', 'topic'], true) && $id < 1) return null;
    if ($reply_id > 0 || $floor > 0) return null;
    if ($action === 'home' && $id > 0) return null;
    if ($action === 'topic' && $sort !== '') return null;
    foreach (['__flash', '__form_error', '__auth_return_url'] as $cookie) {
        if (trim((string)($_COOKIE[$cookie] ?? '')) !== '') return null;
    }
    $config = performance_config();
    if (!$config['page_cache_enabled'] || uid() > 0) return null;
    if (performance_later_boot_plugin() !== '') return null;
    $route = performance_route_context($action, $id);
    if ($route === null) return null;
    $cache_context = ['scope' => 'public', 'action' => $action, 'id' => $id, 'forum_id' => (int)$route['forum_id'], 'page' => $page, 'sort' => $sort];
    if (hook('performance.cacheable', true, $cache_context) !== true) return null;
    $query = ['a' => $action, 'id' => $id, 'p' => $page, 'sort' => $sort];
    $origin = strtolower(base_url());
    if (strlen($origin) > 300) return null;
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    $identity = ['cookies' => performance_effective_cookie_state($action, $id, (int)$route['forum_id'], $sort)];
    $page_version = performance_page_version($action, $id);
    $render_version = performance_render_version();
    $variant_source = $render_version . '|' . $origin . '|' . $script . '|' . http_build_query($query) . '|' . serialize($identity);
    $variant = substr(hash('sha256', $variant_source), 0, 24);
    $key = hash('sha256', $page_version . '|' . $variant_source);
    $route_id = $action === 'home' ? 0 : $id;
    $file_prefix = performance_cache_dir() . '/public-' . $action . '-' . $route_id . '-' . substr($render_version, 0, 12) . '-' . $variant . '-';
    return [
        'file' => $file_prefix . $key . '.html',
        'stale_pattern' => $file_prefix . '*.html',
        'ttl' => (int)$config['page_cache_ttl'],
        'greedy' => (bool)$config['greedy_cache_enabled'],
        'stale_seconds' => (int)$config['stale_cache_seconds'],
        'action' => $action,
        'id' => $id,
        'forum_id' => (int)$route['forum_id'],
        'sort' => $sort,
    ];
}

function performance_start_compression(): void
{
    $config = performance_config();
    if (!$config['compression_enabled'] || PHP_SAPI === 'cli' || headers_sent()) return;
    if (!function_exists('ob_gzhandler') || stripos((string)($_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''), 'gzip') === false) return;
    $zlib = strtolower(trim((string)ini_get('zlib.output_compression')));
    if (in_array($zlib, ['1', 'on', 'yes', 'true'], true) || in_array('ob_gzhandler', ob_list_handlers(), true)) return;
    @ob_start('ob_gzhandler');
}

function performance_database_tune(): void
{
    $config = performance_config();
    if (!$config['sqlite_tuning_enabled'] || db_driver() !== 'sqlite') return;
    try {
        $cache_kb = (int)$config['sqlite_cache_mb'] * 1024;
        $mmap_bytes = min(268435456, max(16777216, (int)$config['sqlite_cache_mb'] * 8388608));
        db()->exec('PRAGMA cache_size=-' . $cache_kb);
        db()->exec('PRAGMA mmap_size=' . $mmap_bytes);
    } catch (Throwable $e) {
        debug_log_write('性能优化 SQLite 参数设置失败', $e);
    }
}

function performance_set_cookie_header_safe(string $header): bool
{
    if (!preg_match('/^set-cookie:\s*([^=;\s]+)=/i', $header, $match)) return false;
    return in_array(strtolower((string)$match[1]), ['__recent_forums', '__viewed_topics', '__topic_index_sort'], true);
}

function performance_recent_forums_placeholder(): string
{
    return '<!--performance-recent-forums-->';
}

function performance_footer_placeholder(string $title): string
{
    return '<!--performance-footer:' . rtrim(strtr(base64_encode($title), '+/', '-_'), '=') . '-->';
}

function performance_cached_page_title(string $html): string
{
    if ((string)($_GET['a'] ?? 'home') === 'home') return '首页';
    if (!preg_match('~<title>(.*?)</title>~is', $html, $match)) return '';
    $title = html_entity_decode(strip_tags((string)$match[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $site_title = trim((string)setting('site_name_title')) ?: trim((string)setting('site_name')) ?: 'FORUM';
    $suffix = ' - ' . $site_title;
    return str_ends_with($title, $suffix) ? substr($title, 0, -strlen($suffix)) : $title;
}

function performance_prepare_cached_html(string $html): ?string
{
    $prepared = $html;
    if (str_contains($prepared, '最近浏览版块')) {
        $pattern = '~<div class="card sidebar-card quick-card"><div class="quick-wrap"><div class="quick-title">最近浏览版块</div><ul class="quick-links quick-forum-links">.*?</ul></div></div>~s';
        $prepared = preg_replace($pattern, performance_recent_forums_placeholder(), $prepared, 1, $count);
        if (!is_string($prepared) || $count !== 1) return null;
    }
    $prepared = preg_replace('~<footer class="footer">.*?</footer>~s', performance_footer_placeholder(performance_cached_page_title($prepared)), $prepared, 1, $footer_count);
    return is_string($prepared) && $footer_count === 1 ? $prepared : null;
}

function performance_expand_cached_html(string $html, array $cache): string
{
    $html = str_replace(performance_recent_forums_placeholder(), quick_forums_html(), $html);
    $html = (string)preg_replace_callback('~(<span\b[^>]*\bdata-performance-time=")(\d{1,12})("[^>]*>).*?(</span>)~is', static function (array $match): string {
        $timestamp = max(0, (int)$match[2]);
        return (string)$match[1] . $timestamp . (string)$match[3] . human_time($timestamp) . (string)$match[4];
    }, $html);
    return (string)preg_replace_callback('~<!--performance-footer:([A-Za-z0-9_-]*)-->~', static function (array $match) use ($cache): string {
        $encoded = (string)$match[1];
        $padding = (4 - strlen($encoded) % 4) % 4;
        $title = base64_decode(strtr($encoded, '-_', '+/') . str_repeat('=', $padding), true);
        $ctx = [
            'title' => is_string($title) ? $title : '',
            'performance_cache_hit' => true,
            'action' => (string)($cache['action'] ?? ''),
            'id' => max(0, (int)($cache['id'] ?? 0)),
            'forum_id' => max(0, (int)($cache['forum_id'] ?? 0)),
        ];
        return '<footer class="footer">' . (string)hook('page.footer', '', $ctx) . '</footer>';
    }, $html, 1);
}

function performance_response_cacheable(string $html): bool
{
    if (http_response_code() !== 200 || strlen($html) < 256 || !str_starts_with(ltrim($html), '<!doctype html>')) return false;
    $error = error_get_last();
    if ($error && in_array((int)($error['type'] ?? 0), [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) return false;
    if (str_contains($html, 'form-error-panel')) return false;
    if (preg_match('/<form\b[^>]*\bmethod\s*=\s*["\']?post\b/i', $html)) return false;
    if (preg_match('/<[^>]+\bclass\s*=\s*["\'][^"\']*\bpoll-card\b/i', $html)) return false;
    foreach (headers_list() as $header) {
        $lower = strtolower($header);
        if (str_starts_with($lower, 'set-cookie:') && !performance_set_cookie_header_safe($header)) return false;
        if (str_starts_with($lower, 'cache-control:') && (str_contains($lower, 'private') || str_contains($lower, 'no-store'))) return false;
    }
    return true;
}

function performance_restore_request_state(array $cache): void
{
    $action = (string)($cache['action'] ?? '');
    $id = max(0, (int)($cache['id'] ?? 0));
    $forum_id = max(0, (int)($cache['forum_id'] ?? 0));
    if ($forum_id > 0) remember_forum($forum_id);
    if ($action === 'topic' && mark_viewed($id)) {
        try {
            q('UPDATE app_topics SET view_count=view_count+1 WHERE id=?', [$id]);
        } catch (Throwable $e) {
            debug_log_write('性能优化浏览计数更新失败', $e);
        }
    }
    $sort = (string)($cache['sort'] ?? '');
    if (in_array($sort, ['comment', 'post'], true)) {
        app_cookie('__topic_index_sort', $sort, time() + COOKIE_TTL, false);
        $_COOKIE['__topic_index_sort'] = $sort;
    }
}

function performance_cache_fresh(string $file, int $ttl, bool $greedy = false): bool
{
    clearstatcache(true, $file);
    $stat = @stat($file);
    return is_array($stat) && (int)($stat['size'] ?? 0) > 0 && ($greedy || (int)($stat['mtime'] ?? 0) >= time() - $ttl);
}

function performance_page_cache_fresh(array $cache): bool
{
    return performance_cache_fresh((string)($cache['file'] ?? ''), (int)($cache['ttl'] ?? 0), !empty($cache['greedy']));
}

function performance_stale_cache_file(array $cache): string
{
    $seconds = max(0, (int)($cache['stale_seconds'] ?? 0));
    $pattern = (string)($cache['stale_pattern'] ?? '');
    $current = (string)($cache['file'] ?? '');
    $action = (string)($cache['action'] ?? '');
    $id = max(0, (int)($cache['id'] ?? 0));
    if ($seconds < 1 || $pattern === '' || !in_array($action, ['home', 'forum', 'topic'], true)) return '';
    $invalidated_at = performance_page_version_mtime($action, $action === 'home' ? 0 : $id);
    if ($invalidated_at < time() - $seconds) return '';
    $candidates = [];
    foreach (glob($pattern, GLOB_NOSORT) ?: [] as $file) {
        if ($file === $current || !is_file($file) || (int)@filesize($file) < 1) continue;
        $candidates[$file] = (int)@filemtime($file);
    }
    if (!$candidates) return '';
    arsort($candidates, SORT_NUMERIC);
    return (string)array_key_first($candidates);
}

function performance_cache_etag(string $file, string $html): string
{
    $semantic = preg_replace('~<footer class="footer">.*?</footer>~s', '<footer class="footer"><!--performance-footer--></footer>', $html, 1);
    $content_hash = hash('sha256', is_string($semantic) ? $semantic : $html);
    return 'W/"performance-' . substr(hash('sha256', basename($file) . '|' . $content_hash), 0, 24) . '"';
}

function performance_cache_etag_matches(string $etag): bool
{
    $header = trim((string)($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''));
    if ($header === '') return false;
    if ($header === '*') return true;
    $target = preg_replace('/^W\//i', '', trim($etag));
    foreach (explode(',', $header) as $candidate) {
        if (preg_replace('/^W\//i', '', trim($candidate)) === $target) return true;
    }
    return false;
}

function performance_cache_headers(array $cache, string $status, string $etag = ''): void
{
    header('Cache-Control: public, no-cache, must-revalidate');
    header('Vary: Cookie, Accept-Encoding', false);
    header('X-Performance-Cache: ' . $status);
    header('X-Performance-Cache-Scope: public');
    $query_status = trim((string)($GLOBALS['__performance_query_cache_status'] ?? ''));
    if ($query_status !== '') header('X-Performance-Query-Cache: ' . $query_status);
    header('X-Performance-Cache-Mode: ' . (!empty($cache['greedy']) ? 'GREEDY' : 'TTL'));
    if (function_exists('sql_query_count')) header('X-Performance-SQL-Queries: ' . sql_query_count());
    if ($etag !== '') header('ETag: ' . $etag);
}

function performance_cache_serve(array $cache, string $status = 'HIT'): void
{
    $file = (string)$cache['file'];
    $html = @file_get_contents($file);
    if (!is_string($html) || $html === '') return;
    performance_restore_request_state($cache);
    $html = performance_expand_cached_html($html, $cache);
    $etag = performance_cache_etag($file, $html);
    header('Content-Type: text/html; charset=utf-8');
    performance_cache_headers($cache, $status, $etag);
    if ($status === 'STALE') header('Warning: 110 - "Response is stale"');
    header('Age: ' . max(0, time() - (int)@filemtime($file)));
    if (performance_cache_etag_matches($etag)) {
        http_response_code(304);
        exit;
    }
    echo $html;
    exit;
}

function performance_cache_serve_stale(array $cache): void
{
    $file = performance_stale_cache_file($cache);
    if ($file === '') return;
    $cache['file'] = $file;
    performance_cache_serve($cache, 'STALE');
}

function performance_cache_lock_file_valid(string $file): bool
{
    $dir = rtrim(str_replace('\\', '/', performance_cache_dir()), '/');
    $path = str_replace('\\', '/', $file);
    return dirname($path) === $dir && str_ends_with(basename($path), '.lock');
}

function performance_cache_lock_release(mixed $lock, bool $remove = false): bool
{
    if (!is_resource($lock)) return false;
    $meta = stream_get_meta_data($lock);
    $file = (string)($meta['uri'] ?? '');
    $valid = $remove && performance_cache_lock_file_valid($file);
    $removed = $valid && is_file($file) && @unlink($file);
    @flock($lock, LOCK_UN);
    @fclose($lock);
    if (!$removed && $valid && is_file($file)) $removed = @unlink($file);
    return $removed;
}

function performance_cache_lock_remove_if_unused(string $file): bool
{
    if (!performance_cache_lock_file_valid($file) || !is_file($file)) return false;
    $lock = @fopen($file, 'c');
    if (!is_resource($lock)) return false;
    if (!@flock($lock, LOCK_EX | LOCK_NB)) {
        performance_cache_lock_release($lock);
        return false;
    }
    return performance_cache_lock_release($lock, true);
}

function performance_cache_write(string $file, string $html): bool
{
    if (!performance_cache_dir_ready()) return false;
    if (!performance_cache_make_room($file)) return false;
    try {
        $suffix = bin2hex(random_bytes(4));
    } catch (Throwable) {
        $suffix = (string)mt_rand(100000, 999999);
    }
    $tmp = $file . '.tmp.' . $suffix;
    if (@file_put_contents($tmp, $html, LOCK_EX) === false) return false;
    if (@rename($tmp, $file)) {
        performance_cache_file_remember($file);
        return true;
    }
    if (is_file($file)) @unlink($file);
    if (@rename($tmp, $file)) {
        performance_cache_file_remember($file);
        return true;
    }
    @unlink($tmp);
    return false;
}

function performance_page_cache_boot(): void
{
    $cache = performance_cache_request();
    if ($cache === null) return;
    $file = (string)$cache['file'];
    if (performance_page_cache_fresh($cache)) performance_cache_serve($cache);
    if (!performance_cache_dir_ready()) {
        performance_cache_serve_stale($cache);
        return;
    }
    $lock = @fopen($file . '.lock', 'c');
    if (!is_resource($lock)) {
        performance_cache_serve_stale($cache);
        return;
    }
    if (!@flock($lock, LOCK_EX | LOCK_NB)) {
        performance_cache_serve_stale($cache);
        $wait_ms = (int)performance_config()['cache_wait_ms'];
        $deadline = microtime(true) + $wait_ms / 1000;
        while ($wait_ms > 0 && microtime(true) < $deadline) {
            usleep(25000);
            if (performance_page_cache_fresh($cache)) {
                performance_cache_lock_release($lock);
                performance_cache_lock_remove_if_unused($file . '.lock');
                performance_cache_serve($cache);
            }
        }
        if (performance_page_cache_fresh($cache)) {
            performance_cache_lock_release($lock);
            performance_cache_lock_remove_if_unused($file . '.lock');
            performance_cache_serve($cache);
        }
        performance_cache_lock_release($lock);
        performance_cache_lock_remove_if_unused($file . '.lock');
        return;
    }
    $buffer = '';
    $started = @ob_start(function (string $chunk, int $phase) use ($file, $cache, $lock, &$buffer): string {
        if (($phase & PHP_OUTPUT_HANDLER_CLEAN) !== 0) {
            $buffer = '';
            if (($phase & PHP_OUTPUT_HANDLER_FINAL) !== 0) performance_cache_lock_release($lock, true);
            return '';
        }
        $buffer .= $chunk;
        if (($phase & PHP_OUTPUT_HANDLER_FINAL) === 0) return '';
        $html = $buffer;
        $buffer = '';
        $prepared = performance_response_cacheable($html) ? performance_prepare_cached_html($html) : null;
        $stored = is_string($prepared) && performance_cache_write($file, $prepared);
        if ($stored && !headers_sent()) performance_cache_headers($cache, 'MISS', performance_cache_etag($file, $html));
        performance_cache_lock_release($lock, true);
        return $html;
    });
    if (!$started) performance_cache_lock_release($lock, true);
}

function performance_boot($value = null, array $ctx = []): mixed
{
    performance_start_compression();
    performance_page_cache_boot();
    performance_database_tune();
    return $value;
}

function performance_topic_cache_targets(int $topic_id, int $forum_id): array
{
    $targets = [['home']];
    if ($forum_id > 0) $targets[] = ['forum', $forum_id];
    if ($topic_id > 0) $targets[] = ['topic', $topic_id];
    return $targets;
}

function performance_invalidate_filter(mixed $value = null, array $ctx = []): mixed
{
    $targets = [];
    if (is_array($ctx['targets'] ?? null)) {
        foreach ($ctx['targets'] as $target) {
            if (!is_array($target)) continue;
            $targets[] = [
                (string)($target['scope'] ?? $target[0] ?? ''),
                max(0, (int)($target['id'] ?? $target[1] ?? 0)),
            ];
        }
    } elseif (max(0, (int)($ctx['topic_id'] ?? 0)) > 0) {
        $topic_id = max(0, (int)$ctx['topic_id']);
        $forum_id = max(0, (int)($ctx['forum_id'] ?? 0));
        if ($forum_id < 1) {
            $topic = row('app_topics', 'id', $topic_id);
            $forum_id = max(0, (int)($topic['forum_id'] ?? 0));
        }
        $targets = performance_topic_cache_targets($topic_id, $forum_id);
        if (!empty($ctx['route_changed'])) $targets[] = ['route', $topic_id];
    } else {
        $scope = (string)($ctx['scope'] ?? 'global');
        if ($scope === 'all') $targets = [['global'], ['query']];
        else $targets[] = [$scope, max(0, (int)($ctx['id'] ?? 0))];
    }
    $valid = ['global' => false, 'query' => false, 'home' => false, 'forum' => true, 'topic' => true, 'route' => true];
    $normalized = [];
    foreach ($targets as $target) {
        $scope = (string)($target[0] ?? '');
        $id = max(0, (int)($target[1] ?? 0));
        if (!array_key_exists($scope, $valid) || ($valid[$scope] && $id < 1)) continue;
        $normalized[] = [$scope, $id];
    }
    if ($normalized) performance_cache_invalidate_many($normalized);
    return $value;
}

function performance_topic_before_save(mixed $value = null, array $ctx = []): mixed
{
    $topic_id = max(0, (int)($ctx['id'] ?? 0));
    if ($topic_id < 1) return $value;
    $topic = row('app_topics', 'id', $topic_id);
    if (!$topic) return $value;
    $forum_id = max(0, (int)($topic['forum_id'] ?? 0));
    $GLOBALS['__performance_topic_old_forum'][$topic_id] = $forum_id;
    $action = (string)($ctx['action'] ?? '');
    if ($action === 'mute_author') performance_cache_invalidate('global');
    elseif (in_array($action, ['pin', 'unpin', 'highlight'], true)) performance_cache_invalidate_many(performance_topic_cache_targets($topic_id, $forum_id));
    return $value;
}

function performance_topic_after_save(mixed $value = null, array $ctx = []): mixed
{
    $topic_id = max(0, (int)($ctx['id'] ?? 0));
    $forum_id = max(0, (int)($ctx['forum_id'] ?? 0));
    if ($topic_id < 1 || $forum_id < 1) return $value;
    $old_forum_id = max(0, (int)($GLOBALS['__performance_topic_old_forum'][$topic_id] ?? 0));
    unset($GLOBALS['__performance_topic_old_forum'][$topic_id]);
    $targets = performance_topic_cache_targets($topic_id, $forum_id);
    if ($old_forum_id > 0 && $old_forum_id !== $forum_id) {
        $targets[] = ['forum', $old_forum_id];
        $targets[] = ['route', $topic_id];
    }
    performance_cache_invalidate_many($targets);
    return $value;
}

function performance_reply_after_save(mixed $value = null, array $ctx = []): mixed
{
    $topic_id = max(0, (int)($ctx['topic_id'] ?? 0));
    if ($topic_id < 1) return $value;
    $topic = row('app_topics', 'id', $topic_id);
    performance_cache_invalidate_many(performance_topic_cache_targets($topic_id, max(0, (int)($topic['forum_id'] ?? 0))));
    return $value;
}

function performance_user_after_save(mixed $value = null, array $ctx = []): mixed
{
    performance_cache_invalidate('global');
    return $value;
}

function performance_content_before_delete(mixed $value = null, array $ctx = []): mixed
{
    $table = (string)($ctx['table'] ?? '');
    $record = is_array($ctx['row'] ?? null) ? $ctx['row'] : [];
    if ($table === 'topics') {
        $topic_id = max(0, (int)($record['id'] ?? 0));
        $targets = performance_topic_cache_targets($topic_id, max(0, (int)($record['forum_id'] ?? 0)));
        if ($topic_id > 0) $targets[] = ['route', $topic_id];
        performance_cache_invalidate_many($targets);
    } elseif ($table === 'replies') {
        $topic_id = max(0, (int)($record['topic_id'] ?? 0));
        $topic = $topic_id > 0 ? row('app_topics', 'id', $topic_id) : null;
        performance_cache_invalidate_many(performance_topic_cache_targets($topic_id, max(0, (int)($topic['forum_id'] ?? 0))));
    } elseif ($table === 'users') {
        performance_cache_invalidate('global');
    }
    return $value;
}

function performance_render_images($html, array $ctx): ?string
{
    $rendered = (string)$html;
    $changed = false;
    $row = is_array($ctx['row'] ?? null) ? $ctx['row'] : [];
    if (!str_contains($rendered, 'data-performance-time=') && $row) {
        if (!empty($ctx['list'])) {
            $sort = (string)($ctx['sort'] ?? 'comment');
            $timestamp = (int)($row['time'] ?? ($sort === 'post' ? ($row['created_at'] ?? 0) : (($row['last_reply_at'] ?? 0) ?: ($row['created_at'] ?? 0))));
        } else {
            $timestamp = (int)($row['created_at'] ?? 0);
        }
        if ($timestamp > 0) {
            $marked = performance_mark_time_placeholder($rendered, $timestamp);
            if ($marked !== null) {
                $rendered = $marked;
                $changed = true;
            }
        }
    }
    if (performance_config()['image_optimization_enabled'] && stripos($rendered, '<img') !== false) {
        $images = preg_replace_callback('/<img\b[^>]*>/i', static function (array $match): string {
            $tag = (string)$match[0];
            $attributes = '';
            if (!preg_match('/\bloading\s*=/i', $tag)) $attributes .= ' loading="lazy"';
            if (!preg_match('/\bdecoding\s*=/i', $tag)) $attributes .= ' decoding="async"';
            if (preg_match('/\bloading\s*=\s*["\']?lazy\b/i', $tag . $attributes) && !preg_match('/\bfetchpriority\s*=/i', $tag)) $attributes .= ' fetchpriority="low"';
            if ($attributes === '') return $tag;
            return (string)preg_replace('/\s*(\/?)>$/', $attributes . '$1>', $tag, 1);
        }, $rendered);
        if (is_string($images) && $images !== $rendered) {
            $rendered = $images;
            $changed = true;
        }
    }
    return $changed ? $rendered : null;
}

function performance_mark_time_placeholder(string $html, int $timestamp): ?string
{
    $marker = ' data-performance-time="' . $timestamp . '"';
    $marked = preg_replace('~(<div class="post-meta">(?:(?!</div>).)*?<span)(?=>[^<]*</span>)~s', '$1' . $marker, $html, 1, $count);
    return is_string($marked) && $count === 1 ? $marked : null;
}

function performance_page_before_render($body, array $ctx): string
{
    $body = (string)$body;
    if (!performance_config()['render_optimization_enabled'] || str_contains($body, 'performance-render-root')) return $body;
    return (string)preg_replace('/^(\s*<div class=")([^"]*)"/', '$1$2 performance-render-root"', $body, 1);
}

function performance_page_head($html, array $ctx): string
{
    $html = (string)$html;
    if (!performance_config()['resource_hints_enabled']) return $html;
    return $html . '<link rel="dns-prefetch" href="//api.dicebear.com"><link rel="preconnect" href="https://api.dicebear.com" crossorigin>';
}

function performance_page_cache_file_route(string $file): ?array
{
    if (!preg_match('/^public-(home|forum|topic)-(\d+)-([a-f0-9]{12})-([a-f0-9]{24})-[a-f0-9]{64}\.html$/D', basename($file), $match)) return null;
    $action = (string)$match[1];
    $id = (int)$match[2];
    if (($action === 'home' && $id !== 0) || ($action !== 'home' && $id < 1)) return null;
    return ['action' => $action, 'id' => $id, 'render' => (string)$match[3], 'variant' => (string)$match[4]];
}

function performance_page_version_mtime(string $action, int $id): int
{
    $mtime = max(0, (int)@filemtime(performance_cache_version_file()));
    if ($action === 'home') return max($mtime, (int)@filemtime(performance_cache_version_file('home')));
    if ($action === 'forum') return max($mtime, (int)@filemtime(performance_cache_version_file('forum', $id)));
    if ($action === 'topic') return max($mtime, (int)@filemtime(performance_cache_version_file('topic', $id)));
    return $mtime;
}

function performance_cache_prune(array $plugin = [], array $task = []): string
{
    performance_cache_files_reset();
    $config = performance_config();
    $files = [];
    $removed = 0;
    $now = time();
    foreach (glob(performance_cache_dir() . '/private-*.html', GLOB_NOSORT) ?: [] as $file) {
        if (is_file($file) && @unlink($file)) $removed++;
    }
    foreach (glob(performance_cache_dir() . '/public-*.html', GLOB_NOSORT) ?: [] as $file) {
        if (!is_file($file)) continue;
        $mtime = (int)@filemtime($file);
        $route = performance_page_cache_file_route($file);
        if ($route === null) {
            if (@unlink($file)) $removed++;
            continue;
        }
        if (!hash_equals(substr(performance_render_version(), 0, 12), (string)$route['render'])) {
            if (@unlink($file)) $removed++;
            continue;
        }
        if ($config['greedy_cache_enabled']) {
            $invalidated_at = performance_page_version_mtime((string)$route['action'], (int)$route['id']);
            $expired = $mtime < $invalidated_at && ($config['stale_cache_seconds'] < 1 || $invalidated_at < $now - (int)$config['stale_cache_seconds']);
        } else {
            $expired = $mtime < $now - (int)$config['page_cache_ttl'];
        }
        if ($expired) {
            if (@unlink($file)) $removed++;
            continue;
        }
        $files[$file] = $mtime;
    }
    foreach (glob(performance_cache_dir() . '/query-*.json', GLOB_NOSORT) ?: [] as $file) {
        if (!is_file($file)) continue;
        $mtime = (int)@filemtime($file);
        $expired = $mtime < $now - (int)$config['query_cache_ttl'];
        if ($config['greedy_cache_enabled']) {
            $payload = json_decode((string)@file_get_contents($file), true);
            $name = basename($file);
            $key = str_starts_with($name, 'query-') && str_ends_with($name, '.json') ? substr($name, 6, -5) : '';
            $expired = $key === '' || !is_array($payload) || !hash_equals(performance_query_cache_version($key), (string)($payload['version'] ?? ''));
        }
        if ($expired) {
            if (@unlink($file)) $removed++;
            continue;
        }
        $files[$file] = $mtime;
    }
    if (count($files) > (int)$config['cache_max_files']) {
        asort($files, SORT_NUMERIC);
        $overflow = count($files) - (int)$config['cache_max_files'];
        foreach (array_keys($files) as $file) {
            if ($overflow-- <= 0) break;
            if (@unlink($file)) $removed++;
        }
    }
    foreach (glob(performance_cache_dir() . '/*.tmp*', GLOB_NOSORT) ?: [] as $file) {
        if (is_file($file) && (int)@filemtime($file) < $now - 600) @unlink($file);
    }
    foreach (glob(performance_cache_dir() . '/*.lock', GLOB_NOSORT) ?: [] as $file) {
        if (!is_file($file)) continue;
        if (performance_cache_lock_remove_if_unused($file)) $removed++;
    }
    return '清理页面与查询缓存 ' . $removed . ' 个';
}

function performance_database_optimize(array $plugin = [], array $task = []): string
{
    if (!performance_config()['sqlite_tuning_enabled'] || db_driver() !== 'sqlite') return '当前数据库无需插件维护';
    try {
        db()->exec('PRAGMA optimize');
        return 'SQLite 查询规划已优化';
    } catch (Throwable $e) {
        debug_log_write('性能优化 SQLite 维护失败', $e);
        throw $e;
    }
}

function performance_cache_stats(): array
{
    $pages = 0;
    $query = 0;
    $locks = 0;
    $bytes = 0;
    foreach (glob(performance_cache_dir() . '/public-*.html', GLOB_NOSORT) ?: [] as $file) {
        if (!is_file($file)) continue;
        if (performance_page_cache_file_route($file) === null) continue;
        $pages++;
        $bytes += max(0, (int)@filesize($file));
    }
    foreach (glob(performance_cache_dir() . '/query-*.json', GLOB_NOSORT) ?: [] as $file) {
        if (!is_file($file)) continue;
        $query++;
        $bytes += max(0, (int)@filesize($file));
    }
    foreach (glob(performance_cache_dir() . '/*.lock', GLOB_NOSORT) ?: [] as $file) {
        if (is_file($file)) $locks++;
    }
    return ['pages' => $pages, 'query' => $query, 'locks' => $locks, 'bytes' => $bytes];
}

function performance_format_bytes(int $bytes): string
{
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return number_format($bytes / 1024, 1) . ' KB';
    return number_format($bytes / 1048576, 1) . ' MB';
}

function performance_admin_page(array $plugin): string
{
    need_admin();
    if (is_post_request()) {
        require_post();
        $action = (string)($_POST['performance_action'] ?? 'save');
        if ($action === 'clear') {
            $removed = performance_cache_clear();
            set_flash('已清理 ' . $removed . ' 个缓存文件');
        } elseif ($action === 'save') {
            $config = [
                'page_cache_enabled' => isset($_POST['page_cache_enabled']) ? '1' : '0',
                'page_cache_ttl' => (string)max(30, min(3600, (int)($_POST['page_cache_ttl'] ?? 300))),
                'greedy_cache_enabled' => isset($_POST['greedy_cache_enabled']) ? '1' : '0',
                'stale_cache_seconds' => (string)max(0, min(60, (int)($_POST['stale_cache_seconds'] ?? 15))),
                'query_cache_enabled' => isset($_POST['query_cache_enabled']) ? '1' : '0',
                'query_cache_ttl' => (string)max(30, min(3600, (int)($_POST['query_cache_ttl'] ?? 600))),
                'cache_max_files' => (string)max(50, min(5000, (int)($_POST['cache_max_files'] ?? 500))),
                'cache_wait_ms' => (string)max(0, min(500, (int)($_POST['cache_wait_ms'] ?? 150))),
                'compression_enabled' => isset($_POST['compression_enabled']) ? '1' : '0',
                'image_optimization_enabled' => isset($_POST['image_optimization_enabled']) ? '1' : '0',
                'render_optimization_enabled' => isset($_POST['render_optimization_enabled']) ? '1' : '0',
                'resource_hints_enabled' => isset($_POST['resource_hints_enabled']) ? '1' : '0',
                'sqlite_tuning_enabled' => isset($_POST['sqlite_tuning_enabled']) ? '1' : '0',
                'sqlite_cache_mb' => (string)max(2, min(64, (int)($_POST['sqlite_cache_mb'] ?? 8))),
            ];
            plugin_save_config('performance', $config);
            performance_cache_clear();
            set_flash('性能优化设置已保存');
        } else err('参数错误');
        go(admin_url(['tab' => 'performance']));
    }
    $config = performance_config();
    $stats = performance_cache_stats();
    $opcache = function_exists('opcache_get_status') && filter_var(ini_get('opcache.enable'), FILTER_VALIDATE_BOOL);
    $gzip = function_exists('ob_gzhandler');
    $writable = performance_cache_dir_ready();
    $debug_mode = performance_debug_mode();
    $engine = ['sqlite' => 'SQLite', 'mysql' => 'MySQL', 'pgsql' => 'PostgreSQL'][db_driver()] ?? db_driver();
    $cards = [
        ['匿名缓存', $config['page_cache_enabled'] ? '已开启' : '已关闭', $config['page_cache_enabled']],
        ['公开页面文件', (int)$stats['pages'] . ' 个', true],
        ['SQL 数据缓存', $config['query_cache_enabled'] ? (int)$stats['query'] . ' 个' : '已关闭', $config['query_cache_enabled']],
        ['并发锁文件', (int)$stats['locks'] . ' 个', (int)$stats['locks'] === 0],
        ['缓存体积', performance_format_bytes((int)$stats['bytes']), true],
        ['Gzip 支持', $gzip ? '可用' : '不可用', $gzip],
        ['OPcache', $opcache ? '已开启' : '未开启', $opcache],
        ['数据库', $engine, true],
        ['站点 Debug 模式', $debug_mode ? '全部缓存绕过' : '未开启', !$debug_mode],
        ['目录写入', $writable ? '正常' : '不可写', $writable],
    ];
    $summary = '<div class="performance-status-grid">';
    foreach ($cards as [$label, $value, $ok]) {
        $summary .= '<div class="performance-status-card"><span>' . h($label) . '</span><strong class="' . ($ok ? 'is-ok' : 'is-off') . '">' . h($value) . '</strong></div>';
    }
    $summary .= '</div>';
    $form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'performance'])) . '">' . form_token() . '<input type="hidden" name="performance_action" value="save">';
    $form .= '<h3 class="plugin-panel-title">页面缓存</h3>';
    $form .= checkbox('匿名公开页缓存', 'page_cache_enabled', (bool)$config['page_cache_enabled'], '共享缓存首页、版块页和帖子页，排序状态单独隔离，最近浏览版块、相对时间和页脚插件在命中时动态生成；登录、搜索、AJAX、定位链接、表单、投票页、提示页面和站点 Debug 模式始终绕过，其他插件也可主动否决或隔离缓存。');
    $form .= number_input('页面缓存有效期（秒）', 'page_cache_ttl', (string)$config['page_cache_ttl'], 30, 3600, true, '普通模式按此时间过期；贪婪模式下匿名公开页忽略该时间，直到内容版本变化。');
    $form .= checkbox('贪婪缓存模式', 'greedy_cache_enabled', (bool)$config['greedy_cache_enabled'], '匿名首页、版块页和帖子页在相关内容未变化时不按有效期过期；发帖、编辑、回复和删除只失效受影响页面。登录请求和动态投票页不缓存，直接修改数据库后需手动清理缓存。');
    $form .= number_input('事件失效缓冲（秒）', 'stale_cache_seconds', (string)$config['stale_cache_seconds'], 0, 60, true, '内容变化后由首个请求重建缓存；仅在重建期间，同一页面和同一排序的并发访客可短暂读取上一版本，避免数据库瞬时击穿。建议 5 至 15 秒，设为 0 可关闭。');
    $form .= '<h3 class="plugin-panel-title">SQL 查询减负</h3>';
    $form .= checkbox('SQL 数据查询缓存', 'query_cache_enabled', (bool)$config['query_cache_enabled'], '缓存帖子所属版块，并通过核心数据 Hook 缓存登录用户的首页、版块主题列表和帖子回复数据。搜索、个人主页、通知和站点 Debug 模式完全绕过；检测到其他插件使用同组数据 Hook 时自动让路。文件实现与 SQLite、MySQL、PostgreSQL 无关。');
    $form .= number_input('查询结果缓存有效期（秒）', 'query_cache_ttl', (string)$config['query_cache_ttl'], 30, 3600, true, '普通模式按此时间过期；贪婪模式长期保留，发帖、回帖、编辑、删除、移动或手动清理时精确失效。');
    $form .= number_input('最多保留缓存文件', 'cache_max_files', (string)$config['cache_max_files'], 50, 5000, true, '计划任务会删除过期、旧格式和旧代际缓存，再按生成时间淘汰最旧文件。');
    $form .= number_input('并发等待时间（毫秒）', 'cache_wait_ms', (string)$config['cache_wait_ms'], 0, 500, true, '同一页面缓存正在生成时，短暂等待首个请求完成，减少高并发下重复查询和重复渲染。');
    $form .= '<h3 class="plugin-panel-title">传输与浏览</h3>';
    $form .= checkbox('Gzip 输出压缩', 'compression_enabled', (bool)$config['compression_enabled'], '仅在服务器未启用压缩且浏览器支持 Gzip 时生效。');
    $form .= checkbox('帖子图片优化', 'image_optimization_enabled', (bool)$config['image_optimization_enabled'], '为帖子和回帖图片补充原生懒加载与异步解码属性。');
    $form .= checkbox('长帖离屏渲染优化', 'render_optimization_enabled', (bool)$config['render_optimization_enabled'], '长回复列表优先渲染可视区域，减少首屏布局和绘制开销。');
    $form .= checkbox('头像连接预热', 'resource_hints_enabled', (bool)$config['resource_hints_enabled'], '提前建立默认头像服务连接，缩短首次显示远程头像的等待时间。');
    $form .= '<h3 class="plugin-panel-title">SQLite 并发</h3>';
    $form .= checkbox('SQLite 连接调优', 'sqlite_tuning_enabled', (bool)$config['sqlite_tuning_enabled'], 'SQLite 使用连接页缓存和内存映射；MySQL、PostgreSQL 继续使用各自数据库缓冲区，页面与查询结果缓存对三种数据库都生效。');
    $form .= number_input('每进程 SQLite 缓存（MB）', 'sqlite_cache_mb', (string)$config['sqlite_cache_mb'], 2, 64, true, '轻量服务器建议 4 至 16 MB；PHP 并发进程较多时不要设置过大。');
    $form .= '<button>保存设置</button></form>';
    $clear = '<form class="post-action-form" method="post" action="' . h(admin_url(['tab' => 'performance'])) . '" data-confirm="确定清理全部页面与查询缓存？">' . form_token() . '<input type="hidden" name="performance_action" value="clear"><button class="danger">清理缓存</button></form>';
    return '<div class="performance-panel"><div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>性能优化</strong><span>分层页面缓存、并发保护、传输压缩和长帖渲染优化</span></div>', $clear) . '<div class="plugin-panel-body">' . $summary . '</div></div>'
        . '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>设置</strong><span>保存后立即生效</span></div>', '') . '<div class="plugin-panel-body">' . $form . '</div></div></div>';
}

function performance_service_worker_route(array $plugin): void
{
    header('Content-Type: application/javascript; charset=utf-8');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    echo "self.addEventListener('install',function(){self.skipWaiting()});self.addEventListener('activate',function(event){event.waitUntil(caches.keys().then(function(keys){return Promise.all(keys.filter(function(key){return key.indexOf('performance-cache-')===0}).map(function(key){return caches.delete(key)}))}).then(function(){return self.registration.unregister()}))});";
    exit;
}

function performance_css(): string
{
    return <<<'CSS'
.performance-panel .performance-status-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px}
.performance-panel .performance-status-card{display:grid;gap:4px;padding:11px 12px;border:1px solid var(--line-soft);border-radius:7px;background:var(--bg)}
.performance-panel .performance-status-card span{color:var(--text-subtle);font-size:11px}
.performance-panel .performance-status-card strong{overflow-wrap:anywhere;font-size:15px}
.performance-panel .performance-status-card strong.is-ok{color:var(--success)}
.performance-panel .performance-status-card strong.is-off{color:var(--text-muted)}
@supports(content-visibility:auto){.performance-render-root .topic-post-list>.post-entry:nth-child(n+4){content-visibility:auto;contain-intrinsic-size:auto 280px}}
CSS;
}

return [
    'id' => 'performance',
    'name' => '性能优化',
    'version' => '1.8.5',
    'description' => '加快页面访问、帖子浏览与长内容显示，并提升高并发访问稳定性。',
    'author' => 'glod',
    'hooks' => [
        'app.boot' => 'performance_boot',
        'topic.index_data.load' => 'performance_topic_index_data_load',
        'topic.index_data.loaded' => 'performance_topic_index_data_loaded',
        'topic.replies_data.load' => 'performance_topic_replies_data_load',
        'topic.replies_data.loaded' => 'performance_topic_replies_data_loaded',
        'topic.before_save' => 'performance_topic_before_save',
        'topic.after_save' => 'performance_topic_after_save',
        'reply.after_save' => 'performance_reply_after_save',
        'user.after_save' => 'performance_user_after_save',
        'content.before_delete' => 'performance_content_before_delete',
        'performance.cache_invalidate' => 'performance_invalidate_filter',
        'topic.after_render' => 'performance_render_images',
        'reply.after_render' => 'performance_render_images',
        'page.before_render' => 'performance_page_before_render',
        'page.head' => 'performance_page_head',
    ],
    'assets' => ['css' => 'performance_css'],
    'routes' => ['performance_sw' => 'performance_service_worker_route'],
    'admin_tabs' => ['performance' => 'performance_admin_page'],
    'cron' => [
        'prune_cache' => [
            'callback' => 'performance_cache_prune',
            'interval' => 3600,
        ],
        'optimize_database' => [
            'callback' => 'performance_database_optimize',
            'interval' => 86400,
        ],
    ],
    'install' => 'performance_install',
    'uninstall' => 'performance_uninstall',
];