<?php
if (!defined('APP_ROOT')) exit;

/* =====================================================================
 * ModSecurity WAF 防火墙插件（OWASP CRS 核心规则集）
 * 通过 app.boot 钩子在路由处理前对每个请求执行异常评分检测。
 * ===================================================================== */

/* ---------------- 配置 ---------------- */

function modsecurity_config_defaults(): array
{
    return [
        'mode' => 'block',                 // block=拦截 | detect=仅检测
        'anomaly_threshold' => '5',        // 异常分阈值（CRS 默认 5）
        'paranoia_level' => '1',           // 警惕级别 1-4
        'auto_ban_enabled' => '1',         // 自动封禁
        'auto_ban_threshold' => '10',      // 窗口内拦截次数达到后封禁
        'auto_ban_window' => '900',        // 统计窗口（秒）
        'auto_ban_duration' => '3600',     // 封禁时长（秒），0=永久
        'max_request_mb' => '25',          // 单请求体积上限（MB）
        'max_args_kb' => '2048',           // 全部参数体积上限（KB）
        'max_args_count' => '500',         // 参数数量上限
        'max_arg_len' => '100000',         // 单个参数长度上限
        'max_arg_name_len' => '1024',      // 参数名长度上限
        'max_uri_len' => '1024',           // 请求路径长度上限
        'max_files' => '20',               // 单请求附件数量上限
        'allowed_content_types' => "application/x-www-form-urlencoded,multipart/form-data,application/json,text/plain,text/html,text/markdown,application/xml,text/xml",
        'log_max_rows' => '50000',           // 事件表最大保留行数
        'disabled_rules' => [],            // 停用规则 ID 列表
        'disabled_categories' => [],       // 停用规则类别列表
        'speed_optimization_enabled' => '0', // 网站访问速度优化
        'page_cache_ttl' => '300',          // 匿名公开页缓存秒数
        'browser_cache_enabled' => '0',    // 浏览器缓存优化
        'cache_version' => '1',            // 浏览器缓存版本
        'admin_bypass_enabled' => '0',     // 管理员仅记录模式
        'trust_proxy_headers' => '0',      // 信任反向代理来源头
        'cc_enabled' => '0',               // CC 防御开关
        'cc_mode' => 'block',              // block=自动封禁 | detect=仅记录
        'cc_threshold' => '120',           // 窗口内请求阈值
        'cc_window' => '60',               // 统计窗口秒数
        'cc_ban_duration' => '600',        // CC 封禁秒数
        'cc_exempt_admin' => '1',          // 管理员不计入 CC
        'log_severities' => ['CRITICAL', 'ERROR', 'WARNING', 'NOTICE'], // 仅控制事件日志写入级别
    ];
}

function modsecurity_config(): array
{
    return plugin_config('modsecurity', modsecurity_config_defaults());
}

function modsecurity_cfg(string $key)
{
    $config = modsecurity_config();
    return $config[$key] ?? modsecurity_config_defaults()[$key] ?? '';
}

function modsecurity_browser_cache_enabled(): bool
{
    return (string)modsecurity_cfg('browser_cache_enabled') === '1';
}

function modsecurity_speed_optimization_enabled(): bool
{
    return (string)modsecurity_cfg('speed_optimization_enabled') === '1';
}

function modsecurity_trusted_proxy_client_ip(): ?string
{
    $remote = clean_ip((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    if ($remote === '' || (string)modsecurity_cfg('trust_proxy_headers') !== '1') return null;
    // A client connected directly from the public Internet must not choose its own IP address.
    if (filter_var($remote, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return null;
    foreach (explode(',', (string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? '')) as $value) {
        $ip = clean_ip($value);
        if ($ip !== '') return $ip;
    }
    return null;
}

function modsecurity_sanitize_proxy_headers(): void
{
    $client_ip = modsecurity_trusted_proxy_client_ip();
    // Core ip_addr() prioritizes these client-controlled headers. Normalize them before routes run.
    foreach (['HTTP_CLIENT_IP', 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED'] as $header) unset($_SERVER[$header]);
    if ($client_ip !== null) $_SERVER['HTTP_X_FORWARDED_FOR'] = $client_ip;
}

function modsecurity_client_ip(): string
{
    $client_ip = modsecurity_trusted_proxy_client_ip();
    if ($client_ip !== null) return $client_ip;
    return clean_ip((string)($_SERVER['REMOTE_ADDR'] ?? '')) ?: '0.0.0.0';
}

function modsecurity_bump_cache_version(): void
{
    modsecurity_page_cache_clear();
    if (!modsecurity_browser_cache_enabled()) return;
    $config = modsecurity_config();
    $config['cache_version'] = (string)max(1, (int)($config['cache_version'] ?? 1) + 1);
    plugin_save_config('modsecurity', $config);
}

function modsecurity_page_cache_dir(): string
{
    return (defined('CACHE_DIR') ? CACHE_DIR : APP_ROOT . '/app/cache') . '/modsecurity-pages';
}

function modsecurity_page_cache_clear(): void
{
    $dir = modsecurity_page_cache_dir();
    foreach (glob($dir . '/*.html') ?: [] as $file) @unlink($file);
}

function modsecurity_page_cache_key(): ?string
{
    if (!modsecurity_speed_optimization_enabled() || ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') return null;
    // Shared HTML cache is only safe for truly anonymous, stateless requests.
    if (!empty($_COOKIE)) return null;
    $action = (string)($_GET['a'] ?? 'home');
    if (!in_array($action, ['home', 'forum', 'topic'], true) || trim((string)($_GET['q'] ?? '')) !== '') return null;
    $allowed = ['a' => true, 'id' => true, 'p' => true, 'replyid' => true, 'floor' => true, 'sort' => true];
    foreach (array_keys($_GET) as $key) if (!isset($allowed[$key])) return null;
    $query = $_GET;
    ksort($query);
    return hash('sha256', $action . '|' . http_build_query($query));
}

function modsecurity_page_cache_boot(): void
{
    $key = modsecurity_page_cache_key();
    if ($key === null) return;
    $dir = modsecurity_page_cache_dir();
    $file = $dir . '/' . $key . '.html';
    $ttl = max(30, min(3600, (int)modsecurity_cfg('page_cache_ttl') ?: 300));
    if (is_file($file) && (int)@filemtime($file) >= time() - $ttl) {
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-cache, must-revalidate');
        header('X-ModSecurity-Page-Cache: HIT');
        readfile($file);
        exit;
    }
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    ob_start(function (string $html) use ($file): string {
        $sets_cookie = false;
        foreach (headers_list() as $header) if (stripos($header, 'Set-Cookie:') === 0) $sets_cookie = true;
        if (!$sets_cookie && http_response_code() === 200 && str_starts_with(ltrim($html), '<!doctype html>')) {
            @file_put_contents($file, $html, LOCK_EX);
            header('Cache-Control: no-cache, must-revalidate');
            header('X-ModSecurity-Page-Cache: MISS');
        }
        return $html;
    });
}

function modsecurity_topic_saved($value = null, array $ctx = [])
{
    modsecurity_bump_cache_version();
    return $value;
}

function modsecurity_service_worker_route(array $plugin): void
{
    if (!modsecurity_browser_cache_enabled()) err('浏览器缓存优化未启用', 404);
    $version = max(1, (int)modsecurity_cfg('cache_version'));
    header('Content-Type: application/javascript; charset=utf-8');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    echo '(function(){const VERSION=' . $version . ';const CACHE="bbs1org-cache-"+VERSION;const canCache=res=>{const cc=(res.headers.get("cache-control")||"").toLowerCase();return res.ok&&!cc.includes("private")&&!cc.includes("no-store")&&!res.headers.has("set-cookie")};const save=(req,res)=>{if(canCache(res)){const cached=res.clone();caches.open(CACHE).then(c=>c.put(req,cached))}return res};self.addEventListener("install",e=>{self.skipWaiting()});self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.indexOf("bbs1org-cache-")===0&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()))});self.addEventListener("fetch",e=>{const r=e.request;if(r.method!=="GET"||new URL(r.url).origin!==self.location.origin)return;const d=r.destination;if(!["style","script","image","font"].includes(d))return;e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(res=>save(r,res))))})})();';
    exit;
}

function modsecurity_page_head($value = '', array $ctx = []): string
{
    $html = (string)$value;
    if (modsecurity_speed_optimization_enabled()) $html .= '<script>(function(){function optimize(){document.querySelectorAll(".post-content img").forEach(function(img){if(!img.hasAttribute("loading"))img.loading="lazy";img.decoding="async"})}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",optimize);else optimize();new MutationObserver(optimize).observe(document.documentElement,{childList:true,subtree:true})})();</script>';
    if (modsecurity_browser_cache_enabled()) {
        $sw = h(route_url('modsecurity_sw')) . '?v=' . (int)modsecurity_cfg('cache_version');
        $html .= '<script>(function(){if("serviceWorker" in navigator){window.addEventListener("load",function(){navigator.serviceWorker.register("' . $sw . '",{scope:"./"}).catch(function(){})})}})();</script>';
    } else $html .= '<script>(function(){if("serviceWorker" in navigator){navigator.serviceWorker.getRegistrations().then(function(regs){return Promise.all(regs.filter(function(reg){return reg.active&&reg.active.scriptURL.indexOf("modsecurity_sw")!==-1}).map(function(reg){return reg.unregister()}))}).then(function(){return caches.keys()}).then(function(keys){return Promise.all(keys.filter(function(key){return key.indexOf("bbs1org-cache-")===0}).map(function(key){return caches.delete(key)}))}).catch(function(){})}})();</script>';
    return $html;
}

/* ---------------- 数据库 ---------------- */

function modsecurity_install(array $plugin): void
{
    modsecurity_schema();
}

function modsecurity_uninstall(array $plugin): void
{
    app_db_drop_table('plugin_modsecurity_events');
    app_db_drop_table('plugin_modsecurity_bans');
    app_db_drop_table('plugin_modsecurity_cc');
}

function modsecurity_schema(): void
{
    static $ready = false;
    if ($ready) return;
    $t = app_db_types();
    app_db_create_table('plugin_modsecurity_events', "id {$t['id']},request_id {$t['string']} NOT NULL,rule_id {$t['uint']} NOT NULL,msg {$t['string']} NOT NULL,severity {$t['string']} NOT NULL,category {$t['string']} NOT NULL,matched {$t['text']} NOT NULL,target {$t['string']} NOT NULL,uri {$t['text']} NOT NULL,method {$t['string']} NOT NULL,ip {$t['key']} NOT NULL,user_id {$t['uint']} NOT NULL DEFAULT 0,blocked {$t['uint']} NOT NULL DEFAULT 0,created_at {$t['uint']} NOT NULL");
    app_db_create_index('idx_plugin_modsec_events_time', 'plugin_modsecurity_events(created_at DESC)');
    app_db_create_index('idx_plugin_modsec_events_ip', 'plugin_modsecurity_events(ip,created_at DESC)');
    app_db_create_index('idx_plugin_modsec_events_rule', 'plugin_modsecurity_events(rule_id,created_at DESC)');
    app_db_create_index('idx_plugin_modsec_events_blocked', 'plugin_modsecurity_events(blocked,created_at DESC)');
    app_db_create_table('plugin_modsecurity_bans', "id {$t['id']},ip {$t['key']} NOT NULL UNIQUE,reason {$t['string']} NOT NULL,hits {$t['uint']} NOT NULL DEFAULT 0,created_at {$t['uint']} NOT NULL,expires_at {$t['uint']} NOT NULL DEFAULT 0");
    app_db_create_index('idx_plugin_modsec_bans_expires', 'plugin_modsecurity_bans(expires_at DESC)');
    app_db_create_table('plugin_modsecurity_cc', "ip {$t['key']} NOT NULL PRIMARY KEY,window_started {$t['uint']} NOT NULL,hits {$t['uint']} NOT NULL DEFAULT 0,updated_at {$t['uint']} NOT NULL");
    app_db_create_index('idx_plugin_modsec_cc_updated', 'plugin_modsecurity_cc(updated_at DESC)');
    $ready = true;
}

function modsecurity_prune(): void
{
    static $pruned = false;
    if ($pruned) return;
    $now = time();
    $max_rows = max(1000, min(200000, (int)modsecurity_cfg('log_max_rows') ?: 50000));
    if ((int)val("SELECT COUNT(*) FROM plugin_modsecurity_events") > $max_rows) {
        $max_id = (int)val("SELECT id FROM plugin_modsecurity_events ORDER BY id DESC LIMIT 1 OFFSET " . max(0, $max_rows));
        if ($max_id > 0) q("DELETE FROM plugin_modsecurity_events WHERE id<=?", [$max_id]);
    }
    q("DELETE FROM plugin_modsecurity_bans WHERE expires_at>0 AND expires_at<=?", [$now]);
    $pruned = true;
}

/* ---------------- 严重级别 ---------------- */

function modsecurity_severity_score(string $sev): int
{
    // Low-confidence signals are useful for investigation, but must not deny normal visitors.
    return ['CRITICAL' => 5, 'ERROR' => 4, 'WARNING' => 0, 'NOTICE' => 0][strtoupper($sev)] ?? 0;
}

function modsecurity_severity_label(string $sev): string
{
    return ['CRITICAL' => '严重', 'ERROR' => '错误', 'WARNING' => '警告', 'NOTICE' => '提示'][strtoupper($sev)] ?? $sev;
}

function modsecurity_categories(): array
{
    return [
        'protocol' => '920 协议执行',
        'protocol_attack' => '921 协议攻击',
        'lfi' => '930 路径穿越/LFI',
        'rfi' => '931 远程文件包含',
        'rce' => '932/944 远程命令执行',
        'php' => '933 PHP 注入',
        'nodejs' => '934 Node.js 注入',
        'xss' => '941 跨站脚本 XSS',
        'sqli' => '942 SQL 注入',
        'session' => '943 会话固定',
        'cc' => 'CC 防御',
    ];
}

/* ---------------- 核心规则集（OWASP CRS 规则 ID） ---------------- */

function modsecurity_rules(): array
{
    static $rules;
    if (is_array($rules)) return $rules;

    $Q = ['QUERY', 'URI', 'COOKIES', 'ARGS_NAMES'];  // URL / 查询串为主（避免误伤正文代码）
    // Named keys keep PHP array union from discarding appended numeric targets.
    // Application form values are validated and stored through parameterized core handlers.
    // Keep signature blocking on externally addressable request surfaces, not ordinary forum text.
    $U = ['query' => 'QUERY', 'uri' => 'URI'];

    $rules = [
        /* ================= 920 协议执行 ================= */
        ['id' => 920100, 'cat' => 'protocol', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => ['URI', 'QUERY'], 'regex' => '~[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]~', 'msg' => '请求行包含无效控制字符'],
        ['id' => 920120, 'cat' => 'protocol', 'sev' => 'ERROR', 'paranoia' => 2, 'target' => ['HEADERS'], 'regex' => '~multipart/form-data[\s\S]*?application/x-www-form-urlencoded|application/x-www-form-urlencoded[\s\S]*?multipart/form-data~i', 'msg' => 'multipart/form-data 旁路攻击尝试'],
        ['id' => 920230, 'cat' => 'protocol', 'sev' => 'NOTICE', 'paranoia' => 2, 'target' => ['ARGS', 'QUERY', 'URI'], 'regex' => '~(?:%[0-9a-fA-F]{2}){2,}~i', 'msg' => '检测到多重 URL 编码'],
        ['id' => 920240, 'cat' => 'protocol', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => ['QUERY', 'URI'], 'regex' => '~%u[0-9a-fA-F]{4}~i', 'msg' => '检测到多重 URL 编码（%u 编码）'],
        ['id' => 920250, 'cat' => 'protocol', 'sev' => 'ERROR', 'paranoia' => 2, 'target' => ['ARGS', 'QUERY', 'URI'], 'regex' => '~(?:%c0%2e|%c0%ae|%c1%9c|%e0%40%af|%e0%80%af|%c0%80|%c0%af)~i', 'msg' => 'UTF-8 超长编码滥用'],
        ['id' => 920270, 'cat' => 'protocol', 'sev' => 'ERROR', 'paranoia' => 1, 'target' => ['ARGS', 'COOKIES'], 'regex' => '~[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]~', 'msg' => '参数包含无效控制字符'],
        ['id' => 920440, 'cat' => 'protocol', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => ['ARGS', 'URI', 'FILE'], 'regex' => '~(?:^|[\\/])(?:\.htaccess|\.htpasswd|\.user\.ini|\.git|\.svn|web\.config)(?:$|[\\/])~i', 'msg' => '受限文件名访问'],
        ['id' => 920450, 'cat' => 'protocol', 'sev' => 'NOTICE', 'paranoia' => 2, 'target' => ['QUERY', 'ARGS'], 'regex' => '~(?:file|gopher|dict|jar|expect)://~i', 'msg' => '协议受限 URL'],
        ['id' => 920500, 'cat' => 'protocol', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => ['ARGS', 'QUERY', 'URI'], 'regex' => '~(?:%00|\x00)~i', 'msg' => '空字节注入尝试'],

        /* ================= 921 协议攻击 ================= */
        ['id' => 921110, 'cat' => 'protocol_attack', 'sev' => 'ERROR', 'paranoia' => 1, 'target' => ['ARGS', 'QUERY', 'URI', 'COOKIES'], 'regex' => '~(?:%0d%0a|%0a%0d|%00)~i', 'msg' => 'HTTP 请求走私 / CRLF 注入'],
        ['id' => 921120, 'cat' => 'protocol_attack', 'sev' => 'ERROR', 'paranoia' => 1, 'target' => ['QUERY', 'URI'], 'regex' => '~(?:%0d%0a|%0a%0d|\r\n|%00)~i', 'msg' => 'HTTP 响应头拆分攻击'],
        ['id' => 921140, 'cat' => 'protocol_attack', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => ['QUERY', 'URI', 'COOKIES'], 'regex' => '~\r?\n[A-Za-z-]+[\s]*:~', 'msg' => 'HTTP 请求头注入'],
        ['id' => 921150, 'cat' => 'protocol_attack', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => ['ARGS', 'QUERY'], 'regex' => '~(?:%0d%0a|\r\n)[A-Za-z-]+[\s]*:~i', 'msg' => 'HTTP 请求头注入'],
        ['id' => 921180, 'cat' => 'protocol_attack', 'sev' => 'NOTICE', 'paranoia' => 2, 'target' => ['QUERY'], 'regex' => '~(?:^|&)([^&=]+)=[^&]*(?:&|\?)\1=~i', 'msg' => 'HTTP 参数污染'],

        /* ================= 930 路径穿越 / 本地文件包含 ================= */
        ['id' => 930100, 'cat' => 'lfi', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['FILE'], 'regex' => '~\.\.(?:\\|/|%2f|%5c)~i', 'msg' => '路径穿越攻击'],
        ['id' => 930110, 'cat' => 'lfi', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['FILE'], 'regex' => '~(?:%2e%2e%2f|%2e%2e%5c|%252e%252e|%2e%2e/|%2e%2e\\)~i', 'msg' => '路径穿越攻击（编码绕过）'],
        ['id' => 930120, 'cat' => 'lfi', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['FILE'], 'regex' => '~(?:etc[/\\]passwd|etc[/\\]shadow|etc[/\\]hosts|proc[/\\]self[/\\]environ|boot\.ini|win\.ini)~i', 'msg' => '操作系统文件访问尝试'],
        ['id' => 930130, 'cat' => 'lfi', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['FILE'], 'regex' => '~(?:\.htaccess|\.htpasswd|\.git[/\\]config|\.svn[/\\]entries|web\.config)~i', 'msg' => '受限配置文件访问尝试'],

        /* ================= 931 远程文件包含 ================= */
        ['id' => 931100, 'cat' => 'rfi', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:include|require)(?:_once)?\s*(?:=|\?=|\[|\(|[\'"])\s*(?:https?|ftp)://~i', 'msg' => '可能的远程文件包含攻击'],
        ['id' => 931110, 'cat' => 'rfi', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:src|href|action|value|url|path|file|page)\s*=\s*[\'"]?\s*(?:https?|ftp|php|file)://~i', 'msg' => '远程文件包含（外部 URL 参数）'],
        ['id' => 931120, 'cat' => 'rfi', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => ['QUERY', 'URI', 'COOKIES'], 'regex' => '~(?:php|file|data|expect|gopher)://~i', 'msg' => '远程文件包含（危险协议）'],

        /* ================= 932 远程命令执行（Unix/Windows/Java） ================= */
        ['id' => 932100, 'cat' => 'rce', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:/(?:bin|usr/bin|usr/sbin|sbin)/)(?:sh|bash|ls|nc|ncat|curl|wget|python|python3|perl|php|cat|rm|chmod|kill|ps|netstat|sudo|su)\b~i', 'msg' => 'Unix 命令执行（危险路径）'],
        ['id' => 932105, 'cat' => 'rce', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:^|[;|&`])\s*(?:id|whoami|uname|hostname|pwd|ls|cat|nc|ncat|curl|wget)\b~i', 'msg' => 'Unix 命令执行（命令探测）'],
        ['id' => 932110, 'cat' => 'rce', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:cmd\.exe|powershell|pwsh|wmic|net\.exe|taskkill|shutdown|reg\s+add|certutil)~i', 'msg' => 'Windows 命令执行'],
        ['id' => 932120, 'cat' => 'rce', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:^|[;&|])\s*(?:cd|copy|del|dir|echo|erase|mkdir|move|ren|rd|set|type|ipconfig|nslookup)\s+~i', 'msg' => 'Windows 批处理命令执行'],
        ['id' => 932130, 'cat' => 'rce', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $Q, 'regex' => '~\$\([^)]*\)|`[^`]*`~i', 'msg' => 'Unix 命令替换 / 反引号执行'],
        ['id' => 932140, 'cat' => 'rce', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => $Q, 'regex' => '~\b(?:for|if)\b[^\n]*\b(?:do|else)\b[^\n]*%~i', 'msg' => 'Windows FOR/IF 命令'],
        ['id' => 932150, 'cat' => 'rce', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:^|[;|&`])\s*(?:cat|ls|id|whoami|rm|mv|cp|wget|curl|nc|bash|sh|kill|ps|uname|perl|python|ruby|php|gcc|cc|env|echo|sleep)\b~i', 'msg' => '直接 Unix 命令执行'],
        ['id' => 932160, 'cat' => 'rce', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:&&|\|\||;\s*|&\s*|\n\s*)[a-z][a-z0-9_]*\s*(?:[;|>]|$)~i', 'msg' => 'Unix Shell 命令拼接'],
        ['id' => 932170, 'cat' => 'rce', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['HEADERS'], 'regex' => '~(?:^|;)\s*\(\)\s*\{\s*;?~i', 'msg' => 'Shellshock 漏洞利用'],
        ['id' => 932180, 'cat' => 'rce', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => ['FILES'], 'regex' => '~\.(?:php[0-9]?|phtml|phar|sh|asp|aspx|ashx|jsp|jspx|war|exe|cgi|pl|py|rb|js|hta|bat|cmd|ps1|vbs)$~i', 'msg' => '危险可执行文件上传尝试'],
        ['id' => 932190, 'cat' => 'rce', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => ['FILE_CONTENT'], 'regex' => '~<\?php[\s\n].{0,200}?(?:eval|assert|system|exec|passthru|shell_exec|proc_open|popen|create_function|call_user_func|file_put_contents|base64_decode)\s*\(~is', 'msg' => 'WebShell 上传尝试'],
        ['id' => 932200, 'cat' => 'rce', 'sev' => 'ERROR', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:java\.lang\.Runtime|java\.lang\.ProcessBuilder|org\.apache\.tools\.javac)~i', 'msg' => 'Java 代码注入'],
        ['id' => 932210, 'cat' => 'rce', 'sev' => 'ERROR', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:%\{[^}]*\}|\$\{[^}]*\})[^}]{0,80}(?:class\.forName|Runtime|ProcessBuilder|getRuntime)~i', 'msg' => 'Java OGNL 表达式注入'],
        ['id' => 932230, 'cat' => 'rce', 'sev' => 'ERROR', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:getRuntime\(\)\.exec|Runtime\.getRuntime|ProcessBuilder\s*\(|\bexec\s*\([^)]*(?:Runtime|Process))~i', 'msg' => 'Java 进程执行'],
        ['id' => 932250, 'cat' => 'rce', 'sev' => 'ERROR', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:^|[.\s])Runtime\.[a-zA-Z]~i', 'msg' => 'Java Runtime 调用'],
        ['id' => 932260, 'cat' => 'rce', 'sev' => 'ERROR', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:javax\.script|GroovyShell|ScriptEngine|Nashorn)~i', 'msg' => 'Java 脚本引擎调用'],
        ['id' => 932270, 'cat' => 'rce', 'sev' => 'ERROR', 'paranoia' => 1, 'target' => $U, 'regex' => '~\bProcessBuilder\b~i', 'msg' => 'Java ProcessBuilder 调用'],

        /* ================= 933 PHP 注入 ================= */
        ['id' => 933100, 'cat' => 'php', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:<\?php|<\?=|\{\{|<\?(?!xml))~i', 'msg' => 'PHP 开放标签（Open Tag）'],
        ['id' => 933110, 'cat' => 'php', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => ['QUERY', 'ARGS', 'COOKIES'], 'regex' => '~(?:^|[/\s.=])(?:[\w-]+\.php(?:\?|#|$|\s))~i', 'msg' => 'PHP 脚本文件上传/引用'],
        ['id' => 933120, 'cat' => 'php', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:register_globals|allow_url_fopen|allow_url_include|display_errors|auto_prepend_file|safe_mode|open_basedir|disable_functions|magic_quotes|session\.save_path)~i', 'msg' => 'PHP 配置指令注入'],
        ['id' => 933130, 'cat' => 'php', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $Q, 'regex' => '~\$_(?:GLOBALS|SERVER|GET|POST|REQUEST|COOKIE|FILES|ENV|SESSION)\b~i', 'msg' => 'PHP 超全局变量注入'],
        ['id' => 933140, 'cat' => 'php', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => ['QUERY', 'URI'], 'regex' => '~php://(?:input|output|stdin|stdout|filter|temp|fd|memory|data)~i', 'msg' => 'PHP 输入输出流滥用'],
        ['id' => 933150, 'cat' => 'php', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:assert|preg_replace|system|exec|passthru|shell_exec|proc_open|popen|pcntl_exec|create_function|call_user_func|array_map|array_walk|eval)\b~i', 'msg' => 'PHP 高危函数名'],
        ['id' => 933151, 'cat' => 'php', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:extract|parse_str|putenv|ini_set|set_time_limit|mail|imap_open|curl_init|fsockopen)\b~i', 'msg' => 'PHP 中危函数名'],
        ['id' => 933152, 'cat' => 'php', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:include|require|include_once|require_once)\s*\(~i', 'msg' => 'PHP 文件包含函数'],
        ['id' => 933160, 'cat' => 'php', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $Q, 'regex' => '~\b(?:eval|assert|system|exec|passthru|shell_exec|proc_open|popen|pcntl_exec)\s*\(~i', 'msg' => 'PHP 高危函数调用'],
        ['id' => 933161, 'cat' => 'php', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:phpinfo|getcwd|scandir|readdir|file_get_contents|fread|fwrite|readfile|base64_encode|base64_decode|getenv)\s*\(~i', 'msg' => 'PHP 信息泄露函数调用'],
        ['id' => 933170, 'cat' => 'php', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:O:\d+:"|a:\d+:\(|s:\d+:"|C:\d+:")~i', 'msg' => 'PHP 序列化对象注入'],
        ['id' => 933180, 'cat' => 'php', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $Q, 'regex' => '~(?:(\$_(?:GLOBALS|REQUEST|POST|GET|COOKIE|SERVER|FILES|ENV|SESSION)))\s*\(~i', 'msg' => 'PHP 变量函数调用'],
        ['id' => 933200, 'cat' => 'php', 'sev' => 'ERROR', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:php|zlib|phar|data|expect|ftp|zip)://~i', 'msg' => 'PHP 危险封装协议'],

        /* ================= 934 Node.js 注入 ================= */
        ['id' => 934100, 'cat' => 'nodejs', 'sev' => 'ERROR', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:child_process|process\.mainModule|execSync|spawnSync|child_process\.exec|require\s*\(\s*[\'"](?:fs|child_process|path))~i', 'msg' => 'Node.js 代码注入'],
        ['id' => 934110, 'cat' => 'nodejs', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:require|import)\s*\(\s*[\'"](?:fs|child_process|path)[\'"]\)~i', 'msg' => 'Node.js 敏感模块加载'],

        /* ================= 941 跨站脚本 XSS ================= */
        ['id' => 941100, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES', 'HEADERS'], 'regex' => '~(?:<\s*script|<\s*\/?\s*script\s*>|javascript\s*:|<\s*iframe[^>]*src|<\s*img[^>]*\sonerror|<\s*s\s*c\s*r\s*i\s*p\s*t)~i', 'msg' => '检测到 XSS 攻击'],
        ['id' => 941110, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES', 'HEADERS'], 'regex' => '~(?:<\s*script[\s>]|<\s*\/\s*script\s*>)~i', 'msg' => 'XSS：Script 标签向量'],
        ['id' => 941120, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES', 'HEADERS'], 'regex' => '~(?:^|[\s\'";:=<>\[\]{}()])\s*on(?:load|error|click|mouseover|mouseout|focus|blur|change|submit|keyup|keydown|keypress|dblclick|contextmenu|dragstart|drop|input|mousedown|mouseup|mousemove|mouseenter|mouseleave|scroll|select|touchstart|touchend|touchmove|wheel|play|pause|canplay|seeking|seeked|ratechange|timeupdate|volumechange|ended|stalled|waiting|playing|abort|animationstart|animationend|animationiteration|transitionend|pointerdown|pointerup|pointermove|pointerover|pointerout|pointerenter|pointerleave|gotpointercapture|lostpointercapture|afterscriptexecute|beforescriptexecute|auxclick|fullscreenchange|readystatechange|toggle|visibilitychange)\s*=~i', 'msg' => 'XSS：事件处理器向量'],
        ['id' => 941130, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:javascript|vbscript)\s*:|(?:data|vbscript)\s*:\s*text/html~i', 'msg' => 'XSS：属性向量'],
        ['id' => 941140, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES', 'HEADERS'], 'regex' => '~(?:j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t|v\s*b\s*s\s*c\s*r\s*i\s*p\s*t)\s*:~i', 'msg' => 'XSS：JavaScript URI 向量'],
        ['id' => 941150, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:<\s*\/?\s*(?:iframe|meta|object|embed|link|style|script|form|textarea|select|input|button|base|svg|math|video|audio|source|track)\b[^>]*>)~i', 'msg' => 'XSS：危险 HTML 标签向量'],
        ['id' => 941160, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:<\s*(?:meta|link)\s+[^>]*\s+(?:http-equiv|refresh)[^>]*>|<\s*meta\s+http-equiv)~i', 'msg' => 'XSS：Meta 刷新 / NoScript 向量'],
        ['id' => 941180, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:alert\s*\(|confirm\s*\(|prompt\s*\(|document\.cookie|document\.location|window\.location|document\.write|innerHTML|outerHTML|String\.fromCharCode|eval\s*\(\s*(?:document|window|location))~i', 'msg' => 'XSS：JavaScript 危险关键字'],
        ['id' => 941190, 'cat' => 'xss', 'sev' => 'ERROR', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:<style|<link\s+rel=["\']?stylesheet|expression\s*\(|behavior\s*:|@import)~i', 'msg' => 'XSS：样式表向量'],
        ['id' => 941200, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:vbscript\s*:|<\s*vbs|<\s*script\s+language\s*=\s*["\']?\s*vbs)~i', 'msg' => 'XSS：VBScript 向量'],
        ['id' => 941210, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:<\s*script\s+language\s*=\s*["\']?\s*javascript|javascript\s*:)~i', 'msg' => 'XSS：JavaScript 语言向量'],
        ['id' => 941220, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:\\x[0-9a-fA-F]{2}|%u[0-9a-fA-F]{4}|&#x[0-9a-fA-F]+;|&#\d+;){2,}~i', 'msg' => 'XSS：混淆 JavaScript'],
        ['id' => 941230, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:on(?:click|load|error|mouseover|focus|blur|change|submit|keyup|keydown)\s*=\s*["\']\s*(?:alert|document|location|window|eval))~i', 'msg' => 'XSS：事件处理器 JavaScript'],
        ['id' => 941240, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:src\s*=\s*["\']?\s*https?://[^"\'>]*\.js|href\s*=\s*["\']?\s*javascript)~i', 'msg' => 'XSS：外部 JavaScript 加载'],
        ['id' => 941250, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:<script[^>]*>\s*<\s*\/script\s*>\s*<\s*script|<!--\[if[^>]*>|<\s*script\s+src\s*=\s*["\']?\s*https?://)~i', 'msg' => 'XSS：IE 过滤器绕过'],
        ['id' => 941260, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:document\s*\.\s*(?:getElementById|getElementsByName|getElementsByClassName|querySelector)|window\s*\[|top\s*\.\s*document)~i', 'msg' => 'XSS：DOM 污染'],
        ['id' => 941270, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U, 'regex' => '~\b(?:eval|Function)\s*\(~i', 'msg' => 'XSS：JavaScript eval'],
        ['id' => 941280, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:ng-(?:app|controller|click|mouseover|mouseenter|change|blur|focus|submit|keyup|keydown|keypress|load|error|bind-html|include|template|if|repeat|class|src|href)\b|\{\{[^}]{1,200}\}\})~i', 'msg' => 'XSS：AngularJS 模板注入'],
        ['id' => 941290, 'cat' => 'xss', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:<\s*svg\b|<\s*math\b|<\s*video\b|<\s*audio\b|<\s*canvas\b|<\s*template\b|<\s*details\b|<\s*dialog\b|<\s*menuitem\b)~i', 'msg' => 'XSS：HTML5 标签向量'],
        ['id' => 941300, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => $U, 'regex' => '~\$\s*\([^)]{0,200}\)\s*\.\s*(?:html|append|prepend|after|before|replaceWith|wrap|unwrap|attr|prop|val|text|data)\s*\(~i', 'msg' => 'XSS：jQuery 危险方法'],
        ['id' => 941320, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:<\s*\/?\s*[a-z][a-z0-9-]*\s[^>]*>|<\s*[a-z][a-z0-9-]*\s[^>]*\/>)~i', 'msg' => 'XSS：HTML 标签探测'],
        ['id' => 941330, 'cat' => 'xss', 'sev' => 'ERROR', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:<\s*script\b[^>]*>[^<]{0,200}?<\s*script|\s+style\s*=\s*["\']?[^"\']{0,80}(?:expression|behavior|javascript))~i', 'msg' => 'XSS：嵌套脚本向量'],
        ['id' => 941340, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:fromCharCode|\\\\u[0-9a-fA-F]{4}|%[0-9a-fA-F]{2}){3,}~i', 'msg' => 'XSS：混淆编码'],
        ['id' => 941380, 'cat' => 'xss', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => $U, 'regex' => '~\{\{[^}]{1,300}\}\}~i', 'msg' => 'XSS：模板注入表达式'],

        /* ================= 942 SQL 注入 ================= */
        ['id' => 942100, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\b(?:union\s*(?:distinct|all)?\s*select|select\s+[^\n]{0,200}\s+from\s+|insert\s+into|update\s+[\w.]+\s+set\s+|delete\s+from\s+|drop\s+(?:table|database)\s+|order\s+by\s+[0-9]+|group\s+by\s+|having\s+|case\s+when\s+|sleep\s*\(|benchmark\s*\(|pg_sleep\s*\(|waitfor\s+delay\s*\'|exec\s*\(|execute\s*\(|xp_cmdshell|sp_executesql|information_schema|char\s*\(|concat\s*\(|load_file\s*\(|0x[0-9a-f]{12,})~i', 'msg' => 'SQL 注入攻击（综合检测）'],
        ['id' => 942110, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"](?:--|#|/\*)[^\n]*$|\b(?:and|or)\s+[\'"]?[0-9]+\s*=\s*[\'"]?[0-9]+)~im', 'msg' => 'SQL 注入（常见注入测试）'],
        ['id' => 942120, 'cat' => 'sqli', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:=|!=|<>|<=|>=)\s*(?:all|any|some)\s*(?:\(|$)|\b(?:like|rlike|regexp|between|is\s+null)\b~i', 'msg' => 'SQL 运算符注入'],
        ['id' => 942130, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]?\s*(?:and|or|xor)\s+[\'"]?[0-9]+\s*=\s*[\'"]?[0-9]+\s*(?:--|#|$)|1\s*=\s*1\s*(?:--|#|$))~im', 'msg' => 'SQL 恒真式（Tautology）'],
        ['id' => 942140, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\b(?:information_schema|mysql\.db|pg_catalog|master\.dbo|sqlite_master|sysobjects|pg_tables|pg_user|mysql\.user)\b~i', 'msg' => 'SQL 数据库名探测'],
        ['id' => 942150, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*;(?:\s*--|#|/\*|$)|[\'"]\s*(?:union|select|and|or|from|where)\s+)~im', 'msg' => 'SQL 注入攻击'],
        ['id' => 942160, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\b(?:sleep\s*\(|benchmark\s*\(|pg_sleep\s*\(|waitfor\s+delay\s*\'|if\s*\([^)]{0,80}sleep)~i', 'msg' => 'SQL 盲注（sleep/benchmark）'],
        ['id' => 942170, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\b(?:sleep|benchmark|pg_sleep)\s*\(\s*[0-9]{2,}~i', 'msg' => 'SQL 时间盲注'],
        ['id' => 942180, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]?\s*or\s+[\'"]?[0-9a-z]+\s*=\s*[\'"]?[0-9a-z]+\s*(?:--|#|/\*|$)|or\s+1\s*=\s*1\s*(?:--|#|$)|admin[\'"]\s*--)~im', 'msg' => 'SQL 认证绕过（基本）'],
        ['id' => 942190, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\b(?:exec\s*(?:\(|master\.|xp_)|xp_cmdshell|sp_executesql|sysobjects|sys\.x|openrowset|opendatasource|bulk\s+insert)\b~i', 'msg' => 'MSSQL 代码执行/信息收集'],
        ['id' => 942200, 'cat' => 'sqli', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:/\*!\d{5}|/\*!|`[^`]*`|/\*[^*]{0,100}\*/)~i', 'msg' => 'MySQL 注释/反引号绕过'],
        ['id' => 942210, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~;\s*(?:select|insert|update|delete|drop|alter|create|exec|truncate)\s~i', 'msg' => 'SQL 链式注入'],
        ['id' => 942220, 'cat' => 'sqli', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:2\s*\*\s*2\s*=\s*4|0x[0-9a-f]{8,}|[0-9]{9,})~i', 'msg' => 'SQL 整数溢出攻击'],
        ['id' => 942230, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:if\s*\(|case\s+when\s+|decode\s*\()~i', 'msg' => 'SQL 条件注入'],
        ['id' => 942240, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\bset\s+(?:names|character_set)\b|\bcharset\s*=\s*utf8mb4\b|\bbegin\s+transaction\b~i', 'msg' => 'MySQL 字符集切换/MSSQL DoS'],
        ['id' => 942250, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\b(?:match\s*\([^)]*\)\s*against|execute\s+immediate|merge\s+into)\b~i', 'msg' => 'MATCH/EXECUTE IMMEDIATE 注入'],
        ['id' => 942260, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:or|and)\s+[\'"]?\s*[0-9]+\s*(?:=\s*[0-9]+)?\s*(?:--|#|$)|admin[\'"]?\s*--)~im', 'msg' => 'SQL 认证绕过（OR/AND 测试）'],
        ['id' => 942270, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]?\s*(?:or|and)\s+[\'"]?\s*[0-9]+\s*=\s*[\'"]?\s*[0-9]+\s*(?:--|#|$)|select\s+[^\n]{0,200}\s+from\s+|union\s+select)~im', 'msg' => 'SQL 基础注入'],
        ['id' => 942280, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\b(?:pg_sleep\s*\(|waitfor\s+delay\s*\'|shutdown\s*(?:with|;)|pg_terminate_backend|dblink|copy\s+[\w.]+\s+from)\b~i', 'msg' => 'PostgreSQL 注入（pg_sleep/waitfor）'],
        ['id' => 942290, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:db\.\w+\s*\.\s*(?:find|insert|update|remove|drop|rename|aggregate)\s*\(|\$where\s*:|\$gt\b|\$ne\b|\$eq\b)~i', 'msg' => 'MongoDB NoSQL 注入'],
        ['id' => 942300, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:/\*!\d{5}|/\*!\s|/\*\*|(?:;|^)\'?\s*--\s)~i', 'msg' => 'MySQL 注释/条件注入'],
        ['id' => 942310, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]?\s*(?:and|or|not)\s+[\'"]?\s*\d+\s*(?:=|!=|<|>)\s*[\'"]?\s*\d+)~i', 'msg' => 'SQL 恒真式（条件组合）'],
        ['id' => 942320, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~\b(?:sp_\w+|xp_\w+|master\s*\.\s*\w+)\b~i', 'msg' => 'SQL 存储过程注入'],
        ['id' => 942330, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:;|--|#|/\*)|(?:;|--)\s*(?:select|insert|update|delete|drop)\b)~im', 'msg' => 'SQL 经典探测'],
        ['id' => 942340, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]?\s*(?:or|and)\s+[\'"]?\s*\w+\s*=\s*[\'"]?\s*\w+\s*(?:--|#|/\*|$)|[\'"]\s*or\s*[\'"]?\s*\w+\s*[\'"]?\s*=\s*[\'"]?\s*\w+\s*[\'"]?)~im', 'msg' => 'SQL 认证绕过（通用）'],
        ['id' => 942350, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:create\s+function|sys_exec|sys_eval|load_file\s*\(|into\s+(?:outfile|dumpfile)|into\s+@|into\s+outfile)~i', 'msg' => 'MySQL UDF 注入'],
        ['id' => 942360, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*\+\s*[\'"]|char\s*\([0-9,]{2,}\)|concat\s*\([^)]{0,80}0x)~i', 'msg' => 'SQL 拼接/编码注入'],
        ['id' => 942361, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:alter\s+(?:table|user|database)|union\s+(?:all|distinct|distinctrow)?\s*select\s+)~i', 'msg' => 'SQL ALTER/UNION 注入'],
        ['id' => 942370, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*;\s*(?:--|#|/\*)|select\s+@@|union\s+all\s+select\s+null\b|--\s+[a-z]+\s*=\s*)~im', 'msg' => 'SQL 经典探测（高级）'],
        ['id' => 942380, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:or|and)\s+[\'"]?\s*(?:[0-9]+|\'[^\']*\')\s*=\s*(?:[0-9]+|\'[^\']*\')|--\s*$|#\s*$)~im', 'msg' => 'SQL 注入攻击'],
        ['id' => 942390, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:or|and)\s+[\'"]?\s*\d+\s*(?:--|#|/\*)|(?:or|and)\s+1\s*=\s*1)~i', 'msg' => 'SQL 注入攻击（OR 恒真式）'],
        ['id' => 942400, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:--|#)[^\n]{0,80}\s*(?:or|and|select|union|insert|update|delete|drop)\b|(?:or|and)\s+[\'"]?[0-9a-z]+[\'"]?\s*=\s*[\'"]?[0-9a-z]+[\'"]?\s*(?:--|#|/\*|$)~im', 'msg' => 'SQL 注入攻击（注释组合）'],
        ['id' => 942410, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:or|and)\s+[\'"]?\s*\d+\s*=\s*[\'"]?\s*\d+|[\'"]\s*--\s*[\'"]?|select\s+@)~i', 'msg' => 'SQL 注入攻击（注入参数）'],
        ['id' => 942420, 'cat' => 'sqli', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => ['QUERY', 'URI', 'COOKIES'], 'regex' => '~(?:--|#|;|[\'"])~', 'count' => 3, 'msg' => 'SQL 异常字符集中检测'],
        ['id' => 942421, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*;\s*[\'"]|;\s*;)~i', 'msg' => 'SQL 特殊字符异常检测'],
        ['id' => 942430, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*\d+\s*[\'"]\s*(?:and|or)|[\s(]+(?:--|#)\s*$)~im', 'msg' => 'SQL 注入攻击（条件）'],
        ['id' => 942440, 'cat' => 'sqli', 'sev' => 'WARNING', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:--\s+|--$|#|/\*\*)~m', 'msg' => 'SQL 注释序列检测'],
        ['id' => 942450, 'cat' => 'sqli', 'sev' => 'WARNING', 'paranoia' => 2, 'target' => $U, 'regex' => '~(?:0x[0-9a-f]{4,}|(?:\\x[0-9a-f]{2}){2,}|\bhex\s*\(|\bunhex\s*\()~i', 'msg' => 'SQL 十六进制编码标识'],
        ['id' => 942460, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:or|and|union|select)\b)~i', 'msg' => 'SQL 元字符异常检测'],
        ['id' => 942470, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:--|#)\s*[\w\s]*$|[\'"]\s*or\s*[\'"]?1\s*=\s*1)~im', 'msg' => 'SQL 注入攻击（恒真式）'],
        ['id' => 942480, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:union\s+(?:all\s+|distinct\s+|distinctrow\s+)?select\b)~i', 'msg' => 'SQL UNION SELECT 注入'],
        ['id' => 942490, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:or|and|union|select)\s+[\'"]?\s*\w+)~i', 'msg' => 'SQL 经典探测（关键字）'],
        ['id' => 942500, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:/\*[^*]*\*/\s*(?:or|and|union|select)|(?:or|and)\s*/\*)~i', 'msg' => 'SQL 行内注释绕过'],
        ['id' => 942510, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]?\s*(?:or|and)\s+[\'"]?\s*\d+\s*(?:=|!=|<|>)\s*[\'"]?\s*\d+)~i', 'msg' => 'SQL 注入攻击（运算符）'],
        ['id' => 942511, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:1\s*=\s*1|2\s*=\s*2|3\s*=\s*3)~i', 'msg' => 'SQL 注入攻击（数字恒真式）'],
        ['id' => 942520, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*;\s*(?:--|#|/\*|select|insert|update|delete|drop)\b)~im', 'msg' => 'SQL 注入攻击（分号注入）'],
        ['id' => 942530, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]?\s*\d+\s*=\s*[\'"]?\s*\d+\s*(?:--|#|/\*|\s+$)|[\s(\'"]+(?:or|and)\s+[\'"]?\s*\d+)~im', 'msg' => 'SQL 注入攻击（绕过尝试）'],
        ['id' => 942540, 'cat' => 'sqli', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:[\'"]\s*(?:or|and)\s+[\'"]?\s*[0-9]+[\'"]?\s*[=<>]\s*[0-9]+[\'"]?\s*(?:--|#|/\*)?\s*$|select\s+case\s+when\b)~im', 'msg' => 'SQL 注入攻击（最终绕过）'],

        /* ================= 943 会话固定 ================= */
        ['id' => 943100, 'cat' => 'session', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U + ['COOKIES'], 'regex' => '~(?:session_id\s*=|PHPSESSID\s*=|ASPSESSIONID\s*=|JSESSIONID\s*=|session-id\s*=|Set-Cookie)~i', 'msg' => '会话固定（Session Fixation）'],

        /* ================= 944 命令注入（Java/反序列化） ================= */
        ['id' => 944100, 'cat' => 'rce', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~\b(?:java\.lang\.Runtime|java\.lang\.ProcessBuilder|com\.sun\.tools\.javac|org\.apache\.tools\.ant)\b~i', 'msg' => '远程命令执行（可疑 Java 类）'],
        ['id' => 944110, 'cat' => 'rce', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~\b(?:ProcessBuilder|Runtime\.getRuntime\(\)|getRuntime\(\)\.exec|\.exec\s*\()~i', 'msg' => '远程命令执行（Java 进程启动）'],
        ['id' => 944120, 'cat' => 'rce', 'sev' => 'CRITICAL', 'paranoia' => 1, 'target' => $U, 'regex' => '~(?:rO0ABX|rO0AB|\\xac\\xed|aced0005)~i', 'msg' => 'Java 反序列化攻击'],
    ];

    /* 校验规则：剔除无效正则，避免整站崩溃或污染调试日志。 */
    $valid = [];
    foreach ($rules as $rule) {
        set_error_handler(static function (): bool { return true; });
        try {
            $is_valid = preg_match($rule['regex'], '') !== false;
        } finally {
            restore_error_handler();
        }
        if (!$is_valid) {
            debug_log_write('ModSecurity 规则 ID ' . (int)$rule['id'] . ' 正则无效，已跳过');
            continue;
        }
        $valid[] = $rule;
    }
    return $rules = $valid;
}

function modsecurity_rule_by_id(int $id): ?array
{
    foreach (modsecurity_rules() as $rule) if ((int)$rule['id'] === $id) return $rule;
    return null;
}

function modsecurity_rule_allowed(array $rule): bool
{
    static $disabled_rules = null;
    static $disabled_categories = null;
    static $paranoia = null;
    if ($disabled_rules === null) {
        $config = modsecurity_config();
        $disabled_rules = array_fill_keys(array_map('intval', (array)($config['disabled_rules'] ?? [])), true);
        $disabled_categories = array_fill_keys(array_map('strval', (array)($config['disabled_categories'] ?? [])), true);
        $paranoia = max(1, min(4, (int)($config['paranoia_level'] ?? 1)));
    }
    if (isset($disabled_rules[(int)$rule['id']])) return false;
    if (isset($disabled_categories[(string)$rule['cat']])) return false;
    if ((int)($rule['paranoia'] ?? 1) > $paranoia) return false;
    return true;
}

/* ---------------- 工具函数 ---------------- */

function modsecurity_utf8(string $s): string
{
    if (preg_match('//u', $s) === 1) return $s;
    if (function_exists('mb_convert_encoding')) {
        $converted = mb_convert_encoding($s, 'UTF-8', 'UTF-8');
        if (is_string($converted)) return $converted;
    }
    return (string)preg_replace('/[\x80-\xFF]/', '', $s);
}

function modsecurity_flatten_value($value, array &$out, int $limit): void
{
    if (count($out) >= $limit) return;
    if (is_array($value)) {
        foreach ($value as $v) modsecurity_flatten_value($v, $out, $limit);
        return;
    }
    $out[] = modsecurity_utf8((string)$value);
}

function modsecurity_is_user_content_field(string $name): bool
{
    return in_array(strtolower($name), ['body', 'content', 'bio', 'description', 'footer_info', 'custom_css'], true);
}

function modsecurity_request_id(): string
{
    static $id;
    if ($id === null) $id = bin2hex(random_bytes(8));
    return $id;
}

function modsecurity_collect_targets(): array
{
    $targets = [
        'ARGS' => [], 'ARGS_NAMES' => [], 'QUERY' => [], 'URI' => [], 'FILE' => [],
        'BODY' => [], 'COOKIES' => [], 'COOKIES_NAMES' => [], 'HEADERS' => [],
        'FILES' => [], 'FILE_CONTENT' => [], 'METHOD' => [],
    ];

    $max_args_count = max(50, min(10000, (int)modsecurity_cfg('max_args_count') ?: 500));
    foreach ([$_GET, $_POST] as $args) {
        foreach ($args as $name => $v) {
            if (!modsecurity_is_user_content_field((string)$name)) {
                modsecurity_flatten_value($v, $targets['ARGS'], $max_args_count);
            }
            if (count($targets['ARGS']) >= $max_args_count) break 2;
        }
    }
    foreach ([$_GET, $_POST] as $args) {
        foreach (array_keys($args) as $k) {
            if (count($targets['ARGS_NAMES']) >= $max_args_count) break;
            $targets['ARGS_NAMES'][] = modsecurity_utf8((string)$k);
        }
        if (count($targets['ARGS_NAMES']) >= $max_args_count) break;
    }
    $GLOBALS['__modsec_args_overflow'] = count($targets['ARGS']) >= $max_args_count || count($targets['ARGS_NAMES']) >= $max_args_count;

    $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $targets['URI'][] = modsecurity_utf8($uri);
    $path = (string)(parse_url($uri, PHP_URL_PATH) ?? '');
    $targets['FILE'][] = modsecurity_utf8($path);
    $targets['QUERY'][] = modsecurity_utf8((string)($_SERVER['QUERY_STRING'] ?? ''));

    foreach ($_COOKIE as $k => $v) {
        modsecurity_flatten_value($v, $targets['COOKIES'], $max_args_count);
        $targets['COOKIES_NAMES'][] = modsecurity_utf8((string)$k);
    }

    $headers = [
        'HTTP_USER_AGENT' => 'User-Agent', 'HTTP_ACCEPT' => 'Accept',
        'HTTP_ACCEPT_ENCODING' => 'Accept-Encoding', 'HTTP_ACCEPT_LANGUAGE' => 'Accept-Language',
        'HTTP_REFERER' => 'Referer', 'HTTP_COOKIE' => 'Cookie',
        'HTTP_CONTENT_TYPE' => 'Content-Type', 'HTTP_CONTENT_LENGTH' => 'Content-Length',
        'HTTP_HOST' => 'Host', 'HTTP_X_FORWARDED_FOR' => 'X-Forwarded-For',
        'HTTP_X_REQUESTED_WITH' => 'X-Requested-With', 'HTTP_AUTHORIZATION' => 'Authorization',
        'HTTP_ORIGIN' => 'Origin', 'HTTP_DNT' => 'DNT',
    ];
    foreach ($headers as $key => $label) {
        $value = (string)($_SERVER[$key] ?? '');
        if ($value !== '') $targets['HEADERS'][] = modsecurity_utf8($label . ': ' . $value);
    }

    if (is_array($_FILES)) {
        $file_count = 0;
        foreach ($_FILES as $field => $f) {
            if (!is_array($f)) continue;
            if (is_array($f['name'] ?? null)) {
                $names = $f['name'];
                $tmps = $f['tmp_name'] ?? [];
                $types = $f['type'] ?? [];
                for ($i = 0, $n = count($names); $i < $n; $i++) {
                    if ((int)($f['error'][$i] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
                    $file_count++;
                    $targets['FILES'][] = modsecurity_utf8(basename((string)$names[$i]));
                    $targets['FILES'][] = modsecurity_utf8((string)($types[$i] ?? ''));
                    modsecurity_file_sniff((string)($tmps[$i] ?? ''), $targets['FILE_CONTENT']);
                }
            } else {
                if ((int)($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
                $file_count++;
                $targets['FILES'][] = modsecurity_utf8(basename((string)($f['name'] ?? '')));
                $targets['FILES'][] = modsecurity_utf8((string)($f['type'] ?? ''));
                modsecurity_file_sniff((string)($f['tmp_name'] ?? ''), $targets['FILE_CONTENT']);
            }
        }
        $GLOBALS['__modsec_file_count'] = $file_count;
    }

    $content_type = strtolower((string)($_SERVER['HTTP_CONTENT_TYPE'] ?? ''));
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'
        && !str_contains($content_type, 'application/x-www-form-urlencoded')
        && !str_contains($content_type, 'multipart/form-data')) {
        $length = (int)($_SERVER['HTTP_CONTENT_LENGTH'] ?? 0);
        if ($length > 0 && $length <= (int)modsecurity_cfg('max_request_mb') * 1048576) {
            $body = @file_get_contents('php://input');
            if (is_string($body) && $body !== '') $targets['BODY'][] = modsecurity_utf8($body);
        }
    }

    $targets['METHOD'][] = modsecurity_utf8((string)($_SERVER['REQUEST_METHOD'] ?? ''));
    return $targets;
}

function modsecurity_file_sniff(string $tmp_name, array &$out): void
{
    if (!is_file($tmp_name)) return;
    $handle = @fopen($tmp_name, 'rb');
    if (!$handle) return;
    $chunk = @fread($handle, 4096);
    fclose($handle);
    if (is_string($chunk) && $chunk !== '') $out[] = modsecurity_utf8($chunk);
}

/* ---------------- 检测引擎 ---------------- */

function modsecurity_add_hit(array &$s, array $rule, string $match, string $target = ''): bool
{
    if (!modsecurity_rule_allowed($rule)) return false;
    $score = modsecurity_severity_score((string)$rule['sev']);
    $s['anomaly'] += $score;
    $blocked = $s['mode'] === 'block' && $s['anomaly'] >= $s['threshold'];
    $log_match = in_array($target, ['COOKIES', 'HEADERS'], true) ? '[redacted]' : cut($match, 255);
    $s['events'][] = [
        'rule_id' => (int)$rule['id'],
        'msg' => (string)($rule['msg'] ?? ('规则 ' . (int)$rule['id'])),
        'severity' => strtoupper((string)$rule['sev']),
        'category' => (string)($rule['cat'] ?? ''),
        'matched' => $log_match,
        'target' => $target !== '' ? $target : (string)($rule['target'][0] ?? ''),
        'blocked' => $blocked ? 1 : 0,
    ];
    return $blocked;
}

function modsecurity_meta_checks(array &$s, array $targets): void
{
    $server = $_SERVER;
    $method = strtoupper((string)($server['REQUEST_METHOD'] ?? 'GET'));

    /* 920160 无效 Content-Length */
    if (isset($server['HTTP_CONTENT_LENGTH']) && !ctype_digit((string)$server['HTTP_CONTENT_LENGTH'])) {
        $rule = modsecurity_rule_by_id(920160) ?? ['id' => 920160, 'cat' => 'protocol', 'sev' => 'ERROR', 'msg' => 'Content-Length 头无效'];
        if (modsecurity_add_hit($s, $rule, (string)$server['HTTP_CONTENT_LENGTH'])) return;
    }

    if ($method === 'GET' || $method === 'POST') {
        /* 920320 缺少 User-Agent */
        if (empty($server['HTTP_USER_AGENT'])) {
            $rule = modsecurity_rule_by_id(920320) ?? ['id' => 920320, 'cat' => 'protocol', 'sev' => 'WARNING', 'msg' => '请求缺少 User-Agent 头'];
            if (modsecurity_add_hit($s, $rule, 'User-Agent')) return;
        }
        /* 920280 缺少 Accept 头 */
        if (empty($server['HTTP_ACCEPT'])) {
            $rule = modsecurity_rule_by_id(920280) ?? ['id' => 920280, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => '请求缺少 Accept 头'];
            if (modsecurity_add_hit($s, $rule, 'Accept')) return;
        }
        /* 920300 缺少 Accept-Encoding */
        if (empty($server['HTTP_ACCEPT_ENCODING'])) {
            $rule = modsecurity_rule_by_id(920300) ?? ['id' => 920300, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => '请求缺少 Accept-Encoding 头'];
            if (modsecurity_add_hit($s, $rule, 'Accept-Encoding')) return;
        }
        /* 920310 空 Accept-Language */
        if (isset($server['HTTP_ACCEPT_LANGUAGE']) && trim((string)$server['HTTP_ACCEPT_LANGUAGE']) === '') {
            $rule = modsecurity_rule_by_id(920310) ?? ['id' => 920310, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => 'Accept-Language 头为空'];
            if (modsecurity_add_hit($s, $rule, 'Accept-Language')) return;
        }
        /* 920330 缺少 Accept-Language */
        if (empty($server['HTTP_ACCEPT_LANGUAGE'])) {
            $rule = modsecurity_rule_by_id(920330) ?? ['id' => 920330, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => '请求缺少 Accept-Language 头'];
            if (modsecurity_add_hit($s, $rule, 'Accept-Language')) return;
        }
        /* 920340 Content-Type 无 Content-Length */
        if ($method === 'POST' && !empty($server['HTTP_CONTENT_TYPE']) && empty($server['HTTP_CONTENT_LENGTH']) && !str_contains(strtolower((string)$server['HTTP_CONTENT_TYPE']), 'multipart/form-data')) {
            $rule = modsecurity_rule_by_id(920340) ?? ['id' => 920340, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => '请求含 Content-Type 但无 Content-Length'];
            if (modsecurity_add_hit($s, $rule, (string)$server['HTTP_CONTENT_TYPE'])) return;
        }
        /* 920350 Host 为数字 IP */
        if (!empty($server['HTTP_HOST']) && preg_match('/^(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?$/', (string)$server['HTTP_HOST'])) {
            $rule = modsecurity_rule_by_id(920350) ?? ['id' => 920350, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => 'Host 头为数字 IP 地址'];
            if (modsecurity_add_hit($s, $rule, (string)$server['HTTP_HOST'])) return;
        }
    }

    /* 920360 请求路径过长 */
    $uri = (string)($server['REQUEST_URI'] ?? '');
    $max_uri = max(256, (int)modsecurity_cfg('max_uri_len'));
    if (strlen($uri) > $max_uri) {
        $rule = modsecurity_rule_by_id(920360) ?? ['id' => 920360, 'cat' => 'protocol', 'sev' => 'WARNING', 'msg' => '请求文件名过长'];
        if (modsecurity_add_hit($s, $rule, cut($uri, 255))) return;
    }

    /* 920370 参数名过长 */
    $max_name = max(64, (int)modsecurity_cfg('max_arg_name_len'));
    foreach ($targets['ARGS_NAMES'] as $name) {
        if (strlen($name) > $max_name) {
            $rule = modsecurity_rule_by_id(920370) ?? ['id' => 920370, 'cat' => 'protocol', 'sev' => 'WARNING', 'msg' => '请求参数名过长'];
            if (modsecurity_add_hit($s, $rule, cut($name, 255))) return;
            break;
        }
    }

    /* 920380 参数过长 */
    $max_len = max(1024, (int)modsecurity_cfg('max_arg_len'));
    foreach ($targets['ARGS'] as $value) {
        if (strlen($value) > $max_len) {
            $rule = modsecurity_rule_by_id(920380) ?? ['id' => 920380, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => '请求参数过长'];
            if (modsecurity_add_hit($s, $rule, cut($value, 255))) return;
            break;
        }
    }

    /* 920390 参数总体积过大 */
    $max_args = max(64, (int)modsecurity_cfg('max_args_kb')) * 1024;
    $total_args = 0;
    foreach ($targets['ARGS'] as $value) $total_args += strlen($value);
    if ($total_args > $max_args) {
        $rule = modsecurity_rule_by_id(920390) ?? ['id' => 920390, 'cat' => 'protocol', 'sev' => 'WARNING', 'msg' => '请求参数总体积过大'];
        if (modsecurity_add_hit($s, $rule, 'ARGS ' . $total_args . 'B')) return;
    }

    if (!empty($GLOBALS['__modsec_args_overflow'])) {
        $rule = ['id' => 920395, 'cat' => 'protocol', 'sev' => 'ERROR', 'msg' => '请求参数数量过多'];
        if (modsecurity_add_hit($s, $rule, 'args=' . count($targets['ARGS']))) return;
    }

    /* 920400 附件数量过多 */
    $max_files = max(1, (int)modsecurity_cfg('max_files'));
    $file_count = (int)($GLOBALS['__modsec_file_count'] ?? 0);
    if ($file_count > $max_files) {
        $rule = modsecurity_rule_by_id(920400) ?? ['id' => 920400, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => '单请求附件数量过多'];
        if (modsecurity_add_hit($s, $rule, 'files=' . $file_count)) return;
    }

    /* 920410 请求总体积过大 */
    $max_request = (int)modsecurity_cfg('max_request_mb');
    if (isset($server['HTTP_CONTENT_LENGTH']) && ctype_digit((string)$server['HTTP_CONTENT_LENGTH'])
        && (int)$server['HTTP_CONTENT_LENGTH'] > $max_request * 1048576) {
        $rule = modsecurity_rule_by_id(920410) ?? ['id' => 920410, 'cat' => 'protocol', 'sev' => 'WARNING', 'msg' => '请求总体积过大'];
        if (modsecurity_add_hit($s, $rule, (string)$server['HTTP_CONTENT_LENGTH'])) return;
    }

    /* 920420 不允许的 Content-Type */
    $content_type = strtolower((string)($server['HTTP_CONTENT_TYPE'] ?? ''));
    if ($method === 'POST' && $content_type !== '') {
        $base = trim(explode(';', $content_type, 2)[0]);
        $allowed = array_values(array_filter(array_map('trim', explode(',', (string)modsecurity_cfg('allowed_content_types'))), 'strlen'));
        $allowed = array_map('strtolower', $allowed);
        if ($base !== '' && !in_array($base, $allowed, true)) {
            $rule = modsecurity_rule_by_id(920420) ?? ['id' => 920420, 'cat' => 'protocol', 'sev' => 'ERROR', 'msg' => '请求 Content-Type 不在策略允许范围'];
            if (modsecurity_add_hit($s, $rule, $content_type)) return;
        }
    }

    /* 920430 HTTP 协议版本 */
    $protocol = (string)($server['SERVER_PROTOCOL'] ?? 'HTTP/1.1');
    if (!in_array(strtoupper($protocol), ['HTTP/1.0', 'HTTP/1.1', 'HTTP/2', 'HTTP/2.0', 'HTTP/3'], true)) {
        $rule = modsecurity_rule_by_id(920430) ?? ['id' => 920430, 'cat' => 'protocol', 'sev' => 'ERROR', 'msg' => 'HTTP 协议版本不允许'];
        if (modsecurity_add_hit($s, $rule, $protocol)) return;
    }

    /* 920470 非法 Content-Type 字符 */
    if ($content_type !== '' && preg_match('/[^a-z0-9!#$%&\'*+\-.^_`|~:;=\/]/', $content_type)) {
        $rule = modsecurity_rule_by_id(920470) ?? ['id' => 920470, 'cat' => 'protocol', 'sev' => 'ERROR', 'msg' => 'Content-Type 头包含非法字符'];
        if (modsecurity_add_hit($s, $rule, cut($content_type, 255))) return;
    }

    /* 920480 Content-Type 字符集 */
    if ($content_type !== '' && preg_match('/charset\s*=\s*([a-z0-9._-]+)/i', $content_type, $m)) {
        $charset = strtolower((string)$m[1]);
        if (!in_array($charset, ['utf-8', 'utf8', 'iso-8859-1', 'latin1', 'us-ascii'], true)) {
            $rule = modsecurity_rule_by_id(920480) ?? ['id' => 920480, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => 'Content-Type 字符集不允许'];
            if (modsecurity_add_hit($s, $rule, $charset)) return;
        }
    }

    /* 920600/920610 HTTP 请求走私 */
    if (!empty($server['HTTP_TRANSFER_ENCODING']) || !empty($server['HTTP_TE'])) {
        $rule = modsecurity_rule_by_id(920610) ?? ['id' => 920610, 'cat' => 'protocol', 'sev' => 'NOTICE', 'msg' => '请求包含 Transfer-Encoding 头'];
        if (modsecurity_add_hit($s, $rule, 'Transfer-Encoding')) return;
    }
    if (!empty($server['HTTP_TRANSFER_ENCODING']) && !empty($server['HTTP_CONTENT_LENGTH'])) {
        $rule = modsecurity_rule_by_id(920600) ?? ['id' => 920600, 'cat' => 'protocol', 'sev' => 'WARNING', 'msg' => '请求同时包含 Content-Length 与 Transfer-Encoding'];
        if (modsecurity_add_hit($s, $rule, 'CL+TE')) return;
    }
}

function modsecurity_collect_events(array $events, array $targets): void
{
    $enabled = array_fill_keys(array_map('strtoupper', array_map('strval', (array)modsecurity_cfg('log_severities'))), true);
    $events = array_values(array_filter($events, static function (array $event) use ($enabled): bool {
        return isset($enabled[strtoupper((string)($event['severity'] ?? ''))]);
    }));
    if (!$events) return;
    $request_id = modsecurity_request_id();
    $ip = modsecurity_client_ip();
    $user_id = (int)(function_exists('uid') ? uid() : 0);
    // Query strings may contain reset tokens or other secrets; retain only the route in audit logs.
    $uri = cut((string)(parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?? ''), 500);
    $method = (string)($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $stmt = db()->prepare('INSERT INTO plugin_modsecurity_events(request_id,rule_id,msg,severity,category,matched,target,uri,method,ip,user_id,blocked,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $now = time();
    foreach ($events as $e) {
        $stmt->execute([
            $request_id, (int)$e['rule_id'], (string)$e['msg'], (string)$e['severity'],
            (string)$e['category'], (string)$e['matched'], (string)$e['target'],
            $uri, $method, $ip, $user_id, (int)$e['blocked'], $now,
        ]);
    }
}

function modsecurity_block(string $message): void
{
    http_response_code(403);
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => 0, 'message' => $message], JSON_UNESCAPED_UNICODE);
    } else {
        header('Content-Type: text/html; charset=utf-8');
        $msg = h($message);
        echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><meta name="viewport" content="width=device-width,initial-scale=1"><title>403 · 请求被拒绝</title><style>html,body{margin:0;padding:0;height:100%}body{display:flex;align-items:center;justify-content:center;background:radial-gradient(1200px 600px at 20% -10%,#2b3a67 0,transparent 55%),radial-gradient(1000px 500px at 110% 120%,#3b2b67 0,transparent 55%),linear-gradient(160deg,#0f172a 0%,#1e293b 100%);color:#e2e8f0;font:15px/1.7 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;-webkit-font-smoothing:antialiased}.card{max-width:520px;margin:24px;padding:48px 40px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);border-radius:20px;box-shadow:0 24px 60px rgba(0,0,0,.35);backdrop-filter:blur(12px);text-align:center;animation:fade .5s ease}.shield{width:84px;height:84px;margin:0 auto 22px;display:flex;align-items:center;justify-content:center;border-radius:50%;background:linear-gradient(135deg,#ef4444,#b91c1c);box-shadow:0 10px 30px rgba(239,68,68,.45);animation:pop .55s cubic-bezier(.2,1.6,.4,1)}h1{margin:0 0 6px;font-size:26px;font-weight:700;letter-spacing:.5px}.code{margin:0 0 16px;font-size:13px;color:#fca5a5;font-weight:600}.msg{margin:0 0 8px;color:#f1f5f9}.hint{margin:0 0 28px;color:#94a3b8;font-size:13px}.btn{display:inline-block;padding:11px 26px;border:1px solid rgba(255,255,255,.22);border-radius:999px;background:rgba(255,255,255,.08);color:#e2e8f0;text-decoration:none;font-size:14px;transition:.2s}.btn:hover{background:rgba(255,255,255,.16);border-color:rgba(255,255,255,.4)}@keyframes fade{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}@keyframes pop{from{transform:scale(.6)}to{transform:scale(1)}}</style></head><body><div class="card"><div class="shield"><svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M9 12l2 2 4-4"/></svg></div><h1>请求被拦截</h1><p class="code">HTTP 403 Forbidden</p><p class="msg">' . $msg . '</p><p class="hint">您的请求特征已被 Web 应用防火墙识别为潜在恶意访问，请检查后重试。如遇误拦截，请联系站点管理员。</p><a class="btn" href="javascript:history.back()">← 返回上一页</a></div></body></html>';
    }
    exit;
}

function modsecurity_run($value = null, array $ctx = []): void
{
    if (PHP_SAPI === 'cli') return;
    try {
        modsecurity_sanitize_proxy_headers();
        if (modsecurity_cc_enabled()) modsecurity_schema();
        modsecurity_cc_run();
        if ((string)modsecurity_cfg('mode') === '') {
            modsecurity_page_cache_boot();
            return;
        }
        $config = modsecurity_config();
        $mode = (string)($config['mode'] ?? 'block');
        if ($mode === 'off') {
            modsecurity_page_cache_boot();
            return;
        }
        $threshold = max(1, min(100, (int)($config['anomaly_threshold'] ?? 5)));
        $ip = modsecurity_client_ip();

        /* Administrators remain protected unless the emergency detect-only option is enabled. */
        $is_admin = function_exists('is_super_user') && is_super_user();
        if ($is_admin && (string)($config['admin_bypass_enabled'] ?? '0') === '1') $mode = 'detect';

        /* 先检查 IP 封禁 */
        if ($mode === 'block' && modsecurity_ip_banned($ip)) {
            modsecurity_block('IP 地址已被防火墙临时封禁，请稍后再试');
        }

        $targets = modsecurity_collect_targets();
        $s = ['mode' => $mode, 'threshold' => $threshold, 'anomaly' => 0, 'events' => []];
        $blocked = false;

        /* 协议类检查 */
        modsecurity_meta_checks($s, $targets);
        $blocked = $blocked || ($mode === 'block' && $s['anomaly'] >= $threshold);

        /* 规则引擎 */
        if (!$blocked) {
            foreach (modsecurity_rules() as $rule) {
                if (!modsecurity_rule_allowed($rule)) continue;
                $found = false;
                $match = '';
                $count = (int)($rule['count'] ?? 0);
                foreach ((array)$rule['target'] as $tname) {
                    foreach ($targets[$tname] ?? [] as $tvalue) {
                        if ($count > 0) {
                            $n = @preg_match_all($rule['regex'], $tvalue, $m);
                            if ($n !== false && $n >= $count) { $found = true; $match = $tvalue; break 2; }
                        } else {
                            if (@preg_match($rule['regex'], $tvalue, $m)) { $found = true; $match = $tvalue; break 2; }
                        }
                    }
                }
                if (!$found) continue;
                if (modsecurity_add_hit($s, $rule, $match, (string)$tname)) { $blocked = true; break; }
            }
        }

        if ($s['events']) modsecurity_collect_events($s['events'], $targets);

        if ($blocked) {
            modsecurity_auto_ban($ip);
            modsecurity_block('检测到恶意请求，已被 Web 应用防火墙拦截');
        }
        modsecurity_page_cache_boot();
    } catch (Throwable $e) {
        debug_log_write('ModSecurity 防火墙执行异常', $e);
    }
}

/* ---------------- IP 封禁 ---------------- */

function modsecurity_ip_banned(string $ip): bool
{
    if ($ip === '' || $ip === '0.0.0.0' || $ip === '::') return false;
    return (bool)one("SELECT id FROM plugin_modsecurity_bans WHERE ip=? AND (expires_at=0 OR expires_at>?)", [$ip, time()]);
}

function modsecurity_auto_ban(string $ip): void
{
    if ((string)modsecurity_cfg('auto_ban_enabled') !== '1') return;
    if ($ip === '' || $ip === '0.0.0.0' || $ip === '::') return;
    $window = max(60, (int)modsecurity_cfg('auto_ban_window'));
    $threshold = max(1, (int)modsecurity_cfg('auto_ban_threshold'));
    $duration = max(0, (int)modsecurity_cfg('auto_ban_duration'));
    $count = (int)val("SELECT COUNT(*) FROM plugin_modsecurity_events WHERE ip=? AND blocked=1 AND created_at>=?", [$ip, time() - $window]);
    if ($count < $threshold) return;
    $now = time();
    $expires = $duration > 0 ? $now + $duration : 0;
    app_db_upsert('plugin_modsecurity_bans', [
        'ip' => $ip,
        'reason' => '防火墙自动封禁（窗口内触发 ' . $count . ' 次拦截）',
        'hits' => $count,
        'created_at' => $now,
        'expires_at' => $expires,
    ], ['ip']);
}

function modsecurity_cc_enabled(): bool
{
    return (string)modsecurity_cfg('cc_enabled') === '1';
}

function modsecurity_cc_hit(string $ip, int $window): int
{
    $now = time();
    $expired = $now - $window;
    if (db_driver() === 'mysql') {
        q('INSERT INTO plugin_modsecurity_cc(ip,window_started,hits,updated_at) VALUES(?,?,1,?) ON DUPLICATE KEY UPDATE hits=IF(window_started<?,1,hits+1),window_started=IF(window_started<?,VALUES(window_started),window_started),updated_at=VALUES(updated_at)', [$ip, $now, $now, $expired, $expired]);
    } else {
        q('INSERT INTO plugin_modsecurity_cc(ip,window_started,hits,updated_at) VALUES(?,?,1,?) ON CONFLICT(ip) DO UPDATE SET hits=CASE WHEN plugin_modsecurity_cc.window_started<? THEN 1 ELSE plugin_modsecurity_cc.hits+1 END,window_started=CASE WHEN plugin_modsecurity_cc.window_started<? THEN excluded.window_started ELSE plugin_modsecurity_cc.window_started END,updated_at=excluded.updated_at', [$ip, $now, $now, $expired, $expired]);
    }
    return (int)val('SELECT hits FROM plugin_modsecurity_cc WHERE ip=?', [$ip]);
}

function modsecurity_cc_run(): void
{
    if (!modsecurity_cc_enabled() || PHP_SAPI === 'cli') return;
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (!in_array($method, ['GET', 'POST', 'HEAD'], true) || (string)($_GET['a'] ?? '') === 'cron') return;
    if ((string)modsecurity_cfg('cc_exempt_admin') === '1' && function_exists('is_super_user') && is_super_user()) return;
    $ip = modsecurity_client_ip();
    if ($ip === '0.0.0.0' || $ip === '::') return;
    if (modsecurity_ip_banned($ip)) modsecurity_block('IP 地址已被防火墙临时封禁，请稍后再试');
    $window = max(10, min(3600, (int)modsecurity_cfg('cc_window') ?: 60));
    $threshold = max(10, min(100000, (int)modsecurity_cfg('cc_threshold') ?: 120));
    $hits = modsecurity_cc_hit($ip, $window);
    if ($hits <= $threshold) return;
    $mode = (string)modsecurity_cfg('cc_mode');
    modsecurity_collect_events([['rule_id' => 990001, 'msg' => 'CC 请求频率超限（' . $hits . '/' . $window . ' 秒）', 'severity' => 'WARNING', 'category' => 'cc', 'matched' => 'hits=' . $hits, 'target' => 'IP', 'blocked' => $mode === 'block' ? 1 : 0]], ['URI' => [(string)($_SERVER['REQUEST_URI'] ?? '')]]);
    if ($mode !== 'block') return;
    $duration = max(60, min(31536000, (int)modsecurity_cfg('cc_ban_duration') ?: 600));
    modsecurity_ban_ip($ip, 'CC 防御自动封禁（' . $window . ' 秒内 ' . $hits . ' 次请求）', $duration);
    modsecurity_block('请求过于频繁，请稍后再试');
}

function modsecurity_ban_ip(string $ip, string $reason, int $duration = 0): void
{
    $ip = clean_ip($ip);
    if ($ip === '') err('IP 地址无效');
    $now = time();
    $expires = $duration > 0 ? $now + $duration : 0;
    app_db_upsert('plugin_modsecurity_bans', [
        'ip' => $ip,
        'reason' => cut($reason, 255) ?: '管理员手动封禁',
        'hits' => 0,
        'created_at' => $now,
        'expires_at' => $expires,
    ], ['ip']);
}

function modsecurity_unban(string $ip): void
{
    $ip = clean_ip($ip);
    if ($ip !== '') {
        q("DELETE FROM plugin_modsecurity_bans WHERE ip=?", [$ip]);
    }
}

/* ---------------- 后台管理页 ---------------- */

function modsecurity_admin_page(array $plugin): string
{
    $view = (string)($_GET['modsec_view'] ?? 'settings');
    if (!in_array($view, ['settings', 'rules', 'events', 'bans', 'cc'], true)) $view = 'settings';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') modsecurity_admin_handle_post($view);

    $nav = '<div class="tab-bar admin-tabs">';
    $tabs = ['settings' => '设置与概览', 'rules' => '规则管理', 'events' => '拦截日志', 'bans' => 'IP 封禁', 'cc' => 'CC 防御'];
    foreach ($tabs as $k => $v) {
        $active = $view === $k ? ' active' : '';
        $nav .= '<a class="tab' . $active . '" href="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => $k])) . '">' . $v . '</a>';
    }
    $nav .= '</div>';

    modsecurity_prune();
    $html = '';
    if ($view === 'settings') $html .= modsecurity_admin_settings_html();
    elseif ($view === 'rules') $html .= modsecurity_admin_rules_html();
    elseif ($view === 'events') $html .= modsecurity_admin_events_html();
    elseif ($view === 'bans') $html .= modsecurity_admin_bans_html();
    elseif ($view === 'cc') $html .= modsecurity_admin_cc_html();
    return $nav . $html;
}

function modsecurity_admin_handle_post(string $view): void
{
    $action = (string)($_POST['modsec_action'] ?? '');
    if ($view === 'settings' && $action === 'save') {
        $config = modsecurity_config();
        $config['mode'] = in_array((string)($_POST['mode'] ?? 'block'), ['block', 'detect', 'off'], true) ? (string)$_POST['mode'] : 'block';
        $config['anomaly_threshold'] = (string)max(1, min(100, (int)($_POST['anomaly_threshold'] ?? 5)));
        $config['paranoia_level'] = (string)max(1, min(4, (int)($_POST['paranoia_level'] ?? 1)));
        $allowed_log_levels = ['CRITICAL', 'ERROR', 'WARNING', 'NOTICE'];
        $config['log_severities'] = array_values(array_intersect($allowed_log_levels, array_map('strtoupper', array_map('strval', (array)($_POST['log_severities'] ?? [])))));
        $config['auto_ban_enabled'] = isset($_POST['auto_ban_enabled']) ? '1' : '0';
        $config['auto_ban_threshold'] = (string)max(1, min(10000, (int)($_POST['auto_ban_threshold'] ?? 10)));
        $config['auto_ban_window'] = (string)max(60, min(86400, (int)($_POST['auto_ban_window'] ?? 900)));
        $config['auto_ban_duration'] = (string)max(0, min(31536000, (int)($_POST['auto_ban_duration'] ?? 3600)));
        $config['max_request_mb'] = (string)max(1, min(1024, (int)($_POST['max_request_mb'] ?? 25)));
        $config['max_args_kb'] = (string)max(64, min(16384, (int)($_POST['max_args_kb'] ?? 2048)));
        $config['max_args_count'] = (string)max(50, min(10000, (int)($_POST['max_args_count'] ?? 500)));
        $config['max_arg_len'] = (string)max(1024, min(1048576, (int)($_POST['max_arg_len'] ?? 100000)));
        $config['max_arg_name_len'] = (string)max(64, min(8192, (int)($_POST['max_arg_name_len'] ?? 1024)));
        $config['max_uri_len'] = (string)max(256, min(16384, (int)($_POST['max_uri_len'] ?? 1024)));
        $config['max_files'] = (string)max(1, min(200, (int)($_POST['max_files'] ?? 20)));
        $config['allowed_content_types'] = cut((string)($_POST['allowed_content_types'] ?? ''), 500);
        $config['speed_optimization_enabled'] = isset($_POST['speed_optimization_enabled']) ? '1' : '0';
        $config['page_cache_ttl'] = (string)max(30, min(3600, (int)($_POST['page_cache_ttl'] ?? 300)));
        $config['browser_cache_enabled'] = isset($_POST['browser_cache_enabled']) ? '1' : '0';
        $config['admin_bypass_enabled'] = isset($_POST['admin_bypass_enabled']) ? '1' : '0';
        $config['trust_proxy_headers'] = isset($_POST['trust_proxy_headers']) ? '1' : '0';
        plugin_save_config('modsecurity', $config);
        modsecurity_page_cache_clear();
        set_flash('ModSecurity 设置已保存');
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'settings']));
    } elseif ($view === 'settings' && $action === 'clear_page_cache') {
        modsecurity_page_cache_clear();
        set_flash('公开页面缓存已清理');
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'settings']));
    } elseif ($view === 'cc' && $action === 'save') {
        $config = modsecurity_config();
        $config['cc_enabled'] = isset($_POST['cc_enabled']) ? '1' : '0';
        $config['cc_mode'] = in_array((string)($_POST['cc_mode'] ?? 'block'), ['block', 'detect'], true) ? (string)$_POST['cc_mode'] : 'block';
        $config['cc_threshold'] = (string)max(10, min(100000, (int)($_POST['cc_threshold'] ?? 120)));
        $config['cc_window'] = (string)max(10, min(3600, (int)($_POST['cc_window'] ?? 60)));
        $config['cc_ban_duration'] = (string)max(60, min(31536000, (int)($_POST['cc_ban_duration'] ?? 600)));
        $config['cc_exempt_admin'] = isset($_POST['cc_exempt_admin']) ? '1' : '0';
        plugin_save_config('modsecurity', $config);
        set_flash('CC 防御设置已保存');
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'cc']));
    } elseif ($view === 'rules' && $action === 'toggle_rule') {
        $config = modsecurity_config();
        $disabled = array_map('intval', (array)($config['disabled_rules'] ?? []));
        $id = (int)($_POST['rule_id'] ?? 0);
        if ($id > 0) {
            if ((string)($_POST['enabled'] ?? '1') === '1') $disabled = array_values(array_diff($disabled, [$id]));
            elseif (!in_array($id, $disabled, true)) $disabled[] = $id;
            $config['disabled_rules'] = array_values(array_unique($disabled));
            plugin_save_config('modsecurity', $config);
        }
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'rules']));
    } elseif ($view === 'rules' && $action === 'toggle_category') {
        $config = modsecurity_config();
        $disabled = array_values(array_diff((array)($config['disabled_categories'] ?? []), ['']));
        $cat = (string)($_POST['category'] ?? '');
        if ($cat !== '') {
            if ((string)($_POST['enabled'] ?? '1') === '1') $disabled = array_values(array_diff($disabled, [$cat]));
            elseif (!in_array($cat, $disabled, true)) $disabled[] = $cat;
            $config['disabled_categories'] = array_values(array_unique($disabled));
            plugin_save_config('modsecurity', $config);
        }
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'rules']));
    } elseif ($view === 'events' && $action === 'clear') {
        q("DELETE FROM plugin_modsecurity_events");
        set_flash('拦截日志已清空');
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'events']));
    } elseif ($view === 'events' && $action === 'clear_older') {
        q("DELETE FROM plugin_modsecurity_events WHERE created_at<?", [time() - 86400 * 7]);
        set_flash('7 天前的日志已清空');
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'events']));
    } elseif ($view === 'bans' && $action === 'unban') {
        modsecurity_unban((string)($_POST['ip'] ?? ''));
        set_flash('已解除封禁');
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'bans']));
    } elseif ($view === 'bans' && $action === 'ban') {
        modsecurity_ban_ip((string)($_POST['ip'] ?? ''), (string)($_POST['reason'] ?? ''), max(0, (int)($_POST['duration'] ?? 3600)));
        set_flash('已封禁 IP');
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'bans']));
    } elseif ($view === 'bans' && $action === 'clear_expired') {
        q("DELETE FROM plugin_modsecurity_bans WHERE expires_at>0 AND expires_at<=?", [time()]);
        set_flash('已清理过期封禁');
        go(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'bans']));
    } else {
        err('参数错误');
    }
}

function modsecurity_admin_stats(): array
{
    $total = (int)val("SELECT COUNT(*) FROM plugin_modsecurity_events");
    $blocked = (int)val("SELECT COUNT(*) FROM plugin_modsecurity_events WHERE blocked=1");
    $blocked_today = (int)val("SELECT COUNT(*) FROM plugin_modsecurity_events WHERE blocked=1 AND created_at>=?", [strtotime('today')]);
    $today = (int)val("SELECT COUNT(*) FROM plugin_modsecurity_events WHERE created_at>=?", [strtotime('today')]);
    $banned = (int)val("SELECT COUNT(*) FROM plugin_modsecurity_bans WHERE expires_at=0 OR expires_at>?", [time()]);
    $active_rules = 0;
    foreach (modsecurity_rules() as $rule) if (modsecurity_rule_allowed($rule)) $active_rules++;
    return ['total' => $total, 'blocked' => $blocked, 'blocked_today' => $blocked_today, 'today' => $today, 'banned' => $banned, 'active_rules' => $active_rules, 'total_rules' => count(modsecurity_rules())];
}

function modsecurity_admin_settings_html(): string
{
    $config = modsecurity_config();
    $stats = modsecurity_admin_stats();
    $mode = (string)($config['mode'] ?? 'block');

    $author_url = 'https://bolgk.eu.org/';
    $cards = '<div class="plugin-panel-body"><div class="admin-plugin-summary"><strong>ModSecurity 防火墙</strong><span>OWASP CRS 核心规则集 · ' . h((string)$stats['active_rules']) . '/' . (int)$stats['total_rules'] . ' 条规则生效</span></div><div class="plugin-entry-line"><span class="plugin-entry-label">运行状态</span><div class="plugin-entry-options"><span class="admin-flag ' . ($mode === 'block' ? 'on' : ($mode === 'detect' ? 'update' : '')) . '">' . h(['block' => '拦截模式', 'detect' => '检测模式', 'off' => '已关闭'][$mode] ?? $mode) . '</span></div></div></div>';
    $cards .= '<div class="plugin-stats-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;padding:12px 14px">';
    $items = [
        ['累计拦截', $stats['blocked']], ['今日拦截', $stats['blocked_today']],
        ['今日事件', $stats['today']], ['封禁中 IP', $stats['banned']],
    ];
    foreach ($items as [$label, $value]) {
        $cards .= '<div style="padding:10px;border:1px solid var(--line-soft);border-radius:7px;background:var(--bg);text-align:center"><strong style="display:block;font-size:20px;line-height:1.2">' . h((string)$value) . '</strong><span style="font-size:11px;color:var(--text-subtle)">' . h($label) . '</span></div>';
    }
    $cards .= '</div>';

    $form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'settings'])) . '">' . form_token();
    $form .= '<h3 class="plugin-panel-title">基本设置</h3>';
    $form .= select_input('运行模式', 'mode', $mode, ['block' => '拦截模式（异常分达阈值即拦截）', 'detect' => '检测模式（仅记录日志不拦截）', 'off' => '关闭检测'], '建议正式上线后使用拦截模式');
    $form .= number_input('异常分阈值', 'anomaly_threshold', (string)($config['anomaly_threshold'] ?? 5), 1, 100, true, '严重=5，错误=4；警告和提示仅记录日志，不参与拦截评分。默认 5 时一条严重规则即触发拦截');
    $form .= select_input('警惕级别（Paranoia）', 'paranoia_level', (string)($config['paranoia_level'] ?? 1), [1 => '级别 1（推荐）', 2 => '级别 2', 3 => '级别 3', 4 => '级别 4'], '级别越高检测越严格，误报率也越高');
    $log_severities = array_map('strtoupper', array_map('strval', (array)($config['log_severities'] ?? ['CRITICAL', 'ERROR', 'WARNING', 'NOTICE'])));
    $form .= '<h3 class="plugin-panel-title">事件日志级别</h3><p class="muted">仅控制是否写入拦截日志，不改变防火墙检测、评分、拦截或自动封禁功能。可多选。</p><div class="modsecurity-log-levels">';
    foreach (['CRITICAL' => '严重', 'ERROR' => '错误', 'WARNING' => '警告', 'NOTICE' => '提示'] as $level => $label) {
        $form .= '<label class="modsecurity-log-level"><span>' . h($label) . '</span><input type="checkbox" name="log_severities[]" value="' . h($level) . '"' . (in_array($level, $log_severities, true) ? ' checked' : '') . '></label>';
    }
    $form .= '</div>';
    $form .= checkbox('管理员仅记录模式', 'admin_bypass_enabled', (string)($config['admin_bypass_enabled'] ?? '0') === '1', '仅用于处理误报时的临时恢复；开启后超级管理员请求只记录不拦截，会降低管理会话防护强度');
    $form .= checkbox('信任反向代理来源头', 'trust_proxy_headers', (string)($config['trust_proxy_headers'] ?? '0') === '1', '仅当站点位于可信的 Nginx、CDN 或负载均衡之后才开启；关闭时自动封禁仅使用 REMOTE_ADDR，避免伪造 X-Forwarded-For 导致误封');
    $form .= number_input('单请求体积上限（MB）', 'max_request_mb', (string)($config['max_request_mb'] ?? 25), 1, 1024, true);
    $form .= number_input('全部参数体积上限（KB）', 'max_args_kb', (string)($config['max_args_kb'] ?? 2048), 64, 16384, true);
    $form .= number_input('参数数量上限', 'max_args_count', (string)($config['max_args_count'] ?? 500), 50, 10000, true);
    $form .= number_input('单个参数长度上限', 'max_arg_len', (string)($config['max_arg_len'] ?? 100000), 1024, 1048576, true);
    $form .= number_input('参数名长度上限', 'max_arg_name_len', (string)($config['max_arg_name_len'] ?? 1024), 64, 8192, true);
    $form .= number_input('请求路径长度上限', 'max_uri_len', (string)($config['max_uri_len'] ?? 1024), 256, 16384, true);
    $form .= number_input('附件数量上限', 'max_files', (string)($config['max_files'] ?? 20), 1, 200, true);
    $form .= textarea('允许的 Content-Type（逗号分隔）', 'allowed_content_types', (string)($config['allowed_content_types'] ?? ''), false, '超出此列表的 POST 请求会被拒绝');
    $form .= '<h3 class="plugin-panel-title">性能优化</h3>';
    $form .= checkbox('网站访问速度优化', 'speed_optimization_enabled', (string)($config['speed_optimization_enabled'] ?? '0') === '1', '匿名访问首页、版块页和帖子页时启用服务端 HTML 缓存；同时为帖子图片启用浏览器原生懒加载和异步解码');
    $form .= number_input('公开页面缓存有效期（秒）', 'page_cache_ttl', (string)($config['page_cache_ttl'] ?? 300), 30, 3600, true, '仅对匿名公开 GET 页面生效；登录、搜索、后台和表单请求不会缓存');
    $form .= checkbox('浏览器缓存优化', 'browser_cache_enabled', (string)($config['browser_cache_enabled'] ?? '0') === '1', '缓存可缓存的静态资源；发布或编辑主题、回复后自动更新缓存版本并清理旧缓存');
    $form .= '<h3 class="plugin-panel-title">自动封禁</h3>';
    $form .= checkbox('启用自动封禁', 'auto_ban_enabled', (string)($config['auto_ban_enabled'] ?? '1') === '1');
    $form .= number_input('封禁触发次数', 'auto_ban_threshold', (string)($config['auto_ban_threshold'] ?? 10), 1, 10000, true, '统计窗口内被拦截次数达到该值后封禁 IP');
    $form .= number_input('统计窗口（秒）', 'auto_ban_window', (string)($config['auto_ban_window'] ?? 900), 60, 86400, true);
    $form .= number_input('封禁时长（秒）', 'auto_ban_duration', (string)($config['auto_ban_duration'] ?? 3600), 0, 31536000, true, '0 表示永久封禁');
    $form .= '<div class="modsecurity-settings-actions"><button name="modsec_action" value="save">保存设置</button><button class="alt" style="margin-left:16px" name="modsec_action" value="clear_page_cache">清理缓存</button></div></form>';

    return '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>ModSecurity 防火墙</strong><span>OWASP CRS 核心规则集插件</span></div>', '<span class="admin-plugin-summary" style="display:inline-flex;align-items:center;gap:4px">作者：<a href="' . h($author_url) . '" target="_blank" rel="noopener">AI开源论坛</a></span>') . $cards . '</div>'
        . '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>设置</strong><span>参数调整后立即生效</span></div>', '') . '<div class="plugin-panel-body">' . $form . '</div></div>';
}

function modsecurity_admin_rules_html(): string
{
    $config = modsecurity_config();
    $disabled_rules = array_map('intval', (array)($config['disabled_rules'] ?? []));
    $disabled_categories = array_values(array_diff((array)($config['disabled_categories'] ?? []), ['']));
    $rules = modsecurity_rules();
    $by_cat = [];
    foreach ($rules as $rule) $by_cat[(string)$rule['cat']][] = $rule;

    $html = '';
    foreach (modsecurity_categories() as $cat => $cat_label) {
        $cat_rules = $by_cat[$cat] ?? [];
        if (!$cat_rules) continue;
        $cat_disabled = in_array($cat, $disabled_categories, true);
        $on_count = 0;
        foreach ($cat_rules as $r) if (!in_array((int)$r['id'], $disabled_rules, true)) $on_count++;
        $toggle = '<form class="post-action-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'rules'])) . '" data-replace-target=".plugin-manage-panel">' . form_token() . hidden_inputs(['modsec_action' => 'toggle_category', 'category' => $cat, 'enabled' => $cat_disabled ? '1' : '0']) . '<button class="' . ($cat_disabled ? '' : 'danger') . '">' . ($cat_disabled ? '启用' : '停用') . '整类</button></form>';
        $head = '<div class="admin-plugin-summary"><strong>' . h($cat_label) . '</strong><span>' . $on_count . '/' . count($cat_rules) . ' 条生效</span></div>';
        $html .= '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head($head, $toggle) . '<ul class="admin-manage-list">';
        foreach ($cat_rules as $rule) {
            $id = (int)$rule['id'];
            $enabled = !$cat_disabled && !in_array($id, $disabled_rules, true);
            $sev = strtoupper((string)$rule['sev']);
            $sev_class = $sev === 'CRITICAL' ? 'danger' : ($sev === 'ERROR' ? '' : ($sev === 'WARNING' ? 'update' : ''));
            $sev_label = modsecurity_severity_label($sev);
            $paranoia = (int)($rule['paranoia'] ?? 1);
            $targets = implode(',', (array)$rule['target']);
            $rule_toggle = '<form class="post-action-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'rules'])) . '" data-replace-target=".plugin-manage-panel">' . form_token() . hidden_inputs(['modsec_action' => 'toggle_rule', 'rule_id' => $id, 'enabled' => $enabled ? '0' : '1']) . '<button class="' . ($enabled ? 'danger' : '') . '">' . ($enabled ? '停用' : '启用') . '</button></form>';
            $html .= '<li class="admin-list-item admin-object-row"><div class="admin-row-main"><div class="plugin-title-line"><strong class="admin-content-title">' . $id . '</strong><span class="admin-flag ' . ($enabled ? 'on' : '') . '">' . h($enabled ? '生效' : '已停用') . '</span><span class="admin-flag ' . $sev_class . '">' . h($sev_label) . '</span><span class="admin-flag">P' . $paranoia . '</span></div><div class="admin-row-meta"><span>' . h((string)$rule['msg']) . '</span></div><div class="admin-content-text plugin-desc" style="font-family:ui-monospace,monospace;font-size:11px">' . h($targets) . '</div></div><div class="admin-inline-ops plugin-ops">' . $rule_toggle . '</div></li>';
        }
        $html .= '</ul></div>';
    }
    return $html;
}

function modsecurity_admin_events_html(): string
{
    $size = 50;
    $page = max(1, (int)($_GET['p'] ?? 1));
    $offset = ($page - 1) * $size;
    $where = [];
    $params = [];
    $severity = (string)($_GET['sev'] ?? '');
    if (in_array(strtoupper($severity), ['CRITICAL', 'ERROR', 'WARNING', 'NOTICE'], true)) {
        $where[] = 'severity=?';
        $params[] = strtoupper($severity);
    }
    $category = (string)($_GET['cat'] ?? '');
    if (array_key_exists($category, modsecurity_categories())) {
        $where[] = 'category=?';
        $params[] = $category;
    }
    $blocked = (string)($_GET['blocked'] ?? '');
    if (in_array($blocked, ['0', '1'], true)) {
        $where[] = 'blocked=?';
        $params[] = (int)$blocked;
    }
    $q = trim((string)($_GET['q'] ?? ''));
    if ($q !== '') {
        $like = admin_search_like($q);
        $where[] = "(ip LIKE ? ESCAPE '!' OR msg LIKE ? ESCAPE '!' OR matched LIKE ? ESCAPE '!' OR uri LIKE ? ESCAPE '!')";
        array_push($params, $like, $like, $like, $like);
    }
    $where_sql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

    $total = (int)val("SELECT COUNT(*) FROM plugin_modsecurity_events" . $where_sql, $params);
    $rows = q("SELECT * FROM plugin_modsecurity_events" . $where_sql . " ORDER BY created_at DESC,id DESC LIMIT " . ($size + 1) . " OFFSET " . $offset, $params)->fetchAll();
    $has_next = count($rows) > $size;
    if ($has_next) array_pop($rows);

    $clear = '<form class="post-action-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'events'])) . '" data-confirm="确定清空全部拦截日志？">' . form_token() . hidden_inputs(['modsec_action' => 'clear']) . '<button class="danger">清空日志</button></form>';
    $clear_older = '<form class="post-action-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'events'])) . '" data-confirm="确定清空 7 天前的日志？">' . form_token() . hidden_inputs(['modsec_action' => 'clear_older']) . '<button>清理 7 天前</button></form>';

    $filters = '<form class="admin-table-search" method="get" action="' . h(index_url()) . '">' . hidden_inputs(['a' => 'admin', 'tab' => 'modsecurity', 'modsec_view' => 'events']) . '<div class="admin-search-field"><input name="q" value="' . h($q) . '" placeholder="搜索 IP / 规则 / 内容"><button class="admin-search-submit" type="submit">搜索</button></div></form>';
    $sev_opts = ['ALL' => '全部级别', 'CRITICAL' => '严重', 'ERROR' => '错误', 'WARNING' => '警告', 'NOTICE' => '提示'];
    $filters .= '<div class="plugin-entry-line"><span class="plugin-entry-label">筛选</span><div class="plugin-entry-options">';
    foreach ($sev_opts as $k => $v) {
        $active = $severity === $k ? ' on' : '';
        $filters .= '<a class="admin-flag' . $active . '" href="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'events', 'sev' => $k === 'ALL' ? null : $k, 'cat' => $category, 'blocked' => $blocked, 'q' => $q])) . '">' . $v . '</a>';
    }
    $cat_opts = modsecurity_categories();
    $filters .= '<select onchange="location.href=this.value"><option value="">全部类别</option>';
    foreach ($cat_opts as $k => $v) $filters .= '<option value="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'events', 'cat' => $k, 'sev' => $severity, 'q' => $q])) . '"' . ($category === $k ? ' selected' : '') . '>' . h($v) . '</option>';
    $filters .= '</select></div></div>';

    $html = '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>拦截日志</strong><span>共 ' . $total . ' 条记录</span></div>', $clear . $clear_older) . '<div class="plugin-panel-body">' . $filters . '</div><ul class="admin-manage-list">';
    foreach ($rows as $row) {
        $sev = (string)$row['severity'];
        $sev_class = $sev === 'CRITICAL' ? 'danger' : ($sev === 'ERROR' ? '' : ($sev === 'WARNING' ? 'update' : ''));
        $blocked_flag = (int)$row['blocked'] === 1 ? '<span class="admin-flag danger">已拦截</span>' : '<span class="admin-flag">仅记录</span>';
        $target = (string)($row['target'] ?? '');
        $matched = in_array($target, ['COOKIES', 'HEADERS'], true) ? '[redacted]' : (string)($row['matched'] ?? '');
        $category_label = modsecurity_categories()[(string)($row['category'] ?? '')] ?? (string)($row['category'] ?? '');
        $detail = '<details class="modsecurity-event-detail"><summary>查看详细日志</summary><div class="modsecurity-event-grid">'
            . '<span>请求 ID</span><code>' . h((string)($row['request_id'] ?? '')) . '</code>'
            . '<span>规则 ID</span><code>' . h((string)$row['rule_id']) . '</code>'
            . '<span>规则类别</span><span>' . h($category_label) . '</span>'
            . '<span>检测目标</span><code>' . h($target ?: '未知') . '</code>'
            . '<span>请求方法</span><code>' . h((string)$row['method']) . '</code>'
            . '<span>来源 IP</span><code>' . h((string)$row['ip']) . '</code>'
            . '<span>用户 ID</span><code>' . ((int)($row['user_id'] ?? 0) > 0 ? (int)$row['user_id'] : '访客') . '</code>'
            . '<span>记录时间</span><code>' . date('Y-m-d H:i:s', (int)$row['created_at']) . '</code>'
            . '<span>请求路径</span><code>' . h((string)$row['uri']) . '</code>'
            . '<span>命中内容</span><code>' . h($matched !== '' ? $matched : '无') . '</code>'
            . '</div></details>';
        $html .= '<li class="admin-list-item admin-object-row"><div class="admin-row-main"><div class="plugin-title-line"><strong class="admin-content-title">规则 ' . h((string)$row['rule_id']) . '</strong><span class="admin-flag ' . $sev_class . '">' . h(modsecurity_severity_label($sev)) . '</span>' . $blocked_flag . '<span class="admin-flag">' . h((string)($row['category'] ?? '')) . '</span></div><div class="admin-row-meta"><span>' . h((string)$row['msg']) . '</span><span>' . h((string)$row['ip']) . '</span><span>' . h((string)$row['method']) . '</span><span>' . date('Y-m-d H:i:s', (int)$row['created_at']) . '</span></div>' . $detail . '</div></li>';
    }
    if (!$rows) $html .= '<li class="empty-state">暂无拦截记录</li>';
    $html .= '</ul></div>';
    $pagination = simple_paginate($page > 1, $has_next, $page, admin_url(['tab' => 'modsecurity', 'modsec_view' => 'events', 'sev' => $severity, 'cat' => $category, 'blocked' => $blocked, 'q' => $q]));
    return '<style>' . modsecurity_css() . '</style>' . $html . ($pagination === '' ? '' : '<div class="pagination-bar">' . $pagination . '</div>');
}

function modsecurity_admin_bans_html(): string
{
    $size = 50;
    $page = max(1, (int)($_GET['p'] ?? 1));
    $offset = ($page - 1) * $size;
    $now = time();
    $total = (int)val("SELECT COUNT(*) FROM plugin_modsecurity_bans WHERE expires_at=0 OR expires_at>?", [$now]);
    $rows = q("SELECT * FROM plugin_modsecurity_bans WHERE expires_at=0 OR expires_at>? ORDER BY created_at DESC,id DESC LIMIT " . ($size + 1) . " OFFSET " . $offset, [$now])->fetchAll();
    $has_next = count($rows) > $size;
    if ($has_next) array_pop($rows);

    $add = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'bans'])) . '">' . form_token() . hidden_inputs(['modsec_action' => 'ban']) . '<div class="grid"><span>手动封禁 IP</span></div>' . input('IP 地址', 'ip', '', 'text', true) . input('原因', 'reason', '', 'text') . number_input('封禁时长（秒，0=永久）', 'duration', 3600, 0, 31536000) . '<button>封禁</button></form>';
    $clear = '<form class="post-action-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'bans'])) . '" data-confirm="确定清理所有已过期封禁？">' . form_token() . hidden_inputs(['modsec_action' => 'clear_expired']) . '<button>清理过期</button></form>';

    $html = '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>添加封禁</strong><span>手动封禁指定 IP</span></div>', '') . '<div class="plugin-panel-body">' . $add . '</div></div>';
    $html .= '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>封禁列表</strong><span>生效中 ' . $total . ' 条</span></div>', $clear) . '<ul class="admin-manage-list">';
    foreach ($rows as $row) {
        $expires = (int)$row['expires_at'];
        $expire_text = $expires === 0 ? '永久' : ($expires > $now ? date('Y-m-d H:i', $expires) : '已过期');
        $unban = '<form class="post-action-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'bans'])) . '" data-confirm="确定解除该 IP 封禁？">' . form_token() . hidden_inputs(['modsec_action' => 'unban', 'ip' => (string)$row['ip']]) . '<button class="danger">解封</button></form>';
        $html .= '<li class="admin-list-item admin-object-row"><div class="admin-row-main"><div class="plugin-title-line"><strong class="admin-content-title">' . h((string)$row['ip']) . '</strong><span class="admin-flag danger">封禁中</span></div><div class="admin-row-meta"><span>' . h((string)$row['reason']) . '</span><span>触发 ' . (int)$row['hits'] . ' 次</span><span>截至 ' . h($expire_text) . '</span><span>' . date('Y-m-d H:i', (int)$row['created_at']) . '</span></div></div><div class="admin-inline-ops">' . $unban . '</div></li>';
    }
    if (!$rows) $html .= '<li class="empty-state">暂无生效封禁</li>';
    $html .= '</ul></div>';
    $pagination = simple_paginate($page > 1, $has_next, $page, admin_url(['tab' => 'modsecurity', 'modsec_view' => 'bans']));
    return $html . ($pagination === '' ? '' : '<div class="pagination-bar">' . $pagination . '</div>');
}

function modsecurity_admin_cc_html(): string
{
    $config = modsecurity_config();
    $enabled = (string)($config['cc_enabled'] ?? '0') === '1';
    $mode = (string)($config['cc_mode'] ?? 'block');
    $form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'modsecurity', 'modsec_view' => 'cc'])) . '">' . form_token() . hidden_inputs(['modsec_action' => 'save']);
    $form .= checkbox('启用 CC 防御', 'cc_enabled', $enabled, '按来源 IP 统计网站请求频率；超过阈值后按所选模式处理');
    $form .= select_input('处理模式', 'cc_mode', $mode, ['block' => '自动封禁并拦截', 'detect' => '仅记录日志'], '建议先使用仅记录模式观察正常访问量，再启用自动封禁');
    $form .= number_input('请求阈值', 'cc_threshold', (string)($config['cc_threshold'] ?? 120), 10, 100000, true, '同一 IP 在统计窗口内允许的最大请求数；超过后触发 CC 防御');
    $form .= number_input('统计窗口（秒）', 'cc_window', (string)($config['cc_window'] ?? 60), 10, 3600, true, '例如 60 秒内超过 120 次请求即触发');
    $form .= number_input('自动封禁时长（秒）', 'cc_ban_duration', (string)($config['cc_ban_duration'] ?? 600), 60, 31536000, true, '仅在自动封禁模式下生效；封禁记录可在「IP 封禁」中统一管理');
    $form .= checkbox('管理员免计数', 'cc_exempt_admin', (string)($config['cc_exempt_admin'] ?? '1') === '1', '已登录的超级管理员请求不计入 CC 统计，避免后台批量操作触发防御');
    $form .= '<button>保存设置</button></form>';
    return '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>CC 防御</strong><span>按 IP 限制高频请求并自动封禁异常访问</span></div>', '') . '<div class="plugin-panel-body">' . $form . '</div></div>';
}

function modsecurity_css(): string
{
    return '.modsecurity-event-detail{margin-top:8px}.modsecurity-event-detail summary{width:max-content;max-width:100%;color:var(--brand);font-size:12px;cursor:pointer}.modsecurity-event-grid{display:grid;grid-template-columns:112px minmax(0,1fr);gap:5px 10px;margin-top:8px;padding:10px;border:1px solid var(--line-soft);border-radius:6px;background:var(--bg);font-size:12px;line-height:1.45}.modsecurity-event-grid>span:nth-child(odd){color:var(--text-subtle)}.modsecurity-event-grid code{min-width:0;overflow-wrap:anywhere;white-space:pre-wrap;color:var(--text);font:11px/1.45 var(--font-mono)}.modsecurity-log-levels{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 14px}.modsecurity-log-level{display:inline-flex!important;grid-template-columns:auto!important;align-items:center!important;gap:6px!important;width:auto!important;min-width:82px;padding:7px 10px;border:1px solid var(--line-soft);border-radius:6px;background:var(--bg);cursor:pointer}.modsecurity-log-level input{width:auto!important;min-height:0!important;max-width:none!important}.modsecurity-settings-actions{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin-top:12px}.plugin-settings-form .modsecurity-settings-actions button{width:auto;margin-top:0}.modsecurity-settings-actions button+button{margin-left:10px;background:var(--bg);color:var(--text-muted);border:1px solid var(--line)}.modsecurity-settings-actions button+button:hover{background:var(--line-soft);color:var(--text);border-color:var(--text-subtle)}@media(max-width:560px){.modsecurity-event-grid{grid-template-columns:1fr;gap:2px;margin-top:7px}.modsecurity-event-grid>span:nth-child(odd){margin-top:5px;font-weight:600}.modsecurity-event-grid>span:nth-child(odd):first-child{margin-top:0}.modsecurity-settings-actions{gap:8px}.modsecurity-settings-actions button+button{margin-left:8px}}';
}

/* ---------------- 插件清单 ---------------- */

return [
    'id' => 'modsecurity',
    'name' => 'ModSecurity 防火墙',
    'version' => '1.3.0',
    'description' => '应用层 Web 应用防火墙（WAF），内置 OWASP ModSecurity 核心规则集，支持异常评分、检测/拦截模式、自动 IP 封禁、可信代理配置、资源限制与脱敏日志审计；另提供可独立启停的网站访问速度优化（匿名公开页缓存与图片懒加载）和浏览器缓存优化（内容变更自动失效）。',
    'author' => 'AI开源论坛',
    'author_url' => 'https://bolgk.eu.org/',
    'hooks' => [
        'app.boot' => 'modsecurity_run',
        'page.head' => 'modsecurity_page_head',
        'topic.after_save' => 'modsecurity_topic_saved',
        'reply.after_save' => 'modsecurity_topic_saved',
        'topic.after_delete' => 'modsecurity_topic_saved',
        'reply.after_delete' => 'modsecurity_topic_saved',
    ],
    'assets' => [
        'css' => 'modsecurity_css',
    ],
    'routes' => [
        'modsecurity_sw' => 'modsecurity_service_worker_route',
    ],
    'admin_tabs' => [
        'modsecurity' => 'modsecurity_admin_page',
    ],
    'install' => 'modsecurity_install',
    'uninstall' => 'modsecurity_uninstall',
];