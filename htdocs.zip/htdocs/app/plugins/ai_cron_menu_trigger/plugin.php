<?php
if (!defined('APP_ROOT')) exit;

function ai_cron_menu_trigger_config(): array
{
    $raw = plugin_config('ai_cron_menu_trigger', []);
    $interval = min(10080, max(1, (int)($raw['interval_minutes'] ?? 60)));
    $raw_names = $raw['menu_names'] ?? ['今日热点'];
    if (!is_array($raw_names)) $raw_names = preg_split('/\R/u', (string)$raw_names) ?: [];
    $names = [];
    foreach ($raw_names as $name) {
        $name = trim((string)$name);
        if ($name === '' || mb_strlen($name) > 100) continue;
        if (!in_array($name, $names, true)) $names[] = $name;
    }
    return [
        'interval_minutes' => $interval,
        'menu_names' => $names,
    ];
}

function ai_cron_menu_trigger_normalize_names(string $value): array
{
    $names = [];
    foreach (preg_split('/\R/u', $value) ?: [] as $name) {
        $name = trim($name);
        if ($name === '' || mb_strlen($name) > 100) continue;
        if (!in_array($name, $names, true)) $names[] = $name;
    }
    return $names;
}

function ai_cron_menu_trigger_admin_page(array $plugin): string
{
    need_admin();
    $config = ai_cron_menu_trigger_config();
    $message = '';
    if (is_post_request()) {
        require_post();
        $interval = min(10080, max(1, (int)($_POST['interval_minutes'] ?? 60)));
        $names = ai_cron_menu_trigger_normalize_names((string)($_POST['menu_names'] ?? ''));
        plugin_save_config('ai_cron_menu_trigger', [
            'interval_minutes' => $interval,
            'menu_names' => $names,
        ]);
        $config = ai_cron_menu_trigger_config();
        $message = '设置已保存';
    }

    $names_text = implode("\n", $config['menu_names']);
    $cron_url = route_url('cron');
    $body = '';
    if ($message !== '') $body .= '<div class="notice success">' . h($message) . '</div>';
    $body .= '<div class="form-panel">'
        . '<form method="post">'
        . form_token()
        . number_input('触发间隔（分钟）', 'interval_minutes', $config['interval_minutes'], 1, 10080, true, '同一浏览器在这个时间内再次点击匹配菜单，不会重复请求 Cron。范围：1 分钟至 7 天。')
        . textarea('触发菜单名称', 'menu_names', $names_text, false, '每行一个菜单名称，按菜单显示文字精确匹配。例如：今日热点。留空表示不触发任何菜单。')
        . '<div class="row settings-actions"><button type="submit">保存</button></div>'
        . '</form>'
        . '<div class="admin-row-meta"><span>后台请求地址：' . h($cron_url) . '</span><span>正常菜单跳转不会被阻塞。</span></div>'
        . '</div>';
    return $body;
}

function ai_cron_menu_trigger_footer($html, array $ctx): string
{
    $config = ai_cron_menu_trigger_config();
    $names_json = plugin_json_encode(array_values($config['menu_names']));
    $interval_seconds = (int)$config['interval_minutes'] * 60;
    $cron_url = route_url('cron');
    $marker = '<div id="ai-cron-menu-trigger-config"'
        . ' data-ai-cron-menu-trigger-interval="' . h((string)$interval_seconds) . '"'
        . ' data-ai-cron-menu-trigger-menu-names="' . h($names_json) . '"'
        . ' data-ai-cron-menu-trigger-cron-url="' . h($cron_url) . '" hidden></div>';
    return (string)$html . $marker;
}

function ai_cron_menu_trigger_js(): string
{
    return <<<'JS'
(function () {
    'use strict';

    function ai_cron_menu_trigger_init() {
        var ai_cron_menu_trigger_config = document.getElementById('ai-cron-menu-trigger-config');
        if (!ai_cron_menu_trigger_config) return;

        var ai_cron_menu_trigger_interval = parseInt(ai_cron_menu_trigger_config.getAttribute('data-ai-cron-menu-trigger-interval') || '3600', 10);
        var ai_cron_menu_trigger_cron_url = ai_cron_menu_trigger_config.getAttribute('data-ai-cron-menu-trigger-cron-url') || '';
        var ai_cron_menu_trigger_names = [];
        try {
            var ai_cron_menu_trigger_raw_names = JSON.parse(ai_cron_menu_trigger_config.getAttribute('data-ai-cron-menu-trigger-menu-names') || '[]');
            if (Array.isArray(ai_cron_menu_trigger_raw_names)) {
                ai_cron_menu_trigger_names = ai_cron_menu_trigger_raw_names.map(function (ai_cron_menu_trigger_name) {
                    return String(ai_cron_menu_trigger_name || '').trim();
                }).filter(Boolean);
            }
        } catch (ai_cron_menu_trigger_error) {
            return;
        }

        ai_cron_menu_trigger_interval = Math.max(60, ai_cron_menu_trigger_interval);
        if (!ai_cron_menu_trigger_cron_url || !ai_cron_menu_trigger_names.length) return;

        var ai_cron_menu_trigger_storage_key = 'ai_cron_menu_trigger_last_at';

        function ai_cron_menu_trigger_get_last_at() {
            try {
                var ai_cron_menu_trigger_value = window.localStorage.getItem(ai_cron_menu_trigger_storage_key);
                var ai_cron_menu_trigger_last_at = parseInt(ai_cron_menu_trigger_value || '0', 10);
                return Number.isFinite(ai_cron_menu_trigger_last_at) ? ai_cron_menu_trigger_last_at : 0;
            } catch (ai_cron_menu_trigger_error) {
                return 0;
            }
        }

        function ai_cron_menu_trigger_mark_now() {
            try {
                window.localStorage.setItem(ai_cron_menu_trigger_storage_key, String(Date.now()));
                return true;
            } catch (ai_cron_menu_trigger_error) {
                return false;
            }
        }

        function ai_cron_menu_trigger_should_run() {
            return Date.now() - ai_cron_menu_trigger_get_last_at() >= ai_cron_menu_trigger_interval * 1000;
        }

        function ai_cron_menu_trigger_match(ai_cron_menu_trigger_link) {
            if (!ai_cron_menu_trigger_link) return false;
            var ai_cron_menu_trigger_text = String(ai_cron_menu_trigger_link.textContent || '').replace(/\s+/g, ' ').trim();
            return ai_cron_menu_trigger_names.indexOf(ai_cron_menu_trigger_text) !== -1;
        }

        function ai_cron_menu_trigger_send() {
            if (!ai_cron_menu_trigger_should_run()) return;
            if (!ai_cron_menu_trigger_mark_now()) return;
            try {
                window.fetch(ai_cron_menu_trigger_cron_url, {
                    method: 'GET',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    keepalive: true
                }).catch(function () {});
            } catch (ai_cron_menu_trigger_error) {}
        }

        document.addEventListener('click', function (ai_cron_menu_trigger_event) {
            if (ai_cron_menu_trigger_event.defaultPrevented) return;
            if (ai_cron_menu_trigger_event.button !== 0) return;
            if (ai_cron_menu_trigger_event.metaKey || ai_cron_menu_trigger_event.ctrlKey || ai_cron_menu_trigger_event.shiftKey || ai_cron_menu_trigger_event.altKey) return;

            var ai_cron_menu_trigger_link = ai_cron_menu_trigger_event.target && ai_cron_menu_trigger_event.target.closest
                ? ai_cron_menu_trigger_event.target.closest('a')
                : null;
            if (!ai_cron_menu_trigger_link || !ai_cron_menu_trigger_match(ai_cron_menu_trigger_link)) return;

            var ai_cron_menu_trigger_is_top_menu = !!ai_cron_menu_trigger_link.closest('[data-slot~="top.menu_links"]');
            var ai_cron_menu_trigger_is_mobile_menu = !!ai_cron_menu_trigger_link.closest('.mobile-menu-body');
            if (!ai_cron_menu_trigger_is_top_menu && !ai_cron_menu_trigger_is_mobile_menu) return;

            ai_cron_menu_trigger_send();
        }, true);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', ai_cron_menu_trigger_init, { once: true });
    } else {
        ai_cron_menu_trigger_init();
    }
}());
JS;
}

return [
    'id' => 'ai_cron_menu_trigger',
    'name' => '菜单触发 Cron',
    'version' => '1.0.0',
    'description' => '点击指定菜单时，在后台更新任务并继续正常打开菜单页面。',
    'author' => 'bbs1.org',
    'assets' => ['js' => 'ai_cron_menu_trigger_js'],
    'hooks' => ['page.footer' => 'ai_cron_menu_trigger_footer'],
    'admin_tabs' => ['ai_cron_menu_trigger' => 'ai_cron_menu_trigger_admin_page'],
];
