<?php
if (!defined('APP_ROOT')) exit;

function next_admin_admin_tabs_hook($items, array $ctx): array
{
    $items = is_array($items) ? $items : [];
    return ['next_admin' => ['label' => '新版后台', 'href' => route_url('next_admin')]] + $items;
}

function next_admin_install(array $plugin): void
{
    app_db_drop_index('idx_next_admin_trash_type_time', 'plugin_next_admin_trash');
    app_db_drop_index('idx_next_admin_trash_parent', 'plugin_next_admin_trash');
    app_db_drop_table('plugin_next_admin_trash');
}

function next_admin_url(string $view = 'overview', array $params = []): string
{
    return route_url('next_admin', array_merge(['view' => $view], $params));
}

function next_admin_view(): string
{
    $view = (string)($_GET['view'] ?? 'overview');
    return in_array($view, ['overview', 'content', 'users', 'user_edit', 'forums', 'forum_edit', 'groups', 'group_edit', 'settings', 'plugins', 'system'], true) ? $view : 'overview';
}

function next_admin_redirect(string $view, string $message, array $params = []): never
{
    set_flash($message);
    go(next_admin_url($view, $params));
}

function next_admin_handle_post(): never
{
    require_post();
    need_admin();
    $action = (string)($_POST['next_admin_action'] ?? '');
    if ($action === 'save_settings') {
        save_settings();
        next_admin_redirect('settings', '站点设置已保存');
    }
    if ($action === 'clear_opcache') {
        clear_opcache_cache();
        next_admin_redirect('settings', 'OPcache 已清理');
    }
    if ($action === 'save_forum') {
        if (isset($_GET['id'])) err('参数错误');
        save_forum();
        next_admin_redirect('forums', '版块已保存');
    }
    if ($action === 'delete_forum') {
        $forum_id = next_admin_post_id();
        if (!can_admin_delete('forums', $forum_id)) err('无权限');
        if ((int)val('SELECT COUNT(*) FROM app_topics WHERE forum_id=?', [$forum_id]) > 0) err('请先迁移该版块中的主题');
        del('forums', $forum_id);
        next_admin_redirect('forums', '版块已删除');
    }
    if ($action === 'save_group') {
        if (isset($_GET['id'])) err('参数错误');
        save_group();
        next_admin_redirect('groups', '用户组已保存');
    }
    if ($action === 'delete_group') {
        $group_id = next_admin_post_id();
        if (!can_admin_delete('groups', $group_id)) err('无权限');
        if ((int)val('SELECT COUNT(*) FROM app_users WHERE group_id=?', [$group_id]) > 0) err('请先迁移该用户组中的用户');
        del('groups', $group_id);
        next_admin_redirect('groups', '用户组已删除');
    }
    if ($action === 'save_user') {
        if (!can_manage()) err('无权限');
        if (isset($_GET['id'])) err('参数错误');
        if ((int)($_POST['id'] ?? 0) === 1 && !is_super_user()) err('无权限');
        save_user(true);
        next_admin_redirect('users', '用户资料已保存');
    }
    if ($action === 'user_state') {
        if (!can_manage()) err('无权限');
        $user_id = next_admin_post_id();
        if ($user_id === 1 || $user_id === uid()) err('不能限制当前账号或超级管理员');
        $state = (string)($_POST['state'] ?? '');
        $updates = ['ban' => ['is_banned', 1], 'unban' => ['is_banned', 0], 'mute' => ['is_muted', 1], 'unmute' => ['is_muted', 0]];
        if (!isset($updates[$state])) err('参数错误');
        [$field, $value] = $updates[$state];
        q("UPDATE app_users SET $field=? WHERE id=?", [$value, $user_id]);
        next_admin_redirect('users', '用户状态已更新');
    }
    if ($action === 'delete_user') {
        if (!can_manage()) err('无权限');
        $user_id = next_admin_post_id();
        if (!can_admin_delete('users', $user_id)) err('无权限');
        del('users', $user_id);
        next_admin_redirect('users', '用户已删除');
    }
    if ($action === 'delete_topic') {
        if (!can_manage()) err('无权限');
        $topic_id = next_admin_post_id();
        if (!can_admin_delete('topics', $topic_id)) err('无权限');
        next_admin_delete_topic($topic_id);
        next_admin_redirect('content', '主题已删除');
    }
    if ($action === 'delete_reply') {
        if (!can_manage()) err('无权限');
        $reply_id = next_admin_post_id();
        if (!can_admin_delete('replies', $reply_id)) err('无权限');
        del('replies', $reply_id);
        next_admin_redirect('content', '回复已删除', ['type' => 'replies']);
    }
    if ($action === 'move_topic') {
        if (!can_manage()) err('无权限');
        $topic_id = next_admin_post_id();
        $forum_id = filter_var($_POST['forum_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($forum_id === false) err('参数错误');
        if (!can_admin_delete('topics', $topic_id) || !forum_by_id($forum_id)) err('参数错误');
        q('UPDATE app_topics SET forum_id=? WHERE id=?', [$forum_id, $topic_id]);
        fire('topic.after_save', ['id' => $topic_id, 'forum_id' => (int)$forum_id, 'editing' => true]);
        next_admin_redirect('content', '主题已转移');
    }
    if ($action === 'bulk') {
        if (!can_manage()) err('无权限');
        $type = in_array((string)($_POST['type'] ?? ''), ['topics', 'replies', 'users'], true) ? (string)$_POST['type'] : err('参数错误');
        $bulk_action = (string)($_POST['bulk_action'] ?? '');
        $ids = array_slice(array_values(array_unique(array_filter(array_map('intval', (array)($_POST['ids'] ?? [])), static fn(int $id): bool => $id > 0))), 0, 500);
        if (!$ids) err('请选择要操作的数据');
        if ($type === 'users' && in_array($bulk_action, ['mute', 'unmute', 'ban', 'unban'], true)) {
            $field = in_array($bulk_action, ['ban', 'unban'], true) ? 'is_banned' : 'is_muted';
            $value = in_array($bulk_action, ['ban', 'mute'], true) ? 1 : 0;
            $ids = array_values(array_diff($ids, [1, uid()]));
            if ($ids) q("UPDATE app_users SET $field=? WHERE id IN (" . sql_marks(count($ids)) . ')', array_merge([$value], $ids));
        } elseif ($type === 'topics' && $bulk_action === 'move') {
            $forum_id = filter_var($_POST['forum_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($forum_id === false || !forum_by_id((int)$forum_id)) err('版块不存在');
            $allowed = [];
            foreach ($ids as $topic_id) if (can_admin_delete('topics', $topic_id)) $allowed[] = $topic_id;
            if (!$allowed) err('所选主题均无权操作');
            q('UPDATE app_topics SET forum_id=? WHERE id IN (' . sql_marks(count($allowed)) . ')', array_merge([(int)$forum_id], $allowed));
            foreach ($allowed as $topic_id) fire('topic.after_save', ['id' => $topic_id, 'forum_id' => (int)$forum_id, 'editing' => true]);
        } elseif ($bulk_action === 'delete') {
            foreach ($ids as $row_id) {
                if (!can_admin_delete($type, $row_id)) continue;
                if ($type === 'topics') next_admin_delete_topic($row_id);
                else del($type, $row_id);
            }
        } else err('参数错误');
        next_admin_redirect($type === 'users' ? 'users' : 'content', '批量操作已完成', $type === 'users' ? [] : ['type' => $type]);
    }
    if ($action === 'plugin_sync') {
        \app\optional\Plugin::plugin_registry_sync();
        \app\optional\Plugin::plugin_assets_rebuild();
        save_settings_values(['plugin_sync_pending' => '0']);
        next_admin_redirect('plugins', '插件目录已同步');
    }
    if ($action === 'plugin_toggle') {
        $plugin_id = (string)($_POST['plugin_id'] ?? '');
        $enabled = (string)($_POST['enabled'] ?? '0') === '1';
        if ($plugin_id === 'next_admin' && !$enabled) err('请在经典后台停用当前后台插件');
        \app\optional\Plugin::plugin_set_enabled($plugin_id, $enabled);
        next_admin_redirect('plugins', $enabled ? '插件已启用' : '插件已停用');
    }
    if ($action === 'plugin_entry') {
        $plugin_id = (string)($_POST['plugin_id'] ?? '');
        $entry = (string)($_POST['entry'] ?? '');
        \app\optional\Plugin::plugin_set_entry_enabled($plugin_id, $entry, (string)($_POST['enabled'] ?? '0') === '1');
        next_admin_redirect('plugins', '插件展示位置已更新');
    }
    if ($action === 'plugin_uninstall') {
        $plugin_id = (string)($_POST['plugin_id'] ?? '');
        if ($plugin_id === 'next_admin') err('不能在当前后台卸载自身');
        $keep_data = (string)($_POST['keep_data'] ?? '1') === '1';
        \app\optional\Plugin::plugin_uninstall($plugin_id, $keep_data);
        next_admin_redirect('plugins', $keep_data ? '插件已卸载，数据已保留' : '插件及其数据已卸载');
    }
    err('参数错误');
}

function next_admin_post_id(): int
{
    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($id === false) err('参数错误');
    return (int)$id;
}

function next_admin_delete_topic(int $topic_id): void
{
    $reply_ids = q('SELECT id FROM app_replies WHERE topic_id=? ORDER BY id', [$topic_id])->fetchAll(PDO::FETCH_COLUMN);
    foreach ($reply_ids as $reply_id) del('replies', (int)$reply_id);
    del('topics', $topic_id);
}

function next_admin_action_form(string $action, string $label, array $fields = [], string $tone = '', string $confirm = ''): string
{
    $confirm_attr = $confirm !== '' ? ' data-next-admin-confirm="' . h($confirm) . '"' : '';
    return '<form class="next-admin-inline-form" method="post" action="' . h(route_url('next_admin')) . '"' . $confirm_attr . '>' . form_token() . hidden_inputs(['next_admin_action' => $action] + $fields) . '<button class="next-admin-small-button' . ($tone !== '' ? ' is-' . h($tone) : '') . '" type="submit">' . h($label) . '</button></form>';
}

function next_admin_icon(string $name): string
{
    $icons = [
        'overview' => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'content' => '<path d="M4 5h16M4 12h16M4 19h10"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        'forums' => '<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 8h8M8 12h5"/>',
        'system' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.1A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H3v-4h.1A1.7 1.7 0 0 0 4.6 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V3h4v.1A1.7 1.7 0 0 0 15.4 4.6a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 9c.12.37.33.7.6 1 .3.28.68.42 1.1.4h.1v4h-.1A1.7 1.7 0 0 0 19.4 15z"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
        'external' => '<path d="M14 3h7v7M10 14 21 3"/><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/>',
        'arrow' => '<path d="m9 18 6-6-6-6"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'close' => '<path d="M18 6 6 18M6 6l12 12"/>',
        'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.66 6.34l1.41-1.41"/>',
        'moon' => '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
        'topic' => '<path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
        'reply' => '<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/>',
        'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.8-4 4.5-6 8-6s6.2 2 8 6"/>',
        'plugin' => '<path d="M9 3h6v4a3 3 0 0 0 6 0v6h-4a3 3 0 0 0 0 6h4v2h-6v-4a3 3 0 0 0-6 0v4H3v-6h4a3 3 0 0 0 0-6H3V3h6z"/>',
        'edit' => '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4z"/>',
        'shield' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    ];
    return '<svg class="next-admin-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($icons[$name] ?? $icons['overview']) . '</svg>';
}

function next_admin_search_like(string $query): string
{
    return '%' . strtr($query, ['!' => '!!', '%' => '!%', '_' => '!_']) . '%';
}

function next_admin_stats(): array
{
    $today = (int)strtotime('today', now());
    $week = $today - 6 * 86400;
    return [
        'topics' => (int)val('SELECT COUNT(*) FROM app_topics'),
        'replies' => (int)val('SELECT COUNT(*) FROM app_replies'),
        'users' => (int)val('SELECT COUNT(*) FROM app_users'),
        'plugins' => (int)val('SELECT COUNT(*) FROM app_plugins WHERE enabled=1'),
        'today_topics' => (int)val('SELECT COUNT(*) FROM app_topics WHERE created_at>=?', [$today]),
        'today_replies' => (int)val('SELECT COUNT(*) FROM app_replies WHERE created_at>=?', [$today]),
        'today_users' => (int)val('SELECT COUNT(*) FROM app_users WHERE created_at>=?', [$today]),
        'week_topics' => (int)val('SELECT COUNT(*) FROM app_topics WHERE created_at>=?', [$week]),
        'week_replies' => (int)val('SELECT COUNT(*) FROM app_replies WHERE created_at>=?', [$week]),
        'week_users' => (int)val('SELECT COUNT(*) FROM app_users WHERE created_at>=?', [$week]),
    ];
}

function next_admin_recent_topics(int $limit = 8, string $query = '', int $forum_id = 0): array
{
    $where = [];
    $params = [];
    if ($forum_id > 0) {
        $where[] = 'forum_id=?';
        $params[] = $forum_id;
    }
    if ($query !== '') {
        $where[] = "(title LIKE ? ESCAPE '!' OR body LIKE ? ESCAPE '!')";
        $like = next_admin_search_like($query);
        $params[] = $like;
        $params[] = $like;
    }
    $sql = 'SELECT id,forum_id,user_id,title,body,reply_count,view_count,created_at FROM app_topics';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY id DESC LIMIT ?';
    $params[] = $limit;
    $rows = attach_users(q($sql, $params)->fetchAll());
    foreach ($rows as &$row) $row['forum_name'] = (string)(forum_by_id((int)$row['forum_id'])['name'] ?? '版块已删除');
    unset($row);
    return $rows;
}

function next_admin_recent_users(int $limit = 8, string $query = ''): array
{
    $params = [];
    $sql = 'SELECT id,username,email,avatar_style,avatar_seed,group_id,points,is_banned,is_muted,created_at FROM app_users';
    if ($query !== '') {
        $like = next_admin_search_like($query);
        $sql .= " WHERE username LIKE ? ESCAPE '!' OR email LIKE ? ESCAPE '!'";
        $params = [$like, $like];
    }
    $sql .= ' ORDER BY id DESC LIMIT ?';
    $params[] = $limit;
    return q($sql, $params)->fetchAll();
}

function next_admin_recent_replies(int $limit = 80, string $query = ''): array
{
    $params = [];
    $sql = 'SELECT id,topic_id,user_id,body,created_at FROM app_replies';
    if ($query !== '') {
        $sql .= " WHERE body LIKE ? ESCAPE '!'";
        $params[] = next_admin_search_like($query);
    }
    $sql .= ' ORDER BY id DESC LIMIT ?';
    $params[] = $limit;
    $rows = attach_users(q($sql, $params)->fetchAll());
    $topics = rows_by_ids('app_topics', array_column($rows, 'topic_id'), 'id,title');
    foreach ($rows as &$row) $row['topic_title'] = (string)($topics[(int)$row['topic_id']]['title'] ?? '主题已删除');
    unset($row);
    return $rows;
}

function next_admin_filter_sql(string $type, string $query, string $field, array $filters = []): ?array
{
    $where = [];
    $params = [];
    $like = $query !== '' ? next_admin_search_like($query) : '';
    if ($type === 'topics') {
        $field = in_array($field, ['title', 'body', 'author', 'id'], true) ? $field : 'title';
        $forum_id = max(0, (int)($filters['forum_id'] ?? 0));
        if ($forum_id > 0) {
            $where[] = 'forum_id=?';
            $params[] = $forum_id;
        }
        next_admin_time_filter($where, $params, $filters);
        if ($query !== '') {
            if ($field === 'id') {
                if (!ctype_digit($query) || (int)$query < 1) return null;
                $where[] = 'id=?';
                $params[] = (int)$query;
            } elseif ($field === 'author') {
                $where[] = "EXISTS (SELECT 1 FROM app_users next_admin_author WHERE next_admin_author.id=app_topics.user_id AND next_admin_author.username LIKE ? ESCAPE '!')";
                $params[] = $like;
            } else {
                [$condition, $search_params] = content_search_condition($query, $field);
                $where[] = '(' . $condition . ')';
                $params = array_merge($params, $search_params);
            }
        }
    } elseif ($type === 'replies') {
        $field = in_array($field, ['body', 'author', 'id'], true) ? $field : 'body';
        $topic_id = max(0, (int)($filters['topic_id'] ?? 0));
        if ($topic_id > 0) {
            $where[] = 'topic_id=?';
            $params[] = $topic_id;
        }
        next_admin_time_filter($where, $params, $filters);
        if ($query !== '') {
            if ($field === 'id') {
                if (!ctype_digit($query) || (int)$query < 1) return null;
                $where[] = 'id=?';
                $params[] = (int)$query;
            } elseif ($field === 'author') {
                $where[] = "EXISTS (SELECT 1 FROM app_users next_admin_author WHERE next_admin_author.id=app_replies.user_id AND next_admin_author.username LIKE ? ESCAPE '!')";
                $params[] = $like;
            } else {
                [$condition, $search_params] = content_search_condition($query, 'reply');
                $where[] = '(' . $condition . ')';
                $params = array_merge($params, $search_params);
            }
        }
    } elseif ($type === 'users') {
        $field = $field === 'id' ? 'id' : 'keyword';
        if ($query !== '') {
            if ($field === 'id') {
                if (!ctype_digit($query) || (int)$query < 1) return null;
                $where[] = 'id=?';
                $params[] = (int)$query;
            } else {
                $where[] = "(username LIKE ? ESCAPE '!' OR email LIKE ? ESCAPE '!' OR bio LIKE ? ESCAPE '!')";
                $params = [$like, $like, $like];
            }
        }
        foreach (['group_id' => 'group_id', 'is_banned' => 'is_banned', 'is_muted' => 'is_muted'] as $key => $column) {
            $value = (int)($filters[$key] ?? ($key === 'group_id' ? 0 : -1));
            if (($key === 'group_id' && $value > 0) || ($key !== 'group_id' && in_array($value, [0, 1], true))) {
                $where[] = $column . '=?';
                $params[] = $value;
            }
        }
    } else return null;
    return ['where' => $where ? ' WHERE ' . implode(' AND ', $where) : '', 'params' => $params];
}

function next_admin_time_filter(array &$where, array &$params, array $filters): void
{
    $from = trim((string)($filters['created_from'] ?? ''));
    $to = trim((string)($filters['created_to'] ?? ''));
    if ($from !== '') {
        $ts = strtotime($from . ' 00:00:00');
        if ($ts === false) err('开始日期格式错误');
        $where[] = 'created_at>=?';
        $params[] = (int)$ts;
    }
    if ($to !== '') {
        $ts = strtotime($to . ' 00:00:00');
        if ($ts === false) err('结束日期格式错误');
        $where[] = 'created_at<?';
        $params[] = (int)$ts + 86400;
    }
}

function next_admin_date_value(string $key): string
{
    $value = trim((string)($_GET[$key] ?? ''));
    if ($value !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value) !== 1) err('日期格式错误');
    return $value;
}

function next_admin_management_rows(string $type, string $query, string $field, array $filters, int $limit, int $offset): array
{
    $filter = next_admin_filter_sql($type, $query, $field, $filters);
    if ($filter === null) return [];
    [$table, $columns] = match ($type) {
        'topics' => ['app_topics', 'id,forum_id,user_id,title,body,reply_count,view_count,created_at'],
        'replies' => ['app_replies', 'id,topic_id,user_id,body,created_at'],
        'users' => ['app_users', 'id,username,email,bio,avatar_style,avatar_seed,group_id,points,is_banned,is_muted,created_at'],
    };
    $rows = q("SELECT $columns FROM $table" . $filter['where'] . ' ORDER BY id DESC LIMIT ? OFFSET ?', array_merge($filter['params'], [$limit, $offset]))->fetchAll();
    if ($type === 'users') return $rows;
    $rows = attach_users($rows);
    if ($type === 'topics') {
        foreach ($rows as &$row) $row['forum_name'] = (string)(forum_by_id((int)$row['forum_id'])['name'] ?? '版块已删除');
    } else {
        $topics = rows_by_ids('app_topics', array_column($rows, 'topic_id'), 'id,title');
        foreach ($rows as &$row) $row['topic_title'] = (string)($topics[(int)$row['topic_id']]['title'] ?? '主题已删除');
    }
    unset($row);
    return $rows;
}

function next_admin_management_count(string $type, string $query, string $field, array $filters): int
{
    $filter = next_admin_filter_sql($type, $query, $field, $filters);
    if ($filter === null) return 0;
    $table = ['topics' => 'app_topics', 'replies' => 'app_replies', 'users' => 'app_users'][$type];
    return (int)val('SELECT COUNT(*) FROM ' . $table . $filter['where'], $filter['params']);
}

function next_admin_pagination(int $total, int $page, int $size, string $view, array $params): string
{
    $pages = max(1, (int)ceil($total / $size));
    if ($pages <= 1) return '';
    $page = min($pages, max(1, $page));
    $html = '<nav class="next-admin-pagination" aria-label="分页"><span>共 ' . number_format($total) . ' 条</span><div>';
    if ($page > 1) $html .= '<a href="' . h(next_admin_url($view, $params + ['p' => $page - 1])) . '">上一页</a>';
    $html .= '<strong>' . $page . ' / ' . $pages . '</strong>';
    if ($page < $pages) $html .= '<a href="' . h(next_admin_url($view, $params + ['p' => $page + 1])) . '">下一页</a>';
    return $html . '</div></nav>';
}

function next_admin_bulk_html(string $type): string
{
    $actions = $type === 'users'
        ? '<option value="mute">禁止发言</option><option value="unmute">取消禁言</option><option value="ban">禁止访问</option><option value="unban">取消禁访</option><option value="delete">删除用户</option>'
        : ($type === 'topics' ? '<option value="move">转移版块</option><option value="delete">删除主题</option>' : '<option value="delete">删除回复</option>');
    $forums = '';
    if ($type === 'topics') {
        $forums = '<select name="forum_id" form="next-admin-bulk-form" data-next-admin-bulk-forum>';
        foreach (forums_cache() as $forum) $forums .= '<option value="' . (int)$forum['id'] . '">' . h($forum['name']) . '</option>';
        $forums .= '</select>';
    }
    return '<form id="next-admin-bulk-form" method="post" action="' . h(route_url('next_admin')) . '" data-next-admin-confirm="确定执行批量操作？">' . form_token() . hidden_inputs(['next_admin_action' => 'bulk', 'type' => $type]) . '</form><div class="next-admin-bulk"><label><input type="checkbox" data-next-admin-select-all><span>全选本页</span></label><select name="bulk_action" form="next-admin-bulk-form" data-next-admin-bulk-action>' . $actions . '</select>' . $forums . '<button type="submit" form="next-admin-bulk-form">执行</button></div>';
}

function next_admin_replies_table(array $replies): string
{
    if (!$replies) return '<div class="next-admin-empty">没有找到符合条件的回复</div>';
    $html = '<div class="next-admin-table-wrap"><table class="next-admin-table"><thead><tr><th class="next-admin-select-col"><span class="next-admin-sr">选择</span></th><th>回复内容</th><th>所属主题</th><th>作者</th><th>发布</th><th>操作</th></tr></thead><tbody>';
    foreach ($replies as $reply) {
        $topic_url = route_url('topic', ['id' => (int)$reply['topic_id'], 'replyid' => (int)$reply['id']]);
        $ops = '<div class="next-admin-row-actions"><a class="next-admin-small-button" href="' . h(route_url('reply_edit', ['id' => (int)$reply['id']])) . '">编辑</a>' . next_admin_action_form('delete_reply', '删除', ['id' => (int)$reply['id']], 'danger', '确定删除这条回复？') . '</div>';
        $html .= '<tr><td class="next-admin-select-col"><input type="checkbox" name="ids[]" value="' . (int)$reply['id'] . '" form="next-admin-bulk-form" aria-label="选择回复"></td><td><div class="next-admin-primary"><a href="' . h($topic_url) . '" target="_blank" rel="noopener">' . h(content_excerpt((string)$reply['body'], 90)) . '</a><span>回复 #' . (int)$reply['id'] . '</span></div></td><td><a class="next-admin-table-link" href="' . h($topic_url) . '" target="_blank" rel="noopener">' . h($reply['topic_title']) . '</a></td><td>' . h($reply['username']) . '</td><td><time>' . h(human_time((int)$reply['created_at'])) . '</time></td><td>' . $ops . '</td></tr>';
    }
    return $html . '</tbody></table></div>';
}

function next_admin_daily_activity(): array
{
    $start = (int)strtotime('today', now()) - 6 * 86400;
    $days = [];
    $selects = [];
    $params = [];
    for ($i = 0; $i < 7; $i++) {
        $ts = $start + $i * 86400;
        $days[] = ['label' => date('n/j', $ts), 'topics' => 0, 'replies' => 0];
        $selects[] = 'SUM(CASE WHEN created_at>=? AND created_at<? THEN 1 ELSE 0 END) AS d' . $i;
        $params[] = $ts;
        $params[] = $ts + 86400;
    }
    foreach (['topics' => 'app_topics', 'replies' => 'app_replies'] as $key => $table) {
        $counts = q('SELECT ' . implode(',', $selects) . " FROM $table WHERE created_at>=?", array_merge($params, [$start]))->fetch() ?: [];
        foreach ($days as $i => &$day) $day[$key] = (int)($counts['d' . $i] ?? 0);
        unset($day);
    }
    return $days;
}

function next_admin_status(): array
{
    $last_cron = (int)val('SELECT MAX(started_at) FROM app_cron_logs');
    return [
        'site_closed' => setting('site_closed', '0') === '1',
        'register' => setting('allow_register', '1') === '1',
        'debug' => setting('debug_mode', '0') === '1',
        'plugin_pending' => setting('plugin_sync_pending', '0') === '1',
        'last_cron' => $last_cron,
        'db' => ['sqlite' => 'SQLite', 'mysql' => 'MySQL', 'pgsql' => 'PostgreSQL'][db_driver()] ?? db_driver(),
        'php' => PHP_VERSION,
    ];
}

function next_admin_stat_card(string $icon, string $label, int $value, string $delta, string $tone): string
{
    return '<article class="next-admin-stat next-admin-tone-' . h($tone) . '"><div class="next-admin-stat-top"><span class="next-admin-stat-icon">' . next_admin_icon($icon) . '</span><span class="next-admin-stat-delta">' . h($delta) . '</span></div><strong>' . number_format($value) . '</strong><span>' . h($label) . '</span></article>';
}

function next_admin_topics_table(array $topics, bool $show_excerpt = false, bool $selectable = true): string
{
    if (!$topics) return '<div class="next-admin-empty">没有找到符合条件的主题</div>';
    $select_head = $selectable ? '<th class="next-admin-select-col"><span class="next-admin-sr">选择</span></th>' : '';
    $html = '<div class="next-admin-table-wrap"><table class="next-admin-table"><thead><tr>' . $select_head . '<th>主题</th><th>版块</th><th>互动</th><th>发布</th><th>操作</th></tr></thead><tbody>';
    foreach ($topics as $topic) {
        $title = '<a href="' . h(route_url('topic', ['id' => (int)$topic['id']])) . '" target="_blank" rel="noopener">' . h($topic['title']) . '</a>';
        if ($show_excerpt) $title .= '<small>' . h(content_excerpt((string)$topic['body'], 72)) . '</small>';
        $ops = '<div class="next-admin-row-actions"><a class="next-admin-small-button" href="' . h(route_url('topic_edit', ['id' => (int)$topic['id']])) . '">编辑</a>' . next_admin_action_form('delete_topic', '删除', ['id' => (int)$topic['id']], 'danger', '确定删除这个主题及其回复？') . '</div>';
        $select_cell = $selectable ? '<td class="next-admin-select-col"><input type="checkbox" name="ids[]" value="' . (int)$topic['id'] . '" form="next-admin-bulk-form" aria-label="选择主题"></td>' : '';
        $html .= '<tr>' . $select_cell . '<td><div class="next-admin-primary">' . $title . '<span>#' . (int)$topic['id'] . ' · ' . h($topic['username']) . '</span></div></td><td><span class="next-admin-chip">' . h($topic['forum_name']) . '</span></td><td><div class="next-admin-metric-pair"><span>' . (int)$topic['reply_count'] . ' 回复</span><span>' . (int)$topic['view_count'] . ' 浏览</span></div></td><td><time>' . h(human_time((int)$topic['created_at'])) . '</time></td><td>' . $ops . '</td></tr>';
    }
    return $html . '</tbody></table></div>';
}

function next_admin_users_table(array $users): string
{
    if (!$users) return '<div class="next-admin-empty">没有找到符合条件的用户</div>';
    $groups = [];
    foreach (groups_cache() as $group) $groups[(int)$group['id']] = (string)$group['name'];
    $html = '<div class="next-admin-table-wrap"><table class="next-admin-table"><thead><tr><th class="next-admin-select-col"><span class="next-admin-sr">选择</span></th><th>用户</th><th>用户组</th><th>状态</th><th>积分</th><th>加入时间</th><th>操作</th></tr></thead><tbody>';
    foreach ($users as $user) {
        $tags = [];
        if ((int)$user['is_banned'] === 1) $tags[] = '<span class="next-admin-badge is-danger">禁访</span>';
        if ((int)$user['is_muted'] === 1) $tags[] = '<span class="next-admin-badge is-warning">禁言</span>';
        if (!$tags) $tags[] = '<span class="next-admin-badge is-success">正常</span>';
        $profile = route_url('user', ['id' => (int)$user['id']]);
        $ops = '<div class="next-admin-row-actions"><a class="next-admin-small-button" href="' . h(next_admin_url('user_edit', ['id' => (int)$user['id']])) . '">编辑</a>';
        if ((int)$user['id'] !== 1 && (int)$user['id'] !== uid()) {
            $ops .= next_admin_action_form('user_state', (int)$user['is_muted'] === 1 ? '解禁言' : '禁言', ['id' => (int)$user['id'], 'state' => (int)$user['is_muted'] === 1 ? 'unmute' : 'mute'], (int)$user['is_muted'] === 1 ? '' : 'warning');
            $ops .= next_admin_action_form('user_state', (int)$user['is_banned'] === 1 ? '解禁访' : '禁访', ['id' => (int)$user['id'], 'state' => (int)$user['is_banned'] === 1 ? 'unban' : 'ban'], (int)$user['is_banned'] === 1 ? '' : 'danger', (int)$user['is_banned'] === 1 ? '' : '确定禁止该用户访问？');
        }
        $ops .= '</div>';
        $html .= '<tr><td class="next-admin-select-col"><input type="checkbox" name="ids[]" value="' . (int)$user['id'] . '" form="next-admin-bulk-form" aria-label="选择用户"></td><td><a class="next-admin-user" href="' . h($profile) . '" target="_blank" rel="noopener"><span class="next-admin-avatar">' . avatar_tag((int)$user['id'], (string)$user['username'], (string)$user['avatar_style'], '', (string)$user['avatar_seed']) . '</span><span><strong>' . h($user['username']) . '</strong><small>' . h((string)$user['email']) . '</small></span></a></td><td>' . h($groups[(int)$user['group_id']] ?? '未知') . '</td><td><div class="next-admin-badges">' . implode('', $tags) . '</div></td><td>' . number_format((int)$user['points']) . '</td><td>' . h(human_time((int)$user['created_at'])) . '</td><td>' . $ops . '</td></tr>';
    }
    return $html . '</tbody></table></div>';
}

function next_admin_panel(string $title, string $body, string $action = ''): string
{
    return '<section class="next-admin-panel"><header><h2>' . h($title) . '</h2>' . $action . '</header>' . $body . '</section>';
}

function next_admin_overview_html(): string
{
    $stats = next_admin_stats();
    $topics = next_admin_recent_topics(7);
    $users = next_admin_recent_users(6);
    $activity = next_admin_daily_activity();
    $status = next_admin_status();
    $max = 1;
    foreach ($activity as $day) $max = max($max, $day['topics'] + $day['replies']);
    $chart = '<div class="next-admin-chart" role="img" aria-label="最近七天内容发布趋势"><div class="next-admin-chart-legend"><span class="is-topic">主题</span><span class="is-reply">回复</span></div><div class="next-admin-bars">';
    foreach ($activity as $day) {
        $topic_height = max(3, (int)round($day['topics'] / $max * 100));
        $reply_height = max(3, (int)round($day['replies'] / $max * 100));
        $chart .= '<div class="next-admin-bar-day" title="' . h($day['label'] . '：' . $day['topics'] . ' 主题，' . $day['replies'] . ' 回复') . '"><div class="next-admin-bar-stack"><i class="is-topic" style="height:' . $topic_height . '%"></i><i class="is-reply" style="height:' . $reply_height . '%"></i></div><span>' . h($day['label']) . '</span></div>';
    }
    $chart .= '</div></div>';

    $health = [
        [$status['site_closed'] ? 'is-danger' : 'is-success', '站点访问', $status['site_closed'] ? '维护中' : '正常开放'],
        [$status['register'] ? 'is-success' : 'is-neutral', '用户注册', $status['register'] ? '允许' : '已关闭'],
        [$status['debug'] ? 'is-warning' : 'is-success', '调试模式', $status['debug'] ? '已开启' : '已关闭'],
        [$status['plugin_pending'] ? 'is-warning' : 'is-success', '插件同步', $status['plugin_pending'] ? '等待同步' : '状态正常'],
    ];
    $health_html = '<div class="next-admin-health">';
    foreach ($health as [$tone, $label, $value]) $health_html .= '<div><span class="next-admin-health-dot ' . $tone . '"></span><span>' . h($label) . '</span><strong>' . h($value) . '</strong></div>';
    $health_html .= '<div><span class="next-admin-health-dot is-neutral"></span><span>计划任务</span><strong>' . ($status['last_cron'] ? h(human_time($status['last_cron'])) : '尚未运行') . '</strong></div></div>';

    $quick = '<div class="next-admin-quick-grid">';
    $actions = [
        ['content', '内容巡检', '检索近期主题与讨论', next_admin_url('content')],
        ['users', '用户查询', '定位账号与受限状态', next_admin_url('users')],
        ['forums', '版块结构', '检查版块内容分布', next_admin_url('forums')],
        ['system', '站点设置', '调整运行策略与插件', next_admin_url('system')],
    ];
    foreach ($actions as [$icon, $title, $desc, $url]) $quick .= '<a href="' . h($url) . '"><span>' . next_admin_icon($icon) . '</span><div><strong>' . h($title) . '</strong><small>' . h($desc) . '</small></div>' . next_admin_icon('arrow') . '</a>';
    $quick .= '</div>';

    $recent_users = '<div class="next-admin-recent-users">';
    foreach ($users as $user) {
        $state = (int)$user['is_banned'] === 1 ? '禁访' : ((int)$user['is_muted'] === 1 ? '禁言' : human_time((int)$user['created_at']));
        $recent_users .= '<a href="' . h(route_url('user', ['id' => (int)$user['id']])) . '" target="_blank" rel="noopener"><span class="next-admin-avatar">' . avatar_tag((int)$user['id'], (string)$user['username'], (string)$user['avatar_style'], '', (string)$user['avatar_seed']) . '</span><span><strong>' . h($user['username']) . '</strong><small>' . h($state) . '</small></span>' . next_admin_icon('arrow') . '</a>';
    }
    $recent_users .= '</div>';

    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">WORKSPACE / TODAY</span><h1>管理概览</h1><p>站点正在发生什么，一屏掌握。</p></div><a class="next-admin-primary-button" href="' . h(route_url('home')) . '" target="_blank" rel="noopener">查看站点' . next_admin_icon('external') . '</a></div>'
        . '<div class="next-admin-stats">'
        . next_admin_stat_card('topic', '主题总数', $stats['topics'], '今日 +' . $stats['today_topics'], 'ink')
        . next_admin_stat_card('reply', '回帖总数', $stats['replies'], '今日 +' . $stats['today_replies'], 'cyan')
        . next_admin_stat_card('user', '注册用户', $stats['users'], '今日 +' . $stats['today_users'], 'green')
        . next_admin_stat_card('plugin', '启用插件', $stats['plugins'], '运行中', 'amber') . '</div>'
        . '<div class="next-admin-grid next-admin-grid-main">'
        . next_admin_panel('七日活跃度', $chart, '<span class="next-admin-panel-note">主题与回复发布量</span>')
        . next_admin_panel('运行状态', $health_html, '<a class="next-admin-text-link" href="' . h(next_admin_url('system')) . '">系统详情</a>') . '</div>'
        . next_admin_panel('快捷工作区', $quick)
        . '<div class="next-admin-grid next-admin-grid-list">'
        . next_admin_panel('最新主题', next_admin_topics_table($topics, false, false), '<a class="next-admin-text-link" href="' . h(next_admin_url('content')) . '">查看全部</a>')
        . next_admin_panel('新加入用户', $recent_users, '<a class="next-admin-text-link" href="' . h(next_admin_url('users')) . '">用户查询</a>') . '</div>';
}

function next_admin_content_html(): string
{
    $query = trim(cut((string)($_GET['q'] ?? ''), 80));
    $type = (string)($_GET['type'] ?? 'topics') === 'replies' ? 'replies' : 'topics';
    $tabs = '<div class="next-admin-segments"><a href="' . h(next_admin_url('content', ['type' => 'topics'])) . '"' . ($type === 'topics' ? ' class="is-active"' : '') . '>主题</a><a href="' . h(next_admin_url('content', ['type' => 'replies'])) . '"' . ($type === 'replies' ? ' class="is-active"' : '') . '>回复</a></div>';
    $head = '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">CONTENT OPS</span><h1>内容管理</h1><p>直接检索、过滤和批量操作内容。</p></div><a class="next-admin-secondary-button" href="' . h(route_url('topic_edit')) . '">' . next_admin_icon('edit') . '发布主题</a></div>';
    $field = $type === 'replies'
        ? (in_array((string)($_GET['field'] ?? 'body'), ['body', 'author', 'id'], true) ? (string)$_GET['field'] : 'body')
        : (in_array((string)($_GET['field'] ?? 'title'), ['title', 'body', 'author', 'id'], true) ? (string)$_GET['field'] : 'title');
    if ($field !== 'id') require_search_min_chars($query);
    $forum_id = max(0, (int)($_GET['forum_id'] ?? 0));
    $topic_id = max(0, (int)($_GET['topic_id'] ?? 0));
    $created_from = next_admin_date_value('created_from');
    $created_to = next_admin_date_value('created_to');
    $page = max(1, (int)($_GET['p'] ?? 1));
    $size = 50;
    $filters_data = ['forum_id' => $forum_id, 'topic_id' => $topic_id, 'created_from' => $created_from, 'created_to' => $created_to];
    $total = next_admin_management_count($type, $query, $field, $filters_data);
    $page = min($page, max(1, (int)ceil($total / $size)));
    $rows = next_admin_management_rows($type, $query, $field, $filters_data, $size, ($page - 1) * $size);
    $options = '<option value="0">全部版块</option>';
    foreach (forums_cache() as $forum) $options .= '<option value="' . (int)$forum['id'] . '"' . ($forum_id === (int)$forum['id'] ? ' selected' : '') . '>' . h($forum['name']) . '</option>';
    $field_options = $type === 'replies'
        ? ['body' => '回复内容', 'author' => '作者', 'id' => '回复 ID']
        : ['title' => '主题标题', 'body' => '主题正文', 'author' => '作者', 'id' => '主题 ID'];
    $field_select = '<select name="field" aria-label="搜索字段">';
    foreach ($field_options as $key => $label) $field_select .= '<option value="' . $key . '"' . ($field === $key ? ' selected' : '') . '>' . $label . '</option>';
    $field_select .= '</select>';
    $date_range = '<span class="next-admin-date-range"><input class="next-admin-standalone-input" type="date" name="created_from" value="' . h($created_from) . '" aria-label="发布开始日期"><i>至</i><input class="next-admin-standalone-input" type="date" name="created_to" value="' . h($created_to) . '" aria-label="发布结束日期"></span>';
    $filters = '<form class="next-admin-filter next-admin-filter-content" method="get" action="' . h(route_url('next_admin')) . '"><input type="hidden" name="view" value="content"><input type="hidden" name="type" value="' . h($type) . '">' . $field_select . '<label><span class="next-admin-sr">搜索内容</span>' . next_admin_icon('search') . '<input type="search" name="q" value="' . h($query) . '" placeholder="' . ($field === 'id' ? '输入精确 ID' : '输入搜索关键词') . '"></label>' . ($type === 'topics' ? '<select name="forum_id" aria-label="选择版块">' . $options . '</select>' : '<input class="next-admin-standalone-input" type="number" name="topic_id" value="' . ($topic_id ?: '') . '" placeholder="主题 ID">') . $date_range . '<button type="submit">筛选</button>' . ($query !== '' || $forum_id > 0 || $topic_id > 0 || $created_from !== '' || $created_to !== '' || ($type === 'topics' ? $field !== 'title' : $field !== 'body') ? '<a href="' . h(next_admin_url('content', ['type' => $type])) . '">清除</a>' : '') . '</form>';
    $table = $type === 'replies' ? next_admin_replies_table($rows) : next_admin_topics_table($rows, true);
    $params = array_filter(['type' => $type, 'q' => $query, 'field' => $field, 'forum_id' => $forum_id ?: null, 'topic_id' => $topic_id ?: null, 'created_from' => $created_from, 'created_to' => $created_to], static fn($value): bool => $value !== null && $value !== '');
    return $head . $tabs . $filters . next_admin_panel(($type === 'replies' ? '回复列表' : '主题列表') . ' · ' . number_format($total), $table) . ($rows ? next_admin_bulk_html($type) : '') . next_admin_pagination($total, $page, $size, 'content', $params);
}

function next_admin_users_html(): string
{
    if (!can_manage()) err('无权限');
    $query = trim(cut((string)($_GET['q'] ?? ''), 80));
    $field = (string)($_GET['field'] ?? 'keyword') === 'id' ? 'id' : 'keyword';
    if ($field !== 'id') require_search_min_chars($query);
    $group_id = max(0, (int)($_GET['group_id'] ?? 0));
    $banned = isset($_GET['is_banned']) && $_GET['is_banned'] !== '' ? (int)$_GET['is_banned'] : -1;
    $muted = isset($_GET['is_muted']) && $_GET['is_muted'] !== '' ? (int)$_GET['is_muted'] : -1;
    $page = max(1, (int)($_GET['p'] ?? 1));
    $size = 50;
    $filter_data = ['group_id' => $group_id, 'is_banned' => $banned, 'is_muted' => $muted];
    $total = next_admin_management_count('users', $query, $field, $filter_data);
    $page = min($page, max(1, (int)ceil($total / $size)));
    $users = next_admin_management_rows('users', $query, $field, $filter_data, $size, ($page - 1) * $size);
    $groups = '<option value="0">全部用户组</option>';
    foreach (groups_cache() as $group) $groups .= '<option value="' . (int)$group['id'] . '"' . ($group_id === (int)$group['id'] ? ' selected' : '') . '>' . h($group['name']) . '</option>';
    $state_options = static fn(int $value, string $all, string $yes, string $no): string => '<option value="">' . $all . '</option><option value="1"' . ($value === 1 ? ' selected' : '') . '>' . $yes . '</option><option value="0"' . ($value === 0 ? ' selected' : '') . '>' . $no . '</option>';
    $filter = '<form class="next-admin-filter next-admin-filter-users" method="get" action="' . h(route_url('next_admin')) . '"><input type="hidden" name="view" value="users"><select name="field" aria-label="搜索字段"><option value="keyword"' . ($field === 'keyword' ? ' selected' : '') . '>关键词</option><option value="id"' . ($field === 'id' ? ' selected' : '') . '>用户 ID</option></select><label><span class="next-admin-sr">搜索用户</span>' . next_admin_icon('search') . '<input type="search" name="q" value="' . h($query) . '" placeholder="' . ($field === 'id' ? '输入精确 ID' : '用户名、邮箱或简介') . '"></label><select name="group_id" aria-label="用户组">' . $groups . '</select><select name="is_muted" aria-label="发言状态">' . $state_options($muted, '发言状态', '禁止发言', '允许发言') . '</select><select name="is_banned" aria-label="访问状态">' . $state_options($banned, '访问状态', '禁止访问', '允许访问') . '</select><button type="submit">筛选</button>' . ($query !== '' || $group_id > 0 || $banned >= 0 || $muted >= 0 || $field !== 'keyword' ? '<a href="' . h(next_admin_url('users')) . '">清除</a>' : '') . '</form>';
    $params = array_filter(['q' => $query, 'field' => $field, 'group_id' => $group_id ?: null, 'is_banned' => $banned >= 0 ? $banned : null, 'is_muted' => $muted >= 0 ? $muted : null], static fn($value): bool => $value !== null && $value !== '');
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">MEMBER DIRECTORY</span><h1>用户查询</h1><p>按账号、用户组与访问状态定位并批量管理用户。</p></div><div class="next-admin-head-actions"><a class="next-admin-secondary-button" href="' . h(next_admin_url('groups')) . '">' . next_admin_icon('shield') . '用户组</a><a class="next-admin-primary-button" href="' . h(next_admin_url('user_edit', ['id' => 0])) . '">新建用户</a></div></div>' . $filter . next_admin_panel('用户列表 · ' . number_format($total), next_admin_users_table($users)) . next_admin_bulk_html('users') . next_admin_pagination($total, $page, $size, 'users', $params);
}

function next_admin_field(string $label, string $name, mixed $value = '', string $type = 'text', string $help = '', bool $required = false): string
{
    return '<label class="next-admin-field"><span>' . h($label) . ($help !== '' ? '<small>' . h($help) . '</small>' : '') . '</span><input type="' . h($type) . '" name="' . h($name) . '" value="' . h($value) . '"' . ($required ? ' required' : '') . '></label>';
}

function next_admin_checkbox(string $label, string $name, bool $checked, string $help = ''): string
{
    return '<label class="next-admin-check"><input type="checkbox" name="' . h($name) . '" value="1"' . ($checked ? ' checked' : '') . '><span><strong>' . h($label) . '</strong>' . ($help !== '' ? '<small>' . h($help) . '</small>' : '') . '</span></label>';
}

function next_admin_user_edit_html(): string
{
    if (!can_manage()) err('无权限');
    $user_id = max(0, (int)($_GET['id'] ?? 0));
    if ($user_id === 1 && !is_super_user()) err('无权限');
    $user = $user_id ? (user_by_id($user_id) ?: err('用户不存在')) : ['id' => 0, 'username' => '', 'email' => '', 'bio' => '', 'group_id' => (int)setting('default_group_id', '2'), 'points' => 0, 'is_banned' => 0, 'is_muted' => 0];
    $groups = '';
    foreach (groups_cache() as $group) $groups .= '<option value="' . (int)$group['id'] . '"' . ((int)$user['group_id'] === (int)$group['id'] ? ' selected' : '') . '>' . h($group['name']) . '</option>';
    $is_new = $user_id === 0;
    $form = '<form class="next-admin-editor" method="post" action="' . h(route_url('next_admin')) . '">' . form_token() . hidden_inputs(['next_admin_action' => 'save_user', 'id' => $user_id, 'avatar_style' => (string)($user['avatar_style'] ?? ''), 'avatar_seed' => (string)($user['avatar_seed'] ?? '')])
        . '<div class="next-admin-form-grid">' . next_admin_field('用户名', 'username', $user['username'], 'text', '', true) . next_admin_field('邮箱', 'email', $user['email'], 'email') . next_admin_field($is_new ? '密码' : '新密码', 'password', '', 'password', $is_new ? '至少满足站点密码长度要求' : '留空则不修改') . next_admin_field('确认密码', 'password2', '', 'password') . '<label class="next-admin-field"><span>用户组</span><select name="group_id">' . $groups . '</select></label>' . next_admin_field('积分', 'points', (int)$user['points'], 'number') . '</div>'
        . '<label class="next-admin-field"><span>个人简介</span><textarea name="bio" rows="5">' . h($user['bio']) . '</textarea></label><div class="next-admin-check-grid">' . next_admin_checkbox('禁止访问', 'is_banned', (int)$user['is_banned'] === 1, '用户将无法访问站点') . next_admin_checkbox('禁止发言', 'is_muted', (int)$user['is_muted'] === 1, '用户无法发布主题与回复') . '</div><div class="next-admin-form-actions"><a href="' . h(next_admin_url('users')) . '">取消</a><button type="submit">保存用户</button></div></form>';
    $danger = '';
    if ($user_id > 1 && $user_id !== uid()) $danger = '<div class="next-admin-danger-zone"><div><strong>删除用户</strong><span>用户及其关联内容将按核心删除规则处理。</span></div>' . next_admin_action_form('delete_user', '删除用户', ['id' => $user_id], 'danger', '确定永久删除这个用户？') . '</div>';
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">MEMBER EDITOR</span><h1>' . ($is_new ? '新建用户' : '编辑用户') . '</h1><p>直接维护账号资料、权限组与访问状态。</p></div></div>' . next_admin_panel('账号资料', $form) . $danger;
}

function next_admin_group_options(array $selected): string
{
    $html = '';
    foreach (groups_cache() as $group) {
        $id = (int)$group['id'];
        $html .= '<label class="next-admin-mini-check"><input type="checkbox" name="__NAME__[]" value="' . $id . '"' . (in_array($id, $selected, true) ? ' checked' : '') . '><span>' . h($group['name']) . '</span></label>';
    }
    return $html;
}

function next_admin_forums_html(): string
{
    $counts = [];
    foreach (q('SELECT forum_id,COUNT(*) AS total FROM app_topics GROUP BY forum_id')->fetchAll() as $row) $counts[(int)$row['forum_id']] = (int)$row['total'];
    $html = '<div class="next-admin-forum-grid">';
    foreach (forums_cache() as $forum) {
        $permissions = [];
        foreach (['allow_view_groups' => '浏览', 'allow_post_groups' => '发帖', 'allow_reply_groups' => '回帖'] as $field => $label) {
            $count = count(forum_group_ids($forum, $field));
            $permissions[] = $label . ' ' . ($count ? $count . ' 组' : '不限');
        }
        $html .= '<article class="next-admin-forum-card"><div class="next-admin-forum-card-top"><span>' . next_admin_icon('forums') . '</span><a class="next-admin-icon-button" href="' . h(next_admin_url('forum_edit', ['id' => (int)$forum['id']])) . '" title="编辑版块">' . next_admin_icon('edit') . '</a></div><h2>' . h($forum['name']) . '</h2><p>' . h((string)$forum['description']) . '</p><div class="next-admin-forum-count"><strong>' . number_format($counts[(int)$forum['id']] ?? 0) . '</strong><span>主题</span></div><div class="next-admin-forum-permissions">' . h(implode(' · ', $permissions)) . '</div><a class="next-admin-forum-open" href="' . h(route_url('forum', ['id' => (int)$forum['id']])) . '" target="_blank" rel="noopener">查看版块' . next_admin_icon('external') . '</a></article>';
    }
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">CHANNEL MAP</span><h1>版块结构</h1><p>查看内容分布、访问权限和版块入口。</p></div><a class="next-admin-primary-button" href="' . h(next_admin_url('forum_edit', ['id' => 0])) . '">新建版块</a></div>' . ($html === '<div class="next-admin-forum-grid">' ? '<div class="next-admin-empty">尚未创建版块</div>' : $html . '</div>');
}

function next_admin_forum_edit_html(): string
{
    $forum_id = max(0, (int)($_GET['id'] ?? 0));
    $forum = $forum_id ? (forum_by_id($forum_id) ?: err('版块不存在')) : ['id' => 0, 'name' => '', 'description' => '', 'sort' => 0, 'allow_view_groups' => '', 'allow_post_groups' => '', 'allow_reply_groups' => ''];
    $permission_html = '';
    foreach (['allow_view_groups' => '允许浏览', 'allow_post_groups' => '允许发帖', 'allow_reply_groups' => '允许回复'] as $field => $label) {
        $options = str_replace('__NAME__', $field, next_admin_group_options(forum_group_ids($forum, $field)));
        $permission_html .= '<fieldset class="next-admin-permission"><legend>' . h($label) . '</legend><p>不选择表示不限制用户组</p><div>' . $options . '</div></fieldset>';
    }
    $form = '<form class="next-admin-editor" method="post" action="' . h(route_url('next_admin')) . '">' . form_token() . hidden_inputs(['next_admin_action' => 'save_forum', 'id' => $forum_id]) . '<div class="next-admin-form-grid">' . next_admin_field('版块名称', 'name', $forum['name'], 'text', '', true) . next_admin_field('排序', 'sort', (int)$forum['sort'], 'number', '数值越小越靠前') . '</div><label class="next-admin-field"><span>版块说明</span><textarea name="description" rows="5">' . h($forum['description']) . '</textarea></label><div class="next-admin-permission-grid">' . $permission_html . '</div><div class="next-admin-form-actions"><a href="' . h(next_admin_url('forums')) . '">取消</a><button type="submit">保存版块</button></div></form>';
    $danger = $forum_id > 0 ? '<div class="next-admin-danger-zone"><div><strong>删除版块</strong><span>仅超级管理员可执行，已有内容时请先迁移主题。</span></div>' . next_admin_action_form('delete_forum', '删除版块', ['id' => $forum_id], 'danger', '确定删除这个版块？') . '</div>' : '';
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">CHANNEL EDITOR</span><h1>' . ($forum_id ? '编辑版块' : '新建版块') . '</h1><p>配置版块信息、排序和用户组访问权限。</p></div></div>' . next_admin_panel('版块配置', $form) . $danger;
}

function next_admin_groups_html(): string
{
    $html = '<div class="next-admin-table-wrap"><table class="next-admin-table"><thead><tr><th>用户组</th><th>用户数</th><th>内容管理</th><th>后台管理</th><th>操作</th></tr></thead><tbody>';
    $counts = [];
    foreach (q('SELECT group_id,COUNT(*) AS total FROM app_users GROUP BY group_id')->fetchAll() as $row) $counts[(int)$row['group_id']] = (int)$row['total'];
    foreach (groups_cache() as $group) {
        $ops = '<div class="next-admin-row-actions"><a class="next-admin-small-button" href="' . h(next_admin_url('group_edit', ['id' => (int)$group['id']])) . '">编辑</a>';
        if (is_super_user() && !isset($counts[(int)$group['id']])) $ops .= next_admin_action_form('delete_group', '删除', ['id' => (int)$group['id']], 'danger', '确定删除这个用户组？');
        $ops .= '</div>';
        $html .= '<tr><td><strong>' . h($group['name']) . '</strong><small class="next-admin-cell-note">ID ' . (int)$group['id'] . '</small></td><td>' . number_format($counts[(int)$group['id']] ?? 0) . '</td><td><span class="next-admin-badge ' . ((int)$group['allow_manage'] ? 'is-success' : '') . '">' . ((int)$group['allow_manage'] ? '允许' : '禁止') . '</span></td><td><span class="next-admin-badge ' . ((int)$group['allow_admin'] ? 'is-success' : '') . '">' . ((int)$group['allow_admin'] ? '允许' : '禁止') . '</span></td><td>' . $ops . '</td></tr>';
    }
    $html .= '</tbody></table></div>';
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">ACCESS CONTROL</span><h1>用户组权限</h1><p>控制用户组的内容管理与后台访问能力。</p></div><a class="next-admin-primary-button" href="' . h(next_admin_url('group_edit', ['id' => 0])) . '">新建用户组</a></div>' . next_admin_panel('权限组', $html);
}

function next_admin_group_edit_html(): string
{
    $group_id = max(0, (int)($_GET['id'] ?? 0));
    $group = $group_id ? (group_by_id($group_id) ?: err('用户组不存在')) : ['id' => 0, 'name' => '', 'allow_manage' => 0, 'allow_admin' => 0];
    $form = '<form class="next-admin-editor" method="post" action="' . h(route_url('next_admin')) . '">' . form_token() . hidden_inputs(['next_admin_action' => 'save_group', 'id' => $group_id]) . next_admin_field('用户组名称', 'name', $group['name'], 'text', '', true) . '<div class="next-admin-check-grid">' . next_admin_checkbox('允许内容管理', 'allow_manage', (int)$group['allow_manage'] === 1, '可管理用户、主题和回复') . next_admin_checkbox('允许后台管理', 'allow_admin', (int)$group['allow_admin'] === 1, '可访问完整后台配置') . '</div><div class="next-admin-form-actions"><a href="' . h(next_admin_url('groups')) . '">取消</a><button type="submit">保存用户组</button></div></form>';
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">ACCESS EDITOR</span><h1>' . ($group_id ? '编辑用户组' : '新建用户组') . '</h1><p>谨慎授予后台权限，超级管理员始终拥有完整权限。</p></div></div>' . next_admin_panel('权限配置', $form);
}

function next_admin_settings_html(): string
{
    $settings = settings_cache();
    $groups = '';
    foreach (groups_cache() as $group) $groups .= '<option value="' . (int)$group['id'] . '"' . ((int)($settings['default_group_id'] ?? 2) === (int)$group['id'] ? ' selected' : '') . '>' . h($group['name']) . '</option>';
    $form = '<form class="next-admin-editor" method="post" action="' . h(route_url('next_admin')) . '">' . form_token() . hidden_inputs(['next_admin_action' => 'save_settings'])
        . '<div class="next-admin-setting-section"><h3>站点信息</h3><div class="next-admin-form-grid">' . next_admin_field('网站名', 'site_name', $settings['site_name'] ?? '', 'text', '', true) . next_admin_field('浏览器标题', 'site_name_title', $settings['site_name_title'] ?? '', 'text', '留空时使用网站名') . next_admin_field('固定访问地址', 'site_base_url', $settings['site_base_url'] ?? '', 'url', '以 https:// 开头') . next_admin_field('关键词', 'site_keywords', $settings['site_keywords'] ?? '') . '</div><label class="next-admin-field"><span>网站介绍</span><textarea name="site_description" rows="4">' . h($settings['site_description'] ?? '') . '</textarea></label></div>'
        . '<div class="next-admin-setting-section"><h3>内容与分页</h3><div class="next-admin-form-grid">' . next_admin_field('顶部版块数', 'pc_nav_forum_count', $settings['pc_nav_forum_count'] ?? 6, 'number') . next_admin_field('主题每页数量', 'topics_per_page', $settings['topics_per_page'] ?? 30, 'number') . next_admin_field('回复每页数量', 'replies_per_page', $settings['replies_per_page'] ?? 50, 'number') . next_admin_field('最大分页数', 'max_pagination_pages', $settings['max_pagination_pages'] ?? 50, 'number') . next_admin_field('搜索最小字符', 'search_min_chars', $settings['search_min_chars'] ?? 2, 'number') . next_admin_field('发帖间隔（秒）', 'post_interval_seconds', $settings['post_interval_seconds'] ?? 5, 'number') . next_admin_field('置顶主题 ID', 'pinned_topic_ids', $settings['pinned_topic_ids'] ?? '', 'text', '多个 ID 使用英文逗号分隔') . '<label class="next-admin-field"><span>新用户默认组</span><select name="default_group_id">' . $groups . '</select></label></div></div>'
        . '<div class="next-admin-setting-section"><h3>运行策略</h3><div class="next-admin-check-grid">' . next_admin_checkbox('允许用户注册', 'allow_register', (string)($settings['allow_register'] ?? '1') === '1') . next_admin_checkbox('启用美化链接', 'pretty_url', (string)($settings['pretty_url'] ?? '0') === '1') . next_admin_checkbox('维护模式', 'site_closed', (string)($settings['site_closed'] ?? '0') === '1', '管理员仍可访问站点') . next_admin_checkbox('Debug 模式', 'debug_mode', (string)($settings['debug_mode'] ?? '0') === '1', '仅排查问题时开启') . next_admin_checkbox('忽略 SSL 错误', 'ignore_ssl_errors', (string)($settings['ignore_ssl_errors'] ?? '0') === '1', '可能降低外部请求安全性') . '</div></div><div class="next-admin-form-actions"><button type="submit">保存全部设置</button></div></form>';
    $tools = '<div class="next-admin-tool-row"><div><strong>OPcache</strong><span>代码更新后清理 PHP 编译缓存。</span></div>' . next_admin_action_form('clear_opcache', '立即清理') . '</div><div class="next-admin-tool-row"><div><strong>在线升级</strong><span>检查并安装核心程序更新。</span></div><a class="next-admin-small-button" href="' . h(route_url('update')) . '">进入升级</a></div>';
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">SITE PREFERENCES</span><h1>站点设置</h1><p>常用核心设置已完整迁移到新版后台。</p></div></div>' . next_admin_panel('基础配置', $form) . next_admin_panel('维护工具', $tools);
}

function next_admin_plugins_html(): string
{
    $section = in_array((string)($_GET['section'] ?? 'local'), ['local', 'cron'], true) ? (string)($_GET['section'] ?? 'local') : 'local';
    $tabs = '<div class="next-admin-segments"><a href="' . h(next_admin_url('plugins')) . '"' . ($section === 'local' ? ' class="is-active"' : '') . '>本地插件</a><a href="' . h(next_admin_url('plugins', ['section' => 'cron'])) . '"' . ($section === 'cron' ? ' class="is-active"' : '') . '>计划任务</a><a href="' . h(admin_url(['tab' => 'plugins', 'view' => 'market'])) . '">插件市场</a></div>';
    if ($section === 'cron') return next_admin_plugins_cron_html($tabs);
    $plugins = \app\optional\Plugin::plugin_registry();
    uasort($plugins, static fn(array $a, array $b): int => ((int)($b['updated_at'] ?? 0) <=> (int)($a['updated_at'] ?? 0)) ?: strcmp((string)$a['id'], (string)$b['id']));
    $html = '<div class="next-admin-plugin-cards">';
    foreach ($plugins as $plugin) {
        $id = (string)$plugin['id'];
        $enabled = !empty($plugin['enabled']);
        $error = !$enabled && trim((string)($plugin['disabled_reason'] ?? '')) !== '';
        $description = trim((string)($plugin['description'] ?? ''));
        $toggle = $id === 'next_admin' ? '<span class="next-admin-badge is-success">当前后台</span>' : next_admin_action_form('plugin_toggle', $enabled ? '停用' : '启用', ['plugin_id' => $id, 'enabled' => $enabled ? 0 : 1], $enabled ? 'warning' : 'primary', $enabled ? '确定停用这个插件？' : '');
        $features = [];
        if (!empty($plugin['hooks'])) $features[] = count($plugin['hooks']) . ' 个钩子';
        if (!empty($plugin['routes'])) $features[] = count($plugin['routes']) . ' 个路由';
        if (!empty($plugin['admin_tabs'])) $features[] = count($plugin['admin_tabs']) . ' 个后台页';
        $manage = '';
        if ($enabled && !empty($plugin['admin_tabs'])) {
            $tab = array_key_first((array)$plugin['admin_tabs']);
            if (is_string($tab)) $manage = '<a class="next-admin-small-button" href="' . h(admin_url(['tab' => $tab])) . '">配置</a>';
        }
        $entries = '';
        foreach (['feature_links' => '快捷功能', 'sidebar_cards' => '边栏卡片'] as $entry => $label) {
            if (!plugin_uses_entry($plugin, $entry)) continue;
            $on = plugin_entry_enabled($plugin, $entry);
            $entries .= next_admin_action_form('plugin_entry', ($on ? '隐藏' : '显示') . $label, ['plugin_id' => $id, 'entry' => $entry, 'enabled' => $on ? 0 : 1]);
        }
        $transfer = '<form class="next-admin-inline-form" method="post" action="' . h(route_url('plugin_download')) . '">' . form_token() . hidden_inputs(['plugin_id' => $id]) . '<button class="next-admin-small-button" type="submit">下载</button></form><form class="next-admin-inline-form" method="post" action="' . h(route_url('plugin_market_share')) . '" target="_blank">' . form_token() . hidden_inputs(['plugin_id' => $id]) . '<button class="next-admin-small-button" type="submit">分享</button></form>';
        $uninstall = $id === 'next_admin' ? '' : '<details class="next-admin-plugin-more"><summary>更多</summary><div><form class="next-admin-uninstall-form" method="post" action="' . h(route_url('next_admin')) . '" data-next-admin-confirm="确定卸载插件？插件目录会被永久删除。">' . form_token() . hidden_inputs(['next_admin_action' => 'plugin_uninstall', 'plugin_id' => $id]) . '<label><input type="checkbox" name="keep_data" value="1" checked>卸载时保留数据</label><button class="next-admin-small-button is-danger" type="submit">卸载</button></form></div></details>';
        $html .= '<article><div class="next-admin-plugin-card-head"><span class="next-admin-plugin-mark ' . ($enabled ? 'is-on' : ($error ? 'is-error' : '')) . '">' . next_admin_icon('plugin') . '</span><span><strong>' . h($plugin['name']) . '</strong><small>' . h($id . ' · ' . $plugin['version'] . ((string)($plugin['author'] ?? '') !== '' ? ' · ' . $plugin['author'] : '')) . '</small></span>' . $toggle . '</div><p>' . h($description !== '' ? $description : '暂无插件说明') . '</p>' . ($features ? '<div class="next-admin-plugin-features">' . h(implode(' · ', $features)) . '</div>' : '') . ($error ? '<div class="next-admin-plugin-error">' . h((string)$plugin['disabled_reason']) . '</div>' : '') . '<div class="next-admin-plugin-actions">' . $manage . $entries . $transfer . '</div>' . $uninstall . '</article>';
    }
    $html .= '</div>';
    $sync = next_admin_action_form('plugin_sync', '同步插件', [], 'primary', '确定扫描插件目录并同步注册信息？');
    $upload = '<form class="next-admin-upload" method="post" action="' . h(admin_url(['tab' => 'plugins'])) . '" enctype="multipart/form-data"><input type="hidden" name="plugin_action" value="upload">' . form_token() . '<label class="next-admin-secondary-button"><input type="file" name="plugin_file" accept=".php" required><span>上传插件</span></label><button class="next-admin-primary-button" type="submit">开始上传</button></form>';
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">EXTENSIONS</span><h1>插件管理</h1><p>管理插件状态、展示入口、配置、分发和卸载。</p></div><div class="next-admin-head-actions">' . $upload . $sync . '</div></div>' . $tabs . ($plugins ? $html : '<div class="next-admin-empty">尚未同步插件</div>');
}

function next_admin_plugins_cron_html(string $tabs): string
{
    $rows = q('SELECT plugin_id,task_name,status,message,started_at,finished_at FROM app_cron_logs ORDER BY started_at DESC,id DESC LIMIT 100')->fetchAll();
    $names = [];
    foreach (\app\optional\Plugin::plugin_registry() as $plugin) $names[(string)$plugin['id']] = (string)$plugin['name'];
    $html = '<div class="next-admin-table-wrap"><table class="next-admin-table"><thead><tr><th>插件 / 任务</th><th>状态</th><th>开始时间</th><th>耗时</th><th>运行信息</th></tr></thead><tbody>';
    foreach ($rows as $row) {
        $status = (string)$row['status'];
        $tone = $status === 'success' ? 'is-success' : ($status === 'failed' ? 'is-danger' : 'is-warning');
        $started = (int)$row['started_at'];
        $finished = (int)$row['finished_at'];
        $html .= '<tr><td><strong>' . h($names[(string)$row['plugin_id']] ?? (string)$row['plugin_id']) . '</strong><small class="next-admin-cell-note">' . h((string)$row['plugin_id'] . ' / ' . (string)$row['task_name']) . '</small></td><td><span class="next-admin-badge ' . $tone . '">' . h(['success' => '成功', 'failed' => '失败', 'running' => '运行中'][$status] ?? $status) . '</span></td><td>' . ($started ? h(date('Y-m-d H:i:s', $started)) : '-') . '</td><td>' . ($finished > 0 ? max(0, $finished - $started) . ' 秒' : '进行中') . '</td><td><span class="next-admin-log-message" title="' . h((string)$row['message']) . '">' . h(cut((string)$row['message'], 160)) . '</span></td></tr>';
    }
    if (!$rows) $html .= '<tr><td colspan="5"><div class="next-admin-empty">暂无计划任务运行记录</div></td></tr>';
    $html .= '</tbody></table></div>';
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">EXTENSION JOBS</span><h1>计划任务</h1><p>查看最近 100 条插件任务运行记录。</p></div></div>' . $tabs . next_admin_panel('运行日志', $html);
}

function next_admin_system_html(): string
{
    $status = next_admin_status();
    $plugins = q('SELECT id,name,version,enabled,status,disabled_reason FROM app_plugins ORDER BY enabled DESC,name')->fetchAll();
    $tools = [
        ['system', '站点设置', '站点名称、注册策略、分页与搜索参数', next_admin_url('settings')],
        ['forums', '版块管理', '新建、排序、权限与内容分区', next_admin_url('forums')],
        ['shield', '用户组权限', '管理内容权限和后台访问权限', next_admin_url('groups')],
        ['plugin', '插件中心', '同步、启用和停用站点插件', next_admin_url('plugins')],
        ['clock', '计划任务', '查看任务状态与最近执行记录', next_admin_url('plugins', ['section' => 'cron'])],
        ['external', '程序升级', '检查并安装核心程序更新', route_url('update')],
    ];
    $tool_html = '<div class="next-admin-system-tools">';
    foreach ($tools as [$icon, $title, $desc, $url]) $tool_html .= '<a href="' . h($url) . '"><span>' . next_admin_icon($icon) . '</span><div><strong>' . h($title) . '</strong><small>' . h($desc) . '</small></div>' . next_admin_icon('arrow') . '</a>';
    $tool_html .= '</div>';
    $plugin_html = '<div class="next-admin-plugin-list">';
    foreach ($plugins as $plugin) {
        $enabled = (int)$plugin['enabled'] === 1;
        $error = (string)$plugin['status'] === 'error';
        $plugin_html .= '<div><span class="next-admin-plugin-mark ' . ($enabled ? 'is-on' : ($error ? 'is-error' : '')) . '">' . next_admin_icon('plugin') . '</span><span><strong>' . h($plugin['name']) . '</strong><small>' . h($plugin['id'] . ' · ' . $plugin['version']) . '</small></span><span class="next-admin-badge ' . ($enabled ? 'is-success' : ($error ? 'is-danger' : '')) . '">' . ($enabled ? '启用' : ($error ? '异常' : '停用')) . '</span></div>';
    }
    $plugin_html .= '</div>';
    $environment = '<div class="next-admin-environment"><div><span>程序版本</span><strong>' . h(APP_VERSION) . '</strong></div><div><span>PHP</span><strong>' . h($status['php']) . '</strong></div><div><span>数据库</span><strong>' . h($status['db']) . '</strong></div><div><span>计划任务</span><strong>' . ($status['last_cron'] ? h(human_time($status['last_cron'])) : '未运行') . '</strong></div></div>';
    return '<div class="next-admin-page-head"><div><span class="next-admin-eyebrow">SYSTEM CONTROL</span><h1>系统与工具</h1><p>站点日常管理已迁入新版后台，少数专项工具继续复用核心流程。</p></div></div><div class="next-admin-grid next-admin-grid-system">' . next_admin_panel('管理工具', $tool_html) . next_admin_panel('运行环境', $environment) . '</div>' . next_admin_panel('插件状态', $plugin_html, '<a class="next-admin-text-link" href="' . h(next_admin_url('plugins')) . '">管理插件</a>');
}

function next_admin_sidebar_html(string $active, string $site_name): string
{
    $active = ['user_edit' => 'users', 'forum_edit' => 'forums', 'group_edit' => 'groups'][$active] ?? $active;
    $items = [
        'overview' => ['overview', '概览'],
        'content' => ['content', '内容'],
        'users' => ['users', '用户'],
        'forums' => ['forums', '版块'],
        'groups' => ['shield', '用户组'],
        'settings' => ['system', '设置'],
        'plugins' => ['plugin', '插件'],
        'system' => ['system', '系统'],
    ];
    $html = '<aside class="next-admin-sidebar" id="next-admin-sidebar"><div class="next-admin-brand"><span>NA</span><div><strong>' . h($site_name) . '</strong><small>ADMIN CONSOLE</small></div><button type="button" data-next-admin-close aria-label="关闭菜单">' . next_admin_icon('close') . '</button></div><nav aria-label="后台导航"><span class="next-admin-nav-label">工作台</span>';
    foreach ($items as $view => [$icon, $label]) $html .= '<a href="' . h(next_admin_url($view)) . '"' . ($active === $view ? ' class="is-active" aria-current="page"' : '') . '>' . next_admin_icon($icon) . '<span>' . h($label) . '</span></a>';
    $html .= '</nav><div class="next-admin-sidebar-foot"><a href="' . h(route_url('home')) . '" target="_blank" rel="noopener">' . next_admin_icon('external') . '<span>返回站点</span></a></div></aside>';
    return $html;
}

function next_admin_shell(string $view, string $content): never
{
    $site_name = trim(setting('site_name')) ?: 'FORUM';
    $me = me();
    $titles = ['overview' => '管理概览', 'content' => '内容管理', 'users' => '用户查询', 'user_edit' => '编辑用户', 'forums' => '版块结构', 'forum_edit' => '编辑版块', 'groups' => '用户组权限', 'group_edit' => '编辑用户组', 'settings' => '站点设置', 'plugins' => '插件管理', 'system' => '系统与工具'];
    $search_view = $view === 'users' ? 'users' : 'content';
    $search_placeholder = $view === 'users' ? '搜索用户名或邮箱' : '搜索主题与内容';
    $flash = trim((string)($_COOKIE['__flash'] ?? ''));
    if ($flash !== '' && !headers_sent()) app_cookie('__flash', '', time() - 3600, true, false);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>' . h($titles[$view] . ' - ' . $site_name) . '</title><link rel="icon" type="image/svg+xml" href="' . h(asset_url('app/assets/index.svg')) . '">' . plugin_asset_tag('css') . '</head><body><div class="next-admin-app" data-next-admin-app>'
        . next_admin_sidebar_html($view, $site_name)
        . '<div class="next-admin-overlay" data-next-admin-close></div><section class="next-admin-workspace"><header class="next-admin-topbar"><button class="next-admin-menu-button" type="button" data-next-admin-open aria-label="打开菜单" aria-controls="next-admin-sidebar" aria-expanded="false">' . next_admin_icon('menu') . '</button><form class="next-admin-global-search" method="get" action="' . h(route_url('next_admin')) . '"><input type="hidden" name="view" value="' . h($search_view) . '">' . next_admin_icon('search') . '<input type="search" name="q" placeholder="' . h($search_placeholder) . '" aria-label="' . h($search_placeholder) . '"><kbd>/</kbd></form><div class="next-admin-top-actions"><button class="next-admin-theme" type="button" data-next-admin-theme title="切换明暗主题"><span class="next-admin-theme-sun">' . next_admin_icon('sun') . '</span><span class="next-admin-theme-moon">' . next_admin_icon('moon') . '</span></button><a class="next-admin-profile" href="' . h(route_url('user', ['id' => (int)$me['id']])) . '"><span class="next-admin-avatar">' . avatar_tag((int)$me['id'], (string)$me['username'], (string)($me['avatar_style'] ?? ''), '', (string)($me['avatar_seed'] ?? '')) . '</span><span><strong>' . h($me['username']) . '</strong><small>' . h($me['group_name'] ?? '管理员') . '</small></span></a></div></header><main class="next-admin-main">' . $content . '</main></section>' . ($flash !== '' ? '<div class="next-admin-toast" role="status" data-next-admin-toast>' . h($flash) . '</div>' : '') . '</div>' . plugin_asset_tag('js') . '</body></html>';
    exit;
}

function next_admin_page(array $plugin): void
{
    need_admin();
    if (is_post_request()) next_admin_handle_post();
    $view = next_admin_view();
    $content = match ($view) {
        'content' => next_admin_content_html(),
        'users' => next_admin_users_html(),
        'user_edit' => next_admin_user_edit_html(),
        'forums' => next_admin_forums_html(),
        'forum_edit' => next_admin_forum_edit_html(),
        'groups' => next_admin_groups_html(),
        'group_edit' => next_admin_group_edit_html(),
        'settings' => next_admin_settings_html(),
        'plugins' => next_admin_plugins_html(),
        'system' => next_admin_system_html(),
        default => next_admin_overview_html(),
    };
    next_admin_shell($view, $content);
}

function next_admin_css(): string
{
    return <<<'CSS'
.next-admin-app{--next-admin-bg:#f3f5f4;--next-admin-panel:#fff;--next-admin-panel-alt:#f8f9f8;--next-admin-sidebar:#151917;--next-admin-sidebar-text:#d5dad7;--next-admin-text:#171b19;--next-admin-muted:#69716d;--next-admin-subtle:#929a96;--next-admin-line:#dde2df;--next-admin-line-strong:#ccd3cf;--next-admin-accent:#21b67a;--next-admin-accent-dark:#087a50;--next-admin-accent-soft:#e7f8f0;--next-admin-danger:#c94747;--next-admin-danger-soft:#fff0ef;--next-admin-warning:#ad6a14;--next-admin-warning-soft:#fff6e7;--next-admin-cyan:#168aa1;--next-admin-cyan-soft:#e8f7fa;--next-admin-command-bg:#151917;--next-admin-command-hover:#29302c;--next-admin-command-text:#fff;--next-admin-shadow:0 10px 30px rgba(24,35,29,.06);--next-admin-font-size-xs:12px;--next-admin-font-size-sm:13px;--next-admin-font-size-md:14px;--next-admin-font-size-lg:16px;--next-admin-font-size-xl:20px;--next-admin-font-size-title:30px;position:fixed;inset:0;min-height:100vh;overflow:auto;background:var(--next-admin-bg);color:var(--next-admin-text);font-family:"IBM Plex Sans","Noto Sans SC","Microsoft YaHei",sans-serif;line-height:1.5;letter-spacing:0;color-scheme:light}
.next-admin-app,.next-admin-app *{box-sizing:border-box}
.next-admin-app a{color:inherit;text-decoration:none}
.next-admin-icon{display:block;width:20px;height:20px;flex:none}
.next-admin-sidebar{position:fixed;inset:0 auto 0 0;z-index:30;display:flex;width:236px;flex-direction:column;background:var(--next-admin-sidebar);color:var(--next-admin-sidebar-text);box-shadow:8px 0 30px rgba(0,0,0,.08)}
.next-admin-brand{display:flex;align-items:center;gap:11px;height:76px;padding:0 18px;border-bottom:1px solid rgba(255,255,255,.08)}
.next-admin-brand>span{display:grid;width:38px;height:38px;place-items:center;border-radius:7px;background:var(--next-admin-accent);color:#072b1d;font-family:Georgia,serif;font-size:var(--next-admin-font-size-md);font-weight:800}
.next-admin-brand>div{display:grid;min-width:0}.next-admin-brand strong{overflow:hidden;color:#fff;font-family:Georgia,"Noto Serif SC",serif;font-size:var(--next-admin-font-size-lg);text-overflow:ellipsis;white-space:nowrap}.next-admin-brand small{color:#78827d;font-size:10px;letter-spacing:.14em}
.next-admin-brand button{display:none;margin-left:auto;border:0;background:none;color:#fff;padding:6px}
.next-admin-sidebar nav{display:grid;align-content:start;gap:4px;min-height:0;flex:1;padding:25px 12px;overflow:auto}
.next-admin-nav-label{padding:0 12px 8px;color:#66706b;font-size:10px;font-weight:700;letter-spacing:.16em}
.next-admin-sidebar nav a,.next-admin-sidebar-foot a{display:flex;align-items:center;gap:12px;min-height:44px;padding:0 13px;border-radius:6px;color:#99a29e;font-size:var(--next-admin-font-size-md);font-weight:600;transition:background .18s,color .18s}
.next-admin-sidebar nav a:hover,.next-admin-sidebar-foot a:hover{background:rgba(255,255,255,.06);color:#fff}.next-admin-sidebar nav a.is-active{background:var(--next-admin-accent);color:#092a1d}.next-admin-sidebar nav a.is-active .next-admin-icon{stroke-width:2.2}
.next-admin-sidebar-foot{display:grid;gap:4px;margin-top:auto;padding:14px 12px 20px;border-top:1px solid rgba(255,255,255,.08)}
.next-admin-workspace{min-height:100vh;margin-left:236px}
.next-admin-topbar{position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:20px;height:76px;padding:0 clamp(20px,3vw,44px);border-bottom:1px solid var(--next-admin-line);background:color-mix(in srgb,var(--next-admin-bg) 90%,transparent);backdrop-filter:blur(16px)}
.next-admin-menu-button{display:none;border:0;background:none;color:var(--next-admin-text);padding:7px}
.next-admin-global-search{display:flex;align-items:center;gap:10px;width:min(420px,45vw);height:40px;padding:0 12px;border:1px solid var(--next-admin-line);border-radius:6px;background:var(--next-admin-panel);transition:border-color .18s,box-shadow .18s}.next-admin-global-search:focus-within{border-color:var(--next-admin-accent);box-shadow:0 0 0 3px var(--next-admin-accent-soft)}.next-admin-global-search .next-admin-icon{width:17px;color:var(--next-admin-subtle)}.next-admin-global-search input{width:100%;border:0;outline:0;background:transparent;color:var(--next-admin-text);font:inherit;font-size:var(--next-admin-font-size-sm)}.next-admin-global-search kbd{padding:1px 6px;border:1px solid var(--next-admin-line);border-bottom-width:2px;border-radius:4px;color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs)}
.next-admin-top-actions{display:flex;align-items:center;gap:15px;margin-left:auto}.next-admin-theme{display:grid;width:38px;height:38px;place-items:center;border:1px solid var(--next-admin-line);border-radius:6px;background:var(--next-admin-panel);color:var(--next-admin-muted);cursor:pointer}.next-admin-theme span{grid-area:1/1}.next-admin-theme .next-admin-theme-moon{display:none}.next-admin-theme .next-admin-icon{width:17px;height:17px}
.next-admin-profile{display:flex;align-items:center;gap:9px}.next-admin-avatar{display:block;width:34px;height:34px;overflow:hidden;border-radius:6px;background:var(--next-admin-panel-alt)}.next-admin-avatar img,.next-admin-avatar svg{display:block;width:100%;height:100%;object-fit:cover}.next-admin-profile>span:last-child{display:grid}.next-admin-profile strong{font-size:var(--next-admin-font-size-sm)}.next-admin-profile small{color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}
.next-admin-main{width:min(1480px,100%);margin:0 auto;padding:36px clamp(20px,3vw,44px) 56px}
.next-admin-page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:24px;margin-bottom:28px}.next-admin-page-head h1{margin:4px 0 2px;font-family:Georgia,"Noto Serif SC",serif;font-size:var(--next-admin-font-size-title);line-height:1.2}.next-admin-page-head p{margin:0;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm)}.next-admin-eyebrow{color:var(--next-admin-accent-dark);font-size:10px;font-weight:800;letter-spacing:.16em}
.next-admin-app .next-admin-primary-button,.next-admin-app .next-admin-secondary-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:40px;padding:0 15px;border:1px solid var(--next-admin-command-bg);border-radius:6px;background:var(--next-admin-command-bg);color:var(--next-admin-command-text);font:inherit;font-size:var(--next-admin-font-size-sm);font-weight:700;white-space:nowrap;cursor:pointer}.next-admin-app .next-admin-secondary-button{border-color:var(--next-admin-line-strong);background:var(--next-admin-panel);color:var(--next-admin-text)}.next-admin-app .next-admin-primary-button:hover{border-color:var(--next-admin-command-hover);background:var(--next-admin-command-hover);color:var(--next-admin-command-text)}.next-admin-app .next-admin-secondary-button:hover{border-color:var(--next-admin-accent);background:var(--next-admin-panel-alt);color:var(--next-admin-text)}.next-admin-primary-button .next-admin-icon,.next-admin-secondary-button .next-admin-icon{width:16px;height:16px}
.next-admin-head-actions{display:flex;align-items:center;gap:9px}
.next-admin-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:18px}.next-admin-stat{display:grid;min-height:144px;padding:18px;border:1px solid var(--next-admin-line);border-radius:7px;background:var(--next-admin-panel);box-shadow:var(--next-admin-shadow)}.next-admin-stat-top{display:flex;align-items:center;justify-content:space-between}.next-admin-stat-icon{display:grid;width:36px;height:36px;place-items:center;border-radius:6px;background:var(--next-admin-panel-alt);color:var(--next-admin-text)}.next-admin-stat-icon .next-admin-icon{width:18px;height:18px}.next-admin-stat-delta{padding:3px 7px;border-radius:4px;background:var(--next-admin-panel-alt);color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs);font-weight:700}.next-admin-stat>strong{align-self:end;margin-top:17px;font-family:Georgia,serif;font-size:26px;line-height:1}.next-admin-stat>span:last-child{margin-top:5px;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm)}.next-admin-tone-cyan .next-admin-stat-icon{background:var(--next-admin-cyan-soft);color:var(--next-admin-cyan)}.next-admin-tone-green .next-admin-stat-icon{background:var(--next-admin-accent-soft);color:var(--next-admin-accent-dark)}.next-admin-tone-amber .next-admin-stat-icon{background:var(--next-admin-warning-soft);color:var(--next-admin-warning)}
.next-admin-grid{display:grid;gap:18px;margin-bottom:18px}.next-admin-grid-main{grid-template-columns:minmax(0,1.65fr) minmax(280px,.75fr)}.next-admin-grid-list{grid-template-columns:minmax(0,1.6fr) minmax(280px,.65fr)}.next-admin-grid-system{grid-template-columns:minmax(0,1.5fr) minmax(260px,.65fr)}
.next-admin-panel{min-width:0;margin-bottom:18px;border:1px solid var(--next-admin-line);border-radius:7px;background:var(--next-admin-panel);box-shadow:var(--next-admin-shadow);overflow:hidden}.next-admin-grid>.next-admin-panel{margin-bottom:0}.next-admin-panel>header{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:55px;padding:0 18px;border-bottom:1px solid var(--next-admin-line)}.next-admin-panel h2{margin:0;font-family:Georgia,"Noto Serif SC",serif;font-size:var(--next-admin-font-size-lg)}.next-admin-panel-note{color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs)}.next-admin-panel .next-admin-text-link{color:var(--next-admin-accent-dark);font-size:var(--next-admin-font-size-xs);font-weight:700}.next-admin-text-link:hover{text-decoration:underline}
.next-admin-chart{position:relative;height:280px;padding:24px 20px 16px}.next-admin-chart:before{position:absolute;inset:24px 20px 45px;content:"";background:repeating-linear-gradient(to bottom,var(--next-admin-line) 0,var(--next-admin-line) 1px,transparent 1px,transparent 25%);opacity:.65}.next-admin-chart-legend{position:absolute;z-index:2;top:14px;right:20px;display:flex;gap:13px;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}.next-admin-chart-legend span:before{display:inline-block;width:7px;height:7px;margin-right:6px;border-radius:2px;background:var(--next-admin-accent);content:""}.next-admin-chart-legend .is-reply:before{background:var(--next-admin-cyan)}.next-admin-bars{position:relative;z-index:1;display:grid;height:100%;grid-template-columns:repeat(7,1fr);gap:clamp(8px,2vw,20px);align-items:end}.next-admin-bar-day{display:grid;height:100%;grid-template-rows:1fr 24px;gap:7px;text-align:center}.next-admin-bar-stack{display:flex;align-items:end;justify-content:center;gap:3px}.next-admin-bar-stack i{display:block;width:min(15px,35%);min-height:3px;border-radius:3px 3px 0 0;background:var(--next-admin-accent);transition:filter .18s}.next-admin-bar-stack i.is-reply{background:var(--next-admin-cyan)}.next-admin-bar-day:hover i{filter:brightness(.85)}.next-admin-bar-day>span{color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs)}
.next-admin-health{display:grid;padding:8px 18px}.next-admin-health>div{display:grid;grid-template-columns:10px 1fr auto;align-items:center;gap:10px;min-height:47px;border-bottom:1px solid var(--next-admin-line);font-size:var(--next-admin-font-size-sm)}.next-admin-health>div:last-child{border-bottom:0}.next-admin-health strong{font-size:var(--next-admin-font-size-xs)}.next-admin-health-dot{width:8px;height:8px;border-radius:50%;background:var(--next-admin-subtle);box-shadow:0 0 0 3px var(--next-admin-panel-alt)}.next-admin-health-dot.is-success{background:var(--next-admin-accent)}.next-admin-health-dot.is-danger{background:var(--next-admin-danger)}.next-admin-health-dot.is-warning{background:var(--next-admin-warning)}
.next-admin-quick-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:1px;background:var(--next-admin-line)}.next-admin-quick-grid>a{display:flex;align-items:center;gap:12px;min-width:0;padding:18px;background:var(--next-admin-panel);transition:background .18s}.next-admin-quick-grid>a:hover{background:var(--next-admin-panel-alt)}.next-admin-quick-grid>a>span:first-child{display:grid;width:36px;height:36px;place-items:center;border-radius:6px;background:var(--next-admin-panel-alt);color:var(--next-admin-accent-dark)}.next-admin-quick-grid>a>span:first-child .next-admin-icon{width:18px}.next-admin-quick-grid>a>div{display:grid;min-width:0}.next-admin-quick-grid strong{font-size:var(--next-admin-font-size-sm)}.next-admin-quick-grid small{overflow:hidden;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs);text-overflow:ellipsis;white-space:nowrap}.next-admin-quick-grid>a>.next-admin-icon{width:15px;margin-left:auto;color:var(--next-admin-subtle)}
.next-admin-table-wrap{overflow:auto}.next-admin-table{width:100%;border-collapse:collapse;font-size:var(--next-admin-font-size-sm)}.next-admin-table th{height:40px;padding:0 15px;background:var(--next-admin-panel-alt);color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs);font-weight:700;text-align:left;white-space:nowrap}.next-admin-table td{height:66px;padding:9px 15px;border-top:1px solid var(--next-admin-line);vertical-align:middle}.next-admin-table tbody tr:hover{background:var(--next-admin-panel-alt)}.next-admin-primary{display:grid;min-width:210px;max-width:520px}.next-admin-primary>a{overflow:hidden;font-weight:700;text-overflow:ellipsis;white-space:nowrap}.next-admin-primary>a:hover{color:var(--next-admin-accent-dark)}.next-admin-primary>span,.next-admin-primary>small{overflow:hidden;color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs);font-weight:400;text-overflow:ellipsis;white-space:nowrap}.next-admin-chip{display:inline-flex;padding:3px 7px;border:1px solid var(--next-admin-line);border-radius:4px;background:var(--next-admin-panel-alt);font-size:var(--next-admin-font-size-xs);white-space:nowrap}.next-admin-metric-pair{display:grid;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs);white-space:nowrap}.next-admin-table time{color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs);white-space:nowrap}.next-admin-icon-button{display:grid;width:32px;height:32px;place-items:center;border:1px solid var(--next-admin-line);border-radius:5px;background:var(--next-admin-panel);color:var(--next-admin-muted)}.next-admin-icon-button:hover{border-color:var(--next-admin-accent);color:var(--next-admin-accent-dark)}.next-admin-icon-button .next-admin-icon{width:15px;height:15px}
.next-admin-cell-note{display:block;color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs);font-weight:400}.next-admin-row-actions{display:flex;align-items:center;gap:5px;white-space:nowrap}.next-admin-inline-form{display:inline-flex;margin:0}.next-admin-app .next-admin-small-button{display:inline-flex;align-items:center;justify-content:center;min-height:30px;padding:0 9px;border:1px solid var(--next-admin-line-strong);border-radius:5px;background:var(--next-admin-panel);color:var(--next-admin-text);font:inherit;font-size:var(--next-admin-font-size-xs);font-weight:700;cursor:pointer}.next-admin-app .next-admin-small-button:hover{border-color:var(--next-admin-accent);background:var(--next-admin-panel-alt);color:var(--next-admin-accent-dark)}.next-admin-app .next-admin-small-button.is-primary{border-color:var(--next-admin-command-bg);background:var(--next-admin-command-bg);color:var(--next-admin-command-text)}.next-admin-app .next-admin-small-button.is-primary:hover{border-color:var(--next-admin-command-hover);background:var(--next-admin-command-hover);color:var(--next-admin-command-text)}.next-admin-app .next-admin-small-button.is-danger{border-color:var(--next-admin-danger-soft);background:var(--next-admin-danger-soft);color:var(--next-admin-danger)}.next-admin-app .next-admin-small-button.is-warning{border-color:var(--next-admin-warning-soft);background:var(--next-admin-warning-soft);color:var(--next-admin-warning)}
.next-admin-recent-users{display:grid;padding:7px 16px}.next-admin-recent-users>a{display:flex;align-items:center;gap:10px;min-height:57px;border-bottom:1px solid var(--next-admin-line)}.next-admin-recent-users>a:last-child{border-bottom:0}.next-admin-recent-users>a>span:nth-child(2){display:grid;min-width:0}.next-admin-recent-users strong{overflow:hidden;font-size:var(--next-admin-font-size-sm);text-overflow:ellipsis;white-space:nowrap}.next-admin-recent-users small{color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}.next-admin-recent-users>a>.next-admin-icon{width:14px;margin-left:auto;color:var(--next-admin-subtle)}
.next-admin-filter{display:flex;align-items:center;gap:9px;margin-bottom:18px;padding:12px;border:1px solid var(--next-admin-line);border-radius:7px;background:var(--next-admin-panel)}.next-admin-filter label{display:flex;align-items:center;gap:8px;min-width:220px;max-width:560px;flex:1;height:38px;padding:0 11px;border:1px solid var(--next-admin-line);border-radius:5px;background:var(--next-admin-panel-alt)}.next-admin-filter label:focus-within{border-color:var(--next-admin-accent)}.next-admin-filter label .next-admin-icon{width:16px;color:var(--next-admin-subtle)}.next-admin-filter input,.next-admin-filter select{border:0;outline:0;background:transparent;color:var(--next-admin-text);font:inherit;font-size:var(--next-admin-font-size-sm)}.next-admin-filter input{width:100%}.next-admin-filter select{height:38px;padding:0 30px 0 10px;border:1px solid var(--next-admin-line);border-radius:5px;background:var(--next-admin-panel-alt)}.next-admin-filter button{height:38px;padding:0 16px;border:0;border-radius:5px;background:var(--next-admin-command-bg);color:var(--next-admin-command-text);font:inherit;font-size:var(--next-admin-font-size-sm);font-weight:700;cursor:pointer}.next-admin-filter button:hover{background:var(--next-admin-command-hover)}.next-admin-filter>a{padding:8px;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm)}
.next-admin-filter-users{flex-wrap:wrap}.next-admin-filter-users label{min-width:260px}.next-admin-select-col{width:42px;text-align:center}.next-admin-select-col input{accent-color:var(--next-admin-accent)}.next-admin-bulk{display:flex;align-items:center;gap:9px;margin:-7px 0 18px;padding:12px 14px;border:1px solid var(--next-admin-line);border-radius:7px;background:var(--next-admin-panel)}.next-admin-bulk>label{display:flex;align-items:center;gap:7px;margin-right:auto;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm)}.next-admin-bulk input{accent-color:var(--next-admin-accent)}.next-admin-bulk select{height:36px;padding:0 30px 0 10px;border:1px solid var(--next-admin-line-strong);border-radius:5px;background:var(--next-admin-panel-alt);color:var(--next-admin-text);font:inherit;font-size:var(--next-admin-font-size-sm)}.next-admin-bulk button{height:36px;padding:0 14px;border:0;border-radius:5px;background:var(--next-admin-command-bg);color:var(--next-admin-command-text);font:inherit;font-size:var(--next-admin-font-size-sm);font-weight:700;cursor:pointer}.next-admin-pagination{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-top:18px;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm)}.next-admin-pagination>div{display:flex;align-items:center;gap:9px}.next-admin-pagination a{display:inline-flex;min-height:34px;align-items:center;padding:0 11px;border:1px solid var(--next-admin-line-strong);border-radius:5px;background:var(--next-admin-panel);color:var(--next-admin-text)}.next-admin-pagination a:hover{border-color:var(--next-admin-accent)}.next-admin-pagination strong{color:var(--next-admin-text);font-size:var(--next-admin-font-size-xs)}
.next-admin-segments{display:inline-flex;margin-bottom:12px;padding:3px;border:1px solid var(--next-admin-line);border-radius:6px;background:var(--next-admin-panel)}.next-admin-app .next-admin-segments a{min-width:72px;padding:7px 12px;border-radius:4px;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm);font-weight:700;text-align:center}.next-admin-app .next-admin-segments a:hover{background:var(--next-admin-panel-alt);color:var(--next-admin-text)}.next-admin-app .next-admin-segments a.is-active{background:var(--next-admin-command-bg);color:var(--next-admin-command-text)}.next-admin-table-link{display:block;overflow:hidden;max-width:280px;color:var(--next-admin-text);text-overflow:ellipsis;white-space:nowrap}.next-admin-table-link:hover{color:var(--next-admin-accent-dark)}
.next-admin-user{display:flex;align-items:center;gap:10px;min-width:200px}.next-admin-user>span:last-child{display:grid;min-width:0}.next-admin-user strong,.next-admin-user small{overflow:hidden;max-width:220px;text-overflow:ellipsis;white-space:nowrap}.next-admin-user small{color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs)}.next-admin-badges{display:flex;gap:5px}.next-admin-badge{display:inline-flex;align-items:center;min-height:22px;padding:1px 7px;border-radius:4px;background:var(--next-admin-panel-alt);color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs);font-weight:700;white-space:nowrap}.next-admin-badge.is-success{background:var(--next-admin-accent-soft);color:var(--next-admin-accent-dark)}.next-admin-badge.is-danger{background:var(--next-admin-danger-soft);color:var(--next-admin-danger)}.next-admin-badge.is-warning{background:var(--next-admin-warning-soft);color:var(--next-admin-warning)}
.next-admin-forum-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.next-admin-forum-card{display:flex;min-height:280px;flex-direction:column;padding:18px;border:1px solid var(--next-admin-line);border-radius:7px;background:var(--next-admin-panel);box-shadow:var(--next-admin-shadow)}.next-admin-forum-card-top{display:flex;align-items:center;justify-content:space-between}.next-admin-forum-card-top>span{display:grid;width:40px;height:40px;place-items:center;border-radius:6px;background:var(--next-admin-accent-soft);color:var(--next-admin-accent-dark)}.next-admin-forum-card h2{margin:19px 0 5px;font-family:Georgia,"Noto Serif SC",serif;font-size:var(--next-admin-font-size-xl)}.next-admin-forum-card p{display:-webkit-box;overflow:hidden;min-height:42px;margin:0;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm);-webkit-box-orient:vertical;-webkit-line-clamp:2}.next-admin-forum-count{display:flex;align-items:baseline;gap:6px;margin-top:18px}.next-admin-forum-count strong{font-family:Georgia,serif;font-size:26px}.next-admin-forum-count span{color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}.next-admin-forum-permissions{margin-top:5px;color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs)}.next-admin-forum-card .next-admin-forum-open{display:flex;align-items:center;gap:7px;margin-top:auto;padding-top:15px;border-top:1px solid var(--next-admin-line);color:var(--next-admin-accent-dark);font-size:var(--next-admin-font-size-sm);font-weight:700}.next-admin-forum-open .next-admin-icon{width:14px}
.next-admin-system-tools{display:grid;grid-template-columns:1fr 1fr}.next-admin-system-tools>a{display:flex;align-items:center;gap:11px;min-width:0;min-height:78px;padding:14px 17px;border-right:1px solid var(--next-admin-line);border-bottom:1px solid var(--next-admin-line)}.next-admin-system-tools>a:nth-child(2n){border-right:0}.next-admin-system-tools>a:nth-last-child(-n+2){border-bottom:0}.next-admin-system-tools>a>span{display:grid;width:36px;height:36px;place-items:center;border-radius:6px;background:var(--next-admin-panel-alt);color:var(--next-admin-accent-dark)}.next-admin-system-tools>a>span .next-admin-icon{width:17px}.next-admin-system-tools>a>div{display:grid;min-width:0}.next-admin-system-tools strong{font-size:var(--next-admin-font-size-sm)}.next-admin-system-tools small{overflow:hidden;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs);text-overflow:ellipsis;white-space:nowrap}.next-admin-system-tools>a>.next-admin-icon{width:14px;margin-left:auto;color:var(--next-admin-subtle)}.next-admin-system-tools>a:hover{background:var(--next-admin-panel-alt)}
.next-admin-environment{display:grid;padding:8px 18px}.next-admin-environment>div{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:49px;border-bottom:1px solid var(--next-admin-line);font-size:var(--next-admin-font-size-sm)}.next-admin-environment>div:last-child{border-bottom:0}.next-admin-environment span{color:var(--next-admin-muted)}.next-admin-environment strong{font-size:var(--next-admin-font-size-xs)}.next-admin-plugin-list{display:grid;grid-template-columns:1fr 1fr}.next-admin-plugin-list>div{display:grid;grid-template-columns:38px 1fr auto;align-items:center;gap:10px;min-height:70px;padding:10px 18px;border-right:1px solid var(--next-admin-line);border-bottom:1px solid var(--next-admin-line)}.next-admin-plugin-list>div:nth-child(2n){border-right:0}.next-admin-plugin-list>div>span:nth-child(2){display:grid;min-width:0}.next-admin-plugin-list strong,.next-admin-plugin-list small{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.next-admin-plugin-list strong{font-size:var(--next-admin-font-size-sm)}.next-admin-plugin-list small{color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs)}.next-admin-plugin-mark{display:grid;width:34px;height:34px;place-items:center;border-radius:6px;background:var(--next-admin-panel-alt);color:var(--next-admin-subtle)}.next-admin-plugin-mark.is-on{background:var(--next-admin-accent-soft);color:var(--next-admin-accent-dark)}.next-admin-plugin-mark.is-error{background:var(--next-admin-danger-soft);color:var(--next-admin-danger)}.next-admin-plugin-mark .next-admin-icon{width:16px}
.next-admin-editor{display:grid;gap:22px;padding:22px}.next-admin-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:17px}.next-admin-field{display:grid;gap:7px;min-width:0}.next-admin-field>span{display:grid;color:var(--next-admin-text);font-size:var(--next-admin-font-size-sm);font-weight:700}.next-admin-field>span small{color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs);font-weight:400}.next-admin-field input,.next-admin-field select,.next-admin-field textarea{width:100%;min-height:40px;padding:8px 11px;border:1px solid var(--next-admin-line-strong);border-radius:5px;outline:0;background:var(--next-admin-panel-alt);color:var(--next-admin-text);font:inherit;font-size:var(--next-admin-font-size-sm)}.next-admin-field textarea{resize:vertical}.next-admin-field input:focus,.next-admin-field select:focus,.next-admin-field textarea:focus{border-color:var(--next-admin-accent);box-shadow:0 0 0 3px var(--next-admin-accent-soft)}.next-admin-check-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.next-admin-check{display:flex;align-items:flex-start;gap:10px;padding:13px;border:1px solid var(--next-admin-line);border-radius:6px;background:var(--next-admin-panel-alt)}.next-admin-check input{margin-top:3px;accent-color:var(--next-admin-accent)}.next-admin-check span{display:grid}.next-admin-check strong{font-size:var(--next-admin-font-size-sm)}.next-admin-check small{color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}.next-admin-form-actions{display:flex;align-items:center;justify-content:flex-end;gap:12px;padding-top:18px;border-top:1px solid var(--next-admin-line)}.next-admin-form-actions>a{color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm)}.next-admin-form-actions>button{min-height:40px;padding:0 18px;border:0;border-radius:5px;background:var(--next-admin-command-bg);color:var(--next-admin-command-text);font:inherit;font-size:var(--next-admin-font-size-sm);font-weight:700;cursor:pointer}.next-admin-form-actions>button:hover{background:var(--next-admin-command-hover)}.next-admin-danger-zone{display:flex;align-items:center;justify-content:space-between;gap:20px;margin-top:18px;padding:17px 20px;border:1px solid var(--next-admin-danger-soft);border-radius:7px;background:var(--next-admin-panel)}.next-admin-danger-zone>div{display:grid}.next-admin-danger-zone strong{color:var(--next-admin-danger);font-size:var(--next-admin-font-size-sm)}.next-admin-danger-zone span{color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}
.next-admin-permission-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.next-admin-permission{margin:0;padding:14px;border:1px solid var(--next-admin-line);border-radius:6px}.next-admin-permission legend{padding:0 5px;font-size:var(--next-admin-font-size-sm);font-weight:700}.next-admin-permission p{margin:0 0 10px;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}.next-admin-permission>div{display:grid;gap:7px}.next-admin-mini-check{display:flex;align-items:center;gap:7px;font-size:var(--next-admin-font-size-sm)}.next-admin-mini-check input{accent-color:var(--next-admin-accent)}
.next-admin-setting-section{display:grid;gap:16px;padding-bottom:22px;border-bottom:1px solid var(--next-admin-line)}.next-admin-setting-section:last-of-type{border-bottom:0}.next-admin-setting-section h3{margin:0;font-family:Georgia,"Noto Serif SC",serif;font-size:var(--next-admin-font-size-lg)}.next-admin-tool-row{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:70px;padding:12px 18px;border-bottom:1px solid var(--next-admin-line)}.next-admin-tool-row:last-child{border-bottom:0}.next-admin-tool-row>div{display:grid}.next-admin-tool-row strong{font-size:var(--next-admin-font-size-sm)}.next-admin-tool-row span{color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}
.next-admin-plugin-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.next-admin-plugin-cards>article{display:grid;align-content:start;gap:13px;min-height:190px;padding:17px;border:1px solid var(--next-admin-line);border-radius:7px;background:var(--next-admin-panel);box-shadow:var(--next-admin-shadow)}.next-admin-plugin-card-head{display:grid;grid-template-columns:38px 1fr auto;align-items:center;gap:10px}.next-admin-plugin-card-head>span:nth-child(2){display:grid;min-width:0}.next-admin-plugin-card-head strong,.next-admin-plugin-card-head small{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.next-admin-plugin-card-head strong{font-size:var(--next-admin-font-size-sm)}.next-admin-plugin-card-head small{color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs)}.next-admin-plugin-cards p{margin:0;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm)}.next-admin-plugin-features{color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs)}.next-admin-plugin-error{padding:8px;border-radius:5px;background:var(--next-admin-danger-soft);color:var(--next-admin-danger);font-size:var(--next-admin-font-size-xs)}.next-admin-plugin-actions{display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin-top:auto;padding-top:11px;border-top:1px solid var(--next-admin-line)}.next-admin-plugin-more{position:relative}.next-admin-plugin-more summary{width:max-content;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs);font-weight:700;cursor:pointer}.next-admin-plugin-more>div{margin-top:9px;padding:9px;border-radius:5px;background:var(--next-admin-panel-alt)}.next-admin-uninstall-form{display:flex;align-items:center;justify-content:space-between;gap:12px}.next-admin-plugin-more label{display:flex;align-items:center;gap:7px;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-xs)}.next-admin-plugin-more input{accent-color:var(--next-admin-accent)}.next-admin-upload{display:flex;align-items:center;gap:6px}.next-admin-upload label{position:relative;overflow:hidden}.next-admin-upload input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer}.next-admin-log-message{display:block;overflow:hidden;max-width:360px;color:var(--next-admin-muted);text-overflow:ellipsis;white-space:nowrap}
.next-admin-toast{position:fixed;z-index:50;right:24px;bottom:24px;max-width:360px;padding:12px 16px;border:1px solid var(--next-admin-line);border-left:4px solid var(--next-admin-accent);border-radius:6px;background:var(--next-admin-panel);box-shadow:0 14px 35px rgba(0,0,0,.18);font-size:var(--next-admin-font-size-sm);animation:next-admin-toast-in .2s ease-out}.next-admin-toast.is-leaving{opacity:0;transform:translateY(8px);transition:opacity .2s,transform .2s}@keyframes next-admin-toast-in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.next-admin-empty{padding:45px 20px;color:var(--next-admin-muted);font-size:var(--next-admin-font-size-sm);text-align:center}.next-admin-sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.next-admin-overlay{display:none}
.next-admin-app.is-dark{--next-admin-bg:#111513;--next-admin-panel:#191e1b;--next-admin-panel-alt:#202622;--next-admin-text:#edf1ee;--next-admin-muted:#a2aaa5;--next-admin-subtle:#77807a;--next-admin-line:#2c342f;--next-admin-line-strong:#3a453e;--next-admin-accent-soft:#153a2b;--next-admin-danger-soft:#3a2020;--next-admin-warning-soft:#3c301d;--next-admin-cyan-soft:#17363d;--next-admin-command-bg:#edf1ee;--next-admin-command-hover:#fff;--next-admin-command-text:#171b19;--next-admin-shadow:0 10px 30px rgba(0,0,0,.16);color-scheme:dark}.next-admin-app.is-dark .next-admin-theme-sun{display:none}.next-admin-app.is-dark .next-admin-theme-moon{display:block}
@media(max-width:1100px){.next-admin-stats{grid-template-columns:1fr 1fr}.next-admin-grid-list{grid-template-columns:1fr}.next-admin-quick-grid{grid-template-columns:1fr 1fr}.next-admin-forum-grid{grid-template-columns:1fr 1fr}.next-admin-permission-grid{grid-template-columns:1fr}.next-admin-plugin-cards{grid-template-columns:1fr}}
@media(max-width:820px){.next-admin-sidebar{transform:translateX(-100%);transition:transform .22s}.next-admin-app.is-menu-open .next-admin-sidebar{transform:translateX(0)}.next-admin-brand button{display:grid}.next-admin-workspace{margin-left:0}.next-admin-menu-button{display:grid}.next-admin-overlay{position:fixed;inset:0;z-index:25;background:rgba(0,0,0,.45)}.next-admin-app.is-menu-open .next-admin-overlay{display:block}.next-admin-grid-main,.next-admin-grid-system{grid-template-columns:1fr}.next-admin-topbar{padding:0 18px}.next-admin-main{padding:28px 18px 44px}}
@media(max-width:600px){.next-admin-topbar{height:66px;gap:9px}.next-admin-global-search{width:auto;min-width:0;flex:1}.next-admin-global-search kbd,.next-admin-profile>span:last-child{display:none}.next-admin-top-actions{gap:8px}.next-admin-page-head{align-items:flex-start;flex-direction:column}.next-admin-head-actions{width:100%;flex-wrap:wrap}.next-admin-page-head h1{font-size:26px}.next-admin-stats{gap:10px}.next-admin-stat{min-height:126px;padding:14px}.next-admin-stat>strong{font-size:22px}.next-admin-quick-grid,.next-admin-forum-grid,.next-admin-system-tools,.next-admin-plugin-list,.next-admin-form-grid,.next-admin-check-grid{grid-template-columns:1fr}.next-admin-quick-grid>a,.next-admin-system-tools>a,.next-admin-plugin-list>div{border-right:0}.next-admin-system-tools>a:nth-last-child(2){border-bottom:1px solid var(--next-admin-line)}.next-admin-filter{align-items:stretch;flex-direction:column}.next-admin-filter label{width:100%;min-width:0}.next-admin-filter select{width:100%}.next-admin-bulk{align-items:stretch;flex-direction:column}.next-admin-bulk>label{margin-right:0}.next-admin-bulk select,.next-admin-bulk button{width:100%}.next-admin-pagination{align-items:flex-start;flex-direction:column}.next-admin-chart{height:240px;padding-inline:12px}.next-admin-bars{gap:6px}.next-admin-panel>header{padding:0 14px}.next-admin-table th,.next-admin-table td{padding-inline:12px}.next-admin-editor{padding:16px}.next-admin-danger-zone,.next-admin-tool-row{align-items:flex-start;flex-direction:column}.next-admin-toast{right:14px;bottom:14px;left:14px}}
.next-admin-filter-content{flex-wrap:wrap}.next-admin-filter-content label{min-width:220px}.next-admin-standalone-input{height:38px;min-width:120px;padding:0 10px;border:1px solid var(--next-admin-line);border-radius:5px;outline:0;background:var(--next-admin-panel-alt);color:var(--next-admin-text);font:inherit;font-size:var(--next-admin-font-size-sm)}.next-admin-standalone-input:focus{border-color:var(--next-admin-accent);box-shadow:0 0 0 3px var(--next-admin-accent-soft)}.next-admin-date-range{display:inline-flex;align-items:center;gap:6px;max-width:100%;flex:none;white-space:nowrap}.next-admin-date-range i{color:var(--next-admin-subtle);font-size:var(--next-admin-font-size-xs);font-style:normal}.next-admin-date-range .next-admin-standalone-input{width:clamp(105px,12vw,135px);min-width:0}
CSS;
}

function next_admin_js(): string
{
    return <<<'JS'
(function next_admin_init(){
    var root=document.querySelector('[data-next-admin-app]');
    if(!root)return;
    var key='next_admin_theme';
    var stored='';
    try{stored=localStorage.getItem(key)||'';}catch(e){}
    var dark=stored?stored==='dark':window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;
    root.classList.toggle('is-dark',dark);
    var menuButton=root.querySelector('[data-next-admin-open]');
    function next_admin_set_menu(open){root.classList.toggle('is-menu-open',open);if(menuButton)menuButton.setAttribute('aria-expanded',open?'true':'false');}
    if(menuButton)menuButton.addEventListener('click',function(){next_admin_set_menu(true);});
    root.querySelectorAll('[data-next-admin-close]').forEach(function(button){button.addEventListener('click',function(){next_admin_set_menu(false);});});
    var theme=root.querySelector('[data-next-admin-theme]');
    if(theme)theme.addEventListener('click',function(){var next=!root.classList.contains('is-dark');root.classList.toggle('is-dark',next);try{localStorage.setItem(key,next?'dark':'light');}catch(e){}});
    document.querySelectorAll('[data-next-admin-confirm]').forEach(function(form){form.addEventListener('submit',function(event){if(!window.confirm(form.getAttribute('data-next-admin-confirm')||'确定执行此操作？'))event.preventDefault();});});
    var selectAll=document.querySelector('[data-next-admin-select-all]');
    if(selectAll)selectAll.addEventListener('change',function(){document.querySelectorAll('input[name="ids[]"]').forEach(function(box){box.checked=selectAll.checked;});});
    var bulkAction=document.querySelector('[data-next-admin-bulk-action]');
    var bulkForum=document.querySelector('[data-next-admin-bulk-forum]');
    function next_admin_bulk_state(){if(bulkForum)bulkForum.hidden=!bulkAction||bulkAction.value!=='move';}
    if(bulkAction){bulkAction.addEventListener('change',next_admin_bulk_state);next_admin_bulk_state();}
    var toast=document.querySelector('[data-next-admin-toast]');
    if(toast)window.setTimeout(function(){toast.classList.add('is-leaving');window.setTimeout(function(){toast.remove();},220);},3200);
    document.addEventListener('keydown',function(event){
        if(event.key==='Escape')next_admin_set_menu(false);
        if(event.key==='/'&&!/input|textarea|select/i.test(document.activeElement.tagName)){event.preventDefault();var input=root.querySelector('.next-admin-global-search input');if(input)input.focus();}
    });
})();
JS;
}

return [
    'id' => 'next_admin',
    'name' => '全新管理后台',
    'version' => '1.5.0',
    'description' => '提供独立完整的管理工作台，可直接管理内容、用户、版块、用户组、站点设置与插件。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'next_admin_css', 'js' => 'next_admin_js'],
    'hooks' => ['admin.tabs' => 'next_admin_admin_tabs_hook'],
    'routes' => ['next_admin' => 'next_admin_page'],
    'install' => 'next_admin_install',
];