<?php
if (!defined('APP_ROOT')) exit;
return array (
  'driver' => 'sqlite',
  'database' => 'forum-b0b94c62481c23c9.sqlite',
  'db_file' => 'forum-b0b94c62481c23c9.sqlite',
);
