<?php
if (!defined('APP_ROOT')) exit;

function puppet_posting_username(string $text): string
{
    if (!can_manage()) return '';
    return preg_match('/@@([A-Za-z0-9_.\-\x{4e00}-\x{9fff}]{1,40})/u', $text, $match) ? (string)$match[1] : '';
}

function puppet_posting_strip_commands(string $text): string
{
    return trim(preg_replace('/@@[A-Za-z0-9_.\-\x{4e00}-\x{9fff}]{1,40}/u', '', $text) ?? $text);
}

function puppet_posting_user_id(string $username): int
{
    $user = one('SELECT id FROM app_users WHERE username=?', [$username]);
    if ($user) return (int)$user['id'];
    $password = bin2hex(random_bytes(16));
    q('INSERT INTO app_users(username,password,email,bio,avatar_style,avatar_seed,group_id,is_banned,is_muted,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)', [
        $username,
        password_hash($password, PASSWORD_DEFAULT),
        $username . '@local',
        '',
        '',
        '',
        (int)setting('default_group_id', '2'),
        0,
        0,
        now(),
    ]);
    return app_db_last_insert_id('app_users');
}

function puppet_posting_topic_author($value, array $ctx): array
{
    $data = is_array($value) ? $value : [];
    $title = (string)($data['title'] ?? '');
    $body = (string)($data['body'] ?? '');
    $username = puppet_posting_username($body);
    if ($username === '') $username = puppet_posting_username($title);
    if ($username === '') return $data;
    $data['user_id'] = puppet_posting_user_id($username);
    $data['title'] = puppet_posting_strip_commands($title);
    $data['body'] = puppet_posting_strip_commands($body);
    return $data;
}

function puppet_posting_reply_author($value, array $ctx): array
{
    $data = is_array($value) ? $value : [];
    $body = (string)($data['body'] ?? '');
    $username = puppet_posting_username($body);
    if ($username === '') return $data;
    $data['user_id'] = puppet_posting_user_id($username);
    $data['body'] = puppet_posting_strip_commands($body);
    return $data;
}

function puppet_posting_admin_page(array $plugin): string
{
    need_admin();
    $head = '<div class="admin-plugin-summary"><strong>马甲发帖</strong><span>使用指定用户名发布主题或回帖</span></div>';
    $guide = '<div class="post-content">'
        . '<h3>谁可以使用</h3><p>管理员和拥有内容管理权限的用户可以使用。普通用户输入相同内容时不会切换发布身份。</p>'
        . '<h3>发布主题</h3><p>在主题标题或正文中加入两个 @ 和用户名。发布后，这段指令会自动消失，主题作者显示为指定用户。</p>'
        . '<pre><code>@@站务助手&#10;欢迎来到社区，请先阅读版规。</code></pre>'
        . '<h3>发布回帖</h3><p>在回帖正文中使用相同写法，回帖会以指定用户身份发布。</p>'
        . '<pre><code>@@活动助手&#10;本次活动报名成功。</code></pre>'
        . '<h3>账号如何处理</h3><p>用户名已经存在时，内容会归到该用户；用户名不存在时，会自动创建一个用于内容署名的站内用户。</p>'
        . '<h3>使用注意</h3><p>每次发布只填写一个马甲用户名。用户名可使用中文、字母、数字、点、横线和下划线，最长 40 个字符。普通的单个 @ 提及不受影响。</p>'
        . '<p><strong>请仅在获得授权或运营官方角色账号时使用已有用户名，避免让用户误以为内容由本人发布。</strong></p>'
        . '</div>';
    return '<section class="admin-list-panel plugin-manage-panel">' . admin_list_head($head, '') . '<div class="plugin-panel-body">' . $guide . '</div></section>';
}

return [
    'id' => 'puppet_posting',
    'name' => '马甲发帖',
    'version' => '1.1.0',
    'description' => '使用指定用户名发布主题或回帖，方便运营不同的社区角色。',
    'author' => 'bbs1org',
    'hooks' => [
        'topic.create_author' => 'puppet_posting_topic_author',
        'reply.create_author' => 'puppet_posting_reply_author',
    ],
    'admin_tabs' => ['puppet_posting' => 'puppet_posting_admin_page'],
];