<?php
if (!defined('APP_ROOT')) exit;

function daily_checkin_install(array $plugin): void
{
    daily_checkin_schema();
}

function daily_checkin_uninstall(array $plugin): void
{
    app_db_drop_table('plugin_daily_checkins');
}

function daily_checkin_schema(): void
{
    static $ready = false;
    if ($ready) return;
    $t = app_db_types();
    app_db_create_table('plugin_daily_checkins', "user_id {$t['uint']} NOT NULL,checkin_date {$t['key']} NOT NULL,streak {$t['uint']} NOT NULL DEFAULT 1,created_at {$t['uint']} NOT NULL,PRIMARY KEY(user_id,checkin_date)");
    app_db_create_index('idx_plugin_daily_checkins_date', 'plugin_daily_checkins(checkin_date,created_at DESC)');
    app_db_create_index('idx_plugin_daily_checkins_user_time', 'plugin_daily_checkins(user_id,created_at DESC)');
    $ready = true;
}

function daily_checkin_today(): string
{
    return date('Y-m-d');
}

function daily_checkin_yesterday(): string
{
    return date('Y-m-d', strtotime('-1 day'));
}

function daily_checkin_row(int $uid, string $date): ?array
{
    return one("SELECT streak,checkin_date FROM plugin_daily_checkins WHERE user_id=? AND checkin_date=?", [$uid, $date]);
}

function daily_checkin_stats_cookie_name(): string
{
    return '__daily_checkin_stats';
}

function daily_checkin_stats_cookie(int $uid, string $today): ?array
{
    $raw = (string)($_COOKIE[daily_checkin_stats_cookie_name()] ?? '');
    if (!preg_match('/^(\d+)\.(\d{4}-\d{2}-\d{2})\.([01])\.(\d+)\.(\d+)$/D', $raw, $match)) return null;
    if ((int)$match[1] !== $uid || $match[2] !== $today) return null;
    return [
        'signed_today' => $match[3] === '1',
        'streak' => (int)$match[4],
        'total' => (int)$match[5],
        'today' => $today,
        'cached_at' => now(),
    ];
}

function daily_checkin_stats_cookie_write(int $uid, array $stats): void
{
    $value = implode('.', [
        $uid,
        (string)$stats['today'],
        !empty($stats['signed_today']) ? 1 : 0,
        (int)$stats['streak'],
        (int)$stats['total'],
    ]);
    $name = daily_checkin_stats_cookie_name();
    setcookie($name, $value, ['expires' => time() + COOKIE_TTL, 'path' => '/', 'secure' => auth_cookie_secure(), 'httponly' => true, 'samesite' => 'Lax']);
    $_COOKIE[$name] = $value;
}

function daily_checkin_user_stats(int $uid, bool $refresh = false): array
{
    static $cache = [];
    $today = daily_checkin_today();
    if (!$refresh && isset($cache[$uid])) return $cache[$uid];
    if (!$refresh && ($stats = daily_checkin_stats_cookie($uid, $today)) !== null) return $cache[$uid] = $stats;
    $row = one("SELECT streak,checkin_date FROM plugin_daily_checkins WHERE user_id=? ORDER BY checkin_date DESC LIMIT 1", [$uid]);
    $total = (int)val("SELECT COUNT(*) FROM plugin_daily_checkins WHERE user_id=?", [$uid]);
    $stats = [
        'signed_today' => (string)($row['checkin_date'] ?? '') === $today,
        'streak' => (int)($row['streak'] ?? 0),
        'total' => $total,
        'today' => $today,
        'cached_at' => now(),
    ];
    daily_checkin_stats_cookie_write($uid, $stats);
    return $cache[$uid] = $stats;
}

function daily_checkin_config(): array
{
    return plugin_config('daily_checkin', [
        'card_title' => '每日签到',
        'button_label' => '签到',
        'done_label' => '已完成',
        'show_stats' => '1',
        'reward_mode' => 'fixed',
        'reward_points' => '1',
        'reward_min' => '1',
        'reward_max' => '5',
    ]);
}

function daily_checkin_reward_points(array $config): int
{
    if ((string)($config['reward_mode'] ?? 'fixed') === 'random') {
        $min = max(0, (int)($config['reward_min'] ?? 1));
        $max = max($min, (int)($config['reward_max'] ?? $min));
        return random_int($min, $max);
    }
    return max(0, (int)($config['reward_points'] ?? 1));
}

function daily_checkin_css(): string
{
    return '
.daily-checkin-wrap{display:grid;gap:10px;padding:12px 14px}
.daily-checkin-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
.daily-checkin-title{color:var(--text);font-size:13px;font-weight:700;line-height:1.35}
.daily-checkin-sub{margin-top:2px;color:var(--text-subtle);font-size:11px;line-height:1.35}
.daily-checkin-badge{display:inline-flex;align-items:center;justify-content:center;min-height:22px;padding:0 8px;border:1px solid var(--warning-soft);border-radius:999px;background:var(--warning-soft);color:var(--warning);font-size:11px;font-weight:600;white-space:nowrap}
.daily-checkin-badge.done{border-color:var(--brand-soft);background:var(--brand-soft);color:var(--brand)}
.daily-checkin-stats{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.daily-checkin-stats>div{display:grid;gap:2px;padding:8px;border:1px solid var(--line-soft);border-radius:7px;background:var(--bg);text-align:center}
.daily-checkin-stats strong{color:var(--text);font-size:17px;line-height:1.1}
.daily-checkin-stats span{color:var(--text-subtle);font-size:11px;line-height:1.25}
.daily-checkin-action{display:block}
.daily-checkin-action .post-action-form{display:block!important;width:100%!important}
.daily-checkin-action button,.daily-checkin-done{display:flex;align-items:center;justify-content:center;width:100%;min-height:32px;padding:0 10px;border-radius:7px;font-size:12px;font-weight:700}
.daily-checkin-action button{border:1px solid var(--brand);background:var(--brand);color:var(--inverse-text)}
.daily-checkin-action button:hover{border-color:var(--brand-hover);background:var(--brand-hover);color:var(--inverse-text)}
.daily-checkin-done{border:1px solid var(--brand-soft);background:var(--brand-soft);color:var(--brand)}
.daily-checkin-page-panel .admin-list-head{padding:14px 16px}
.daily-checkin-page-body{display:grid;gap:16px;padding:16px}
.daily-checkin-page-stats{gap:12px}
.daily-checkin-page-stats>div{padding:16px 12px}
.daily-checkin-page-stats strong{font-size:24px}
.daily-checkin-page-stats span{font-size:12px}
.daily-checkin-page-action button,.daily-checkin-page-action .daily-checkin-done{min-height:42px;font-size:14px}
.admin-object-row.daily-checkin-row{grid-template-columns:minmax(0,1fr)}
@media (max-width:760px){.admin-object-row.daily-checkin-row{grid-template-columns:minmax(0,1fr)}}
';
}

function daily_checkin_card_html(array $config, array $stats): string
{
    $signed = !empty($stats['signed_today']);
    $status = $signed ? '已签到' : '待签到';
    $button = $signed
        ? '<div class="daily-checkin-done">' . h((string)$config['done_label']) . '</div>'
        : '<form class="post-action-form" method="post" action="' . h(route_url('daily_checkin')) . '" data-replace-target=".daily-checkin-card">' . form_token() . '<input type="hidden" name="source" value="sidebar"><button type="submit" class="daily-checkin-btn">' . h((string)$config['button_label']) . '</button></form>';
    $stats_html = (string)$config['show_stats'] === '1' ? '<div class="daily-checkin-stats"><div><strong>' . (int)$stats['streak'] . '</strong><span>连续天数</span></div><div><strong>' . (int)$stats['total'] . '</strong><span>累计签到</span></div></div>' : '';
    return '<div class="card sidebar-card daily-checkin-card"><div class="daily-checkin-wrap"><div class="daily-checkin-head"><div><div class="daily-checkin-title">' . h((string)$config['card_title']) . '</div><div class="daily-checkin-sub">今天' . h($status) . '</div></div><span class="daily-checkin-badge' . ($signed ? ' done' : '') . '">' . h($status) . '</span></div>' . $stats_html . '<div class="daily-checkin-action">' . $button . '</div></div></div>';
}

function daily_checkin_sidebar($parts, array $ctx): array
{
    $parts = is_array($parts) ? $parts : [];
    if (empty($ctx['is_home_first_page'])) return $parts;
    if (!uid()) return $parts;
    $config = daily_checkin_config();
    $stats = daily_checkin_user_stats(uid());
    array_splice($parts, 1, 0, [daily_checkin_card_html($config, $stats)]);
    return $parts;
}

function daily_checkin_feature_links($links, array $ctx): array
{
    $links = is_array($links) ? $links : [];
    if (!uid()) return $links;
    $links[] = ['text' => '每日签到', 'url' => route_url('daily_checkin'), 'badge_dot' => !daily_checkin_user_stats(uid())['signed_today']];
    return $links;
}

function daily_checkin_page(array $plugin): void
{
    need_login();
    $uid = uid();
    $today = daily_checkin_today();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        $config = daily_checkin_config();
        $stats = daily_checkin_user_stats($uid);
        $signed = !empty($stats['signed_today']);
        $action = $signed
            ? '<div class="daily-checkin-done">' . h((string)$config['done_label']) . '</div>'
            : post_action_form(route_url('daily_checkin'), (string)$config['button_label'], [], 'daily-checkin-btn');
        $html = '<div class="admin-list-panel plugin-manage-panel daily-checkin-page-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>' . h((string)$config['card_title']) . '</strong><span>今天' . h($signed ? '已签到' : '待签到') . '</span></div>', '') . '<div class="plugin-panel-body daily-checkin-page-body"><div class="daily-checkin-stats daily-checkin-page-stats"><div><strong>' . (int)$stats['streak'] . '</strong><span>连续天数</span></div><div><strong>' . (int)$stats['total'] . '</strong><span>累计签到</span></div></div><div class="daily-checkin-action daily-checkin-page-action">' . $action . '</div></div></div>';
        page('每日签到', shell_html($html, sidebar_stack_html([sidebar_user_card_html()])));
        return;
    }
    $sidebar_ajax = ajax_request() && post('source', 20) === 'sidebar';
    if (daily_checkin_row($uid, $today)) {
        $stats = daily_checkin_user_stats($uid, true);
        if ($sidebar_ajax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => 1, 'message' => '今日已经签到', 'html' => daily_checkin_card_html(daily_checkin_config(), $stats)], JSON_UNESCAPED_UNICODE);
            exit;
        }
        set_flash('今日已经签到');
        go(route_url('daily_checkin'));
    }
    $yesterday = daily_checkin_row($uid, daily_checkin_yesterday());
    $streak = $yesterday ? (int)$yesterday['streak'] + 1 : 1;
    $reward = daily_checkin_reward_points(daily_checkin_config());
    q("INSERT INTO plugin_daily_checkins(user_id,checkin_date,streak,created_at) VALUES(?,?,?,?)", [$uid, $today, $streak, now()]);
    if ($reward > 0) user_points_change($uid, $reward, '每日签到');
    $message = '签到成功，连续 ' . $streak . ' 天' . ($reward > 0 ? '，获得 ' . $reward . ' 积分' : '');
    $stats = daily_checkin_user_stats($uid, true);
    if ($sidebar_ajax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => 1, 'message' => $message, 'html' => daily_checkin_card_html(daily_checkin_config(), $stats)], JSON_UNESCAPED_UNICODE);
        exit;
    }
    set_flash($message);
    go(route_url('daily_checkin'));
}

function daily_checkin_admin_page(array $plugin): string
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $reward_min = max(0, (int)($_POST['reward_min'] ?? 1));
        $reward_max = max($reward_min, (int)($_POST['reward_max'] ?? 5));
        plugin_save_config('daily_checkin', [
            'card_title' => post('card_title', 40) ?: '每日签到',
            'button_label' => post('button_label', 20) ?: '签到',
            'done_label' => post('done_label', 20) ?: '已完成',
            'show_stats' => isset($_POST['show_stats']) ? '1' : '0',
            'reward_mode' => in_array((string)($_POST['reward_mode'] ?? 'fixed'), ['fixed', 'random'], true) ? (string)$_POST['reward_mode'] : 'fixed',
            'reward_points' => (string)max(0, (int)($_POST['reward_points'] ?? 1)),
            'reward_min' => (string)$reward_min,
            'reward_max' => (string)$reward_max,
        ]);
        set_flash('插件设置已保存');
        go(admin_url(['tab' => 'daily_checkin']));
    }
    $config = daily_checkin_config();
    $today = daily_checkin_today();
    $counts = one("SELECT COALESCE(SUM(CASE WHEN checkin_date=? THEN 1 ELSE 0 END),0) today_count,COUNT(*) total_count,COUNT(DISTINCT user_id) user_count FROM plugin_daily_checkins", [$today]) ?: [];
    $today_count = (int)($counts['today_count'] ?? 0);
    $total_count = (int)($counts['total_count'] ?? 0);
    $user_count = (int)($counts['user_count'] ?? 0);
    $rows = attach_users(q("SELECT user_id,checkin_date,streak,created_at FROM plugin_daily_checkins ORDER BY created_at DESC LIMIT 30")->fetchAll());
    $settings_head = '<div class="admin-plugin-summary"><strong>每日签到设置</strong><span>配置侧边栏签到卡片的显示内容</span></div>';
    $reward_select = '<label class="grid"><span>积分奖励方式</span><select name="reward_mode"><option value="fixed"' . ((string)$config['reward_mode'] === 'fixed' ? ' selected' : '') . '>固定积分</option><option value="random"' . ((string)$config['reward_mode'] === 'random' ? ' selected' : '') . '>范围随机</option></select></label>';
    $settings_form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'daily_checkin'])) . '">' . form_token() . input('卡片标题', 'card_title', $config['card_title'], 'text', true) . input('签到按钮文字', 'button_label', $config['button_label'], 'text', true) . input('已签到文字', 'done_label', $config['done_label'], 'text', true) . '<label class="grid"><span>显示签到统计</span><input type="checkbox" name="show_stats" value="1"' . ((string)$config['show_stats'] === '1' ? ' checked' : '') . '></label>' . $reward_select . input('固定奖励积分', 'reward_points', (int)$config['reward_points'], 'number', true) . input('随机最小积分', 'reward_min', (int)$config['reward_min'], 'number', true) . input('随机最大积分', 'reward_max', (int)$config['reward_max'], 'number', true) . '<button>保存设置</button></form>';
    $html = '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head($settings_head, '') . '<div class="plugin-panel-body">' . $settings_form . '</div></div>';
    $record_head = '<div class="admin-plugin-summary"><strong>签到记录</strong><span>今日签到 ' . $today_count . ' 次，累计签到 ' . $total_count . ' 次，参与用户 ' . $user_count . ' 人</span></div>';
    $html .= '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head($record_head, '') . '<ul class="admin-manage-list">';
    foreach ($rows as $row) {
        $html .= '<li class="admin-list-item admin-object-row daily-checkin-row"><div class="admin-row-main"><div class="admin-user-cell">' . avatar_tag((int)$row['user_id'], (string)$row['username'], (string)($row['avatar_style'] ?? ''), 'table-avatar', (string)($row['avatar_seed'] ?? '')) . '<div class="admin-user-text"><strong>' . h($row['username']) . '</strong><span>' . h((string)$row['checkin_date']) . ' / 连续 ' . (int)$row['streak'] . ' 天 / ' . date('Y-m-d H:i', (int)$row['created_at']) . '</span></div></div></div></li>';
    }
    if (!$rows) $html .= '<li class="empty-state">暂无签到记录</li>';
    return $html . '</ul></div>';
}

return [
    'id' => 'daily_checkin',
    'name' => '每日签到',
    'version' => '1.0.6',
    'description' => '让用户每天签到并累计连续签到天数，管理员可查看签到情况。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'daily_checkin_css'],
    'hooks' => [
        'sidebar.feature_links' => 'daily_checkin_feature_links',
        'sidebar.stack' => 'daily_checkin_sidebar',
    ],
    'routes' => [
        'daily_checkin' => 'daily_checkin_page',
    ],
    'admin_tabs' => [
        'daily_checkin' => 'daily_checkin_admin_page',
    ],
    'install' => 'daily_checkin_install',
    'uninstall' => 'daily_checkin_uninstall',
];