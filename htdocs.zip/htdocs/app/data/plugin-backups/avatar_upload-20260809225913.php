<?php
if (!defined('APP_ROOT')) exit;

const AVATAR_UPLOAD_SIZE = 200;
const AVATAR_UPLOAD_MAX_BYTES = 1048576;

function avatar_upload_style(): string
{
    $style = avatar_style(setting('avatar_upload_style', 'dylan'));
    return $style !== '' ? $style : 'dylan';
}

function avatar_upload_relative_file(int $uid): string
{
    $hash = hash('sha256', 'avatar-upload:' . max(1, $uid));
    return 'avatar_upload/' . upload_hash_dir($hash) . '/' . max(1, $uid) . '.jpg';
}

function avatar_upload_file(int $uid): string
{
    return UPLOAD_DIR . '/' . avatar_upload_relative_file($uid);
}

function avatar_upload_url(int $uid): string
{
    $file = avatar_upload_file($uid);
    return asset_url('app/upload/' . avatar_upload_relative_file($uid)) . '?v=' . (is_file($file) ? (string)filemtime($file) : '0');
}

function avatar_upload_avatar_url($url, array $ctx): string
{
    $uid = (int)($ctx['uid'] ?? 0);
    return $uid > 0 && is_file(avatar_upload_file($uid)) ? avatar_upload_url($uid) : (string)$url;
}

function avatar_upload_picker($picker, array $ctx): array
{
    $picker = is_array($picker) ? $picker : [];
    $style = avatar_upload_style();
    $picker['style'] = $style;
    $picker['styles'] = [$style => avatar_styles()[$style]];
    $picker['local_only'] = false;
    $picker['base_url'] = '';
    return $picker;
}

function avatar_upload_user_before_save($user, array $ctx): array
{
    if (!is_array($user)) return [];
    $user['avatar_style'] = avatar_upload_style();
    return $user;
}

function avatar_upload_json(array $data): never
{
    json_response($data);
}

function avatar_upload_route(array $plugin): void
{
    need_login();
    require_post();
    $uid = uid();
    $action = (string)($_POST['avatar_upload_action'] ?? 'upload');
    $file = avatar_upload_file($uid);
    if ($action === 'delete') {
        if (is_file($file) && !@unlink($file)) err('头像删除失败');
        avatar_upload_json(['ok' => true, 'message' => '已恢复预置头像', 'redirect' => route_url('profile')]);
    }
    if ($action === 'preset') {
        $style = avatar_upload_style();
        $seed = avatar_seed($style, (string)($_POST['avatar_seed'] ?? ''), $uid);
        if (is_file($file) && !@unlink($file)) err('头像切换失败');
        q('UPDATE app_users SET avatar_style=?,avatar_seed=? WHERE id=?', [$style, $seed, $uid]);
        fire('user.after_save', ['id' => $uid, 'admin' => false, 'creating' => false]);
        avatar_upload_json(['ok' => true, 'message' => '已切换预置头像', 'redirect' => route_url('profile')]);
    }
    $upload = (array)($_FILES['avatar'] ?? []);
    if ((int)($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) err('请选择头像图片');
    $tmp = (string)($upload['tmp_name'] ?? '');
    $bytes = (int)($upload['size'] ?? 0);
    if ($tmp === '' || !is_uploaded_file($tmp) || $bytes < 1 || $bytes > AVATAR_UPLOAD_MAX_BYTES) err('裁切后的头像不能超过 1MB');
    $info = @getimagesize($tmp);
    if (!is_array($info) || (int)($info[0] ?? 0) !== AVATAR_UPLOAD_SIZE || (int)($info[1] ?? 0) !== AVATAR_UPLOAD_SIZE || (string)($info['mime'] ?? '') !== 'image/jpeg') {
        err('头像格式无效，请重新裁切');
    }
    $dir = dirname($file);
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) err('头像目录创建失败');
    require_writable_dir($dir, '头像目录不可写');
    $target = $file . '.tmp.' . bin2hex(random_bytes(4));
    if (!move_uploaded_file($tmp, $target)) err('头像保存失败');
    @chmod($target, 0644);
    if (!rename($target, $file)) {
        @unlink($target);
        err('头像保存失败');
    }
    avatar_upload_json(['ok' => true, 'message' => '头像已更新', 'url' => avatar_upload_url($uid), 'redirect' => route_url('profile')]);
}

function avatar_upload_profile_html($html, array $ctx): string
{
    $user = is_array($ctx['user'] ?? null) ? $ctx['user'] : [];
    $uid = (int)($user['id'] ?? 0);
    if ($uid < 1 || $uid !== uid()) return (string)$html;
    $has_upload = is_file(avatar_upload_file($uid));
    $style = avatar_upload_style();
    $seed = avatar_seed($style, (string)($user['avatar_seed'] ?? ''), $uid);
    $current = avatar_tag($uid, (string)($user['username'] ?? ''), $style, '', $seed);
    $presets = '<div class="avatar-options avatar-upload-preset-options" data-avatar-preset-options hidden>';
    foreach (range(1, avatar_seed_count($style)) as $preset_seed) {
        $preset_seed = (string)$preset_seed;
        $presets .= '<button class="avatar-option' . (!$has_upload && $preset_seed === $seed ? ' active' : '') . '" type="button" data-avatar-preset-seed="' . h($preset_seed) . '"><img class="avatar-img" src="' . h(avatar_remote_url($style, $preset_seed)) . '" alt="预置头像" loading="lazy"></button>';
    }
    $presets .= '</div>';
    return (string)$html . '<section class="avatar-upload-panel profile-disclosure" data-avatar-upload data-upload-url="' . h(route_url('avatar_upload')) . '"><div class="avatar-upload-row"><span class="avatar-upload-current">' . $current . '</span><div><strong>头像</strong><p>上传图片可拖动和缩放裁切，也可以选择统一的预置头像。</p><div class="avatar-upload-actions"><label class="btn avatar-upload-select">上传头像<input type="file" accept="image/jpeg,image/png,image/webp" data-avatar-upload-input hidden></label><button type="button" class="btn alt" data-avatar-preset-toggle>选择预置头像</button></div></div></div>' . $presets . form_token() . '<div class="avatar-upload-status" data-avatar-upload-status></div></section><div class="modal-backdrop avatar-crop-modal" data-avatar-crop-modal hidden><div class="modal-panel avatar-crop-dialog"><div class="modal-head"><strong>裁切头像</strong><button type="button" class="modal-close" data-avatar-crop-close aria-label="关闭">×</button></div><div class="modal-body"><canvas width="280" height="280" data-avatar-crop-canvas></canvas><label class="avatar-crop-zoom"><span>缩放</span><input type="range" min="100" max="300" value="100" data-avatar-crop-zoom></label><div class="confirm-actions"><button type="button" class="btn alt" data-avatar-crop-close>取消</button><button type="button" data-avatar-crop-save>保存头像</button></div></div></div></div>';
}

function avatar_upload_admin_page(array $plugin): string
{
    need_admin();
    if (is_post_request()) {
        $style = avatar_style((string)($_POST['avatar_upload_style'] ?? ''));
        if ($style === '') err('请选择预置头像风格');
        save_settings_values(['avatar_upload_style' => $style]);
        set_flash('头像设置已保存');
        go(admin_url(['tab' => 'avatar_upload']));
    }
    $options = '';
    $selected = avatar_upload_style();
    foreach (avatar_styles() as $style => $label) {
        $options .= '<option value="' . h($style) . '"' . ($style === $selected ? ' selected' : '') . '>' . h($label) . '</option>';
    }
    $form = '<form method="post" action="' . h(admin_url(['tab' => 'avatar_upload'])) . '">' . form_token() . '<label class="grid"><span>用户预置头像风格<small>个人资料中只显示这一组预置头像，已上传的本地头像不受影响。</small></span><select name="avatar_upload_style">' . $options . '</select></label><button type="submit">保存设置</button></form>';
    return '<section class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>本地头像</strong><span>设置用户可选的统一预置头像风格</span></div>', '') . '<div class="plugin-panel-body">' . $form . '</div></section>';
}

function avatar_upload_css(): string
{
    return '.avatar-upload-panel{min-width:0}.avatar-upload-row{display:grid;grid-template-columns:72px minmax(0,1fr);gap:12px;align-items:center}.avatar-upload-current{display:flex;width:72px;height:72px;overflow:hidden;border:1px solid var(--line);border-radius:50%;background:var(--bg)}.avatar-upload-row strong{display:block;margin-bottom:3px}.avatar-upload-row p{margin:0 0 10px;color:var(--text-muted)}.avatar-upload-actions{display:flex;flex-wrap:wrap;gap:8px}.avatar-upload-select{width:auto}.avatar-upload-status{min-height:0;margin-top:8px;color:var(--text-muted)}.avatar-upload-status:empty{display:none}.avatar-upload-status.error{color:var(--danger)}.avatar-upload-preset-options[hidden]{display:none!important}.avatar-upload-preset-options{margin-top:10px;padding-top:10px;border-top:1px solid var(--line-soft)}.avatar-crop-modal{z-index:1200}.avatar-crop-dialog{width:min(360px,calc(100vw - 24px))}.avatar-crop-dialog canvas{display:block;width:min(280px,100%);height:auto;margin:0 auto;border-radius:var(--radius);background:var(--bg);cursor:grab;touch-action:none}.avatar-crop-dialog canvas.dragging{cursor:grabbing}.avatar-crop-zoom{display:grid;grid-template-columns:42px minmax(0,1fr);gap:10px;align-items:center;margin-top:14px}.avatar-crop-zoom input{padding:0}.avatar-field{display:none!important}@media(max-width:600px){.avatar-upload-row{grid-template-columns:56px minmax(0,1fr)}.avatar-upload-current{width:56px;height:56px}}';
}

function avatar_upload_js(): string
{
    return <<<'JS'
(() => {
    const panel = document.querySelector('[data-avatar-upload]');
    if (!panel) return;
    const input = panel.querySelector('[data-avatar-upload-input]');
    const status = panel.querySelector('[data-avatar-upload-status]');
    const modal = document.querySelector('[data-avatar-crop-modal]');
    const canvas = modal?.querySelector('[data-avatar-crop-canvas]');
    const zoom = modal?.querySelector('[data-avatar-crop-zoom]');
    const save = modal?.querySelector('[data-avatar-crop-save]');
    const csrf = panel.querySelector('input[name=_csrf]')?.value || '';
    const ctx = canvas?.getContext('2d');
    const avatarField = document.querySelector('.avatar-field');
    if (avatarField) avatarField.before(panel);
    const presets = panel.querySelector('[data-avatar-preset-options]');
    let image = null, objectUrl = '', scale = 1, minScale = 1, x = 0, y = 0, dragging = false, px = 0, py = 0;
    const setStatus = (text, error = false) => {
        if (!status) return;
        status.textContent = text || '';
        status.classList.toggle('error', error);
    };
    const clamp = () => {
        if (!image || !canvas) return;
        x = Math.min(0, Math.max(canvas.width - image.naturalWidth * scale, x));
        y = Math.min(0, Math.max(canvas.height - image.naturalHeight * scale, y));
    };
    const draw = () => {
        if (!ctx || !canvas || !image) return;
        clamp();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(image, x, y, image.naturalWidth * scale, image.naturalHeight * scale);
    };
    const close = () => {
        if (modal) modal.hidden = true;
        if (input) input.value = '';
        if (objectUrl) URL.revokeObjectURL(objectUrl);
        objectUrl = '';
        image = null;
    };
    input?.addEventListener('change', () => {
        const file = input.files?.[0];
        if (!file || !file.type.startsWith('image/')) return setStatus('请选择图片文件', true);
        if (file.size > 10 * 1024 * 1024) return setStatus('原图不能超过 10MB', true);
        objectUrl = URL.createObjectURL(file);
        const next = new Image();
        next.onload = () => {
            image = next;
            minScale = Math.max(canvas.width / image.naturalWidth, canvas.height / image.naturalHeight);
            scale = minScale;
            x = (canvas.width - image.naturalWidth * scale) / 2;
            y = (canvas.height - image.naturalHeight * scale) / 2;
            zoom.value = '100';
            draw();
            modal.hidden = false;
        };
        next.onerror = () => { close(); setStatus('图片读取失败', true); };
        next.src = objectUrl;
    });
    zoom?.addEventListener('input', () => {
        if (!image) return;
        const old = scale;
        scale = minScale * Number(zoom.value || 100) / 100;
        const cx = canvas.width / 2, cy = canvas.height / 2;
        x = cx - (cx - x) * scale / old;
        y = cy - (cy - y) * scale / old;
        draw();
    });
    canvas?.addEventListener('pointerdown', e => {
        if (!image) return;
        dragging = true; px = e.clientX; py = e.clientY;
        canvas.classList.add('dragging'); canvas.setPointerCapture(e.pointerId);
    });
    canvas?.addEventListener('pointermove', e => {
        if (!dragging) return;
        const ratio = canvas.width / canvas.getBoundingClientRect().width;
        x += (e.clientX - px) * ratio; y += (e.clientY - py) * ratio;
        px = e.clientX; py = e.clientY; draw();
    });
    const stopDrag = () => { dragging = false; canvas?.classList.remove('dragging'); };
    canvas?.addEventListener('pointerup', stopDrag);
    canvas?.addEventListener('pointercancel', stopDrag);
    modal?.querySelectorAll('[data-avatar-crop-close]').forEach(button => button.addEventListener('click', close));
    save?.addEventListener('click', () => {
        if (!image) return;
        const output = document.createElement('canvas');
        output.width = output.height = 200;
        const out = output.getContext('2d');
        out.fillStyle = '#fff'; out.fillRect(0, 0, 200, 200);
        out.drawImage(image, -x / scale, -y / scale, canvas.width / scale, canvas.height / scale, 0, 0, 200, 200);
        save.disabled = true;
        output.toBlob(async blob => {
            try {
                if (!blob) throw new Error('头像生成失败');
                const body = new FormData();
                body.append('_csrf', csrf); body.append('avatar_upload_action', 'upload'); body.append('avatar', blob, 'avatar.jpg');
                const response = await fetch(panel.dataset.uploadUrl, {method: 'POST', body, headers: {'X-Requested-With': 'XMLHttpRequest'}});
                const data = await response.json();
                if (!data.ok) throw new Error(data.message || '头像上传失败');
                window.location.href = data.redirect || window.location.href;
            } catch (error) {
                setStatus(error?.message || '头像上传失败', true); close();
            } finally { save.disabled = false; }
        }, 'image/jpeg', .9);
    });
    panel.querySelector('[data-avatar-preset-toggle]')?.addEventListener('click', button => {
        if (!presets) return;
        presets.hidden = !presets.hidden;
        button.textContent = presets.hidden ? '选择预置头像' : '收起预置头像';
    });
    presets?.querySelectorAll('[data-avatar-preset-seed]').forEach(option => option.addEventListener('click', async () => {
        presets.querySelectorAll('[data-avatar-preset-seed]').forEach(button => button.disabled = true);
        setStatus('正在切换头像');
        try {
            const body = new FormData();
            body.append('_csrf', csrf);
            body.append('avatar_upload_action', 'preset');
            body.append('avatar_seed', option.dataset.avatarPresetSeed || '1');
            const response = await fetch(panel.dataset.uploadUrl, {method: 'POST', body, headers: {'X-Requested-With': 'XMLHttpRequest'}});
            const data = await response.json();
            if (!data.ok) throw new Error(data.message || '头像切换失败');
            window.location.href = data.redirect || window.location.href;
        } catch (error) {
            setStatus(error?.message || '头像切换失败', true);
            presets.querySelectorAll('[data-avatar-preset-seed]').forEach(button => button.disabled = false);
        }
    }));
})();
JS;
}

return [
    'id' => 'avatar_upload',
    'name' => '本地头像',
    'version' => '1.1.2',
    'description' => '允许用户上传并裁切自己的头像，同时统一用户可选的预置头像风格。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'avatar_upload_css', 'js' => 'avatar_upload_js'],
    'hooks' => [
        'avatar.url' => 'avatar_upload_avatar_url',
        'avatar.picker' => 'avatar_upload_picker',
        'user.before_save' => 'avatar_upload_user_before_save',
        'profile.after_form' => 'avatar_upload_profile_html',
    ],
    'routes' => ['avatar_upload' => 'avatar_upload_route'],
    'admin_tabs' => ['avatar_upload' => 'avatar_upload_admin_page'],
];
