<?php

function coc_style_avatar_styles(mixed $styles, array $ctx = []): mixed
{
    if (!is_array($styles)) return $styles;
    $styles['coc'] = 'COC';
    return $styles;
}

return [
    'id' => 'coc_style',
    'name' => 'COC头像样式',
    'version' => '1.0.0',
    'description' => '仅增加 COC 头像样式。',
    'hooks' => [
        'avatar.styles' => 'coc_style_avatar_styles',
    ],
];
