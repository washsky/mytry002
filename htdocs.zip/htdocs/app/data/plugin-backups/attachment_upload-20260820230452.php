<?php
if (!defined('APP_ROOT')) exit;

function attachment_upload_install(array $plugin): void
{
    $values = [];
    if ((int)val("SELECT COUNT(*) FROM app_settings WHERE name=?", ['plugin_attachment_upload_max_mb']) === 0) {
        $values['plugin_attachment_upload_max_mb'] = '20';
    }
    if ((int)val("SELECT COUNT(*) FROM app_settings WHERE name=?", ['plugin_attachment_upload_group_quotas']) === 0) {
        $values['plugin_attachment_upload_group_quotas'] = '{}';
    }
    if ($values) save_settings_values($values);
}

function attachment_upload_config(): array
{
    static $config;
    if (is_array($config)) return $config;
    $max_safe_mb = intdiv(PHP_INT_MAX, 1024 * 1024);
    $quotas = json_decode(setting('plugin_attachment_upload_group_quotas', '{}'), true);
    if (!is_array($quotas)) $quotas = [];
    $group_quotas = [];
    foreach ($quotas as $group_id => $quota_mb) {
        $group_id = (int)$group_id;
        if ($group_id > 0) $group_quotas[$group_id] = min($max_safe_mb, max(0, (int)$quota_mb));
    }
    return $config = [
        'max_mb' => min($max_safe_mb, max(0, (int)setting('plugin_attachment_upload_max_mb', '20'))),
        'group_quotas' => $group_quotas,
    ];
}

function attachment_upload_quota_mb(?array $user = null): int
{
    $user = $user ?: me();
    if (!$user) return 0;
    $config = attachment_upload_config();
    return max(0, (int)($config['group_quotas'][(int)($user['group_id'] ?? 0)] ?? 200));
}

function attachment_upload_quota_bytes(?array $user = null): int
{
    return attachment_upload_quota_mb($user) * 1024 * 1024;
}

function attachment_upload_url(string $hash = '', string $file = ''): string
{
    $path = 'app/upload/';
    if ($hash !== '' && $file !== '') $path .= rawurlencode(upload_hash_dir($hash)) . '/' . rawurlencode(basename($file));
    return asset_url($path);
}

function attachment_upload_used_bytes(int $user_id): int
{
    return max(0, (int)(val("SELECT COALESCE(SUM(size),0) FROM app_attachments WHERE user_id=?", [$user_id]) ?: 0));
}

function attachment_upload_mb_label(int $bytes): string
{
    $mb = $bytes / 1048576;
    $mb = $mb >= 100 ? round($mb) : round($mb * 10) / 10;
    return (string)$mb . 'MB';
}

function attachment_upload_image_ext(string $ext): bool
{
    return in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true);
}

function attachment_upload_detect_mime(string $path): string
{
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = @finfo_file($finfo, $path);
            if (is_string($mime) && $mime !== '') return strtolower($mime);
        }
    }
    if (function_exists('mime_content_type')) {
        $mime = @mime_content_type($path);
        if (is_string($mime) && $mime !== '') return strtolower($mime);
    }
    return '';
}

function attachment_upload_image_mime(string $ext): string
{
    return match ($ext) {
        'jpg', 'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'webp' => 'image/webp',
        default => '',
    };
}

function attachment_upload_image_valid(string $path, string $ext, string $mime): bool
{
    $expected = attachment_upload_image_mime($ext);
    if ($expected === '' || $mime !== $expected) return false;
    $info = @getimagesize($path);
    if (!is_array($info) || (string)($info['mime'] ?? '') !== $expected) return false;
    $width = (int)($info[0] ?? 0);
    $height = (int)($info[1] ?? 0);
    if ($width <= 0 || $height <= 0 || $width > 8192 || $height > 8192) return false;
    return $width <= intdiv(20000000, $height);
}

function attachment_upload_allowed_ext(string $ext): bool
{
    static $allowed = [
        'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'bmp', 'ico', 'svg',
        'mp3', 'wav', 'flac', 'aac', 'm4a', 'ogg', 'oga', 'opus',
        'mp4', 'm4v', 'mov', 'webm', 'ogv', 'mpeg', 'mpg',
    ];
    return in_array(strtolower($ext), $allowed, true);
}

function attachment_upload_storage_ext(string $ext): string
{
    $ext = strtolower(trim($ext));
    if ($ext === '' || preg_match('/^[a-z0-9]{1,24}$/', $ext) !== 1) return 'file1';
    return $ext . (attachment_upload_allowed_ext($ext) ? '' : '1');
}

function attachment_upload_neutralized_ext(string $ext): string
{
    $ext = strtolower(trim($ext));
    if ($ext === '' || preg_match('/^[a-z0-9]{1,24}$/', $ext) !== 1) return 'file1';
    return $ext . '1';
}

class AttachmentUploadPluginException extends RuntimeException {}

function attachment_upload_store(int $user_id, string $tmp, string $target, string $hash, string $file_name, string $original, string $ext, string $mime, int $size, bool $is_image): void
{
    $created_file = false;
    try {
        tx(function () use ($user_id, $tmp, $target, $hash, $file_name, $original, $ext, $mime, $size, $is_image, &$created_file): void {
            $user = one('SELECT group_id FROM app_users WHERE id=?' . (db_driver() !== 'sqlite' ? ' FOR UPDATE' : ''), [$user_id]);
            if (!$user) throw new AttachmentUploadPluginException('登录状态已失效，请重新登录');
            $quota = attachment_upload_quota_bytes($user);
            $used = attachment_upload_used_bytes($user_id);
            if ($quota <= 0 || $used + $size > $quota) {
                throw new AttachmentUploadPluginException('已用空间' . attachment_upload_mb_label($used) . '，上限' . attachment_upload_mb_label($quota));
            }
            if (!is_file($target)) {
                if (!move_uploaded_file($tmp, $target)) throw new AttachmentUploadPluginException('上传失败');
                $created_file = true;
            }
            app_db_insert_ignore('app_attachments', [
                'user_id' => $user_id,
                'hash' => $hash,
                'file_name' => $file_name,
                'original_name' => $original,
                'ext' => $ext,
                'mime' => $mime,
                'size' => $size,
                'is_image' => $is_image ? 1 : 0,
                'created_at' => now(),
            ], ['user_id', 'hash']);
        });
    } catch (Throwable $e) {
        if ($created_file && is_file($target)) @unlink($target);
        throw $e;
    }
}

function attachment_upload_markdown(array $file): string
{
    $max_mb = (int)attachment_upload_config()['max_mb'];
    if ($max_mb <= 0) err('附件上传已关闭');
    $user_id = uid();
    if ($user_id <= 0) err('请先登录');
    $allowed = hook('attachment.before_upload', true, ['user_id' => $user_id]);
    if ($allowed !== true) err(is_string($allowed) ? $allowed : '禁止上传附件');
    $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error !== UPLOAD_ERR_OK) err($error === UPLOAD_ERR_NO_FILE ? '请选择附件' : '上传失败');
    require_writable_dir(UPLOAD_DIR, '附件目录不可写，请检查 app/upload/ 目录权限');
    $size = (int)($file['size'] ?? 0);
    if ($size <= 0) err('附件不能为空');
    if ($size > $max_mb * 1024 * 1024) err('单个附件不能超过' . $max_mb . 'MB');
    $original = trim(preg_replace('/[\r\n]+/', ' ', basename((string)($file['name'] ?? ''))) ?? '');
    $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    $storage_ext = attachment_upload_storage_ext($ext);
    if (!is_uploaded_file((string)($file['tmp_name'] ?? ''))) err('上传失败');
    $tmp = (string)$file['tmp_name'];
    $is_image = attachment_upload_image_ext($ext);
    $mime = $is_image ? attachment_upload_detect_mime($tmp) : 'application/octet-stream';
    if ($is_image && ($mime === '' || !attachment_upload_image_valid($tmp, $ext, $mime))) {
        $is_image = false;
        $mime = 'application/octet-stream';
        $storage_ext = attachment_upload_neutralized_ext($ext);
    }
    $hash = hash_file('sha256', $tmp);
    if (!is_string($hash) || $hash === '') err('上传失败');
    $dir = UPLOAD_DIR . '/' . upload_hash_dir($hash);
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) err('附件目录不可写');
    require_writable_dir($dir, '附件目录不可写，请检查 app/upload/ 目录权限');
    $name = $hash . '.' . $storage_ext;
    try {
        attachment_upload_store($user_id, $tmp, $dir . '/' . $name, $hash, $name, $original, $ext, $mime, $size, $is_image);
    } catch (AttachmentUploadPluginException $e) {
        err($e->getMessage());
    }
    $label = markdown_link_text($original !== '' ? $original : $name);
    if ($is_image) return '![' . $label . '](' . attachment_upload_url($hash, $name) . ')';
    return '[' . $label . '](' . route_url('attachment', ['f' => $name, 'name' => $original !== '' ? $original : '附件.' . $ext]) . ')';
}

function attachment_upload_route(array $plugin = []): void
{
    require_post();
    need_speak();
    ob_start();
    try {
        $markdown = attachment_upload_markdown(is_array($_FILES['attachment'] ?? null) ? $_FILES['attachment'] : []);
        if (ob_get_level() > 0) ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => 1, 'markdown' => $markdown], JSON_UNESCAPED_UNICODE);
        exit;
    } catch (Throwable $e) {
        if (ob_get_level() > 0) ob_end_clean();
        debug_log_write('附件上传失败', $e);
        err(database_error($e) ? database_error_message() : ($e->getMessage() ?: '附件上传失败'), 200, 'ajax');
    }
}

function attachment_upload_download_route(array $plugin = []): void
{
    $file = (string)($_GET['f'] ?? '');
    if (preg_match('/^[a-f0-9]{64}\.[a-z0-9]{1,25}$/', $file) !== 1) err('附件不存在', 404);
    $hash = substr($file, 0, 64);
    $path = UPLOAD_DIR . '/' . upload_hash_dir($hash) . '/' . $file;
    if (!is_file($path)) err('附件不存在', 404);
    $name = trim(preg_replace('/[\r\n"\\\\\/]+/', ' ', basename((string)($_GET['name'] ?? '附件'))) ?? '');
    if ($name === '') $name = '附件';
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $is_image = attachment_upload_image_ext($ext);
    header('Content-Type: ' . ($is_image ? attachment_upload_image_mime($ext) : 'application/octet-stream'));
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: ' . ($is_image ? 'inline' : 'attachment') . '; filename="' . rawurlencode($name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

function attachment_upload_uploader_html(mixed $html, array $ctx): string
{
    $max_mb = (int)attachment_upload_config()['max_mb'];
    if ($max_mb <= 0 || !can_speak() || attachment_upload_quota_bytes() <= 0) return (string)$html;
    $muted = !empty($ctx['muted']);
    return (string)$html . '<div class="grid attachment-field' . ($muted ? ' attachment-field-muted' : '') . '"><div class="attachment-uploader" data-upload-url="' . h(route_url('attachment_upload')) . '" data-upload-max-mb="' . $max_mb . '" data-upload-storage-key="bbs1_attachment_upload_history_v1_' . uid() . '"><label class="attachment-drop"><input class="attachment-input" type="file" multiple data-attachment-input><strong>选择附件</strong><span>单个不超过' . $max_mb . 'MB</span></label><div class="attachment-upload-toolbar" data-attachment-upload-toolbar hidden><span data-attachment-upload-summary></span><button type="button" class="attachment-upload-insert" data-attachment-insert-all>批量插入</button></div><div class="attachment-upload-list" data-attachment-upload-list aria-live="polite" hidden></div></div></div>';
}

function attachment_upload_reply_form_extra(mixed $html, array $ctx): string
{
    if (!empty($ctx['editing'])) return (string)$html;
    return attachment_upload_uploader_html($html, ['muted' => true]);
}

function attachment_upload_topic_before_save(mixed $value, array $ctx): mixed
{
    if (!is_array($value) || !empty($ctx['id'])) return $value;
    $files = $_FILES['attachments'] ?? null;
    if (!is_array($files) || !is_array($files['name'] ?? null)) return $value;
    $items = [];
    foreach ((array)$files['name'] as $index => $name) {
        if ((int)($files['error'][$index] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
        $items[] = attachment_upload_markdown([
            'name' => $name,
            'type' => $files['type'][$index] ?? '',
            'tmp_name' => $files['tmp_name'][$index] ?? '',
            'error' => $files['error'][$index] ?? UPLOAD_ERR_NO_FILE,
            'size' => $files['size'][$index] ?? 0,
        ]);
    }
    if ($items) $value['body'] = (string)($value['body'] ?? '') . "\n\n附件：\n" . implode("\n", $items);
    return $value;
}

function attachment_upload_after_save(mixed $value, array $ctx): mixed
{
    if (uid() > 0) app_cookie('__attachment_upload_history_clear', (string)uid(), time() + 120, false);
    return $value;
}

function attachment_upload_csrf_exempt(mixed $exempt, array $ctx): bool
{
    return $exempt === true || ((string)($ctx['action'] ?? '') === 'attachment_upload' && ajax_request());
}

function attachment_upload_admin_page(array $plugin): string
{
    need_admin();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $max_safe_mb = intdiv(PHP_INT_MAX, 1024 * 1024);
        $max_mb = min($max_safe_mb, max(0, (int)($_POST['max_mb'] ?? 20)));
        $quotas = [];
        foreach (groups_cache() as $group) {
            $group_id = (int)$group['id'];
            $quotas[$group_id] = min($max_safe_mb, max(0, (int)($_POST['group_quotas'][$group_id] ?? 200)));
        }
        save_settings_values([
            'plugin_attachment_upload_max_mb' => (string)$max_mb,
            'plugin_attachment_upload_group_quotas' => json_encode($quotas, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
        ]);
        set_flash('附件上传设置已保存');
        go(admin_url(['tab' => 'attachment_upload']));
    }
    $config = attachment_upload_config();
    $fields = number_input('单个附件大小（MB）', 'max_mb', (int)$config['max_mb'], 0, null, true, '设置为 0 可关闭附件上传，实际上限受服务器配置影响。');
    $group_fields = '';
    foreach (groups_cache() as $group) {
        $group_id = (int)$group['id'];
        $quota = (int)($config['group_quotas'][$group_id] ?? 200);
        $group_fields .= number_input((string)$group['name'], 'group_quotas[' . $group_id . ']', $quota, 0);
    }
    $form = '<form class="plugin-settings-form attachment-upload-settings" method="post" action="' . h(admin_url(['tab' => 'attachment_upload'])) . '">' . form_token() . '<section class="attachment-upload-settings-section"><strong>上传限制</strong>' . $fields . '</section><section class="attachment-upload-settings-section"><strong>用户组空间（MB）</strong><div class="attachment-upload-settings-groups">' . $group_fields . '</div></section><button type="submit">保存设置</button></form>';
    return '<section class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>附件上传</strong><span>设置附件大小和各用户组可用空间</span></div>', '') . '<div class="plugin-panel-body">' . $form . '</div></section>';
}

function attachment_upload_css(): string
{
    return <<<'CSS'
.attachment-uploader{display:grid;gap:8px}.attachment-input{position:absolute;width:1px;height:1px;padding:0;border:0;opacity:0;pointer-events:none}.attachment-drop{display:grid;justify-items:start;gap:2px;padding:0;border:0;background:transparent;color:var(--text-muted);text-align:left;cursor:pointer}.attachment-drop strong{color:var(--text);font-size:var(--font-size-md);line-height:1.4}.attachment-drop span{font-size:var(--font-size-sm);line-height:1.45}.attachment-uploader:focus-within .attachment-drop,.attachment-drop:hover{background:transparent;color:var(--brand)}.attachment-field-muted>span{color:var(--text-subtle)}.attachment-field-muted .attachment-uploader{gap:6px}.attachment-field-muted .attachment-drop{display:flex;align-items:center;justify-content:flex-start;gap:8px;padding:0;border:0;background:transparent;color:var(--text-subtle)}.attachment-field-muted .attachment-drop strong{flex:0 0 auto;color:var(--text-muted);font-size:var(--font-size-sm);font-weight:500}.attachment-field-muted .attachment-drop span{min-width:0;font-size:11px}.attachment-field-muted .attachment-uploader:focus-within .attachment-drop,.attachment-field-muted .attachment-drop:hover{background:transparent;color:var(--text-muted)}.attachment-upload-toolbar{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px 10px;color:var(--text-subtle);font-size:11px}.attachment-upload-toolbar[hidden],.attachment-upload-list[hidden]{display:none}.attachment-upload-insert{min-height:28px;padding:4px 9px;font-size:var(--font-size-sm);white-space:nowrap}.attachment-upload-list{display:grid;gap:6px;margin-top:2px}.attachment-upload-item{display:grid;gap:6px;min-width:0;padding:8px 10px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--bg)}.attachment-upload-head{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:10px;min-width:0}.attachment-upload-name{min-width:0;overflow:hidden;color:var(--text);font-size:var(--font-size-sm);font-weight:500;text-overflow:ellipsis;white-space:nowrap}.attachment-upload-head-actions{display:flex;align-items:center;justify-content:flex-end;gap:6px;min-width:0}.attachment-upload-status{max-width:220px;color:var(--text-subtle);font-size:11px;line-height:1.4;text-align:right;overflow-wrap:anywhere}.attachment-upload-head-actions .attachment-upload-remove{display:grid;place-items:center;justify-self:auto;width:20px;min-width:20px;min-height:20px;padding:0;border:0;border-radius:var(--radius-sm);background:transparent;color:var(--text-subtle);font-size:18px;line-height:1;box-shadow:none}.attachment-upload-remove:hover{background:var(--line-soft);color:var(--danger)}.attachment-upload-remove:focus-visible{outline:2px solid var(--focus-ring);outline-offset:1px}.attachment-upload-progress{display:block;width:100%;height:4px;overflow:hidden;border-radius:4px;background:var(--line)}.attachment-upload-progress>span{display:block;width:0;height:100%;border-radius:inherit;background:var(--brand);transition:width .15s ease}.attachment-upload-item[data-state="success"] .attachment-upload-status{color:var(--success)}.attachment-upload-item[data-state="success"] .attachment-upload-progress{display:none}.attachment-upload-item[data-state="success"][data-markdown]{cursor:pointer;transition:border-color .15s,background .15s}.attachment-upload-item[data-state="success"][data-markdown]:hover{border-color:var(--brand);background:var(--brand-soft)}.attachment-upload-item[data-state="success"][data-markdown]:focus-visible{border-color:var(--brand);outline:2px solid var(--focus-ring);outline-offset:1px}.attachment-upload-item[data-state="error"] .attachment-upload-status{color:var(--danger)}.attachment-upload-item[data-state="error"] .attachment-upload-progress>span{background:var(--danger)}
.attachment-upload-settings{max-width:none;gap:12px}.attachment-upload-settings-section{display:grid;gap:10px;padding:14px;border:1px solid var(--line);border-radius:8px;background:var(--bg)}.attachment-upload-settings-section>strong{font-size:12px}.attachment-upload-settings-section .grid{margin:0}.attachment-upload-settings-groups{display:grid;grid-template-columns:1fr;gap:10px}.attachment-upload-settings-groups .grid{grid-template-columns:minmax(90px,140px) minmax(0,1fr)}
@media(max-width:600px){.attachment-upload-settings-groups .grid{grid-template-columns:1fr}}
CSS;
}

function attachment_upload_js(): string
{
    return <<<'JS'
(function(){
"use strict";
const historyPrefix="bbs1_attachment_upload_history_v1_",states=new WeakMap(),limit=100;
const toast=message=>{const el=document.getElementById("toast");if(!el)return;el.textContent=message;el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>{el.hidden=true},2200)};
const insertText=(field,text)=>{const start=field.selectionStart??field.value.length,end=field.selectionEnd??start,prefix=start>0&&!field.value.slice(0,start).endsWith("\n")?"\n":"",suffix=end<field.value.length&&!field.value.slice(end).startsWith("\n")?"\n":"";field.setRangeText(prefix+text+suffix,start,end,"end");field.dispatchEvent(new Event("input",{bubbles:true}));field.focus()};
const read=key=>{if(!key)return[];try{const data=JSON.parse(localStorage.getItem(key)||"[]"),keys=new Set();if(!Array.isArray(data))return[];return data.filter(x=>{if(!x||typeof x.key!=="string"||typeof x.markdown!=="string"||!x.key||!x.markdown||keys.has(x.key))return false;keys.add(x.key);return true}).slice(-limit)}catch(_){return[]}};
const write=(key,items)=>{if(!key)return;try{localStorage.setItem(key,JSON.stringify(items.slice(-limit)))}catch(_){}};
const row=(list,file,key)=>{const item=document.createElement("div");item.className="attachment-upload-item";item.dataset.state="waiting";item.dataset.attachmentKey=key;const head=document.createElement("div");head.className="attachment-upload-head";const name=document.createElement("span");name.className="attachment-upload-name";name.textContent=file.name||"未命名附件";name.title=file.name||"";const actions=document.createElement("div");actions.className="attachment-upload-head-actions";const status=document.createElement("span");status.className="attachment-upload-status";status.textContent="等待上传";const remove=document.createElement("button");remove.type="button";remove.className="attachment-upload-remove";remove.dataset.attachmentRemove="";remove.setAttribute("aria-label","不插入此附件");remove.title="不插入内容";remove.textContent="×";actions.append(status,remove);head.append(name,actions);const progress=document.createElement("span");progress.className="attachment-upload-progress";progress.setAttribute("role","progressbar");progress.setAttribute("aria-valuemin","0");progress.setAttribute("aria-valuemax","100");progress.setAttribute("aria-valuenow","0");progress.append(document.createElement("span"));item.append(head,progress);list.append(item);return{item,status,progress,bar:progress.firstElementChild}};
const update=(item,state,percent,message)=>{if(!item)return;const value=Math.max(0,Math.min(100,Math.round(percent||0)));item.item.dataset.state=state;item.bar.style.width=value+"%";item.progress.setAttribute("aria-valuenow",String(value));item.status.textContent=message||(state==="uploading"?"上传中 "+value+"%":state==="error"?"上传失败":"等待上传")};
const success=(item,entry,restored=false)=>{if(!item)return;item.item.dataset.markdown=entry.markdown;item.item.tabIndex=0;item.item.setAttribute("role","button");item.item.setAttribute("aria-label","复制 "+entry.name+" 的 Markdown");update(item,"success",100,restored?"历史记录 · 点击复制":"上传完成 · 点击复制")};
const toolbar=(uploader,state)=>{const bar=uploader.querySelector("[data-attachment-upload-toolbar]"),summary=uploader.querySelector("[data-attachment-upload-summary]"),button=uploader.querySelector("[data-attachment-insert-all]"),pending=state.history.filter(x=>!state.inserted.has(x.key)).length;if(bar)bar.hidden=state.history.length===0;if(summary)summary.textContent="已上传 "+state.history.length+" 个";if(button){button.disabled=pending===0;button.textContent=pending>0?"批量插入（"+pending+"）":"已全部插入"}};
const stateFor=uploader=>{let state=states.get(uploader);if(state)return state;const storageKey=uploader.dataset.uploadStorageKey||"",history=read(storageKey);state={storageKey,history,selected:new Set(history.map(x=>x.key)),inserted:new Set(),dismissed:new Set()};states.set(uploader,state);const list=uploader.querySelector("[data-attachment-upload-list]");if(list&&history.length){list.hidden=false;history.forEach(entry=>success(row(list,entry,entry.key),entry,true))}toolbar(uploader,state);return state};
const dismiss=(uploader,key,item)=>{if(!uploader||!key)return;const state=stateFor(uploader);state.dismissed.add(key);state.history=state.history.filter(x=>x.key!==key);state.inserted.delete(key);write(state.storageKey,state.history);item?.remove();const list=uploader.querySelector("[data-attachment-upload-list]");if(list&&!list.children.length)list.hidden=true;toolbar(uploader,state)};
const beforeSubmit=form=>{const textarea=form?.querySelector("textarea[name=body]");if(!textarea)return 0;const pending=[],seen=new Set(),uploaders=Array.from(form.querySelectorAll(".attachment-uploader[data-upload-storage-key]"));uploaders.forEach(uploader=>{const state=stateFor(uploader);state.history.forEach(entry=>{if(state.inserted.has(entry.key)||seen.has(entry.key))return;seen.add(entry.key);if(textarea.value.includes(entry.markdown)){state.inserted.add(entry.key);return}pending.push({entry,state})})});if(pending.length){const prefix=textarea.value===""||textarea.value.endsWith("\n")?"":"\n";textarea.value+=prefix+pending.map(x=>x.entry.markdown).join("\n");textarea.dispatchEvent(new Event("input",{bubbles:true}));pending.forEach(x=>x.state.inserted.add(x.entry.key))}uploaders.forEach(x=>toolbar(x,stateFor(x)));return pending.length};
const clear=storageKey=>{if(!storageKey)return;try{localStorage.removeItem(storageKey)}catch(_){}document.querySelectorAll(".attachment-uploader[data-upload-storage-key]").forEach(uploader=>{if(uploader.dataset.uploadStorageKey!==storageKey)return;const state=stateFor(uploader);state.history.length=0;state.selected.clear();state.inserted.clear();state.dismissed.clear();const list=uploader.querySelector("[data-attachment-upload-list]");if(list){list.replaceChildren();list.hidden=true}toolbar(uploader,state)})};
const afterSubmit=()=>{const marker=document.cookie.split("; ").find(x=>x.startsWith("__attachment_upload_history_clear="));if(!marker)return false;const userId=marker.slice(marker.indexOf("=")+1);if(/^\d+$/.test(userId))clear(historyPrefix+userId);document.cookie="__attachment_upload_history_clear=; Max-Age=0; path=/; SameSite=Lax"+(location.protocol==="https:"?"; Secure":"");return true};
const copy=async item=>{const markdown=item?.dataset?.markdown||"";if(!markdown||item.dataset.state!=="success")return;const status=item.querySelector(".attachment-upload-status");try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(markdown);else{const field=document.createElement("textarea");field.value=markdown;field.setAttribute("readonly","");field.style.position="fixed";field.style.opacity="0";document.body.append(field);field.select();const copied=document.execCommand("copy");field.remove();if(!copied)throw new Error()}if(status)status.textContent="已复制 Markdown";toast("Markdown 已复制");item.closest("form")?.querySelector("textarea[name=body]")?.focus()}catch(_){if(status)status.textContent="复制失败 · 点击重试";toast("复制失败")}};
const send=(url,csrf,file,onProgress)=>new Promise((resolve,reject)=>{const request=new XMLHttpRequest();request.open("POST",url,true);request.setRequestHeader("X-Requested-With","XMLHttpRequest");request.upload.addEventListener("progress",event=>{if(event.lengthComputable)onProgress(event.loaded*100/event.total)});request.addEventListener("load",()=>{let data;try{data=JSON.parse(request.responseText||"")}catch(_){reject(new Error("上传失败"));return}if(request.status<200||request.status>=300||!data.ok){reject(new Error(data.message||"上传失败"));return}resolve(data)});request.addEventListener("error",()=>reject(new Error("上传失败")));request.addEventListener("abort",()=>reject(new Error("上传已取消")));const body=new FormData();body.append("_csrf",csrf);body.append("attachment",file);request.send(body)});
afterSubmit();document.querySelectorAll(".attachment-uploader[data-upload-storage-key]").forEach(stateFor);
document.addEventListener("change",async event=>{const input=event.target.closest("[data-attachment-input]");if(!input)return;const uploader=input.closest(".attachment-uploader"),form=input.closest("form"),textarea=form?.querySelector("textarea[name=body]"),url=uploader?.dataset?.uploadUrl||"",csrf=form?.querySelector("input[name=_csrf]")?.value||"",selected=Array.from(input.files||[]);if(!uploader||!textarea||!url||!selected.length)return;const state=stateFor(uploader),batch=new Set(),entries=[];let duplicates=0;selected.forEach(file=>{const key=[file.name,file.size,file.lastModified].join("\u001f");if(state.selected.has(key)||batch.has(key)){duplicates++;return}batch.add(key);entries.push({file,key})});if(duplicates)toast("已忽略"+duplicates+"个重复文件");if(!entries.length){input.value="";return}entries.forEach(x=>state.selected.add(x.key));const maxMb=parseInt(uploader.dataset.uploadMaxMb||"20",10)||20,list=uploader.querySelector("[data-attachment-upload-list]");if(list)list.hidden=false;const rows=entries.map(x=>list?row(list,x.file,x.key):null);input.disabled=true;for(const [index,entry] of entries.entries()){const item=rows[index],file=entry.file;uploader.dataset.uploadingCount=String((parseInt(uploader.dataset.uploadingCount||"0",10)||0)+1);try{if(file.size>maxMb*1024*1024)throw new Error("超过"+maxMb+"MB");if(item)update(item,"uploading",0);const data=await send(url,csrf,file,percent=>{if(item)update(item,"uploading",percent)}),markdown=String(data.markdown||""),saved={key:entry.key,name:file.name||"未命名附件",size:file.size||0,lastModified:file.lastModified||0,markdown,createdAt:Date.now()};if(markdown&&!state.dismissed.has(saved.key)){state.history.push(saved);write(state.storageKey,state.history);if(item)success(item,saved);toolbar(uploader,state)}else if(item)update(item,"success",100,"上传完成")}catch(error){const message=error?.message||"上传失败";if(item)update(item,"error",100,message);toast((file.name?file.name+"：":"")+message)}finally{uploader.dataset.uploadingCount=String(Math.max(0,(parseInt(uploader.dataset.uploadingCount||"0",10)||0)-1))}}input.disabled=false;input.value=""});
document.addEventListener("click",event=>{const remove=event.target.closest("[data-attachment-remove]");if(remove){event.preventDefault();event.stopPropagation();const item=remove.closest(".attachment-upload-item");dismiss(item?.closest(".attachment-uploader"),item?.dataset.attachmentKey||"",item);return}const insert=event.target.closest("[data-attachment-insert-all]");if(insert){const uploader=insert.closest(".attachment-uploader"),textarea=uploader?.closest("form")?.querySelector("textarea[name=body]");if(!uploader||!textarea)return;const state=stateFor(uploader),entries=state.history.filter(x=>!state.inserted.has(x.key));if(!entries.length)return;insertText(textarea,entries.map(x=>x.markdown).join("\n"));entries.forEach(x=>state.inserted.add(x.key));toolbar(uploader,state);toast("已插入 "+entries.length+" 个附件");return}const item=event.target.closest(".attachment-upload-item[data-state='success'][data-markdown]");if(item)copy(item)});
document.addEventListener("keydown",event=>{if(event.target.closest("[data-attachment-remove]"))return;const item=event.target.closest(".attachment-upload-item[data-state='success'][data-markdown]");if(!item||(event.key!=="Enter"&&event.key!==" "))return;event.preventDefault();copy(item)});
window.bbs1AttachmentUpload={beforeSubmit,afterSubmit,isUploading:form=>!!form?.querySelector?.(".attachment-uploader[data-uploading-count]:not([data-uploading-count='0'])")};
})();
JS;
}

return [
    'id' => 'attachment_upload',
    'name' => '附件上传',
    'version' => '1.0.10',
    'description' => '支持在主题和回帖中上传图片与文件，让内容分享更方便。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'attachment_upload_css', 'js' => 'attachment_upload_js'],
    'hooks' => [
        'attachment.uploader' => 'attachment_upload_uploader_html',
        'reply.form_extra' => 'attachment_upload_reply_form_extra',
        'topic.before_save' => 'attachment_upload_topic_before_save',
        'topic.after_save' => 'attachment_upload_after_save',
        'reply.after_save' => 'attachment_upload_after_save',
        'request.csrf_exempt' => 'attachment_upload_csrf_exempt',
    ],
    'routes' => [
        'attachment' => 'attachment_upload_download_route',
        'attachment_upload' => 'attachment_upload_route',
    ],
    'admin_tabs' => ['attachment_upload' => 'attachment_upload_admin_page'],
    'install' => 'attachment_upload_install',
];