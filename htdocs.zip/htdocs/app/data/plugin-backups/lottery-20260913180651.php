<?php
if (!defined('APP_ROOT')) exit;

const LOTTERY_MAX_PRIZES = 20;
const LOTTERY_RULES_VERSION = 1;

function lottery_config(): array
{
    return plugin_config('lottery', [
        'allowed_groups' => '',
        'default_min_chars' => '5',
        'max_open_per_user' => '0',
        'default_min_entries' => '0',
        'default_insufficient_action' => 'wait',
        'default_postpone_hours' => '24',
        'default_max_postpones' => '3',
        'default_min_account_days' => '0',
        'default_min_user_points' => '0',
        'default_claim_days' => '7',
    ]);
}

function lottery_allowed_group_ids(): array
{
    $raw = (string)(lottery_config()['allowed_groups'] ?? '');
    return array_values(array_filter(array_map('intval', preg_split('/[^0-9]+/', $raw) ?: []), static fn(int $id): bool => $id > 0));
}

function lottery_group_allowed(): bool
{
    if (!uid()) return false;
    if (can_manage()) return true;
    $ids = lottery_allowed_group_ids();
    if (!$ids) return true;
    return in_array((int)(me()['group_id'] ?? 0), $ids, true);
}

function lottery_open_count(int $user_id): int
{
    return $user_id > 0 ? (int)val("SELECT COUNT(*) FROM plugin_lottery_draws WHERE creator_id=? AND status='open'", [$user_id]) : 0;
}

function lottery_prize_points(string $kind, int $quantity, int $unit_points): int
{
    if ($kind !== 'points') return 0;
    return min(1000, max(1, $quantity)) * min(100000, max(0, $unit_points));
}

function lottery_csv_ids(mixed $value): array
{
    $values = is_array($value) ? $value : (preg_split('/[^0-9]+/', (string)$value) ?: []);
    $ids = [];
    foreach ($values as $id) {
        $id = (int)$id;
        if ($id > 0) $ids[$id] = $id;
    }
    return array_values($ids);
}

function lottery_insufficient_actions(): array
{
    return [
        'wait' => '等待发起人处理',
        'postpone' => '自动延期',
        'draw' => '按当前人数开奖',
    ];
}

function lottery_group_checks(string $name, array $selected): string
{
    $html = '';
    foreach (groups_cache() as $group) {
        $id = (int)$group['id'];
        $html .= '<label class="lottery-group-check"><input type="checkbox" name="' . h($name) . '[]" value="' . $id . '"'
            . (in_array($id, $selected, true) ? ' checked' : '') . '><span>' . h((string)$group['name']) . '</span></label>';
    }
    return $html !== '' ? $html : '<span class="lottery-note">没有可选的用户组</span>';
}

function lottery_user_points(int $user_id): int
{
    return $user_id > 0 ? (int)(row('app_users', 'id', $user_id)['points'] ?? 0) : 0;
}

function lottery_rule_values(string $prefix, array $defaults): array
{
    $action = (string)($_POST[$prefix . 'insufficient_action'] ?? ($defaults['insufficient_action'] ?? 'wait'));
    if (!isset(lottery_insufficient_actions()[$action])) $action = 'wait';
    $groups = lottery_csv_ids($_POST[$prefix . 'eligible_groups'] ?? ($defaults['eligibility_groups'] ?? ''));
    return [
        'min_entries' => min(100000, max(0, (int)($_POST[$prefix . 'min_entries'] ?? ($defaults['min_entries'] ?? 0)))),
        'insufficient_action' => $action,
        'postpone_hours' => min(720, max(1, (int)($_POST[$prefix . 'postpone_hours'] ?? ($defaults['postpone_hours'] ?? 24)))),
        'max_postpones' => min(20, max(0, (int)($_POST[$prefix . 'max_postpones'] ?? ($defaults['max_postpones'] ?? 3)))),
        'eligibility_groups' => implode(',', $groups),
        'min_account_days' => min(3650, max(0, (int)($_POST[$prefix . 'min_account_days'] ?? ($defaults['min_account_days'] ?? 0)))),
        'min_user_points' => min(100000000, max(0, (int)($_POST[$prefix . 'min_user_points'] ?? ($defaults['min_user_points'] ?? 0)))),
        'exclude_restricted' => !empty($_POST[$prefix . 'exclude_restricted']) ? 1 : 0,
        'claim_days' => min(365, max(0, (int)($_POST[$prefix . 'claim_days'] ?? ($defaults['claim_days'] ?? 7)))),
    ];
}

function lottery_eligibility_text(array $draw): string
{
    $parts = [];
    $groups = lottery_csv_ids($draw['eligibility_groups'] ?? '');
    if ($groups) {
        $names = [];
        foreach (groups_cache() as $group) if (in_array((int)$group['id'], $groups, true)) $names[] = (string)$group['name'];
        if ($names) $parts[] = '用户组：' . implode('、', $names);
    }
    if ((int)($draw['min_account_days'] ?? 0) > 0) $parts[] = '注册满 ' . (int)$draw['min_account_days'] . ' 天';
    if ((int)($draw['min_user_points'] ?? 0) > 0) $parts[] = '至少 ' . (int)$draw['min_user_points'] . ' 积分';
    if ((int)($draw['exclude_restricted'] ?? 1) === 1) $parts[] = '禁言/封禁用户除外';
    return implode(' · ', $parts);
}

function lottery_eligibility_reason_for_user(array $draw, array $user): string
{
    if ((int)($user['id'] ?? 0) <= 0) return '用户不存在';
    if ((int)($draw['exclude_restricted'] ?? 1) === 1 && ((int)($user['is_banned'] ?? 0) === 1 || (int)($user['is_muted'] ?? 0) === 1)) {
        return '被禁言或封禁的用户不能参与';
    }
    $groups = lottery_csv_ids($draw['eligibility_groups'] ?? '');
    if ($groups && !in_array((int)($user['group_id'] ?? 0), $groups, true)) return '当前用户组不在参与范围内';
    $days = max(0, (int)($draw['min_account_days'] ?? 0));
    if ($days > 0 && (int)($user['created_at'] ?? 0) > now() - $days * 86400) return '账号注册时间不足 ' . $days . ' 天';
    $points = max(0, (int)($draw['min_user_points'] ?? 0));
    if ($points > 0 && (int)($user['points'] ?? 0) < $points) return '参与需要至少 ' . $points . ' 积分';
    return '';
}

function lottery_eligibility_reason(array $draw, int $user_id): string
{
    if ($user_id <= 0) return '请先登录';
    $user = row('app_users', 'id', $user_id);
    return $user ? lottery_eligibility_reason_for_user($draw, $user) : '用户不存在';
}

function lottery_reconcile_entries(int $topic_id): int
{
    $draw = one('SELECT * FROM plugin_lottery_draws WHERE topic_id=?', [$topic_id]);
    if (!$draw || (string)$draw['status'] !== 'open') return 0;
    $rows = q('SELECT r.id reply_id,r.user_id,r.body,r.created_at reply_created_at,u.group_id,u.created_at,u.points,u.is_banned,u.is_muted FROM app_replies r JOIN app_users u ON u.id=r.user_id WHERE r.topic_id=? AND r.user_id<>? ORDER BY r.id', [$topic_id, (int)$draw['creator_id']])->fetchAll();
    $eligible = [];
    foreach ($rows as $row) {
        $user_id = (int)$row['user_id'];
        if (isset($eligible[$user_id])) continue;
        if (search_char_count((string)$row['body']) < max(1, (int)$draw['min_chars'])) continue;
        $user = ['id' => $user_id, 'group_id' => (int)$row['group_id'], 'created_at' => (int)$row['created_at'], 'points' => (int)$row['points'], 'is_banned' => (int)$row['is_banned'], 'is_muted' => (int)$row['is_muted']];
        if (lottery_eligibility_reason_for_user($draw, $user) !== '') continue;
        $eligible[$user_id] = ['reply_id' => (int)$row['reply_id'], 'created_at' => (int)$row['reply_created_at']];
    }
    tx(function () use ($topic_id, $eligible): void {
        foreach ($eligible as $user_id => $entry) {
            app_db_insert_ignore('plugin_lottery_entries', [
                'topic_id' => $topic_id,
                'user_id' => (int)$user_id,
                'reply_id' => (int)$entry['reply_id'],
                'created_at' => (int)$entry['created_at'],
            ], ['topic_id', 'user_id']);
        }
        $count = (int)val('SELECT COUNT(*) FROM plugin_lottery_entries WHERE topic_id=?', [$topic_id]);
        q('UPDATE plugin_lottery_draws SET entry_count=?,rules_locked=? WHERE topic_id=?', [$count, $count > 0 ? 1 : 0, $topic_id]);
    });
    lottery_forget($topic_id);
    return count($eligible);
}

function lottery_reserve_points(int $user_id, int $points): void
{
    if ($points <= 0) return;
    $changed = q('UPDATE app_users SET points=points-? WHERE id=? AND points>=?', [$points, $user_id, $points])->rowCount();
    if ($changed < 1) err('积分不足，积分奖共需预付 ' . $points . ' 积分');
    if ($user_id === uid()) unset($GLOBALS['__me_cache']);
    create_notification($user_id, 0, 'points', '你的积分减少 ' . $points . '，原因：抽奖奖池预付。当前积分 ' . lottery_user_points($user_id) . '。');
}

function lottery_create_blocked_reason(int $user_id, int $required_points = 0): string
{
    if (!lottery_group_allowed()) return '当前用户组不能发起抽奖';
    $config = lottery_config();
    $limit = max(0, (int)$config['max_open_per_user']);
    if (!can_manage() && $limit > 0 && lottery_open_count($user_id) >= $limit) {
        return '你已有 ' . $limit . ' 个未开奖的抽奖，开奖后才能再发起';
    }
    if ($required_points > 0 && lottery_user_points($user_id) < $required_points) {
        return '积分不足，积分奖共需预付 ' . $required_points . ' 积分';
    }
    return '';
}

function lottery_kinds(): array
{
    return [
        'points' => ['label' => '积分', 'auto' => true],
        'code' => ['label' => '兑换码', 'auto' => false],
        'manual' => ['label' => '手工发奖', 'auto' => false],
    ];
}

function lottery_install(array $plugin): void
{
    $t = app_db_types();
    app_db_create_table('plugin_lottery_draws', "topic_id {$t['uint']} PRIMARY KEY,creator_id {$t['uint']} NOT NULL,min_chars {$t['uint']} NOT NULL DEFAULT 5,draw_at {$t['uint']} NOT NULL DEFAULT 0,draw_count {$t['uint']} NOT NULL DEFAULT 0,status {$t['key']} NOT NULL DEFAULT 'open',entry_count {$t['uint']} NOT NULL DEFAULT 0,commit_hash {$t['key']} NOT NULL DEFAULT '',seed {$t['key']} NOT NULL DEFAULT '',deposit_points {$t['uint']} NOT NULL DEFAULT 0,min_entries {$t['uint']} NOT NULL DEFAULT 0,insufficient_action {$t['key']} NOT NULL DEFAULT 'wait',postpone_hours {$t['uint']} NOT NULL DEFAULT 24,max_postpones {$t['uint']} NOT NULL DEFAULT 3,postpone_count {$t['uint']} NOT NULL DEFAULT 0,eligibility_groups {$t['string']} NOT NULL DEFAULT '',min_account_days {$t['uint']} NOT NULL DEFAULT 0,min_user_points {$t['uint']} NOT NULL DEFAULT 0,exclude_restricted {$t['uint']} NOT NULL DEFAULT 1,claim_days {$t['uint']} NOT NULL DEFAULT 7,rules_locked {$t['uint']} NOT NULL DEFAULT 0,rules_hash {$t['key']} NOT NULL DEFAULT '',rules_snapshot {$t['text']} NULL,drawn_at {$t['uint']} NOT NULL DEFAULT 0,created_at {$t['uint']} NOT NULL");
    app_db_ensure_columns('plugin_lottery_draws', [
        'deposit_points' => "{$t['uint']} NOT NULL DEFAULT 0",
        'min_entries' => "{$t['uint']} NOT NULL DEFAULT 0",
        'insufficient_action' => "{$t['key']} NOT NULL DEFAULT 'wait'",
        'postpone_hours' => "{$t['uint']} NOT NULL DEFAULT 24",
        'max_postpones' => "{$t['uint']} NOT NULL DEFAULT 3",
        'postpone_count' => "{$t['uint']} NOT NULL DEFAULT 0",
        'eligibility_groups' => "{$t['string']} NOT NULL DEFAULT ''",
        'min_account_days' => "{$t['uint']} NOT NULL DEFAULT 0",
        'min_user_points' => "{$t['uint']} NOT NULL DEFAULT 0",
        'exclude_restricted' => "{$t['uint']} NOT NULL DEFAULT 1",
        'claim_days' => "{$t['uint']} NOT NULL DEFAULT 7",
        'rules_locked' => "{$t['uint']} NOT NULL DEFAULT 0",
        'rules_hash' => "{$t['key']} NOT NULL DEFAULT ''",
        'rules_snapshot' => "{$t['text']} NULL",
    ]);
    app_db_create_index('idx_lottery_due', 'plugin_lottery_draws(status,draw_at)');
    app_db_create_table('plugin_lottery_prizes', "id {$t['id']},topic_id {$t['uint']} NOT NULL,name {$t['string']} NOT NULL,kind {$t['key']} NOT NULL,quantity {$t['uint']} NOT NULL DEFAULT 1,unit_points {$t['uint']} NOT NULL DEFAULT 0,sort_order {$t['uint']} NOT NULL DEFAULT 0");
    app_db_create_index('idx_lottery_prizes_topic', 'plugin_lottery_prizes(topic_id,sort_order,id)');
    app_db_create_table('plugin_lottery_entries', "id {$t['id']},topic_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,reply_id {$t['uint']} NOT NULL DEFAULT 0,created_at {$t['uint']} NOT NULL,UNIQUE(topic_id,user_id)");
    app_db_create_index('idx_lottery_entries_topic', 'plugin_lottery_entries(topic_id,id)');
    app_db_create_table('plugin_lottery_winners', "id {$t['id']},topic_id {$t['uint']} NOT NULL,prize_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,prize_name {$t['string']} NOT NULL DEFAULT '',created_at {$t['uint']} NOT NULL,UNIQUE(topic_id,user_id)");
    app_db_create_index('idx_lottery_winners_topic', 'plugin_lottery_winners(topic_id,prize_id,id)');
    app_db_create_table('plugin_lottery_point_ledger', "id {$t['id']},topic_id {$t['uint']} NOT NULL,prize_id {$t['uint']} NOT NULL DEFAULT 0,user_id {$t['uint']} NOT NULL DEFAULT 0,kind {$t['key']} NOT NULL,points {$t['uint']} NOT NULL DEFAULT 0,note {$t['string']} NOT NULL DEFAULT '',created_at {$t['uint']} NOT NULL");
    app_db_create_index('idx_lottery_ledger_topic', 'plugin_lottery_point_ledger(topic_id,id)');
    app_db_create_table('plugin_lottery_claims', "id {$t['id']},topic_id {$t['uint']} NOT NULL,prize_id {$t['uint']} NOT NULL,user_id {$t['uint']} NOT NULL,status {$t['key']} NOT NULL DEFAULT 'pending',deadline_at {$t['uint']} NOT NULL DEFAULT 0,note {$t['string']} NOT NULL DEFAULT '',created_at {$t['uint']} NOT NULL,updated_at {$t['uint']} NOT NULL,UNIQUE(topic_id,prize_id,user_id)");
    app_db_create_index('idx_lottery_claims_topic', 'plugin_lottery_claims(topic_id,status,id)');
    $existing = q('SELECT topic_id,entry_count,status FROM plugin_lottery_draws')->fetchAll();
    foreach ($existing as $row) {
        $topic_id = (int)$row['topic_id'];
        lottery_rules_refresh($topic_id);
        if ((string)$row['status'] === 'open') lottery_reconcile_entries($topic_id);
        elseif ((int)$row['entry_count'] > 0) q('UPDATE plugin_lottery_draws SET rules_locked=1 WHERE topic_id=?', [$topic_id]);
    }
}

function lottery_uninstall(array $plugin): void
{
    app_db_drop_index('idx_lottery_due', 'plugin_lottery_draws');
    app_db_drop_index('idx_lottery_prizes_topic', 'plugin_lottery_prizes');
    app_db_drop_index('idx_lottery_entries_topic', 'plugin_lottery_entries');
    app_db_drop_index('idx_lottery_claims_topic', 'plugin_lottery_claims');
    app_db_drop_index('idx_lottery_ledger_topic', 'plugin_lottery_point_ledger');
    app_db_drop_index('idx_lottery_winners_topic', 'plugin_lottery_winners');
    app_db_drop_table('plugin_lottery_claims');
    app_db_drop_table('plugin_lottery_point_ledger');
    app_db_drop_table('plugin_lottery_winners');
    app_db_drop_table('plugin_lottery_entries');
    app_db_drop_table('plugin_lottery_prizes');
    app_db_drop_table('plugin_lottery_draws');
}

function lottery_prefetch(array $topic_ids): void
{
    $ids = [];
    foreach ($topic_ids as $topic_id) {
        $topic_id = (int)$topic_id;
        if ($topic_id > 0 && !array_key_exists($topic_id, $GLOBALS['__lottery_draws'] ?? [])) $ids[$topic_id] = $topic_id;
    }
    if (!$ids) return;
    $ids = array_values($ids);
    foreach (q('SELECT * FROM plugin_lottery_draws WHERE topic_id IN (' . sql_marks(count($ids)) . ')', $ids)->fetchAll() as $row) {
        $GLOBALS['__lottery_draws'][(int)$row['topic_id']] = $row;
    }
    foreach ($ids as $id) $GLOBALS['__lottery_draws'][$id] ??= false;
}

function lottery_cached(int $topic_id): ?array
{
    $row = $GLOBALS['__lottery_draws'][$topic_id] ?? null;
    return is_array($row) ? $row : null;
}

function lottery_load(int $topic_id): ?array
{
    lottery_prefetch([$topic_id]);
    return lottery_cached($topic_id);
}

function lottery_forget(int $topic_id): void
{
    unset($GLOBALS['__lottery_draws'][$topic_id]);
}

function lottery_draw_for_update(int $topic_id): ?array
{
    $sql = 'SELECT * FROM plugin_lottery_draws WHERE topic_id=?';
    if (db_driver() !== 'sqlite') $sql .= ' FOR UPDATE';
    return one($sql, [$topic_id]);
}

function lottery_prizes_map(array $topic_ids): array
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $topic_ids))));
    if (!$ids) return [];
    $rows = q('SELECT * FROM plugin_lottery_prizes WHERE topic_id IN (' . sql_marks(count($ids)) . ') ORDER BY sort_order,id', $ids)->fetchAll();
    $map = array_fill_keys($ids, []);
    foreach ($rows as $row) {
        $map[(int)$row['topic_id']][] = $row;
    }
    return $map;
}

function lottery_prizes(int $topic_id): array
{
    return lottery_prizes_map([$topic_id])[$topic_id] ?? [];
}

function lottery_point_ledger_add(int $topic_id, int $prize_id, int $user_id, string $kind, int $points, string $note): void
{
    if ($topic_id <= 0 || $points <= 0) return;
    q('INSERT INTO plugin_lottery_point_ledger(topic_id,prize_id,user_id,kind,points,note,created_at) VALUES(?,?,?,?,?,?,?)', [
        $topic_id, max(0, $prize_id), max(0, $user_id), cut($kind, 40), $points, cut($note, 255), now(),
    ]);
}

function lottery_rules_snapshot(array $draw, array $prizes): string
{
    $prize_rows = [];
    foreach ($prizes as $prize) {
        $prize_rows[] = [
            'id' => (int)($prize['id'] ?? 0),
            'name' => (string)($prize['name'] ?? ''),
            'kind' => (string)($prize['kind'] ?? ''),
            'quantity' => (int)($prize['quantity'] ?? 0),
            'unit_points' => (int)($prize['unit_points'] ?? 0),
            'sort_order' => (int)($prize['sort_order'] ?? 0),
        ];
    }
    return json_encode([
        'version' => LOTTERY_RULES_VERSION,
        'min_chars' => (int)($draw['min_chars'] ?? 0),
        'draw_at' => (int)($draw['draw_at'] ?? 0),
        'draw_count' => (int)($draw['draw_count'] ?? 0),
        'min_entries' => (int)($draw['min_entries'] ?? 0),
        'insufficient_action' => (string)($draw['insufficient_action'] ?? 'wait'),
        'postpone_hours' => (int)($draw['postpone_hours'] ?? 0),
        'max_postpones' => (int)($draw['max_postpones'] ?? 0),
        'eligibility_groups' => lottery_csv_ids($draw['eligibility_groups'] ?? ''),
        'min_account_days' => (int)($draw['min_account_days'] ?? 0),
        'min_user_points' => (int)($draw['min_user_points'] ?? 0),
        'exclude_restricted' => (int)($draw['exclude_restricted'] ?? 1),
        'claim_days' => (int)($draw['claim_days'] ?? 0),
        'prizes' => $prize_rows,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
}

function lottery_rules_refresh(int $topic_id): void
{
    $draw = one('SELECT * FROM plugin_lottery_draws WHERE topic_id=?', [$topic_id]);
    if (!$draw || (int)($draw['rules_locked'] ?? 0) === 1) return;
    $snapshot = lottery_rules_snapshot($draw, lottery_prizes($topic_id));
    $hash = hash('sha256', (string)$draw['seed'] . "\n" . $snapshot);
    q('UPDATE plugin_lottery_draws SET rules_snapshot=?,rules_hash=? WHERE topic_id=? AND rules_locked=0', [$snapshot, $hash, $topic_id]);
}

function lottery_can_manage(array $topic): bool
{
    if (!uid()) return false;
    return (int)($topic['user_id'] ?? 0) === uid() || can_manage_topic($topic);
}

function lottery_condition_text(array $draw): string
{
    $parts = [];
    if ((int)$draw['draw_at'] > 0) $parts[] = '到 ' . date('Y-m-d H:i', (int)$draw['draw_at']);
    if ((int)$draw['draw_count'] > 0) $parts[] = '满 ' . (int)$draw['draw_count'] . ' 人';
    return $parts ? implode(' 或 ', $parts) . '自动开奖' : '由发起人手动开奖';
}

function lottery_after_view($value, array $ctx): void
{
    $topic = is_array($ctx['topic'] ?? null) ? $ctx['topic'] : [];
    $topic_id = (int)($topic['id'] ?? 0);
    if ($topic_id <= 0) return;
    lottery_prefetch([$topic_id]);
    $draw = lottery_cached($topic_id);
    if (!$draw) return;
    $GLOBALS['__lottery_view'] = [
        'topic' => $topic,
        'prizes' => lottery_prizes($topic_id),
        'entered' => uid() > 0 && (int)val('SELECT COUNT(*) FROM plugin_lottery_entries WHERE topic_id=? AND user_id=?', [$topic_id, uid()]) > 0,
        'eligibility_reason' => uid() > 0 ? lottery_eligibility_reason($draw, uid()) : '',
        'winners' => (string)$draw['status'] === 'drawn'
            ? q('SELECT w.prize_id,w.prize_name,w.user_id,u.username FROM plugin_lottery_winners w LEFT JOIN app_users u ON u.id=w.user_id WHERE w.topic_id=? ORDER BY w.prize_id,w.id', [$topic_id])->fetchAll()
            : [],
        'claims' => (string)$draw['status'] === 'drawn'
            ? q('SELECT prize_id,user_id,status,deadline_at,note FROM plugin_lottery_claims WHERE topic_id=? ORDER BY id', [$topic_id])->fetchAll()
            : [],
        'ledger' => q("SELECT kind,COALESCE(SUM(points),0) points FROM plugin_lottery_point_ledger WHERE topic_id=? GROUP BY kind", [$topic_id])->fetchAll(),
    ];
}

function lottery_index_loaded($value, array $ctx): void
{
    $rows = is_array($value['rows'] ?? null) ? $value['rows'] : [];
    lottery_prefetch(array_map(static fn(array $row): int => (int)($row['id'] ?? 0), $rows));
}

function lottery_title_suffix($html, array $ctx): string
{
    $row = is_array($ctx['row'] ?? null) ? $ctx['row'] : [];
    $draw = lottery_cached((int)($row['id'] ?? 0));
    if (!$draw) return (string)$html;
    $status = (string)$draw['status'];
    $label = $status === 'open' ? '抽奖中' : ($status === 'cancelled' ? '已取消' : '已开奖');
    return (string)$html . '<span class="lottery-title-status ' . ($status === 'open' ? 'open' : 'done') . '">' . $label . '</span>';
}

function lottery_topic_actions($html, array $ctx): string
{
    $topic = is_array($ctx['topic'] ?? null) ? $ctx['topic'] : [];
    $topic_id = (int)($topic['id'] ?? 0);
    if ($topic_id <= 0 || !lottery_can_manage($topic)) return (string)$html;
    $draw = lottery_cached($topic_id);
    $label = $draw ? '抽奖设置' : '设为抽奖帖';
    return (string)$html . '<a class="icon-action lottery-manage-link" href="' . h(route_url('lottery_manage', ['topic_id' => $topic_id])) . '" title="' . h($label) . '">'
        . '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 12v7a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-7M3 8h18v4H3zM12 8v12M12 8S9 3 6.5 4.5 8 8 12 8Zm0 0s3-5 5.5-3.5S16 8 12 8Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>'
        . '<span>' . h($label) . '</span></a>';
}

function lottery_form_extra($html, array $ctx): string
{
    $html = is_string($html) ? $html : '';
    $topic = is_array($ctx['topic'] ?? null) ? $ctx['topic'] : [];
    $topic_id = (int)($topic['id'] ?? 0);
    if ($topic_id > 0) {
        if (!lottery_can_manage($topic)) return $html;
        $draw = lottery_load($topic_id);
        $label = $draw ? ((string)$draw['status'] === 'open' ? '本帖是抽奖帖，去设置奖品和开奖条件' : '本帖抽奖已开奖，查看中奖名单') : '把本帖设为抽奖帖';
        return $html . '<div class="lottery-compose"><div class="lottery-compose-head"><strong>抽奖</strong>'
            . '<a href="' . h(route_url('lottery_manage', ['topic_id' => $topic_id])) . '">' . h($label) . ' →</a></div></div>';
    }
    if (!uid()) return $html;
    $blocked = lottery_create_blocked_reason(uid());
    if ($blocked !== '' && !lottery_group_allowed()) return $html;
    $config = lottery_config();
    $min_chars = min(200, max(1, (int)$config['default_min_chars']));
    if ($blocked !== '') {
        return $html . '<div class="lottery-compose"><div class="lottery-compose-head"><strong>抽奖</strong></div>'
            . '<p class="lottery-compose-note">' . h($blocked) . '</p></div>';
    }
    $options = '';
    foreach (lottery_kinds() as $key => $kind) $options .= '<option value="' . h($key) . '">' . h($kind['label']) . '</option>';
    $insufficient_options = '';
    $default_action = (string)$config['default_insufficient_action'];
    foreach (lottery_insufficient_actions() as $key => $label) {
        $insufficient_options .= '<option value="' . h($key) . '"' . ($key === $default_action ? ' selected' : '') . '>' . h($label) . '</option>';
    }
    return $html . '<div class="lottery-compose"><details class="lottery-compose-details"><summary>设为抽奖帖</summary>'
        . '<div class="lottery-compose-body">'
        . '<label class="lottery-compose-toggle"><input type="checkbox" name="lottery_enabled" value="1"><span>发布后把本帖变成抽奖帖</span></label>'
        . '<div class="lottery-compose-grid">'
        . '<label class="grid"><span>参与门槛（回复字数）</span><input name="lottery_min_chars" type="number" value="' . $min_chars . '" min="1" max="200"></label>'
        . '<label class="grid"><span>定时开奖（可留空）</span><input name="lottery_draw_at" type="datetime-local"></label>'
        . '<label class="grid"><span>满多少人开奖（0 为不限）</span><input name="lottery_draw_count" type="number" value="0" min="0" max="100000"></label>'
        . '</div>'
        . '<div class="lottery-compose-grid">'
        . '<label class="grid"><span>奖品名称</span><input name="lottery_prize_name" type="text" maxlength="120" placeholder="例如 10 刀兑换码"></label>'
        . '<label class="grid"><span>奖品类型</span><select name="lottery_prize_kind">' . $options . '</select></label>'
        . '<label class="grid"><span>份数</span><input name="lottery_prize_quantity" type="number" value="1" min="1" max="1000"></label>'
        . '<label class="grid"><span>每份积分（仅积分奖）</span><input name="lottery_prize_points" type="number" value="0" min="0" max="100000"></label>'
        . '</div>'
        . '<details class="lottery-compose-advanced"><summary>可选高级规则</summary>'
        . '<div class="lottery-compose-grid">'
        . '<label class="grid"><span>最低参与人数</span><input name="lottery_min_entries" type="number" value="' . max(0, (int)$config['default_min_entries']) . '" min="0" max="100000"></label>'
        . '<label class="grid"><span>人数不足时</span><select name="lottery_insufficient_action">' . $insufficient_options . '</select></label>'
        . '<label class="grid"><span>每次延期小时</span><input name="lottery_postpone_hours" type="number" value="' . max(1, (int)$config['default_postpone_hours']) . '" min="1" max="720"></label>'
        . '<label class="grid"><span>最多自动延期</span><input name="lottery_max_postpones" type="number" value="' . max(0, (int)$config['default_max_postpones']) . '" min="0" max="20"></label>'
        . '<label class="grid"><span>账号至少注册天数</span><input name="lottery_min_account_days" type="number" value="' . max(0, (int)$config['default_min_account_days']) . '" min="0" max="3650"></label>'
        . '<label class="grid"><span>参与所需最低积分</span><input name="lottery_min_user_points" type="number" value="' . max(0, (int)$config['default_min_user_points']) . '" min="0" max="100000000"></label>'
        . '<label class="grid"><span>手工奖领取期限（天）</span><input name="lottery_claim_days" type="number" value="' . max(0, (int)$config['default_claim_days']) . '" min="0" max="365"></label>'
        . '</div><div class="grid"><span>允许参与的用户组<small>全不勾选表示全部用户组</small></span><div class="lottery-group-checks">' . lottery_group_checks('lottery_eligible_groups', []) . '</div></div>'
        . '<label class="lottery-compose-toggle"><input type="checkbox" name="lottery_exclude_restricted" value="1" checked><span>排除被禁言或封禁的用户</span></label>'
        . '</details>'
        . '<p class="lottery-compose-note">积分奖会按“份数 × 每份积分”预先扣除奖池，发布后不退。第一个有效参与者出现后，开奖规则和奖品会锁定。</p>'
        . '</div></details></div>';
}

function lottery_before_save($value, array $ctx): mixed
{
    if (!empty($ctx['editing']) || empty($_POST['lottery_enabled'])) return $value;
    $prize_name = trim((string)($_POST['lottery_prize_name'] ?? ''));
    $prize_kind = (string)($_POST['lottery_prize_kind'] ?? 'manual');
    $prize_points = $prize_name === '' ? 0 : lottery_prize_points(
        $prize_kind,
        (int)($_POST['lottery_prize_quantity'] ?? 1),
        (int)($_POST['lottery_prize_points'] ?? 0)
    );
    $blocked = lottery_create_blocked_reason(uid(), $prize_points);
    if ($blocked !== '') err($blocked);
    $raw_at = trim((string)($_POST['lottery_draw_at'] ?? ''));
    if ($raw_at !== '') {
        $draw_at = (int)strtotime($raw_at);
        if ($draw_at <= 0) err('抽奖的开奖时间格式无效');
        if ($draw_at <= now()) err('抽奖的开奖时间必须晚于当前时间');
    }
    $rules = lottery_rule_values('lottery_', []);
    $draw_count = max(0, (int)($_POST['lottery_draw_count'] ?? 0));
    if ($draw_count > 0 && $rules['min_entries'] > $draw_count) err('最低参与人数不能大于满人数开奖条件');
    return $value;
}

function lottery_topic_after_save($value, array $ctx): void
{
    if (!empty($ctx['editing']) || empty($_POST['lottery_enabled'])) return;
    $topic_id = (int)($ctx['id'] ?? 0);
    $creator_id = (int)($ctx['user_id'] ?? uid());
    if ($topic_id <= 0 || $creator_id <= 0) return;
    $config = lottery_config();
    $raw_at = trim((string)($_POST['lottery_draw_at'] ?? ''));
    $draw_at = $raw_at !== '' ? max(0, (int)strtotime($raw_at)) : 0;
    if ($draw_at > 0 && $draw_at <= now()) $draw_at = 0;
    $prize_name = trim((string)($_POST['lottery_prize_name'] ?? ''));
    $prize_kind = (string)($_POST['lottery_prize_kind'] ?? 'manual');
    if (!isset(lottery_kinds()[$prize_kind])) $prize_kind = 'manual';
    $prize_quantity = min(1000, max(1, (int)($_POST['lottery_prize_quantity'] ?? 1)));
    $prize_unit_points = $prize_kind === 'points' ? min(100000, max(0, (int)($_POST['lottery_prize_points'] ?? 0))) : 0;
    $deposit = $prize_name === '' ? 0 : lottery_prize_points($prize_kind, $prize_quantity, $prize_unit_points);
    $blocked = lottery_create_blocked_reason($creator_id, $deposit);
    if ($blocked !== '') err($blocked);
    $rules = lottery_rule_values('lottery_', [
        'min_entries' => $config['default_min_entries'],
        'insufficient_action' => $config['default_insufficient_action'],
        'postpone_hours' => $config['default_postpone_hours'],
        'max_postpones' => $config['default_max_postpones'],
        'min_account_days' => $config['default_min_account_days'],
        'min_user_points' => $config['default_min_user_points'],
        'claim_days' => $config['default_claim_days'],
    ]);
    $seed = bin2hex(random_bytes(16));
    tx(function () use ($topic_id, $creator_id, $config, $draw_at, $deposit, $seed, $prize_name, $prize_kind, $prize_quantity, $prize_unit_points, $rules): void {
        lottery_reserve_points($creator_id, $deposit);
        app_db_upsert('plugin_lottery_draws', [
            'topic_id' => $topic_id,
            'creator_id' => $creator_id,
            'min_chars' => min(200, max(1, (int)($_POST['lottery_min_chars'] ?? $config['default_min_chars']))),
            'draw_at' => $draw_at,
            'draw_count' => min(100000, max(0, (int)($_POST['lottery_draw_count'] ?? 0))),
            'status' => 'open',
            'entry_count' => 0,
            'commit_hash' => hash('sha256', $seed),
            'seed' => $seed,
            'deposit_points' => $deposit,
            'min_entries' => $rules['min_entries'],
            'insufficient_action' => $rules['insufficient_action'],
            'postpone_hours' => $rules['postpone_hours'],
            'max_postpones' => $rules['max_postpones'],
            'postpone_count' => 0,
            'eligibility_groups' => $rules['eligibility_groups'],
            'min_account_days' => $rules['min_account_days'],
            'min_user_points' => $rules['min_user_points'],
            'exclude_restricted' => $rules['exclude_restricted'],
            'claim_days' => $rules['claim_days'],
            'rules_locked' => 0,
            'rules_hash' => '',
            'rules_snapshot' => null,
            'drawn_at' => 0,
            'created_at' => now(),
        ], ['topic_id']);
        if ($prize_name !== '') {
            q('INSERT INTO plugin_lottery_prizes(topic_id,name,kind,quantity,unit_points,sort_order) VALUES(?,?,?,?,?,?)', [
                $topic_id,
                cut($prize_name, 120),
                $prize_kind,
                $prize_quantity,
                $prize_unit_points,
                1,
            ]);
            $prize_id = (int)db()->lastInsertId();
            if ($deposit > 0) lottery_point_ledger_add($topic_id, $prize_id, $creator_id, 'reserve', $deposit, '发布抽奖时预付奖池');
        }
    });
    lottery_rules_refresh($topic_id);
    lottery_forget($topic_id);
}

function lottery_card_html(array $draw, array $view): string
{
    $topic_id = (int)$draw['topic_id'];
    $open = (string)$draw['status'] === 'open';
    $kinds = lottery_kinds();
    $prizes = is_array($view['prizes'] ?? null) ? $view['prizes'] : [];
    $total_shares = 0;
    $items = '';
    foreach ($prizes as $prize) {
        $kind = (string)$prize['kind'];
        $quantity = max(1, (int)$prize['quantity']);
        $total_shares += $quantity;
        $meta = ($kinds[$kind]['label'] ?? $kind) . ' · ' . $quantity . ' 份';
        if ($kind === 'points' && (int)$prize['unit_points'] > 0) $meta .= ' · 每份 ' . (int)$prize['unit_points'] . ' 积分';
        $items .= '<li><strong>' . h((string)$prize['name']) . '</strong><span>' . h($meta) . '</span></li>';
    }
    if ($items === '') $items = '<li class="lottery-prize-empty"><strong>还没有设置奖品</strong><span>发起人可在「抽奖设置」里添加</span></li>';
    $entry_count = (int)$draw['entry_count'];
    $head = '<header><div><b>抽奖帖</b><span>回复满 ' . max(1, (int)$draw['min_chars']) . ' 字即参与</span></div><em>' . $entry_count . ' 人参与</em></header>';
    $body = '<ul class="lottery-prizes">' . $items . '</ul>';
    if ($open) {
        $minimum = (int)($draw['min_entries'] ?? 0) > 0 ? ' · 最少 ' . (int)$draw['min_entries'] . ' 人' : '';
        $body .= '<div class="lottery-condition">' . h(lottery_condition_text($draw)) . $minimum . ($total_shares > 0 ? ' · 共 ' . $total_shares . ' 份奖品' : '') . '</div>';
        $eligibility = lottery_eligibility_text($draw);
        if ($eligibility !== '') $body .= '<div class="lottery-eligibility">参与资格：' . h($eligibility) . '</div>';
        if (!uid()) {
            $body .= '<div class="lottery-hint"><a href="' . h(route_url('login')) . '">登录后回复即可参与</a></div>';
        } elseif (uid() === (int)$draw['creator_id']) {
            $body .= '<div class="lottery-hint">你是发起人，不参与本次抽奖。</div>';
        } elseif (!empty($view['entered'])) {
            $body .= '<div class="lottery-hint is-joined">✅ 你已参与本次抽奖，等待开奖。</div>';
        } elseif ((string)($view['eligibility_reason'] ?? '') !== '') {
            $body .= '<div class="lottery-hint is-blocked">暂不能参与：' . h((string)$view['eligibility_reason']) . '。</div>';
        } else {
            $body .= '<div class="lottery-hint">在本帖回复满 ' . max(1, (int)$draw['min_chars']) . ' 字即可参与。</div>';
        }
        if ((string)$draw['commit_hash'] !== '') {
            $body .= '<details class="lottery-fair"><summary>公平性承诺</summary><p>随机种子与完整规则快照都已生成承诺值；首个有效参与者出现后，规则和奖品自动锁定。</p>'
                . '<code>SHA256(seed) = ' . h((string)$draw['commit_hash']) . '</code>'
                . ((string)($draw['rules_hash'] ?? '') !== '' ? '<code>SHA256(seed + rules) = ' . h((string)$draw['rules_hash']) . '</code>' : '') . '</details>';
        }
    } elseif ((string)$draw['status'] === 'cancelled') {
        $body .= '<div class="lottery-result"><div class="lottery-result-head"><b>抽奖已取消</b><span>' . date('Y-m-d H:i', (int)$draw['drawn_at']) . '</span></div>'
            . '<p class="lottery-hint">参与记录、奖品快照和奖池流水均已保留，预付积分不退还。</p></div>';
    } else {
        $winners = is_array($view['winners'] ?? null) ? $view['winners'] : [];
        $claims = [];
        foreach (is_array($view['claims'] ?? null) ? $view['claims'] : [] as $claim) {
            $claims[(int)$claim['prize_id'] . ':' . (int)$claim['user_id']] = $claim;
        }
        $groups = [];
        foreach ($winners as $winner) $groups[(int)$winner['prize_id']][] = $winner;
        $won = '';
        foreach ($prizes as $prize) {
            $list = $groups[(int)$prize['id']] ?? [];
            $names = [];
            foreach ($list as $winner) {
                $winner_id = (int)$winner['user_id'];
                $name = h((string)($winner['username'] ?? ('用户 ' . $winner_id)));
                $claim = $claims[(int)$prize['id'] . ':' . $winner_id] ?? null;
                if (is_array($claim)) {
                    $labels = ['pending' => '待发奖', 'sent' => '已发送', 'confirmed' => '已确认', 'disputed' => '有申诉'];
                    $name .= ' <em>' . h($labels[(string)$claim['status']] ?? (string)$claim['status']) . '</em>';
                    if ($winner_id === uid() && in_array((string)$claim['status'], ['sent', 'pending'], true)) {
                        $name .= ' <a href="' . h(route_url('lottery_claim', ['topic_id' => $topic_id])) . '">处理领取</a>';
                    }
                }
                $names[] = $name;
            }
            $won .= '<li><strong>' . h((string)$prize['name']) . '</strong><span>' . ($names ? implode('、', $names) : '无人中奖') . '</span></li>';
        }
        $body .= '<div class="lottery-result"><div class="lottery-result-head"><b>🎉 中奖名单</b><span>' . date('Y-m-d H:i', (int)$draw['drawn_at']) . ' 开奖 · ' . count($winners) . ' 人中奖</span></div>'
            . '<ul class="lottery-winners">' . ($won !== '' ? $won : '<li><strong>无奖品</strong><span>-</span></li>') . '</ul></div>';
        $body .= '<details class="lottery-fair"><summary>开奖如何复核</summary>'
            . '<p>把种子和参与者 ID 拼成 <code>seed:用户ID</code> 求 SHA256，按结果从小到大排序，再按奖品顺序依次取人，即可完整复现名单。</p>'
            . '<code>seed = ' . h((string)$draw['seed']) . '</code>'
            . '<code>SHA256(seed) = ' . h((string)$draw['commit_hash']) . '</code>'
            . ((string)($draw['rules_hash'] ?? '') !== '' ? '<code>SHA256(seed + rules) = ' . h((string)$draw['rules_hash']) . '</code>' : '') . '</details>';
    }
    $ledger = [];
    foreach (is_array($view['ledger'] ?? null) ? $view['ledger'] : [] as $row) $ledger[(string)$row['kind']] = (int)$row['points'];
    if ($ledger) {
        $reserved = (int)($ledger['reserve'] ?? 0);
        $awarded = (int)($ledger['award'] ?? 0);
        $forfeited = (int)($ledger['forfeit'] ?? 0);
        $body .= '<div class="lottery-ledger">奖池流水：累计预付 ' . $reserved . ' · 已发放 ' . $awarded
            . ' · 尚未发放 ' . max(0, $reserved - $awarded) . ($forfeited > 0 ? '（其中已作废 ' . $forfeited . '）' : '') . ' 积分</div>';
    }
    $manage = '';
    if (is_array($view['topic'] ?? null) && lottery_can_manage($view['topic'])) {
        $manage = '<a class="lottery-card-manage" href="' . h(route_url('lottery_manage', ['topic_id' => $topic_id])) . '">抽奖设置 →</a>';
    }
    return '<li class="lottery-card-item"><section class="lottery-card' . ($open ? '' : ' is-done') . '">' . $head . $body . $manage . '</section></li>';
}

function lottery_topic_after_render($html, array $ctx): string
{
    if (!empty($ctx['list'])) return (string)$html;
    $row = is_array($ctx['row'] ?? null) ? $ctx['row'] : [];
    $topic_id = (int)($row['id'] ?? 0);
    if ($topic_id <= 0 || isset($row['topic_id'])) return (string)$html;
    $draw = lottery_cached($topic_id);
    $view = is_array($GLOBALS['__lottery_view'] ?? null) ? $GLOBALS['__lottery_view'] : [];
    if (!$draw || (int)(($view['topic']['id'] ?? 0)) !== $topic_id) return (string)$html;
    return (string)$html . lottery_card_html($draw, $view);
}

function lottery_reply_after_save($value, array $ctx): void
{
    if (!empty($ctx['editing'])) return;
    $topic_id = (int)($ctx['topic_id'] ?? 0);
    $reply_id = (int)($ctx['id'] ?? 0);
    $user_id = (int)($ctx['user_id'] ?? uid());
    if ($topic_id <= 0 || $reply_id <= 0 || $user_id <= 0) return;
    $draw = one('SELECT * FROM plugin_lottery_draws WHERE topic_id=? AND status=?', [$topic_id, 'open']);
    if (!is_array($draw) || $user_id === (int)$draw['creator_id']) return;
    if (search_char_count((string)($ctx['body'] ?? '')) < max(1, (int)$draw['min_chars'])) return;
    if (lottery_eligibility_reason($draw, $user_id) !== '') return;
    $entry_count = tx(function () use ($topic_id, $user_id, $reply_id): int {
        $current = lottery_draw_for_update($topic_id);
        if (!$current || (string)$current['status'] !== 'open') return -1;
        $driver = db_driver();
        $sql = 'INSERT INTO plugin_lottery_entries(topic_id,user_id,reply_id,created_at) VALUES(?,?,?,?)';
        $sql = $driver === 'mysql' ? str_replace('INSERT INTO', 'INSERT IGNORE INTO', $sql) : $sql . ' ON CONFLICT(topic_id,user_id) DO NOTHING';
        $inserted = q($sql, [$topic_id, $user_id, $reply_id, now()])->rowCount();
        if ($inserted < 1) return (int)$current['entry_count'];
        q('UPDATE plugin_lottery_draws SET entry_count=entry_count+1,rules_locked=1 WHERE topic_id=? AND status=?', [$topic_id, 'open']);
        return (int)$current['entry_count'] + 1;
    });
    if ($entry_count < 0) return;
    lottery_forget($topic_id);
    $target = (int)$draw['draw_count'];
    if ($target > 0 && $entry_count >= $target) {
        q('UPDATE plugin_lottery_draws SET draw_at=? WHERE topic_id=? AND status=?', [now(), $topic_id, 'open']);
        lottery_forget($topic_id);
    }
}

function lottery_execute_draw(int $topic_id, array $prizes, bool $force = false): bool
{
    $result = tx(function () use ($topic_id, $prizes, $force): ?array {
        $draw = lottery_draw_for_update($topic_id);
        if (!is_array($draw) || (string)$draw['status'] !== 'open') return null;
        $entries = (int)$draw['entry_count'];
        $minimum = max(0, (int)($draw['min_entries'] ?? 0));
        if (!$force && $minimum > 0 && $entries < $minimum) {
            $action = (string)($draw['insufficient_action'] ?? 'wait');
            if ($action === 'postpone' && (int)$draw['draw_at'] > 0 && (int)$draw['postpone_count'] < (int)$draw['max_postpones']) {
                $next = now() + max(1, (int)$draw['postpone_hours']) * 3600;
                q('UPDATE plugin_lottery_draws SET draw_at=?,postpone_count=postpone_count+1 WHERE topic_id=? AND status=?', [$next, $topic_id, 'open']);
                create_notification((int)$draw['creator_id'], 0, 'lottery', '抽奖参与人数不足，已自动延期到 ' . date('Y-m-d H:i', $next) . '。', $topic_id);
                return ['outcome' => 'postponed'];
            }
            if ($action !== 'draw') {
                q('UPDATE plugin_lottery_draws SET draw_at=0 WHERE topic_id=? AND status=?', [$topic_id, 'open']);
                create_notification((int)$draw['creator_id'], 0, 'lottery', '抽奖参与人数不足，已暂停自动开奖，请手动处理。', $topic_id);
                return ['outcome' => 'waiting'];
            }
        }
        $claimed = q("UPDATE plugin_lottery_draws SET status='drawn',rules_locked=1,drawn_at=? WHERE topic_id=? AND status='open'", [now(), $topic_id])->rowCount();
        if ($claimed < 1) return null;
        $seed = (string)$draw['seed'];
        $entry_rows = q('SELECT user_id FROM plugin_lottery_entries WHERE topic_id=? ORDER BY id', [$topic_id])->fetchAll();
        $pool = [];
        foreach ($entry_rows as $entry) {
            $user_id = (int)$entry['user_id'];
            $pool[] = ['user_id' => $user_id, 'ticket' => hash('sha256', $seed . ':' . $user_id)];
        }
        usort($pool, static fn(array $a, array $b): int => [$a['ticket'], $a['user_id']] <=> [$b['ticket'], $b['user_id']]);
        $topic = row('app_topics', 'id', $topic_id);
        $title = cut((string)($topic['title'] ?? ''), 60);
        $index = 0;
        $count = count($pool);
        $awards = [];
        foreach ($prizes as $prize) {
            $quantity = max(1, (int)$prize['quantity']);
            $awarded = 0;
            for ($i = 0; $i < $quantity && $index < $count; $i++, $index++) {
                $winner = (int)$pool[$index]['user_id'];
                app_db_insert_ignore('plugin_lottery_winners', [
                    'topic_id' => $topic_id,
                    'prize_id' => (int)$prize['id'],
                    'user_id' => $winner,
                    'prize_name' => cut((string)$prize['name'], 120),
                    'created_at' => now(),
                ], ['topic_id', 'user_id']);
                $awarded++;
                $awards[] = [
                    'prize_id' => (int)$prize['id'],
                    'kind' => (string)$prize['kind'],
                    'user_id' => $winner,
                    'points' => (string)$prize['kind'] === 'points' ? max(0, (int)$prize['unit_points']) : 0,
                    'prize' => cut((string)$prize['name'], 60),
                    'creator_id' => (int)$draw['creator_id'],
                    'title' => $title,
                ];
            }
            if ((string)$prize['kind'] === 'points' && $awarded < $quantity) {
                lottery_point_ledger_add($topic_id, (int)$prize['id'], (int)$draw['creator_id'], 'forfeit', ($quantity - $awarded) * max(0, (int)$prize['unit_points']), '参与人数不足，剩余预付积分不退');
            }
        }
        foreach ($awards as $award) {
            if ($award['points'] > 0) {
                q('UPDATE app_users SET points=points+? WHERE id=?', [(int)$award['points'], (int)$award['user_id']]);
                $now_points = lottery_user_points((int)$award['user_id']);
                create_notification((int)$award['user_id'], 0, 'points', '你的积分增加 ' . (int)$award['points'] . '，原因：抽奖奖励。当前积分 ' . $now_points . '。');
                lottery_point_ledger_add($topic_id, (int)$award['prize_id'], (int)$award['user_id'], 'award', (int)$award['points'], '积分奖自动发放');
            } else {
                $deadline = (int)$draw['claim_days'] > 0 ? now() + (int)$draw['claim_days'] * 86400 : 0;
                app_db_insert_ignore('plugin_lottery_claims', [
                    'topic_id' => $topic_id,
                    'prize_id' => (int)$award['prize_id'],
                    'user_id' => (int)$award['user_id'],
                    'status' => 'pending',
                    'deadline_at' => $deadline,
                    'note' => '',
                    'created_at' => now(),
                    'updated_at' => now(),
                ], ['topic_id', 'prize_id', 'user_id']);
            }
            create_notification((int)$award['user_id'], (int)$award['creator_id'], 'lottery', '你在抽奖《' . $award['title'] . '》中获得：' . $award['prize'], $topic_id);
        }
        return ['outcome' => 'drawn', 'awards' => $awards];
    });
    lottery_forget($topic_id);
    return is_array($result) && (string)($result['outcome'] ?? '') === 'drawn';
}

function lottery_cron_draw(array $plugin, array $task): string
{
    $rows = q("SELECT topic_id FROM plugin_lottery_draws WHERE status='open' AND draw_at>0 AND draw_at<=? ORDER BY draw_at LIMIT 50", [now()])->fetchAll();
    $topic_ids = array_map(static fn(array $row): int => (int)$row['topic_id'], $rows);
    $prize_map = lottery_prizes_map($topic_ids);
    $drawn = 0;
    foreach ($topic_ids as $topic_id) {
        if (lottery_execute_draw($topic_id, $prize_map[$topic_id] ?? [])) $drawn++;
    }
    return $drawn > 0 ? '已开奖 ' . $drawn . ' 个抽奖帖' : '没有到期的抽奖';
}

function lottery_cron_interval(array $plugin, array $task): int
{
    return 60;
}

function lottery_manage_page(array $plugin): void
{
    need_login();
    $topic_id = max(1, (int)($_GET['topic_id'] ?? $_POST['topic_id'] ?? 0));
    $topic = row('app_topics', 'id', $topic_id) ?: err('主题不存在');
    if (!lottery_can_manage($topic)) err('只有发起人或管理员可以设置抽奖');
    if (is_post_request()) {
        require_post();
        $action = (string)($_POST['lottery_action'] ?? '');
        $draw = lottery_load($topic_id);
        if ($action === 'save') {
            $min_chars = min(200, max(1, (int)($_POST['min_chars'] ?? 5)));
            $draw_count = min(100000, max(0, (int)($_POST['draw_count'] ?? 0)));
            $raw_at = trim((string)($_POST['draw_at'] ?? ''));
            $draw_at = $raw_at !== '' ? (int)strtotime($raw_at) : 0;
            if ($raw_at !== '' && $draw_at <= 0) err('开奖时间格式无效');
            if ($draw_at > 0 && $draw_at <= now()) err('开奖时间必须晚于当前时间');
            $rules = lottery_rule_values('', $draw ?: [
                'min_entries' => lottery_config()['default_min_entries'],
                'insufficient_action' => lottery_config()['default_insufficient_action'],
                'postpone_hours' => lottery_config()['default_postpone_hours'],
                'max_postpones' => lottery_config()['default_max_postpones'],
                'min_account_days' => lottery_config()['default_min_account_days'],
                'min_user_points' => lottery_config()['default_min_user_points'],
                'claim_days' => lottery_config()['default_claim_days'],
            ]);
            if ($draw_count > 0 && $rules['min_entries'] > $draw_count) err('最低参与人数不能大于满人数开奖条件');
            if ($draw) {
                if ((string)$draw['status'] !== 'open') err('已开奖的抽奖不能再修改');
                if ((int)($draw['rules_locked'] ?? 0) === 1) err('已有参与者，抽奖规则和奖品已经锁定');
                q('UPDATE plugin_lottery_draws SET min_chars=?,draw_at=?,draw_count=?,min_entries=?,insufficient_action=?,postpone_hours=?,max_postpones=?,eligibility_groups=?,min_account_days=?,min_user_points=?,exclude_restricted=?,claim_days=? WHERE topic_id=?', [
                    $min_chars, $draw_at, $draw_count, $rules['min_entries'], $rules['insufficient_action'], $rules['postpone_hours'], $rules['max_postpones'], $rules['eligibility_groups'], $rules['min_account_days'], $rules['min_user_points'], $rules['exclude_restricted'], $rules['claim_days'], $topic_id,
                ]);
                lottery_rules_refresh($topic_id);
                set_flash('抽奖设置已保存');
            } else {
                $creator_id = (int)$topic['user_id'];
                $blocked = lottery_create_blocked_reason($creator_id);
                if ($blocked !== '') err($blocked);
                $seed = bin2hex(random_bytes(16));
                app_db_upsert('plugin_lottery_draws', [
                    'topic_id' => $topic_id,
                    'creator_id' => $creator_id,
                    'min_chars' => $min_chars,
                    'draw_at' => $draw_at,
                    'draw_count' => $draw_count,
                    'status' => 'open',
                    'entry_count' => 0,
                    'commit_hash' => hash('sha256', $seed),
                    'seed' => $seed,
                    'deposit_points' => 0,
                    'min_entries' => $rules['min_entries'],
                    'insufficient_action' => $rules['insufficient_action'],
                    'postpone_hours' => $rules['postpone_hours'],
                    'max_postpones' => $rules['max_postpones'],
                    'postpone_count' => 0,
                    'eligibility_groups' => $rules['eligibility_groups'],
                    'min_account_days' => $rules['min_account_days'],
                    'min_user_points' => $rules['min_user_points'],
                    'exclude_restricted' => $rules['exclude_restricted'],
                    'claim_days' => $rules['claim_days'],
                    'rules_locked' => 0,
                    'rules_hash' => '',
                    'rules_snapshot' => null,
                    'drawn_at' => 0,
                    'created_at' => now(),
                ], ['topic_id']);
                lottery_rules_refresh($topic_id);
                lottery_reconcile_entries($topic_id);
                set_flash('已设为抽奖帖，已有符合条件的回复已计入参与人数');
            }
        } elseif ($action === 'prize_add') {
            if (!$draw) err('请先保存抽奖设置');
            if ((string)$draw['status'] !== 'open') err('已开奖的抽奖不能再改奖品');
            if ((int)($draw['rules_locked'] ?? 0) === 1) err('已有参与者，抽奖规则和奖品已经锁定');
            if ((int)val('SELECT COUNT(*) FROM plugin_lottery_prizes WHERE topic_id=?', [$topic_id]) >= LOTTERY_MAX_PRIZES) err('奖品数量已达上限');
            $name = trim((string)($_POST['prize_name'] ?? ''));
            $kind = (string)($_POST['prize_kind'] ?? 'manual');
            if ($name === '') err('请填写奖品名称');
            if (!isset(lottery_kinds()[$kind])) err('奖品类型无效');
            $quantity = min(1000, max(1, (int)($_POST['prize_quantity'] ?? 1)));
            $unit_points = $kind === 'points' ? min(100000, max(0, (int)($_POST['prize_points'] ?? 0))) : 0;
            $deposit = lottery_prize_points($kind, $quantity, $unit_points);
            $sort_order = min(999, max(0, (int)val('SELECT COALESCE(MAX(sort_order),0)+1 FROM plugin_lottery_prizes WHERE topic_id=?', [$topic_id])));
            tx(function () use ($topic_id, $draw, $name, $kind, $quantity, $unit_points, $deposit, $sort_order): void {
                lottery_reserve_points((int)$draw['creator_id'], $deposit);
                q('INSERT INTO plugin_lottery_prizes(topic_id,name,kind,quantity,unit_points,sort_order) VALUES(?,?,?,?,?,?)', [
                    $topic_id, cut($name, 120), $kind, $quantity, $unit_points, $sort_order,
                ]);
                $prize_id = (int)db()->lastInsertId();
                if ($deposit > 0) {
                    q('UPDATE plugin_lottery_draws SET deposit_points=deposit_points+? WHERE topic_id=?', [$deposit, $topic_id]);
                    lottery_point_ledger_add($topic_id, $prize_id, (int)$draw['creator_id'], 'reserve', $deposit, '追加积分奖时预付奖池');
                }
            });
            lottery_rules_refresh($topic_id);
            set_flash('奖品已添加');
        } elseif ($action === 'prize_delete') {
            if (!$draw || (string)$draw['status'] !== 'open') err('已开奖的抽奖不能再改奖品');
            if ((int)($draw['rules_locked'] ?? 0) === 1) err('已有参与者，抽奖规则和奖品已经锁定');
            $prize_id = max(1, (int)($_POST['prize_id'] ?? 0));
            $prize = one('SELECT * FROM plugin_lottery_prizes WHERE id=? AND topic_id=?', [$prize_id, $topic_id]);
            if (!$prize) err('奖品不存在');
            tx(function () use ($topic_id, $prize_id, $prize, $draw): void {
                q('DELETE FROM plugin_lottery_prizes WHERE id=? AND topic_id=?', [$prize_id, $topic_id]);
                $forfeit = lottery_prize_points((string)$prize['kind'], (int)$prize['quantity'], (int)$prize['unit_points']);
                if ($forfeit > 0) lottery_point_ledger_add($topic_id, $prize_id, (int)$draw['creator_id'], 'forfeit', $forfeit, '删除奖品，预付积分不退');
            });
            lottery_rules_refresh($topic_id);
            set_flash('奖品已删除');
        } elseif ($action === 'claim_sent') {
            if (!$draw || (string)$draw['status'] !== 'drawn') err('当前抽奖还没有开奖');
            $claim_id = max(1, (int)($_POST['claim_id'] ?? 0));
            $note = cut(trim((string)($_POST['claim_note'] ?? '')), 255);
            q("UPDATE plugin_lottery_claims SET status='sent',note=?,updated_at=? WHERE id=? AND topic_id=? AND status IN ('pending','disputed')", [$note, now(), $claim_id, $topic_id]);
            set_flash('已标记为已发送，等待获奖者确认');
        } elseif ($action === 'draw_now') {
            if (!$draw || (string)$draw['status'] !== 'open') err('当前抽奖不可开奖');
            if ((int)$draw['entry_count'] <= 0) err('还没有人参与，无法开奖');
            lottery_execute_draw($topic_id, lottery_prizes($topic_id), true);
            set_flash('已开奖');
        } elseif ($action === 'cancel') {
            if (!$draw) err('该主题不是抽奖帖');
            if ((string)$draw['status'] !== 'open') err('已开奖的抽奖不能取消');
            $cancel_prizes = lottery_prizes($topic_id);
            tx(function () use ($topic_id, $draw, $cancel_prizes): void {
                foreach ($cancel_prizes as $prize) {
                    $forfeit = lottery_prize_points((string)$prize['kind'], (int)$prize['quantity'], (int)$prize['unit_points']);
                    if ($forfeit > 0) lottery_point_ledger_add($topic_id, (int)$prize['id'], (int)$draw['creator_id'], 'forfeit', $forfeit, '取消抽奖，预付积分不退');
                }
                q("UPDATE plugin_lottery_draws SET status='cancelled',rules_locked=1,draw_at=0,drawn_at=? WHERE topic_id=? AND status='open'", [now(), $topic_id]);
            });
            set_flash('已取消抽奖，记录和奖池流水已保留，预付积分不退还');
            go(route_url('topic', ['id' => $topic_id]));
        } else {
            err('操作无效');
        }
        lottery_forget($topic_id);
        go(route_url('lottery_manage', ['topic_id' => $topic_id]));
    }
    $draw = lottery_load($topic_id);
    $kinds = lottery_kinds();
    $status = !$draw ? '未开启' : ((string)$draw['status'] === 'open' ? '抽奖中' : ((string)$draw['status'] === 'cancelled' ? '已取消' : '已开奖'));
    $body = '<div class="lottery-manage">'
        . '<div class="admin-list-panel plugin-manage-panel">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>抽奖设置</strong><span>' . h((string)$topic['title']) . '</span></div>',
            '<a class="lottery-back" href="' . h(route_url('topic', ['id' => $topic_id])) . '">← 返回主题</a>')
        . '<div class="plugin-panel-body">';
    $body .= '<div class="lottery-manage-state"><span>当前状态</span><strong>' . $status . '</strong>'
        . ($draw ? '<span>已有 ' . (int)$draw['entry_count'] . ' 人参与</span>' : '<span>保存后本帖会显示抽奖卡片</span>') . '</div>';
    $locked = $draw && (int)($draw['rules_locked'] ?? 0) === 1;
    if (!$draw || ((string)$draw['status'] === 'open' && !$locked)) {
        $base = $draw ?: lottery_config();
        $action_value = (string)($draw['insufficient_action'] ?? lottery_config()['default_insufficient_action']);
        $action_options = '';
        foreach (lottery_insufficient_actions() as $key => $label) $action_options .= '<option value="' . h($key) . '"' . ($key === $action_value ? ' selected' : '') . '>' . h($label) . '</option>';
        $body .= '<form method="post" class="lottery-form">' . form_token() . hidden_inputs(['topic_id' => $topic_id, 'lottery_action' => 'save'])
            . input('参与门槛（回复字数）', 'min_chars', (string)($draw ? (int)$draw['min_chars'] : 5), 'number', true, '回复达到这个字数才算参与')
            . input('定时开奖', 'draw_at', $draw && (int)$draw['draw_at'] > 0 ? date('Y-m-d\TH:i', (int)$draw['draw_at']) : '', 'datetime-local', false, '留空表示不按时间开奖')
            . input('满多少人开奖', 'draw_count', (string)($draw ? (int)$draw['draw_count'] : 0), 'number', false, '填 0 表示不按人数开奖')
            . input('最低参与人数', 'min_entries', (string)(int)($draw['min_entries'] ?? lottery_config()['default_min_entries']), 'number', false, '不足时按下方策略处理')
            . '<label class="grid"><span>人数不足时</span><select name="insufficient_action">' . $action_options . '</select></label>'
            . input('每次延期小时', 'postpone_hours', (string)(int)($draw['postpone_hours'] ?? lottery_config()['default_postpone_hours']), 'number', false, '仅自动延期策略使用')
            . input('最多自动延期次数', 'max_postpones', (string)(int)($draw['max_postpones'] ?? lottery_config()['default_max_postpones']), 'number', false, '达到上限后等待手动处理')
            . input('账号至少注册天数', 'min_account_days', (string)(int)($draw['min_account_days'] ?? lottery_config()['default_min_account_days']), 'number', false, '填 0 表示不限')
            . input('参与所需最低积分', 'min_user_points', (string)(int)($draw['min_user_points'] ?? lottery_config()['default_min_user_points']), 'number', false, '只校验参与当时的积分')
            . input('手工奖领取期限（天）', 'claim_days', (string)(int)($draw['claim_days'] ?? lottery_config()['default_claim_days']), 'number', false, '填 0 表示不限期')
            . '<div class="grid"><span>允许参与的用户组<small>全不勾选表示全部用户组</small></span><div class="lottery-group-checks">' . lottery_group_checks('eligible_groups', lottery_csv_ids($draw['eligibility_groups'] ?? '')) . '</div></div>'
            . '<label class="lottery-compose-toggle"><input type="checkbox" name="exclude_restricted" value="1"' . ((int)($draw['exclude_restricted'] ?? 1) === 1 ? ' checked' : '') . '><span>排除被禁言或封禁的用户</span></label>'
            . '<button type="submit" data-loading-text="正在保存">' . ($draw ? '保存设置' : '设为抽奖帖') . '</button></form>';
    } elseif ((string)$draw['status'] === 'open') {
        $body .= '<div class="lottery-hint is-joined">已有参与者，规则和奖品已锁定；仍可立即开奖或取消抽奖。</div>';
    } else {
        $body .= '<div class="lottery-hint">本次抽奖状态为“' . h($status) . '”，设置不可再修改。</div>';
    }
    $body .= '</div></div>';
    if ($draw) {
        $prizes = lottery_prizes($topic_id);
        $rows = '';
        foreach ($prizes as $prize) {
            $kind = (string)$prize['kind'];
            $meta = ($kinds[$kind]['label'] ?? $kind) . ' · ' . (int)$prize['quantity'] . ' 份'
                . ($kind === 'points' && (int)$prize['unit_points'] > 0 ? ' · 每份 ' . (int)$prize['unit_points'] . ' 积分' : '');
            $ops = (string)$draw['status'] === 'open' && (int)($draw['rules_locked'] ?? 0) === 0
                ? post_action_form(route_url('lottery_manage', ['topic_id' => $topic_id]), '删除', ['topic_id' => $topic_id, 'lottery_action' => 'prize_delete', 'prize_id' => (int)$prize['id']], 'lottery-prize-delete', '确定删除这个奖品？已预付的积分不会退还。')
                : '';
            $rows .= '<li class="admin-list-item admin-object-row"><div class="admin-row-main"><strong class="admin-content-title">' . h((string)$prize['name']) . '</strong>'
                . '<div class="admin-row-meta"><span>' . h($meta) . '</span></div></div>' . $ops . '</li>';
        }
        if ($rows === '') $rows = '<li class="empty-state">还没有奖品，先添加一个。</li>';
        $add = '';
        if ((string)$draw['status'] === 'open' && (int)($draw['rules_locked'] ?? 0) === 0) {
            $options = '';
            foreach ($kinds as $key => $kind) $options .= '<option value="' . h($key) . '">' . h($kind['label']) . '</option>';
            $add = '<form method="post" class="lottery-prize-add">' . form_token() . hidden_inputs(['topic_id' => $topic_id, 'lottery_action' => 'prize_add'])
                . '<label class="grid"><span>奖品名称</span><input name="prize_name" type="text" required maxlength="120"></label>'
                . '<label class="grid"><span>类型</span><select name="prize_kind">' . $options . '</select></label>'
                . '<label class="grid"><span>份数</span><input name="prize_quantity" type="number" value="1" min="1" max="1000"></label>'
                . '<label class="grid"><span>每份积分</span><input name="prize_points" type="number" value="0" min="0" max="100000"></label>'
                . '<button type="submit">添加奖品</button>'
                . '<p class="lottery-note">积分奖会立即按总额预付，发布后不退；兑换码和手工发奖需要发起人自己联系中奖者。</p></form>';
        }
        $body .= '<div class="admin-list-panel plugin-manage-panel">'
            . admin_list_head('<div class="admin-plugin-summary"><strong>奖品</strong><span>按顺序依次抽出中奖者</span></div>', '')
            . '<div class="plugin-panel-body"><ul class="admin-manage-list">' . $rows . '</ul>' . $add . '</div></div>';
        if ((string)$draw['status'] === 'drawn') {
            $claim_rows = '';
            $claim_data = q('SELECT c.id,c.status,c.deadline_at,c.note,c.user_id,p.name,u.username FROM plugin_lottery_claims c LEFT JOIN plugin_lottery_prizes p ON p.id=c.prize_id LEFT JOIN app_users u ON u.id=c.user_id WHERE c.topic_id=? ORDER BY c.id', [$topic_id])->fetchAll();
            foreach ($claim_data as $claim) {
                $labels = ['pending' => '待发奖', 'sent' => '已发送', 'confirmed' => '已确认', 'disputed' => '有申诉'];
                $claim_status = (string)$claim['status'];
                $ops = '';
                if (in_array($claim_status, ['pending', 'disputed'], true)) {
                    $ops = '<form method="post" class="lottery-claim-send">' . form_token() . hidden_inputs(['topic_id' => $topic_id, 'lottery_action' => 'claim_sent', 'claim_id' => (int)$claim['id']])
                        . '<input name="claim_note" type="text" maxlength="255" placeholder="发奖说明或联系方式"><button type="submit">标记已发送</button></form>';
                }
                $meta = h((string)($claim['username'] ?? ('用户 ' . (int)$claim['user_id']))) . ' · ' . h($labels[$claim_status] ?? $claim_status)
                    . ((int)$claim['deadline_at'] > 0 ? ' · 截止 ' . date('Y-m-d', (int)$claim['deadline_at']) : '')
                    . ((string)$claim['note'] !== '' ? ' · ' . h((string)$claim['note']) : '');
                $claim_rows .= '<li class="admin-list-item admin-object-row"><div class="admin-row-main"><strong class="admin-content-title">' . h((string)($claim['name'] ?? '手工奖品')) . '</strong><div class="admin-row-meta"><span>' . $meta . '</span></div></div>' . $ops . '</li>';
            }
            if ($claim_rows !== '') {
                $body .= '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>发奖确认</strong><span>兑换码和手工奖品</span></div>', '')
                    . '<div class="plugin-panel-body"><ul class="admin-manage-list">' . $claim_rows . '</ul></div></div>';
            }
        }
        if ((string)$draw['status'] === 'open') {
            $body .= '<div class="admin-list-panel plugin-manage-panel">'
                . admin_list_head('<div class="admin-plugin-summary"><strong>开奖与取消</strong><span>开奖后不可撤销</span></div>', '')
                . '<div class="plugin-panel-body"><div class="lottery-danger">'
                . post_action_form(route_url('lottery_manage', ['topic_id' => $topic_id]), '立即开奖', ['topic_id' => $topic_id, 'lottery_action' => 'draw_now'], 'lottery-draw-now', '确定立即开奖？开奖后不能撤销。')
                . post_action_form(route_url('lottery_manage', ['topic_id' => $topic_id]), '取消抽奖', ['topic_id' => $topic_id, 'lottery_action' => 'cancel'], 'lottery-cancel', '确定取消？奖品和参与记录会一起删除，预付奖池不会退还。')
                . '</div></div></div>';
        }
    }
    $body .= '</div>';
    page('抽奖设置', shell_html($body, sidebar_stack_html(array_filter([
        sidebar_user_card_html(me()),
        sidebar_notice_card_html('抽奖怎么运作', [
            '读者在本帖回复达到门槛字数即算参与。',
            '发起人不参与自己的抽奖。',
            '时间或人数任一条件满足即自动开奖。',
            '随机种子创建时锁定，开奖后公开可复核。',
        ]),
    ], 'strlen'))));
}

function lottery_claim_page(array $plugin): void
{
    need_login();
    $topic_id = max(1, (int)($_GET['topic_id'] ?? $_POST['topic_id'] ?? 0));
    $topic = row('app_topics', 'id', $topic_id) ?: err('主题不存在');
    if (is_post_request()) {
        require_post();
        $claim_id = max(1, (int)($_POST['claim_id'] ?? 0));
        $action = (string)($_POST['claim_action'] ?? '');
        $note = cut(trim((string)($_POST['claim_note'] ?? '')), 255);
        if ($action === 'confirm') {
            q("UPDATE plugin_lottery_claims SET status='confirmed',note=?,updated_at=? WHERE id=? AND topic_id=? AND user_id=? AND status='sent'", [$note, now(), $claim_id, $topic_id, uid()]);
            set_flash('已确认领取奖品');
        } elseif ($action === 'dispute') {
            if ($note === '') err('请填写申诉原因');
            q("UPDATE plugin_lottery_claims SET status='disputed',note=?,updated_at=? WHERE id=? AND topic_id=? AND user_id=? AND status IN ('pending','sent')", [$note, now(), $claim_id, $topic_id, uid()]);
            $draw = one('SELECT creator_id FROM plugin_lottery_draws WHERE topic_id=?', [$topic_id]);
            if ($draw) create_notification((int)$draw['creator_id'], uid(), 'lottery', '抽奖《' . cut((string)$topic['title'], 60) . '》的获奖者提交了发奖申诉。', $topic_id);
            set_flash('申诉已提交');
        } else {
            err('操作无效');
        }
        go(route_url('lottery_claim', ['topic_id' => $topic_id]));
    }
    $claims = q('SELECT c.id,c.status,c.deadline_at,c.note,p.name FROM plugin_lottery_claims c LEFT JOIN plugin_lottery_prizes p ON p.id=c.prize_id WHERE c.topic_id=? AND c.user_id=? ORDER BY c.id', [$topic_id, uid()])->fetchAll();
    if (!$claims) err('你没有这个抽奖的待领取奖品');
    $rows = '';
    $labels = ['pending' => '等待发起人发奖', 'sent' => '发起人已标记发送', 'confirmed' => '已确认领取', 'disputed' => '申诉处理中'];
    foreach ($claims as $claim) {
        $status = (string)$claim['status'];
        $ops = '';
        if (in_array($status, ['pending', 'sent'], true)) {
            $confirm = $status === 'sent'
                ? '<form method="post">' . form_token() . hidden_inputs(['topic_id' => $topic_id, 'claim_id' => (int)$claim['id'], 'claim_action' => 'confirm']) . '<input name="claim_note" maxlength="255" placeholder="可填写领取备注"><button type="submit">确认已领取</button></form>'
                : '';
            $ops = '<div class="lottery-claim-actions">' . $confirm
                . '<form method="post">' . form_token() . hidden_inputs(['topic_id' => $topic_id, 'claim_id' => (int)$claim['id'], 'claim_action' => 'dispute']) . '<input name="claim_note" maxlength="255" required placeholder="申诉原因"><button type="submit" class="btn alt">提交申诉</button></form></div>';
        }
        $meta = h($labels[$status] ?? $status) . ((int)$claim['deadline_at'] > 0 ? ' · 领取期限 ' . date('Y-m-d', (int)$claim['deadline_at']) : '')
            . ((string)$claim['note'] !== '' ? ' · ' . h((string)$claim['note']) : '');
        $rows .= '<li class="admin-list-item admin-object-row"><div class="admin-row-main"><strong class="admin-content-title">' . h((string)($claim['name'] ?? '奖品')) . '</strong><div class="admin-row-meta"><span>' . $meta . '</span></div></div>' . $ops . '</li>';
    }
    $main = '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>奖品领取</strong><span>' . h((string)$topic['title']) . '</span></div>', '<a href="' . h(route_url('topic', ['id' => $topic_id])) . '">← 返回主题</a>')
        . '<div class="plugin-panel-body"><ul class="admin-manage-list">' . $rows . '</ul></div></div>';
    page('奖品领取', shell_html($main, sidebar_stack_html([sidebar_user_card_html(me())])));
}

function lottery_admin_page(array $plugin): string
{
    need_admin();
    if (is_post_request()) {
        require_post();
        $groups = [];
        foreach ((array)($_POST['lottery_groups'] ?? []) as $gid) {
            $gid = (int)$gid;
            if ($gid > 0) $groups[$gid] = $gid;
        }
        $default_action = (string)($_POST['default_insufficient_action'] ?? 'wait');
        if (!isset(lottery_insufficient_actions()[$default_action])) $default_action = 'wait';
        plugin_save_config('lottery', [
            'allowed_groups' => implode(',', array_values($groups)),
            'default_min_chars' => (string)min(200, max(1, (int)($_POST['default_min_chars'] ?? 5))),
            'max_open_per_user' => (string)min(1000, max(0, (int)($_POST['max_open_per_user'] ?? 0))),
            'default_min_entries' => (string)min(100000, max(0, (int)($_POST['default_min_entries'] ?? 0))),
            'default_insufficient_action' => $default_action,
            'default_postpone_hours' => (string)min(720, max(1, (int)($_POST['default_postpone_hours'] ?? 24))),
            'default_max_postpones' => (string)min(20, max(0, (int)($_POST['default_max_postpones'] ?? 3))),
            'default_min_account_days' => (string)min(3650, max(0, (int)($_POST['default_min_account_days'] ?? 0))),
            'default_min_user_points' => (string)min(100000000, max(0, (int)($_POST['default_min_user_points'] ?? 0))),
            'default_claim_days' => (string)min(365, max(0, (int)($_POST['default_claim_days'] ?? 7))),
        ]);
        set_flash('抽奖设置已保存');
        go(admin_url(['tab' => 'lottery']));
    }
    $config = lottery_config();
    $allowed = lottery_allowed_group_ids();
    $stats = one("SELECT COUNT(*) total,SUM(CASE WHEN status='open' THEN 1 ELSE 0 END) open_count,SUM(entry_count) entries,SUM(deposit_points) prepaid_points FROM plugin_lottery_draws") ?: [];
    $ledger_stats = one("SELECT SUM(CASE WHEN kind='reserve' THEN points ELSE 0 END) reserved_points,SUM(CASE WHEN kind='award' THEN points ELSE 0 END) awarded_points,SUM(CASE WHEN kind='forfeit' THEN points ELSE 0 END) forfeited_points FROM plugin_lottery_point_ledger") ?: [];
    $cards = [
        ['抽奖帖总数', (int)($stats['total'] ?? 0)],
        ['进行中', (int)($stats['open_count'] ?? 0)],
        ['累计参与人次', (int)($stats['entries'] ?? 0)],
        ['累计预付奖池', (int)($stats['prepaid_points'] ?? 0) . ' 积分'],
        ['已发放积分', (int)($ledger_stats['awarded_points'] ?? 0) . ' 积分'],
        ['尚未发放', max(0, (int)($ledger_stats['reserved_points'] ?? 0) - (int)($ledger_stats['awarded_points'] ?? 0)) . ' 积分'],
        ['已作废积分', (int)($ledger_stats['forfeited_points'] ?? 0) . ' 积分'],
    ];
    $summary = '<div class="lottery-admin-cards">';
    foreach ($cards as [$label, $value]) {
        $summary .= '<div class="lottery-admin-card"><span>' . h($label) . '</span><strong>' . h((string)$value) . '</strong></div>';
    }
    $summary .= '</div>';
    $checks = '';
    foreach (groups_cache() as $group) {
        $gid = (int)$group['id'];
        $checks .= '<label class="lottery-group-check"><input type="checkbox" name="lottery_groups[]" value="' . $gid . '"'
            . (in_array($gid, $allowed, true) ? ' checked' : '') . '><span>' . h((string)$group['name']) . '</span></label>';
    }
    $default_action_options = '';
    foreach (lottery_insufficient_actions() as $key => $label) {
        $default_action_options .= '<option value="' . h($key) . '"' . ($key === (string)$config['default_insufficient_action'] ? ' selected' : '') . '>' . h($label) . '</option>';
    }
    $form = '<form method="post" class="lottery-form">' . form_token()
        . input('默认参与门槛（回复字数）', 'default_min_chars', (string)(int)$config['default_min_chars'], 'number', false, '发帖页抽奖表单的默认值')
        . input('每人同时进行的抽奖上限', 'max_open_per_user', (string)(int)$config['max_open_per_user'], 'number', false, '填 0 表示不限制；管理员不受限制')
        . input('默认最低参与人数', 'default_min_entries', (string)(int)$config['default_min_entries'], 'number', false, '填 0 表示不限')
        . '<label class="grid"><span>默认人数不足策略</span><select name="default_insufficient_action">' . $default_action_options . '</select></label>'
        . input('默认延期小时', 'default_postpone_hours', (string)(int)$config['default_postpone_hours'], 'number', false, '仅自动延期策略使用')
        . input('默认最多延期次数', 'default_max_postpones', (string)(int)$config['default_max_postpones'], 'number', false, '达到上限后等待手动处理')
        . input('默认账号注册天数', 'default_min_account_days', (string)(int)$config['default_min_account_days'], 'number', false, '参与资格，填 0 表示不限')
        . input('默认参与最低积分', 'default_min_user_points', (string)(int)$config['default_min_user_points'], 'number', false, '参与资格，填 0 表示不限')
        . input('默认手工奖领取期限', 'default_claim_days', (string)(int)$config['default_claim_days'], 'number', false, '天，填 0 表示不限期')
        . '<div class="grid"><span>允许发起抽奖的用户组<small>全不勾选表示所有用户组都可以；管理员始终可以</small></span>'
        . '<div class="lottery-group-checks">' . ($checks !== '' ? $checks : '<span class="lottery-note">没有可选的用户组</span>') . '</div></div>'
        . '<button type="submit" data-loading-text="正在保存">保存设置</button></form>';
    $rows = '';
    foreach (q("SELECT d.topic_id,d.entry_count,d.draw_at,d.draw_count,d.deposit_points,t.title,u.username FROM plugin_lottery_draws d LEFT JOIN app_topics t ON t.id=d.topic_id LEFT JOIN app_users u ON u.id=d.creator_id WHERE d.status='open' ORDER BY d.created_at DESC LIMIT 20")->fetchAll() as $row) {
        $meta = '发起人 ' . (string)($row['username'] ?? '-') . ' · ' . (int)$row['entry_count'] . ' 人参与'
            . ((int)$row['draw_at'] > 0 ? ' · ' . date('m-d H:i', (int)$row['draw_at']) . ' 开奖' : '')
            . ((int)$row['draw_count'] > 0 ? ' · 满 ' . (int)$row['draw_count'] . ' 人开奖' : '')
            . ((int)$row['deposit_points'] > 0 ? ' · 预付奖池 ' . (int)$row['deposit_points'] . ' 积分' : '');
        $rows .= '<li class="admin-list-item admin-object-row"><div class="admin-row-main">'
            . '<a class="admin-content-title" href="' . h(route_url('topic', ['id' => (int)$row['topic_id']])) . '">' . h((string)($row['title'] ?? ('主题 #' . (int)$row['topic_id']))) . '</a>'
            . '<div class="admin-row-meta"><span>' . h($meta) . '</span></div></div>'
            . '<div class="admin-inline-ops"><a class="lottery-note" href="' . h(route_url('lottery_manage', ['topic_id' => (int)$row['topic_id']])) . '">设置</a></div></li>';
    }
    if ($rows === '') $rows = '<li class="empty-state">当前没有进行中的抽奖。</li>';
    return '<div class="lottery-admin">'
        . '<div class="admin-list-panel plugin-manage-panel">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>抽奖</strong><span>读者回复即参与，到时间或满人数自动开奖</span></div>', '')
        . '<div class="plugin-panel-body">' . $summary . '</div></div>'
        . '<div class="admin-list-panel plugin-manage-panel">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>参数设置</strong><span>保存后立即生效</span></div>', '')
        . '<div class="plugin-panel-body">' . $form . '</div></div>'
        . '<div class="admin-list-panel plugin-manage-panel">'
        . admin_list_head('<div class="admin-plugin-summary"><strong>进行中的抽奖</strong><span>最多显示 20 个</span></div>', '')
        . '<div class="plugin-panel-body"><ul class="admin-manage-list">' . $rows . '</ul></div></div>'
        . '</div>';
}

function lottery_css(): string
{
    return '.lottery-title-status{display:inline-flex;align-items:center;min-height:20px;margin-left:6px;padding:0 8px;border-radius:999px;font-size:var(--font-size-xs);font-weight:600;white-space:nowrap}'
        . '.lottery-title-status.open{background:var(--warning-soft);color:var(--warning)}'
        . '.lottery-title-status.done{background:var(--success-soft);color:var(--success)}'
        . '.lottery-card-item{list-style:none;padding:0;border:0;background:transparent}'
        . '.lottery-card{display:grid;gap:11px;margin:12px 0;padding:16px;border:1px solid var(--warning);border-radius:var(--radius);background:var(--warning-soft)}'
        . '.lottery-card.is-done{border-color:var(--success);background:var(--success-soft)}'
        . '.lottery-card>header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}'
        . '.lottery-card>header b{font-size:var(--font-size-lg)}'
        . '.lottery-card>header span{display:block;margin-top:2px;color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-card>header em{flex:0 0 auto;padding:5px 11px;border-radius:999px;background:var(--panel);color:var(--text);font-size:var(--font-size-sm);font-style:normal;font-weight:600}'
        . '.lottery-prizes,.lottery-winners{display:grid;gap:7px;margin:0;padding:0;list-style:none}'
        . '.lottery-prizes li,.lottery-winners li{display:flex;align-items:baseline;justify-content:space-between;gap:12px;padding:9px 12px;border-radius:var(--radius-sm);background:var(--panel)}'
        . '.lottery-prizes strong,.lottery-winners strong{font-size:var(--font-size-md)}'
        . '.lottery-prizes span,.lottery-winners span{color:var(--text-muted);font-size:var(--font-size-xs);text-align:right}'
        . '.lottery-prize-empty strong{color:var(--text-muted);font-weight:400}'
        . '.lottery-condition{color:var(--text);font-size:var(--font-size-sm);font-weight:600}.lottery-eligibility{color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-hint{padding:9px 12px;border-radius:var(--radius-sm);background:var(--panel);color:var(--text-muted);font-size:var(--font-size-sm)}'
        . '.lottery-hint.is-joined{color:var(--success)}.lottery-hint.is-blocked{color:var(--danger)}'
        . '.lottery-result{display:grid;gap:8px}'
        . '.lottery-result-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px}'
        . '.lottery-result-head b{font-size:var(--font-size-lg)}'
        . '.lottery-result-head span{color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-winners span{color:var(--text);text-align:right;font-size:var(--font-size-sm)}'
        . '.lottery-winners em{padding:1px 5px;border-radius:999px;background:var(--bg);color:var(--text-muted);font-size:var(--font-size-xs);font-style:normal}.lottery-winners a{color:var(--brand)}'
        . '.lottery-ledger{padding:8px 10px;border-radius:var(--radius-sm);background:var(--panel);color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-fair{color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-fair summary{cursor:pointer;color:var(--text);font-size:var(--font-size-sm)}'
        . '.lottery-fair p{margin:7px 0}'
        . '.lottery-fair code{display:block;margin-top:4px;padding:7px 9px;border-radius:var(--radius-sm);background:var(--panel);font-family:var(--font-mono);overflow-wrap:anywhere}'
        . '.lottery-card-manage{justify-self:start;color:var(--text);font-size:var(--font-size-sm);font-weight:600}'
        . '.lottery-manage-link:before{display:none}.lottery-manage-link svg{display:block;width:14px;height:14px}'
        . '.lottery-manage{display:grid;gap:12px}'
        . '.lottery-back{color:var(--text-muted);font-size:var(--font-size-sm)}'
        . '.lottery-manage-state{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap;margin-bottom:13px;padding:10px 12px;border-radius:var(--radius-sm);background:var(--bg)}'
        . '.lottery-manage-state span{color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-manage-state strong{font-size:var(--font-size-md)}'
        . '.lottery-form,.lottery-prize-add{display:grid;gap:11px}'
        . '.lottery-manage .grid{grid-template-columns:minmax(0,1fr);gap:5px;margin:0}'
        . '.lottery-manage .grid>span{padding-top:0}'
        . '.lottery-manage .grid input,.lottery-manage .grid select{width:100%;max-width:none}'
        . '.lottery-prize-add{margin-top:13px;padding-top:13px;border-top:1px solid var(--line-soft)}'
        . '.lottery-note{margin:0;color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-danger{display:flex;gap:9px;flex-wrap:wrap}'
        . '.lottery-compose{display:grid;gap:8px;margin:10px 0;padding:12px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--bg)}'
        . '.lottery-compose-head{display:flex;align-items:center;justify-content:space-between;gap:10px}'
        . '.lottery-compose-head a{color:var(--brand);font-size:var(--font-size-sm)}'
        . '.lottery-compose-details summary,.lottery-compose-advanced summary{cursor:pointer;font-weight:600}'
        . '.lottery-compose-body{display:grid;gap:11px;margin-top:11px}'
        . '.lottery-compose-advanced{padding:10px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--panel)}.lottery-compose-advanced>div{margin-top:10px}'
        . '.lottery-compose-toggle{display:flex;align-items:center;gap:9px;font-size:var(--font-size-sm)}.lottery-compose-toggle input[type=checkbox]{flex:0 0 38px;width:38px;min-width:38px;margin:0}'
        . '.lottery-compose-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px}'
        . '.lottery-compose-note{margin:0;color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-admin{display:grid;gap:12px}'
        . '.lottery-admin-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:9px}'
        . '.lottery-admin-card{display:grid;gap:3px;padding:10px 12px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--bg)}'
        . '.lottery-admin-card span{color:var(--text-muted);font-size:var(--font-size-xs)}'
        . '.lottery-admin-card strong{font-size:var(--font-size-lg)}'
        . '.lottery-group-checks{display:flex;flex-wrap:wrap;gap:9px}'
        . '.lottery-group-check{display:flex;align-items:center;gap:6px;padding:6px 10px;border:1px solid var(--line);border-radius:999px;font-size:var(--font-size-sm)}'
        . '.lottery-claim-send,.lottery-claim-actions,.lottery-claim-actions form{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.lottery-claim-send input,.lottery-claim-actions input{min-width:180px}'
        . '@media(max-width:720px){.lottery-card>header{flex-direction:column}.lottery-card>header em{align-self:flex-start}'
        . '.lottery-prizes li,.lottery-winners li{flex-direction:column;gap:2px}'
        . '.lottery-prizes span,.lottery-winners span{text-align:left}}';
}

return [
    'id' => 'lottery',
    'name' => '抽奖帖',
    'version' => '1.4.0',
    'description' => '把帖子变成抽奖：读者回复即参与，到时间或满人数自动开奖，中奖名单公开且可复核。',
    'author' => '233',
    'assets' => ['css' => 'lottery_css'],
    'hooks' => [
        'topic.after_view' => 'lottery_after_view',
        'topic.after_render' => 'lottery_topic_after_render',
        'topic.index_data.loaded' => 'lottery_index_loaded',
        'topic.title_suffix' => 'lottery_title_suffix',
        'topic.actions' => 'lottery_topic_actions',
        'topic.form_extra' => 'lottery_form_extra',
        'topic.before_save' => 'lottery_before_save',
        'topic.after_save' => 'lottery_topic_after_save',
        'reply.after_save' => 'lottery_reply_after_save',
    ],
    'routes' => ['lottery_manage' => 'lottery_manage_page', 'lottery_claim' => 'lottery_claim_page'],
    'admin_tabs' => ['lottery' => 'lottery_admin_page'],
    'cron' => ['draw' => ['callback' => 'lottery_cron_draw', 'interval' => 'lottery_cron_interval']],
    'install' => 'lottery_install',
    'uninstall' => 'lottery_uninstall',
];
