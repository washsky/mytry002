<?php
if (!defined('APP_ROOT')) exit;

function better_topic_list_config(): array
{
    $raw = plugin_config('better_topic_list', []);
    return [
        'enabled' => (int)($raw['enabled'] ?? 1) === 1,
        'poll_interval' => max(5, (int)($raw['poll_interval'] ?? 8)),
        'notice_content' => trim((string)($raw['notice_content'] ?? '')),
        'notice_enabled' => (int)($raw['notice_enabled'] ?? 0) === 1,
    ];
}

function better_topic_list_install(array $plugin): void
{
    plugin_save_config('better_topic_list', [
        'enabled' => 1,
        'poll_interval' => 8,
        'notice_content' => '**友善**、**团结**、**热心**、**专业**，共建你我引以为荣之社区。[《社区准则》](/index.php)',
        'notice_enabled' => 1,
    ]);
}

function better_topic_list_uninstall(array $plugin): void
{
    plugin_save_config('better_topic_list', []);
}

function better_topic_list_current_page(): array
{
    $a = (string)($_GET['a'] ?? 'home');
    $forum_id = 0;
    $is_timeline = false;
    if ($a === 'home') {
        $is_timeline = true;
    } elseif ($a === 'forum') {
        $forum_id = (int)($_GET['id'] ?? 0);
        if ($forum_id > 0) {
            $is_timeline = true;
        }
    }
    $page = max(1, (int)($_GET['p'] ?? 1));
    return ['is_timeline' => $is_timeline, 'forum_id' => $forum_id, 'page' => $page];
}

function better_topic_list_admin_page(array $plugin): string
{
    $config = better_topic_list_config();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals(csrf_token(), (string)($_POST['_csrf'] ?? ''))) {
            err('请求已过期');
        }
        $next = [
            'enabled' => ($_POST['enabled'] ?? '0') === '1' ? 1 : 0,
            'notice_enabled' => ($_POST['notice_enabled'] ?? '0') === '1' ? 1 : 0,
            'poll_interval' => max(5, (int)($_POST['poll_interval'] ?? 8)),
            'notice_content' => trim((string)($_POST['notice_content'] ?? ''))
        ];
        plugin_save_config('better_topic_list', $next);
        set_flash('设置已保存');
        go(admin_url(['tab' => 'better_topic_list']));
    }

    $enabled_checked = $config['enabled'] ? ' checked' : '';
    $notice_enabled_checked = $config['notice_enabled'] ? ' checked' : '';
    $poll_interval_val = (int)$config['poll_interval'];
    $notice_content_val = h($config['notice_content']);

    $form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'better_topic_list'])) . '">'
        . form_token()
        . '<label class="grid"><span>启用实时更新帖子列表</span><input type="hidden" name="enabled" value="0"><input type="checkbox" name="enabled" value="1"' . $enabled_checked . '></label>'
        . '<label class="grid"><span>每次更新间隔（秒）</span><input type="number" name="poll_interval" value="' . $poll_interval_val . '" min="5" step="1"></label>'
        . '<hr><h4>站点核心守则</h4>'
        . '<label class="grid"><span>启用守则横幅</span><input type="hidden" name="notice_enabled" value="0"><input type="checkbox" name="notice_enabled" value="1"' . $notice_enabled_checked . '></label>'
        . '<label class="grid"><span>守则内容（支持 Markdown）</span><textarea name="notice_content" rows="4" style="width:100%;box-sizing:border-box;">' . $notice_content_val . '</textarea></label>'
        . '<button>保存设置</button></form>';

    $head = '<div class="admin-plugin-summary"><strong>更好的帖子列表</strong><span>自动更新帖子列表，并可配置展示站点核心守则</span></div>';
    return '<div class="admin-list-panel plugin-manage-panel">' . admin_list_head($head, '') . '<div class="plugin-panel-body">' . $form . '</div></div>';
}

function better_topic_list_api(): void
{
    header('Content-Type: application/json; charset=utf-8');

    $action = (string)($_GET['action'] ?? '');
    if ($action !== 'get_new') {
        echo json_encode(['success' => false, 'error' => '未知操作']);
        exit;
    }

    $config = better_topic_list_config();
    if (!$config['enabled']) {
        echo json_encode(['success' => false, 'error' => '插件未启用']);
        exit;
    }

    $last_id = (int)($_GET['last_id'] ?? 0);
    $forum_id = (int)($_GET['forum_id'] ?? 0);
    $limit = min(20, (int)($_GET['limit'] ?? 10));

    if ($forum_id > 0) {
        $forum = forum_by_id($forum_id);
        if (!$forum || !forum_group_allowed($forum, 'allow_view_groups')) {
            echo json_encode(['success' => false, 'error' => '无权限']);
            exit;
        }
    }

    $pinned_ids = pinned_topic_ids();

    $where = 'id > ?';
    $params = [$last_id];
    if ($forum_id > 0) {
        $where .= ' AND forum_id = ?';
        $params[] = $forum_id;
    }
    if (!empty($pinned_ids)) {
        $marks = sql_marks(count($pinned_ids));
        $where .= ' AND id NOT IN (' . $marks . ')';
        $params = array_merge($params, $pinned_ids);
    }
    $rows = q("SELECT * FROM app_topics WHERE $where ORDER BY id DESC LIMIT ?", array_merge($params, [$limit]))->fetchAll();
    if (empty($rows)) {
        echo json_encode(['success' => true, 'html' => '', 'count' => 0, 'latest_id' => $last_id]);
        exit;
    }

    $latest_id = (int)$rows[0]['id'];

    $rows = array_reverse($rows);

    $user_ids = array_column($rows, 'user_id');
    $users = rows_by_ids('app_users', $user_ids, 'id,username,avatar_style,avatar_seed,group_id,points,is_banned,is_muted');
    foreach ($rows as &$row) {
        $row['user'] = $users[(int)$row['user_id']] ?? user_summary_defaults();
        $row['forum'] = forum_by_id((int)$row['forum_id']);
        $row['time'] = $row['created_at'];
    }
    unset($row);

    $html = '';
    foreach ($rows as $topic) {
        $user = $topic['user'];
        $avatar = avatar_tag((int)$user['id'], (string)$user['username'], (string)($user['avatar_style'] ?? ''), '', (string)($user['avatar_seed'] ?? ''));
        $username = h($user['username']);
        $title = h($topic['title']);
        $topic_url = route_url('topic', ['id' => (int)$topic['id']]);
        $forum_name = $topic['forum'] ? h($topic['forum']['name']) : '';
        $forum_url = $topic['forum'] ? route_url('forum', ['id' => (int)$topic['forum']['id']]) : '';
        $reply_count = (int)$topic['reply_count'];
        $created = human_time((int)$topic['created_at']);

        $html .= '<li class="post-item" data-topic-id="' . (int)$topic['id'] . '">';
        $html .= '<div class="post-avatar"><a class="avatar-profile-link" href="' . h(route_url('user', ['id' => (int)$user['id']])) . '">' . $avatar . '</a></div>';
        $html .= '<div class="post-body">';
        $html .= '<div class="post-title-row"><a class="post-title" href="' . h($topic_url) . '">' . $title . '</a></div>';
        $html .= '<div class="post-meta">';
        $html .= '<span><a href="' . h(route_url('user', ['id' => (int)$user['id']])) . '">' . $username . '</a></span>';
        if ($forum_name) {
            $html .= '<span class="post-forum-meta"><a href="' . h($forum_url) . '">' . $forum_name . '</a></span>';
        }
        $html .= '<span>' . svg_icon('reply') . $reply_count . '</span>';
        $html .= '<span>' . $created . '</span>';
        $html .= '</div></div>';
        if ($forum_name) {
            $html .= '<a class="post-tag post-forum-badge" href="' . h($forum_url) . '">' . $forum_name . '</a>';
        }
        $html .= '</li>';
    }

    echo json_encode(['success' => true, 'html' => $html, 'count' => count($rows), 'latest_id' => $latest_id]);
    exit;
}

function better_topic_list_before_render($html, array $ctx): string
{
    if (!is_string($html)) return $html;

    $config = better_topic_list_config();
    if (!$config['enabled']) {
        return $html;
    }

    $page_info = better_topic_list_current_page();
    if (!$page_info['is_timeline'] || $page_info['page'] !== 1) {
        return $html;
    }

    if (strpos($html, '<ul class="post-list') === false) {
        return $html;
    }

    if ($config['notice_enabled'] && !empty($config['notice_content'])) {
        $notice_html = '<div class="global-notice">'
            . '<div class="row">'
            . '<div id="global-notice-alert-global-notice" class="alert alert-global-notice">'
            . '<span class="text">' . markdown_html($config['notice_content']) . '</span>'
            . '</div></div></div>';
        $html = preg_replace('/(<ul\s+class="[^"]*post-list[^"]*")/i', $notice_html . '$1', $html, 1);
    }
    $bar_html = '<div class="new-topics-bar"><a tabindex="0" href="#" class="alert clickable"><span>查看 <span class="new-topics-count">0</span> 个新的或更新的话题</span></a></div>';
    $html = preg_replace('/(<ul\s+class="[^"]*post-list[^"]*")/i', $bar_html . '$1', $html, 1);

    return $html;
}

function better_topic_list_footer($html, array $ctx): string
{
    if (!is_string($html)) return $html;

    $config = better_topic_list_config();
    if (!$config['enabled']) {
        return $html;
    }

    $page_info = better_topic_list_current_page();
    $is_timeline = $page_info['is_timeline'] && $page_info['page'] === 1;
    $a = (string)($_GET['a'] ?? '');
    if ($a === 'topic') {
        $topic_id = (int)($_GET['id'] ?? 0);
        if ($topic_id > 0) {
            setcookie('highlight_topic', (string)$topic_id, time() + 1200, '/');
            $topic = row('app_topics', 'id', $topic_id);
            if ($topic) {
                setcookie('highlight_forum', (string)$topic['forum_id'], time() + 1200, '/');
            }
        }
    }
    if (!$is_timeline) {
        return $html;
    }

    $css = better_topic_list_css();
    $js = better_topic_list_js($page_info['forum_id'], (int)$config['poll_interval']);

    return $html . '<style>' . $css . '</style>' . $js;
}

function better_topic_list_css(): string
{
    return <<<'CSS'
.global-notice {
    width: 100%;
    margin-bottom: 12px;
}
.global-notice .alert {
    width: 100%;
    box-sizing: border-box;
    display: block;
    padding: 10px 18px;
    border-radius: 0;
    background: var(--brand-soft);
    opacity: 0.7;
    color: var(--text);
    text-decoration: none;
    border: none;
    text-align: center;
}
.global-notice .alert a {
    color: var(--brand-hover);
    text-decoration: none;
}

.new-topics-bar {
    width: 100%;
    max-height: 0;
    overflow: hidden;
    opacity: 0;
    transition: max-height 0.5s ease, opacity 0.5s ease, margin-bottom 0.5s ease;
    margin-bottom: 0;
}
.new-topics-bar.show {
    max-height: 1000px;
    opacity: 1;
    margin-bottom: 12px;
}
.new-topics-bar .alert {
    display: block;
    padding: 10px 18px;
    border-radius: 0;
    background: var(--brand-soft);
    opacity: 0.7;
    color: var(--text);
    cursor: pointer;
    text-decoration: none;
    border: none;
    text-align: center;
}

@keyframes new-topic-highlight {
    0% { background: var(--brand-soft); }
    100% { background: transparent; }
}
.new-topic-highlight {
    animation: new-topic-highlight 4s ease-out forwards;
}

.highlight-topic {
    animation: new-topic-highlight 4s ease-out forwards;
}
CSS;
}

function better_topic_list_js(int $forum_id, int $poll_interval): string
{
    return <<<JS
<script>
(function() {
    'use strict';

    var forumId = {$forum_id};
    var pollInterval = {$poll_interval} * 1000;
    var list = document.querySelector('ul.post-list');
    if (!list) return;

    function getCookie(name) {
        var value = '; ' + document.cookie;
        var parts = value.split('; ' + name + '=');
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }

    function highlightTopic() {
        var highlightId = getCookie('highlight_topic');
        if (!highlightId) return;
        document.cookie = 'highlight_topic=; path=/; max-age=0';
        document.cookie = 'highlight_forum=; path=/; max-age=0';

        var items = list.querySelectorAll('li.post-item');
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var topicId = item.dataset.topicId;
            if (topicId && String(topicId) === highlightId) {
                item.classList.add('highlight-topic');
                return;
            }
            if (!topicId) {
                var link = item.querySelector('a.post-title');
                if (link) {
                    var href = link.getAttribute('href');
                    var match = href.match(/[?&]id=(\\d+)/);
                    if (match && match[1] === highlightId) {
                        item.classList.add('highlight-topic');
                        return;
                    }
                }
            }
        }
    }

    highlightTopic();
    window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
            highlightTopic();
        }
    });

    function getMaxTopicId() {
        var items = list.querySelectorAll('li.post-item');
        if (items.length === 0) return 0;
        var maxId = 0;
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var topicId = item.dataset.topicId;
            if (topicId) {
                var id = parseInt(topicId, 10);
                if (id > maxId) maxId = id;
            } else {
                var link = item.querySelector('a.post-title');
                if (link) {
                    var href = link.getAttribute('href');
                    var match = href.match(/[?&]id=(\\d+)/);
                    if (match) {
                        var id = parseInt(match[1], 10);
                        if (id > maxId) maxId = id;
                    }
                }
            }
        }
        return maxId;
    }

    var lastId = getMaxTopicId();
    if (lastId === 0) return;

    var bar = document.querySelector('.new-topics-bar');
    var countSpan = bar ? bar.querySelector('.new-topics-count') : null;
    var link = bar ? bar.querySelector('a') : null;

    var totalNewCount = 0;
    var newHtmls = [];

    function insertNewTopics(html) {
        if (!html) return;
        var temp = document.createElement('div');
        temp.innerHTML = html;
        var items = temp.querySelectorAll('li.post-item');
        if (!items.length) return;

        for (var i = items.length - 1; i >= 0; i--) {
            var node = items[i].cloneNode(true);
            node.classList.add('new-topic-highlight');
            list.insertBefore(node, list.firstChild);
        }
    }

    function loadNewTopics() {
        if (newHtmls.length === 0) return;
        for (var i = 0; i < newHtmls.length; i++) {
            insertNewTopics(newHtmls[i]);
        }
        totalNewCount = 0;
        newHtmls = [];
        if (bar) bar.classList.remove('show');
    }

    function fetchNewTopics() {
        var url = window.location.pathname + '?a=better_topic_list_api&action=get_new&last_id=' + lastId + '&forum_id=' + forumId;
        fetch(url, { credentials: 'same-origin' })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (!data.success || data.count === 0) {
                    return;
                }
                if (data.latest_id) {
                    lastId = data.latest_id;
                }
                totalNewCount += data.count;
                newHtmls.push(data.html);
                if (countSpan) countSpan.textContent = totalNewCount;
                if (bar) {
                    bar.classList.add('show');
                }
                if (link && !link._bound) {
                    link._bound = true;
                    link.addEventListener('click', function(e) {
                        e.preventDefault();
                        loadNewTopics();
                    });
                }
            })
            .catch(function(err) { console.warn('轮询新帖失败:', err); });
    }

    setTimeout(fetchNewTopics, 3000);
    setInterval(fetchNewTopics, pollInterval);
})();
</script>
JS;
}

return [
    'id' => 'better_topic_list',
    'name' => '更好的帖子列表',
    'version' => '1.1.3',
    'description' => '提供 实时更新帖子列表、论坛守则 及 返回首页高亮最近帖子 的功能。',
    'author' => 'banming',
    'hooks' => [
        'page.before_render' => 'better_topic_list_before_render',
        'page.footer' => 'better_topic_list_footer',
    ],
    'routes' => [
        'better_topic_list_api' => 'better_topic_list_api',
    ],
    'admin_tabs' => [
        'better_topic_list' => 'better_topic_list_admin_page',
    ],
    'install' => 'better_topic_list_install',
    'uninstall' => 'better_topic_list_uninstall',
];