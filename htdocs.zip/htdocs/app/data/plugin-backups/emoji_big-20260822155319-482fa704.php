<?php
if (!defined('APP_ROOT')) exit;

const EMOJI_BIG_VERSION = '1.4.2';

function emoji_big_config(): array
{
    $defaults = [
        'enabled' => 1,
        'size' => 1.8,
        'scope_topic' => 1,
        'scope_reply' => 1,
        'limited_mode' => 0,
        'trigger_chars' => '',
        'merge_before_chars' => '',
        'merge_after_chars' => '',
        'custom_tokens' => '',
        'emoji_only_suffix' => 1,
        'whole_message_mode' => 0,
        'whole_message_tokens' => '',
        'keyword_emoji_mode' => 'none',
        'keyword_emoji_tokens' => '',
        'keyword_emoji_distance' => 20,
    ];
    $raw = plugin_config('emoji_big', $defaults);
    $size = (float)($raw['size'] ?? $defaults['size']);
    $size = min(60.0, max(0.1, $size));
    $normalize = static function (mixed $value, int $max = 200): string {
        return cut(trim((string)$value), $max);
    };
    return [
        'enabled' => (int)($raw['enabled'] ?? 0) === 1,
        'size' => $size,
        'scope_topic' => (int)($raw['scope_topic'] ?? 1) === 1,
        'scope_reply' => (int)($raw['scope_reply'] ?? 1) === 1,
        'limited_mode' => (int)($raw['limited_mode'] ?? 0) === 1,
        'trigger_chars' => $normalize($raw['trigger_chars'] ?? ''),
        'merge_before_chars' => $normalize($raw['merge_before_chars'] ?? ''),
        'merge_after_chars' => $normalize($raw['merge_after_chars'] ?? ''),
        'custom_tokens' => $normalize($raw['custom_tokens'] ?? '', 500),
        'emoji_only_suffix' => (int)($raw['emoji_only_suffix'] ?? 1) === 1,
        'whole_message_mode' => (int)($raw['whole_message_mode'] ?? 0) === 1,
        'whole_message_tokens' => $normalize($raw['whole_message_tokens'] ?? '', 500),
        'keyword_emoji_mode' => in_array(($raw['keyword_emoji_mode'] ?? 'none'), ['none', 'emoji_only', 'distance'], true)
            ? $raw['keyword_emoji_mode'] : 'none',
        'keyword_emoji_tokens' => $normalize($raw['keyword_emoji_tokens'] ?? '', 500),
        'keyword_emoji_distance' => min(1000.0, max(1.0, (float)($raw['keyword_emoji_distance'] ?? 20))),
    ];
}

function emoji_big_tokens(): array
{
    $config = emoji_big_config();
    $tokens = [];
    foreach (preg_split('/[,，\r\n]+/u', $config['custom_tokens']) ?: [] as $token) {
        $token = trim($token);
        if ($token !== '') $tokens[] = $token;
    }
    usort($tokens, static fn(string $a, string $b): int => mb_strlen($b, 'UTF-8') <=> mb_strlen($a, 'UTF-8'));
    return array_values(array_unique($tokens));
}

function emoji_big_mark_post(string $html, array $ctx): string
{
    $config = emoji_big_config();
    if (!$config['enabled']) return $html;

    $is_reply = isset($ctx['row']['topic_id']) && (int)($ctx['row']['topic_id'] ?? 0) > 0;
    if ($is_reply && !$config['scope_reply']) return $html;
    if (!$is_reply && !$config['scope_topic']) return $html;

    $tokens = emoji_big_tokens();
    $data = [
        'enabled' => 1,
        'size' => $config['size'],
        'limited' => $config['limited_mode'] ? 1 : 0,
        'trigger' => $config['trigger_chars'],
        'before' => $config['merge_before_chars'],
        'after' => $config['merge_after_chars'],
        'tokens' => $tokens,
        'emojiOnlySuffix' => $config['emoji_only_suffix'] ? 1 : 0,
        'wholeMessage' => $config['whole_message_mode'] ? 1 : 0,
        'wholeTokens' => preg_split('/[,，\r\n]+/u', $config['whole_message_tokens']) ?: [],
        'keywordEmojiMode' => $config['keyword_emoji_mode'],
        'keywordEmojiTokens' => preg_split('/[,，\r\n]+/u', $config['keyword_emoji_tokens']) ?: [],
        'keywordEmojiDistance' => $config['keyword_emoji_distance'],
    ];
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    if (!is_string($json)) return $html;

    return preg_replace_callback('/(<div class="post-content)(")/u', static function (array $m) use ($json): string {
        return $m[1] . ' emoji-big-root" data-emoji-big-config="' . h($json) . $m[2];
    }, $html, 1) ?? $html;
}

function emoji_big_install(array $plugin): void
{
    $current = plugin_config('emoji_big', []);
    plugin_save_config('emoji_big', array_merge([
        'enabled' => 1,
        'size' => 1.8,
        'scope_topic' => 1,
        'scope_reply' => 1,
        'limited_mode' => 0,
        'trigger_chars' => '',
        'merge_before_chars' => '',
        'merge_after_chars' => '',
        'custom_tokens' => '',
        'emoji_only_suffix' => 1,
        'whole_message_mode' => 0,
        'whole_message_tokens' => '',
        'keyword_emoji_mode' => 'none',
        'keyword_emoji_tokens' => '',
        'keyword_emoji_distance' => 20,
    ], $current));
}

function emoji_big_admin_save(): void
{
    need_admin();
    require_post();

    $enabled = isset($_POST['enabled']) ? 1 : 0;
    $limited = isset($_POST['limited_mode']) ? 1 : 0;
    $scope_topic = isset($_POST['scope_topic']) ? 1 : 0;
    $scope_reply = isset($_POST['scope_reply']) ? 1 : 0;
    // 放大倍数使用独立的小数解析，避免后台 number_input/整数过滤导致合法小数被截断。
    $size_raw = trim((string)($_POST['size'] ?? '1.8'));
    // 同时接受 1.8 和 1,8；允许 .5 / 0.5 / 60 / 60.0 等合法数字。
    $size_raw = str_replace(',', '.', $size_raw);
    if (!preg_match('/^(?:\d+(?:\.\d*)?|\.\d+)$/', $size_raw)) {
        $size = 1.8;
    } else {
        $size = (float)$size_raw;
    }
    if (!is_finite($size)) $size = 1.8;
    $size = min(60.0, max(0.1, $size));
    $trigger = cut(trim((string)($_POST['trigger_chars'] ?? '')), 200);
    $before = cut(trim((string)($_POST['merge_before_chars'] ?? '')), 200);
    $after = cut(trim((string)($_POST['merge_after_chars'] ?? '')), 200);
    $tokens = cut(trim((string)($_POST['custom_tokens'] ?? '')), 500);
    $emoji_only_suffix = isset($_POST['emoji_only_suffix']) ? 1 : 0;
    $whole_message_mode = isset($_POST['whole_message_mode']) ? 1 : 0;
    $whole_message_tokens = cut(trim((string)($_POST['whole_message_tokens'] ?? '')), 500);
    $keyword_emoji_mode = (string)($_POST['keyword_emoji_mode'] ?? 'none');
    $keyword_emoji_tokens = cut(trim((string)($_POST['keyword_emoji_tokens'] ?? '')), 500);
    if (!in_array($keyword_emoji_mode, ['none', 'emoji_only', 'distance'], true)) $keyword_emoji_mode = 'none';
    $keyword_emoji_distance = (float)str_replace(',', '.', (string)($_POST['keyword_emoji_distance'] ?? 20));
    if (!is_finite($keyword_emoji_distance)) $keyword_emoji_distance = 20.0;
    $keyword_emoji_distance = min(1000.0, max(1.0, $keyword_emoji_distance));

    plugin_save_config('emoji_big', [
        'enabled' => $enabled,
        'size' => $size,
        'scope_topic' => $scope_topic,
        'scope_reply' => $scope_reply,
        'limited_mode' => $limited,
        'trigger_chars' => $trigger,
        'merge_before_chars' => $before,
        'merge_after_chars' => $after,
        'custom_tokens' => $tokens,
        'emoji_only_suffix' => $emoji_only_suffix,
        'whole_message_mode' => $whole_message_mode,
        'whole_message_tokens' => $whole_message_tokens,
        'keyword_emoji_mode' => $keyword_emoji_mode,
        'keyword_emoji_tokens' => $keyword_emoji_tokens,
        'keyword_emoji_distance' => $keyword_emoji_distance,
    ]);
    set_flash('大号表情符号设置已保存');
    go(admin_url(['tab' => 'emoji_big']));
}

function emoji_big_admin_toggle(): void
{
    need_admin();
    require_post();
    $config = emoji_big_config();
    $config['enabled'] = !$config['enabled'] ? 1 : 0;
    plugin_save_config('emoji_big', $config);
    set_flash($config['enabled'] ? '大号表情符号已开启' : '大号表情符号已关闭');
    go(admin_url(['tab' => 'emoji_big']));
}

function emoji_big_decimal_size_field(float $value): string
{
    $value = min(60.0, max(0.1, $value));
    // 使用最多 4 位小数显示，避免 1.8 被格式化成整数；保存时仍接受更高精度的小数。
    $display = rtrim(rtrim(number_format($value, 4, '.', ''), '0'), '.');
    if ($display === '') $display = '0.1';

    return '<div class="row emoji-big-size-field">'
        . '<label for="emoji-big-size-input">Emoji 放大倍数</label>'
        . '<div class="emoji-big-size-control">'
        . '<button type="button" class="emoji-big-size-step" data-step="-0.1" aria-label="减少 0.1">−</button>'
        . '<input id="emoji-big-size-input" name="size" type="number" min="0.1" max="60.0" step="any" inputmode="decimal" value="' . h($display) . '" autocomplete="off">'
        . '<button type="button" class="emoji-big-size-step" data-step="0.1" aria-label="增加 0.1">+</button>'
        . '</div>'
        . '<small>范围 0.1～60.0；支持小数，例如 0.1、0.25、1.8、2.5、10.75、60.0。按钮每次增减 0.1，也可以直接输入任意合法小数。</small>'
        . '</div>';
}

function emoji_big_admin_page(array $plugin): string
{
    $config = emoji_big_config();
    if (is_post_request()) {
        if ((string)($_POST['emoji_big_action'] ?? '') === 'toggle') emoji_big_admin_toggle();
        emoji_big_admin_save();
    }

    $status = $config['enabled'] ? '已开启' : '已关闭';
    $toggle_label = $config['enabled'] ? '快捷关闭' : '快捷开启';
    $toggle_class = $config['enabled'] ? 'danger' : '';
    $tokens = h($config['custom_tokens']);

    $html = '<div class="form-panel emoji-big-admin-root">'
        . '<div class="emoji-big-admin-head"><div><h2>大号表情符号</h2><p>版本 ' . h(EMOJI_BIG_VERSION) . ' / 当前状态：' . h($status) . '</p></div>'
        . post_action_form(admin_url(['tab' => 'emoji_big']), $toggle_label, ['emoji_big_action' => 'toggle'], $toggle_class) . '</div>'
        . '<form method="post">' . form_token()
        . checkbox('启用插件', 'enabled', $config['enabled'], '关闭后不再放大帖子和回复中的 Emoji。')
         . emoji_big_decimal_size_field($config['size'])
        . checkbox('主题正文启用', 'scope_topic', $config['scope_topic'])
        . checkbox('回复内容启用', 'scope_reply', $config['scope_reply'])
        . checkbox('启用限定模式', 'limited_mode', $config['limited_mode'], '开启后，只有满足“触发字符”或“自定义字符串”的 Emoji 才会放大。')
        . textarea('触发字符', 'trigger_chars', $config['trigger_chars'], false, '限定模式使用。Emoji 左右紧邻这些字符时才触发，例如：! ? ~ 。')
        . textarea('Emoji 前置合并字符', 'merge_before_chars', $config['merge_before_chars'], false, '命中后，将 Emoji 左侧连续出现的这些字符一起放大，例如输入：(*😂。')
        . textarea('Emoji 后置合并字符', 'merge_after_chars', $config['merge_after_chars'], false, '命中后，将 Emoji 右侧连续出现的这些字符一起放大，例如输入：😂!!!')
        . textarea('自定义字符串', 'custom_tokens', $tokens, false, '用逗号或换行分隔，例如：[狗头]、:smile:、233。限定模式下，Emoji 紧邻这些字符串也会触发，并会把字符串一起放大。')
        . '<div class="row"><label for="emoji-big-keyword-emoji-tokens">关键词/词语</label>'
        . '<textarea id="emoji-big-keyword-emoji-tokens" name="keyword_emoji_tokens" rows="3" placeholder="例如：开心,重要,哈哈,狗头">' . h($config['keyword_emoji_tokens'] ?? '') . '</textarea>'
        . '<small>单独填写此功能要匹配的关键词或词语，用逗号或换行分隔。不会使用“整条消息限定词”里的内容。</small></div>'
        . '<div class="row"><label for="emoji-big-keyword-emoji-mode">关键词/词语限定表情放大</label>'
        . '<select id="emoji-big-keyword-emoji-mode" name="keyword_emoji_mode">'
        . '<option value="none" ' . (($config['keyword_emoji_mode'] ?? 'none') === 'none' ? 'selected' : '') . '>关闭</option>'
        . '<option value="emoji_only" ' . (($config['keyword_emoji_mode'] ?? 'none') === 'emoji_only' ? 'selected' : '') . '>匹配到关键词后，仅放大消息中的 Emoji</option>'
        . '<option value="distance" ' . (($config['keyword_emoji_mode'] ?? 'none') === 'distance' ? 'selected' : '') . '>仅放大关键词附近距离内的 Emoji</option>'
        . '</select><small>这是独立的限定模式，只使用下面“关键词/词语”输入框。开启后，即使旧的“启用限定模式”关闭，也可以单独按关键词放大 Emoji；与旧限定同时开启时，两套规则任意命中即可。</small></div>'
        . '<div class="row" id="emoji-big-keyword-distance-row"><label for="emoji-big-keyword-emoji-distance">附近距离</label>'
        . '<input id="emoji-big-keyword-emoji-distance" name="keyword_emoji_distance" type="number" min="1" max="1000" step="1" value="' . h((string)($config['keyword_emoji_distance'] ?? 20)) . '">'
        . '<small>仅“附近距离”模式生效，按关键词前后字符距离 1～1000 判断。关键词模式单独计算，不会要求同时满足触发字符或自定义字符串。</small></div>'
        . '<div class="emoji-big-admin-example"><strong>示例</strong><span>😂 → 单独放大（普通模式）</span><span>😂!!! → 开启“后置符号只放大 Emoji”时，仅 😂 放大，!!! 不放大</span><span>[狗头]😂 → 可把 [狗头] 与 Emoji 作为一个整体放大</span><span>消息含“开心” → 在“关键词/词语”中填写“开心”，再选择“仅放大 Emoji”后，只有该消息的 Emoji 按规则放大</span></div>'
        . '<div class="row emoji-big-admin-actions"><button type="submit">保存设置</button></div>'
        . '</form></div>';
    return $html;
}

function emoji_big_css(): string
{
    return <<<'CSS'
 .emoji-big-size-field { margin: 1rem 0; }
.emoji-big-size-field > label { display:block; margin-bottom:.4rem; font-weight:600; }
.emoji-big-size-control { display:flex; align-items:center; gap:.35rem; max-width:20rem; }
.emoji-big-size-control input { width:9rem; }
.emoji-big-size-step { min-width:2.25rem; height:2.25rem; padding:0; cursor:pointer; }
.emoji-big-size-field small { display:block; margin-top:.4rem; opacity:.75; }
#emoji-big-keyword-emoji-mode { min-width: 20rem; }
#emoji-big-keyword-emoji-tokens { min-width: 20rem; }
#emoji-big-keyword-distance-row { margin-top: .5rem; }
 .emoji-big-root.emoji-big-whole-message { font-size: var(--emoji-big-size); }
.emoji-big-root .emoji-big-emoji {
    display: inline-block;
    font-size: var(--emoji-big-size);
    line-height: 1;
    vertical-align: -0.08em;
}
.emoji-big-admin-root .emoji-big-admin-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 18px;
}
.emoji-big-admin-root .emoji-big-admin-head h2 {
    margin: 0 0 4px;
}
.emoji-big-admin-root .emoji-big-admin-head p {
    margin: 0;
    color: var(--text-muted);
    font-size: var(--font-size-sm);
}
.emoji-big-admin-root .emoji-big-admin-example {
    display: grid;
    gap: 6px;
    margin-top: 14px;
    padding: 12px;
    border: 1px solid var(--line-soft);
    border-radius: 8px;
    background: var(--panel);
    color: var(--text-muted);
}
.emoji-big-admin-root .emoji-big-admin-actions {
    margin-top: 18px;
}
CSS;
}

function emoji_big_js(): string
{
    return <<<'JS'
(function () {
    "use strict";

    const emoji_big_emoji_pattern = /(?:\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?)*(?:\p{Emoji_Modifier})?|\p{Regional_Indicator}{2})/gu;

    function emoji_big_read_config(root) {
        try {
            const data = JSON.parse(root.getAttribute("data-emoji-big-config") || "{}");
            data.tokens = Array.isArray(data.tokens) ? data.tokens.filter(Boolean) : [];
            data.trigger = String(data.trigger || "");
            data.before = String(data.before || "");
            data.after = String(data.after || "");
            data.size = Math.max(0.1, Math.min(60.0, Number(data.size || 1.8)));
            data.limited = Number(data.limited || 0) === 1;
            data.emojiOnlySuffix = Number(data.emojiOnlySuffix || 0) === 1;
            data.wholeMessage = Number(data.wholeMessage || 0) === 1;
            data.wholeTokens = Array.isArray(data.wholeTokens) ? data.wholeTokens.map(String).filter(Boolean) : [];
            data.keywordEmojiTokens = Array.isArray(data.keywordEmojiTokens) ? data.keywordEmojiTokens.map(String).filter(Boolean) : [];
            data.keywordEmojiMode = ['none', 'emoji_only', 'distance'].includes(String(data.keywordEmojiMode || 'none')) ? String(data.keywordEmojiMode || 'none') : 'none';
            data.keywordEmojiDistance = Math.max(1, Math.min(1000, Number(data.keywordEmojiDistance || 20)));
            return data;
        } catch (error) {
            return null;
        }
    }

    function emoji_big_has_any_char(text, chars) {
        if (!text || !chars) return false;
        for (const char of Array.from(chars)) {
            if (text.includes(char)) return true;
        }
        return false;
    }

    function emoji_big_take_left(text, index, chars, tokens) {
        let start = index;
        while (start > 0) {
            let matched = false;
            for (const token of tokens) {
                if (token && text.slice(Math.max(0, start - token.length), start) === token) {
                    start -= token.length;
                    matched = true;
                    break;
                }
            }
            if (matched) continue;
            const previous = Array.from(text.slice(0, start)).pop() || "";
            if (!previous || !chars.includes(previous)) break;
            start -= previous.length;
        }
        return start;
    }

    function emoji_big_take_right(text, end, chars, tokens) {
        let finish = end;
        while (finish < text.length) {
            let matched = false;
            for (const token of tokens) {
                if (token && text.slice(finish, finish + token.length) === token) {
                    finish += token.length;
                    matched = true;
                    break;
                }
            }
            if (matched) continue;
            const next = Array.from(text.slice(finish)).shift() || "";
            if (!next || !chars.includes(next)) break;
            finish += next.length;
        }
        return finish;
    }

    function emoji_big_keyword_ranges(text, config) {
        if (config.keywordEmojiMode === "none" || !config.keywordEmojiTokens.length) return [];

        const ranges = [];
        // 关键词匹配允许跨换行：把 CRLF/CR 统一成 LF，并把连续空白视为可跨行空白。
        const normalized = String(text).replace(/\r\n?/g, "\n");

        for (const rawKeyword of config.keywordEmojiTokens) {
            const keyword = String(rawKeyword).trim();
            if (!keyword) continue;

            // 精确匹配优先；如果关键词本身包含换行，按原样匹配。
            let pos = normalized.indexOf(keyword);
            while (pos !== -1) {
                if (config.keywordEmojiMode === "emoji_only") {
                    ranges.push([0, text.length]);
                } else {
                    ranges.push([
                        Math.max(0, pos - config.keywordEmojiDistance),
                        Math.min(text.length, pos + keyword.length + config.keywordEmojiDistance)
                    ]);
                }
                pos = normalized.indexOf(keyword, pos + Math.max(1, keyword.length));
            }

            // 关键词不含换行时，额外允许关键词两部分之间出现换行/空白。
            if (!keyword.includes("\n") && /\s/.test(keyword)) {
                const escaped = keyword.split(/\s+/u).filter(Boolean)
                    .map(part => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
                    .join("\\s+");
                const re = new RegExp(escaped, "gu");
                let match;
                while ((match = re.exec(normalized)) !== null) {
                    if (config.keywordEmojiMode === "emoji_only") {
                        ranges.push([0, text.length]);
                    } else {
                        ranges.push([
                            Math.max(0, match.index - config.keywordEmojiDistance),
                            Math.min(text.length, match.index + match[0].length + config.keywordEmojiDistance)
                        ]);
                    }
                }
            }
        }
        return ranges;
    }


    function emoji_big_index_in_ranges(index, ranges) {
        for (const range of ranges) {
            if (index >= range[0] && index <= range[1]) return true;
        }
        return false;
    }

    function emoji_big_wrap_text_node(node, config, fullText, nodeOffset) {
        const text = node.nodeValue || "";
        if (!text) return;

        emoji_big_emoji_pattern.lastIndex = 0;
        const matches = [];
        let match;
        while ((match = emoji_big_emoji_pattern.exec(text)) !== null) matches.push({start: match.index, end: match.index + match[0].length, value: match[0]});
        if (!matches.length) return;

        const keywordModeActive = config.keywordEmojiMode !== "none" && config.keywordEmojiTokens.length > 0;
        const fullKeywordRanges = keywordModeActive
            ? emoji_big_keyword_ranges(fullText, config)
            : [];
        const keywordRanges = fullKeywordRanges.map(range => [
            range[0] - nodeOffset,
            range[1] - nodeOffset
        ]);

        const fragment = document.createDocumentFragment();
        let cursor = 0;

        for (const item of matches) {
            let start = item.start;
            let end = item.end;
            const left = text.slice(0, start);
            const right = text.slice(end);
            const leftTrigger = emoji_big_has_any_char(Array.from(left).slice(-1).join(""), config.trigger);
            const rightTrigger = emoji_big_has_any_char(Array.from(right)[0] || "", config.trigger);
            const tokenTrigger = config.tokens.some(token => (token && (left.endsWith(token) || right.startsWith(token))));
            const limitedMatch = leftTrigger || rightTrigger || tokenTrigger;

            // 1.3.1：关键词限定是“独立规则”，不再给原来的限定模式额外加一层限制。
            // 旧规则命中 OR 新关键词规则命中，即可放大。
            // 三类规则彼此独立：
            // 1) 普通模式：没有启用任何限定时，Emoji 全部放大；
            // 2) 旧限定模式：仅按触发字符/前后字符/自定义字符串判断；
            // 3) 关键词模式：仅按“关键词/词语”输入框判断。
            // 如果旧限定和关键词限定同时开启，则两套规则任意一套命中即可。
            const keywordRuleEnabled = keywordModeActive && config.keywordEmojiTokens.length > 0;
            const keywordRuleMatch = keywordRuleEnabled && emoji_big_index_in_ranges(item.start, keywordRanges);
            const oldRuleMatch = config.limited && limitedMatch;
            const normalMode = !config.limited && !keywordRuleEnabled;
            const shouldEnlarge = normalMode || oldRuleMatch || keywordRuleMatch;

            if (!shouldEnlarge) {
                if (start > cursor) fragment.appendChild(document.createTextNode(text.slice(cursor, start)));
                fragment.appendChild(document.createTextNode(item.value));
                cursor = end;
                continue;
            }

            start = emoji_big_take_left(text, start, config.before, config.tokens);
            const emojiEnd = item.end;
            end = emoji_big_take_right(text, end, config.after, config.tokens);
            if (config.emojiOnlySuffix && end > emojiEnd) end = emojiEnd;
            if (start < cursor) start = cursor;

            if (start > cursor) fragment.appendChild(document.createTextNode(text.slice(cursor, start)));
            const span = document.createElement("span");
            span.className = "emoji-big-emoji";
            span.style.setProperty("--emoji-big-size", config.size + "em");
            span.textContent = text.slice(start, end);
            fragment.appendChild(span);
            cursor = end;
        }

        if (cursor < text.length) fragment.appendChild(document.createTextNode(text.slice(cursor)));
        node.replaceWith(fragment);
    }

    function emoji_big_process(root) {
        if (!root || !(root instanceof Element || root instanceof Document)) return;
        const containers = root.matches?.(".emoji-big-root") ? [root] : Array.from(root.querySelectorAll(".emoji-big-root"));
        for (const container of containers) {
            const config = emoji_big_read_config(container);
            if (!config) continue;

            if (config.wholeMessage && config.wholeTokens.some(token => container.textContent.includes(token))) {
                container.classList.add("emoji-big-whole-message");
                container.style.setProperty("--emoji-big-size", config.size + "em");
                continue;
            }
            const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
                acceptNode(node) {
                    const parent = node.parentElement;
                    if (!parent || parent.closest(".emoji-big-emoji, script, style, textarea, input, code, pre")) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                }
            });
            const nodes = [];
            let node;
            while ((node = walker.nextNode())) nodes.push(node);

            // 统一按整个帖子正文计算关键词位置，避免关键词/距离判断在换行、
            // <br> 或多个文本节点之间被截断。
            const fullText = container.textContent || "";
            let searchOffset = 0;
            nodes.forEach(function (item) {
                const nodeText = item.nodeValue || "";
                const nodeOffset = fullText.indexOf(nodeText, searchOffset);
                const offset = nodeOffset >= 0 ? nodeOffset : searchOffset;
                emoji_big_wrap_text_node(item, config, fullText, offset);
                searchOffset = offset + nodeText.length;
            });
        }
    }

    function emoji_big_init() {
        emoji_big_process(document);
        if (!document.body) return;
        const observer = new MutationObserver(mutations => {
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE) emoji_big_process(node);
                    else if (node.nodeType === Node.TEXT_NODE && node.parentElement) emoji_big_process(node.parentElement);
                }
            }
        });
        observer.observe(document.body, {childList: true, subtree: true});
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", emoji_big_init, {once: true});
    else emoji_big_init();
}());
(function () {
    const keywordEmojiMode = document.getElementById("emoji-big-keyword-emoji-mode");
    const keywordDistanceRow = document.getElementById("emoji-big-keyword-distance-row");
    function emojiBigSyncKeywordDistance() {
        if (!keywordEmojiMode || !keywordDistanceRow) return;
        keywordDistanceRow.style.display = keywordEmojiMode.value === "distance" ? "" : "none";
    }
    if (keywordEmojiMode) {
        keywordEmojiMode.addEventListener("change", emojiBigSyncKeywordDistance);
        emojiBigSyncKeywordDistance();
    }

    const input = document.getElementById("emoji-big-size-input");
    if (!input) return;

    document.querySelectorAll(".emoji-big-size-step").forEach(function (button) {
        button.addEventListener("click", function () {
            let value = Number(String(input.value).replace(",", "."));
            if (!Number.isFinite(value)) value = 1.8;
            const step = Number(button.dataset.step || 0);
            value = Math.round((value + step) * 1000) / 1000;
            value = Math.min(60, Math.max(0.1, value));
            input.value = String(value);
            input.dispatchEvent(new Event("input", {bubbles: true}));
        });
    });

    input.addEventListener("blur", function () {
        let value = Number(String(input.value).replace(",", "."));
        if (!Number.isFinite(value)) value = 1.8;
        value = Math.min(60, Math.max(0.1, value));
        input.value = String(Math.round(value * 1000) / 1000);
    });
}());

JS;
}

return [
    'id' => 'emoji_big',
    'name' => '大号表情符号',
    'version' => EMOJI_BIG_VERSION,
    'description' => '放大论坛主题和回复中的表情符号，并可自定义放大倍数、触发字符和合并规则。',
    'author' => 'OpenAI',
    'assets' => ['css' => 'emoji_big_css', 'js' => 'emoji_big_js'],
    'hooks' => [
        'topic.after_render' => 'emoji_big_mark_post',
        'reply.after_render' => 'emoji_big_mark_post',
    ],
    'admin_tabs' => ['emoji_big' => 'emoji_big_admin_page'],
    'install' => 'emoji_big_install',
];