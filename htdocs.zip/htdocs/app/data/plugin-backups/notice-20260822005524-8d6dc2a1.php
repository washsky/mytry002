<?php
if (!defined('APP_ROOT')) exit;

// ============ 通知中心 1.0.0 ============
// 独立公告内容管理：所有用户可查看；拥有“用户和内容管理”权限的用户组可管理。
// 一个插件可管理多个通知，不需要为每个通知安装一个插件。
// 编辑表单同时提供 topic.form_extra 与 attachment.uploader，尽量复用论坛现有内容编辑扩展。

const NOTICE_DEFAULT_NAME = '站点公告';
const NOTICE_DEFAULT_TITLE = '欢迎来到 bbs1.org';
const NOTICE_DEFAULT_BODY = "这里是一个通知示例。\n\n拥有“用户和内容管理”权限的用户可以编辑、添加和管理通知。";
function notice_default_ui(): array
{
    return [
        'menu_label' => '通知中心',
        'page_title' => '通知中心',
        'page_subtitle' => '发布站点公告与社区消息',
        'add_label' => '发布公告',
        'edit_label' => '编辑公告',
        'disabled_label' => '未公开',
        'empty_label' => '暂无公告。',
        'edit_title' => '编辑公告',
        'new_title' => '发布公告',
        'back_label' => '返回通知中心',
        'name_label' => '公告名称',
        'name_help' => '用于标识公告，列表中会显示此名称。',
        'title_label' => '公告标题',
        'body_label' => '公告内容',
        'body_help' => '使用论坛现有 Markdown 内容格式，可配合已安装的编辑器和附件功能。',
        'enabled_label' => '公开显示',
        'enabled_help' => '关闭后普通用户不会看到此公告，但内容管理员仍可管理。',
        'sort_label' => '显示顺序',
        'sort_help' => '数字越小越靠前。',
        'edit_help' => '公告内容使用论坛现有 Markdown 渲染机制；已安装的内容编辑和附件扩展可在此继续使用。',
        'save_label' => '保存公告',
        'delete_label' => '删除公告',
        'cancel_label' => '取消',
        'deleted_flash' => '公告已删除',
        'saved_flash' => '公告已保存',
        'settings_title' => '通知中心设置',
        'settings_desc' => '设置通知中心对外显示的名称和界面文字，不影响公告正文内容。',
        'settings_save_label' => '保存通知中心设置',
        'settings_link_label' => '通知中心设置',
        'delete_confirm' => '确认删除这条公告吗？删除后无法恢复。',
        'settings_saved_flash' => '通知中心设置已保存',
        'empty_content_label' => '暂无公告内容。',
    ];
}

function notice_ui(array $plugin): array
{
    $config = plugin_config((string)($plugin['id'] ?? 'notice'), []);
    $defaults = notice_default_ui();
    $saved = is_array($config['ui'] ?? null) ? $config['ui'] : [];
    $ui = [];
    foreach ($defaults as $key => $value) {
        $candidate = trim((string)($saved[$key] ?? ''));
        $ui[$key] = $candidate !== '' ? cut($candidate, 500) : $value;
    }
    return $ui;
}

function notice_save_ui(array $plugin, array $ui): void
{
    $config = plugin_config((string)($plugin['id'] ?? 'notice'), []);
    $defaults = notice_default_ui();
    $clean = [];
    foreach ($defaults as $key => $default) {
        $value = trim((string)($ui[$key] ?? $default));
        $clean[$key] = cut($value !== '' ? $value : $default, 500);
    }
    $config['ui'] = $clean;
    plugin_save_config((string)$plugin['id'], $config);
}

function notice_default_item(): array
{
    return [
        'id' => 'notice_1',
        'name' => NOTICE_DEFAULT_NAME,
        'title' => NOTICE_DEFAULT_TITLE,
        'body' => NOTICE_DEFAULT_BODY,
        'enabled' => 1,
        'sort' => 10,
    ];
}

function notice_normalize_item(array $item, int $index = 0): array
{
    $id = trim((string)($item['id'] ?? ''));
    if ($id === '') $id = 'notice_' . max(1, $index + 1);
    $id = preg_replace('/[^A-Za-z0-9_-]/', '_', $id) ?: ('notice_' . max(1, $index + 1));
    return [
        'id' => $id,
        'name' => cut(trim((string)($item['name'] ?? '')), 120) ?: NOTICE_DEFAULT_NAME,
        'title' => cut(trim((string)($item['title'] ?? '')), 120) ?: NOTICE_DEFAULT_TITLE,
        'body' => cut(trim((string)($item['body'] ?? '')), 20000),
        'enabled' => !empty($item['enabled']) ? 1 : 0,
        'sort' => max(0, (int)($item['sort'] ?? 10)),
    ];
}

function notice_config(array $plugin): array
{
    $config = plugin_config((string)($plugin['id'] ?? 'notice'), []);
    $items = [];

    // 兼容 1.0.24 的单通知配置。
    if (is_array($config['notices'] ?? null)) {
        foreach ($config['notices'] as $index => $item) {
            if (is_array($item)) $items[] = notice_normalize_item($item, (int)$index);
        }
    } elseif (isset($config['title']) || isset($config['body'])) {
        $items[] = notice_normalize_item([
            'id' => 'notice_1',
            'name' => NOTICE_DEFAULT_NAME,
            'title' => (string)($config['title'] ?? NOTICE_DEFAULT_TITLE),
            'body' => (string)($config['body'] ?? NOTICE_DEFAULT_BODY),
            'enabled' => 1,
            'sort' => 10,
        ], 0);
    }

    if (!$items) $items[] = notice_default_item();

    // 去重 ID，并按排序显示。
    $seen = [];
    foreach ($items as $i => &$item) {
        $base = $item['id'];
        $candidate = $base;
        $n = 2;
        while (isset($seen[$candidate])) $candidate = $base . '_' . $n++;
        $item['id'] = $candidate;
        $seen[$candidate] = true;
    }
    unset($item);

    usort($items, static function (array $a, array $b): int {
        $sort = ((int)$a['sort']) <=> ((int)$b['sort']);
        return $sort !== 0 ? $sort : strcasecmp((string)$a['name'], (string)$b['name']);
    });

    return ['notices' => $items];
}

function notice_find(array $config, string $id): ?array
{
    foreach ($config['notices'] as $item) {
        if ((string)$item['id'] === $id) return $item;
    }
    return null;
}

function notice_save_config(array $plugin, array $items): void
{
    // 保存通知时保留现有页面显示设置等插件配置，避免新增/编辑/删除通知重置 UI。
    $config = plugin_config((string)($plugin['id'] ?? 'notice'), []);
    $normalized = [];
    $seen = [];
    foreach ($items as $index => $item) {
        if (!is_array($item)) continue;
        $item = notice_normalize_item($item, (int)$index);
        $base = $item['id'];
        $candidate = $base;
        $n = 2;
        while (isset($seen[$candidate])) $candidate = $base . '_' . $n++;
        $item['id'] = $candidate;
        $seen[$candidate] = true;
        $normalized[] = $item;
    }
    if (!$normalized) $normalized[] = notice_default_item();
    $config['notices'] = $normalized;
    plugin_save_config((string)$plugin['id'], $config);
}

function notice_top_menu($links, array $ctx): array
{
    $links = is_array($links) ? $links : [];
    $ui = notice_ui(['id' => 'notice']);
    $links[] = ['text' => $ui['menu_label'], 'url' => route_url('notifications')];
    return $links;
}

function notice_render_body(string $body): string
{
    $body = trim($body);
    if ($body === '') {
        $ui = notice_ui(['id' => 'notice']);
        return '<p class="notice-empty">' . h($ui['empty_content_label']) . '</p>';
    }
    return '<div class="post-content notice-content">' . markdown_html($body) . '</div>';
}

function notice_save(array $plugin): void
{
    require_post();
    need_manage();

    $config = notice_config($plugin);
    $id = trim((string)($_POST['notice_id'] ?? ''));
    $action = (string)($_POST['notice_action'] ?? 'save');

    if ($action === 'delete') {
        $remaining = array_values(array_filter($config['notices'], static fn(array $item): bool => (string)$item['id'] !== $id));
        if (!$remaining) err('至少需要保留一条公告');
        notice_save_config($plugin, $remaining);
        $ui = notice_ui($plugin);
        set_flash($ui['deleted_flash']);
        go(route_url('notifications'));
    }

    $name = cut(trim((string)($_POST['name'] ?? '')), 120);
    $title = cut(trim((string)($_POST['title'] ?? '')), 120);
    $body = cut(trim((string)($_POST['body'] ?? '')), 20000);
    $enabled = !empty($_POST['enabled']) ? 1 : 0;
    $sort = max(0, (int)($_POST['sort'] ?? 10));

    if ($name === '') $name = NOTICE_DEFAULT_NAME;
    if ($title === '') $title = $name;

    if ($id === '') {
        $id = 'notice_' . (string)(time() . '_' . random_int(100, 999));
        $config['notices'][] = [
            'id' => $id,
            'name' => $name,
            'title' => $title,
            'body' => $body,
            'enabled' => $enabled,
            'sort' => $sort,
        ];
    } else {
        $found = false;
        foreach ($config['notices'] as &$item) {
            if ((string)$item['id'] !== $id) continue;
            $item = [
                'id' => $id,
                'name' => $name,
                'title' => $title,
                'body' => $body,
                'enabled' => $enabled,
                'sort' => $sort,
            ];
            $found = true;
            break;
        }
        unset($item);
        if (!$found) err('公告不存在');
    }

    notice_save_config($plugin, $config['notices']);
    $ui = notice_ui($plugin);
    set_flash($ui['saved_flash']);
    go(route_url('notifications'));
}

function notice_settings_save(array $plugin): void
{
    require_post();
    need_manage();
    $defaults = notice_default_ui();
    $ui = [];
    foreach ($defaults as $key => $default) {
        $ui[$key] = trim((string)($_POST['ui'][$key] ?? $default));
    }
    notice_save_ui($plugin, $ui);
    $ui = notice_ui($plugin);
    set_flash($ui['settings_saved_flash']);
    go(route_url('notifications'));
}

function notice_settings_page(array $plugin): void
{
    need_manage();
    $ui = notice_ui($plugin);
    $fields = [
        ['menu_label', '顶部导航名称', '显示在论坛顶部导航中的名称。'],
        ['page_title', '中心标题', '通知中心顶部的大标题。'],
        ['page_subtitle', '中心副标题', '中心标题下面的说明文字。'],
        ['add_label', '发布按钮文字', '公告列表右上角的发布按钮。'],
        ['edit_label', '编辑按钮文字', '每条公告右上角的编辑按钮。'],
        ['disabled_label', '未公开状态文字', '管理员查看未公开公告时显示。'],
        ['empty_label', '空列表文字', '没有可显示公告时使用。'],
        ['edit_title', '编辑页标题', '编辑已有公告时的页面标题。'],
        ['new_title', '发布页标题', '发布公告时的页面标题。'],
        ['back_label', '返回按钮文字', '编辑页面返回通知中心的链接。'],
        ['name_label', '名称字段文字', '公告编辑页的名称字段标题。'],
        ['name_help', '名称字段说明', '公告名称字段下方的说明。'],
        ['title_label', '标题字段文字', '公告编辑页的标题字段标题。'],
        ['body_label', '内容字段文字', '公告编辑页的正文编辑框标题。'],
        ['body_help', '内容字段说明', '公告正文编辑框下方的说明。'],
        ['enabled_label', '公开显示字段文字', '公开/未公开开关的标题。'],
        ['enabled_help', '公开显示字段说明', '公开/未公开开关的说明。'],
        ['sort_label', '显示顺序字段文字', '显示顺序数字字段标题。'],
        ['sort_help', '显示顺序字段说明', '显示顺序数字字段说明。'],
        ['edit_help', '编辑器说明文字', '编辑页面底部的提示文字。'],
        ['save_label', '保存按钮文字', '编辑页面保存按钮。'],
        ['delete_label', '删除按钮文字', '编辑已有通知时的删除按钮。'],
        ['cancel_label', '取消按钮文字', '编辑页面取消链接。'],
        ['deleted_flash', '删除成功提示', '删除公告后显示的提示。'],
        ['saved_flash', '保存成功提示', '保存公告后显示的提示。'],
        ['settings_title', '设置页标题', '管理通知中心显示文字时使用的标题。'],
        ['settings_desc', '设置页说明', '管理通知中心显示文字时使用的说明。'],
        ['settings_save_label', '设置保存按钮文字', '保存通知中心设置的按钮。'],
        ['settings_link_label', '设置入口文字', '通知中心右上角进入设置的链接。'],
        ['delete_confirm', '删除确认文字', '点击删除通知后显示的确认提示。'],
        ['settings_saved_flash', '设置保存成功提示', '保存通知中心设置后显示的提示。'],
        ['empty_content_label', '空公告内容文字', '公告正文为空时显示的文字。'],
    ];
    $body = '<div class="notice-edit form-panel topic-form-panel">'
        . '<div class="notice-edit-head"><div><h1>' . h($ui['settings_title']) . '</h1><p class="notice-settings-desc">' . h($ui['settings_desc']) . '</p></div><a href="' . h(route_url('notifications')) . '">' . h($ui['back_label']) . '</a></div>'
        . '<form method="post" action="' . h(route_url('notifications')) . '">' . form_token()
        . '<input type="hidden" name="do" value="settings_save">';
    foreach ($fields as [$key, $label, $help]) {
        $body .= input($label, 'ui[' . $key . ']', $ui[$key], 'text', true, $help);
    }
    $body .= '<div class="form-actions"><button type="submit">' . h($ui['settings_save_label']) . '</button><a href="' . h(route_url('notifications')) . '">' . h($ui['cancel_label']) . '</a></div>'
        . '</form></div>';
    page($ui['settings_title'], shell_html($body, sidebar_stack_html([sidebar_user_card_html()] )));
}

function notice_edit_page(array $plugin, array $config): void
{
    need_manage();
    $ui = notice_ui($plugin);

    $id = trim((string)($_GET['id'] ?? ''));
    $editing = $id !== '';
    $item = $editing ? notice_find($config, $id) : null;
    if ($editing && !$item) err('公告不存在');
    if (!$editing) $item = [
        'id' => '',
        'name' => NOTICE_DEFAULT_NAME,
        'title' => NOTICE_DEFAULT_TITLE,
        'body' => '',
        'enabled' => 1,
        'sort' => 10,
    ];

    $fake_topic = [
        'id' => 0,
        'title' => $item['title'],
        'body' => $item['body'],
        'user_id' => uid(),
    ];
    $form_extra = (string)hook('topic.form_extra', '', ['topic' => $fake_topic, 'editing' => $editing, 'notice' => true]);
    $attachments = (string)hook('attachment.uploader', '', ['muted' => true, 'notice' => true]);

    $delete = '';
    if ($editing) {
        $confirm_js = h(json_encode($ui['delete_confirm'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $delete = '<button type="submit" name="notice_action" value="delete" formnovalidate data-notice-delete="1" onclick="return confirm(' . $confirm_js . ')">' . h($ui['delete_label']) . '</button>';
    }

    $body = '<div class="notice-edit form-panel topic-form-panel">'
        . '<div class="notice-edit-head"><h1>' . h($editing ? $ui['edit_title'] : $ui['new_title']) . '</h1><a href="' . h(route_url('notifications')) . '">' . h($ui['back_label']) . '</a></div>'
        . '<form method="post" action="' . h(route_url('notifications')) . '">'
        . form_token()
        . '<input type="hidden" name="notice_id" value="' . h($item['id']) . '">'
        . '<input type="hidden" name="do" value="save">'
        . '<input type="hidden" name="notice_action" value="save">'
        . input($ui['name_label'], 'name', $item['name'], 'text', true, $ui['name_help'])
        . input($ui['title_label'], 'title', $item['title'], 'text', true)
        . textarea($ui['body_label'], 'body', $item['body'], false, $ui['body_help'])
        . $attachments
        . $form_extra
        . checkbox($ui['enabled_label'], 'enabled', !empty($item['enabled']), $ui['enabled_help'])
        . number_input($ui['sort_label'], 'sort', (int)$item['sort'], 0, 9999, true, $ui['sort_help'])
        . '<p class="notice-edit-help">' . h($ui['edit_help']) . '</p>'
        . '<div class="form-actions"><button type="submit" data-loading-text="保存中">' . h($ui['save_label']) . '</button>' . $delete . '<a href="' . h(route_url('notifications')) . '">' . h($ui['cancel_label']) . '</a></div>'
        . '</form>'
        . '</div>';

    page($editing ? $ui['edit_title'] : $ui['new_title'], shell_html($body, sidebar_stack_html([sidebar_user_card_html()] )));
}

function notice_page(array $plugin): void
{
    $config = notice_config($plugin);
    $ui = notice_ui($plugin);
    $do = (string)($_GET['do'] ?? $_POST['do'] ?? '');

    if ($do === 'settings_save') {
        notice_settings_save($plugin);
        return;
    }
    if ($do === 'save' || $do === 'delete') {
        notice_save($plugin);
        return;
    }
    if ($do === 'edit') {
        notice_edit_page($plugin, $config);
        return;
    }
    if ($do === 'settings') {
        notice_settings_page($plugin);
        return;
    }

    $actions = can_manage()
        ? '<span class="notice-admin-actions"><a class="notice-edit-link" href="' . h(route_url('notifications', ['do' => 'edit'])) . '">' . h($ui['add_label']) . '</a> <a class="notice-edit-link notice-settings-link" href="' . h(route_url('notifications', ['do' => 'settings'])) . '">' . h($ui['settings_link_label']) . '</a></span>'
        : '';

    $cards = '';
    foreach ($config['notices'] as $item) {
        if (empty($item['enabled']) && !can_manage()) continue;
        $admin = can_manage()
            ? '<a class="notice-card-edit" href="' . h(route_url('notifications', ['do' => 'edit', 'id' => $item['id']])) . '">' . h($ui['edit_label']) . '</a>'
            : '';
        $status = !empty($item['enabled']) ? '' : '<span class="notice-disabled">' . h($ui['disabled_label']) . '</span>';
        $cards .= '<article class="notice-card' . (empty($item['enabled']) ? ' notice-card-disabled' : '') . '">'
            . '<div class="notice-card-head"><div><div class="notice-card-name">' . h($item['name']) . ' ' . $status . '</div><h2>' . h($item['title']) . '</h2></div>' . $admin . '</div>'
            . notice_render_body($item['body'])
            . '</article>';
    }

    if ($cards === '') $cards = '<p class="notice-empty">' . h($ui['empty_label']) . '</p>';

    $body = '<div class="notice-page">'
        . '<div class="notice-head"><div><h1 class="notice-title">' . h($ui['page_title']) . '</h1><p class="notice-sub">' . h($ui['page_subtitle']) . '</p></div>' . $actions . '</div>'
        . $cards
        . '</div>';

    page($ui['page_title'], shell_html($body, sidebar_stack_html([sidebar_user_card_html(null, true)])));
}

function notice_head($value, array $ctx): string
{
    if ((string)($_GET['a'] ?? '') !== 'notifications') return (string)$value;
    return (string)$value . notice_css();
}

function notice_css(): string
{
    return '<style>'
        . '.notice-page{max-width:860px;margin:0 auto;padding:var(--space-lg,16px)}'
        . '.notice-head{display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-md,14px);margin-bottom:var(--space-md,14px)}'
        . '.notice-title{font-size:var(--font-size-xl);margin:0;color:var(--text)}'
        . '.notice-sub{font-size:var(--font-size-sm);color:var(--text-muted);margin:4px 0 0}'
        . '.notice-edit-link,.notice-card-edit{color:var(--brand-hover);font-size:var(--font-size-sm);font-weight:600;text-decoration:none}'
        . '.notice-edit-link:hover,.notice-card-edit:hover{color:var(--brand)}'
        . '.notice-card{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);padding:var(--space-lg,16px);margin-bottom:var(--space-md,14px)}'
        . '.notice-card-disabled{opacity:.65}'
        . '.notice-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-md,14px);margin-bottom:var(--space-md,14px)}'
        . '.notice-card-name{font-size:var(--font-size-sm);color:var(--text-muted);margin-bottom:4px}'
        . '.notice-card h2{font-size:var(--font-size-lg);margin:0;color:var(--text)}'
        . '.notice-disabled{display:inline-block;margin-left:6px;padding:2px 6px;border:1px solid var(--line);border-radius:999px;font-size:11px}'
        . '.notice-content,.notice-empty{color:var(--text);font-size:var(--font-size-md);line-height:1.8}'
        . '.notice-content p:first-child{margin-top:0}.notice-content p:last-child{margin-bottom:0}'
        . '.notice-empty{color:var(--text-muted);margin:0}'
        . '.notice-edit{max-width:860px;margin:0 auto}'
        . '.notice-edit-head{display:flex;align-items:center;justify-content:space-between;gap:var(--space-md,14px);margin-bottom:var(--space-md,14px)}'
        . '.notice-edit-head h1{font-size:var(--font-size-xl);margin:0}'
        . '.notice-edit-head a,.notice-edit .form-actions a{color:var(--brand-hover);text-decoration:none}'
        . '.notice-edit textarea{min-height:320px}'
        . '.notice-settings-desc{font-size:var(--font-size-sm);color:var(--text-muted);margin:4px 0 0}.notice-edit-help{font-size:var(--font-size-sm);color:var(--text-muted);margin:var(--space-sm,8px) 0}'
        . '.notice-edit .form-actions{display:flex;align-items:center;gap:var(--space-md,14px);margin-top:var(--space-md,14px);flex-wrap:wrap}'
        . '.notice-edit .form-actions button[name="notice_action"][value="delete"]{margin-left:auto}'
        . '@media (max-width:640px){.notice-head,.notice-card-head{flex-direction:column}.notice-edit-head{align-items:flex-start;flex-direction:column}.notice-edit .form-actions button[name="notice_action"][value="delete"]{margin-left:0}}'
        . '</style>';
}

return [
    'id' => 'notice',
    'name' => '通知中心',
    'version' => '1.0.0',
    'description' => '通用通知中心(改编自“开发者文档中心”插件)：拥有“用户和内容管理”权限的用户可以公告发布、编辑、删除、排序、公开状态和通知中心界面文字自定义。',
    'author' => 'bbc',
    'hooks' => [
        'top.menu_links' => 'notice_top_menu',
        'page.head' => 'notice_head',
    ],
    'entries' => ['top_menu' => true],
    'routes' => [
        'notifications' => 'notice_page',
    ],
];