<?php
if (!defined('APP_ROOT')) exit;

/**
 * 今日热点 (Today Hot)
 * 参考 newsnow 的实时热点聚合页，数据源统一使用 orz-ai/hot_news 项目 API
 * （https://news.orz.ai/api/v1/dailynews ），一次拉取其支持的全部 22 个平台热点。
 * 支持分类浏览、计划任务刷新、缓存与侧边栏卡片。纯插件实现，不修改核心。
 */

const TODAY_HOT_CACHE_PREFIX = 'today_hot_cache_';

function today_hot_sources(): array
{
    // 覆盖 orz-ai/hot_news 项目支持的全部平台（key=缓存/配置键，code=API 平台码）
    return [
        // —— 科技 ——
        'github'        => ['name' => 'GitHub 趋势', 'code' => 'github', 'cat' => 'tech', 'color' => '#4078c0'],
        'hackernews'    => ['name' => 'Hacker News', 'code' => 'hackernews', 'cat' => 'tech', 'color' => '#ff6600'],
        'stackoverflow' => ['name' => 'Stack Overflow', 'code' => 'stackoverflow', 'cat' => 'tech', 'color' => '#f48024'],
        '36kr'          => ['name' => '36氪', 'code' => '36kr', 'cat' => 'tech', 'color' => '#ea4c89'],
        'juejin'        => ['name' => '掘金', 'code' => 'juejin', 'cat' => 'tech', 'color' => '#1e80ff'],
        'sspai'         => ['name' => '少数派', 'code' => 'shaoshupai', 'cat' => 'tech', 'color' => '#e05a33'],
        'v2ex'          => ['name' => 'V2EX', 'code' => 'v2ex', 'cat' => 'tech', 'color' => '#52699e'],
        // —— 综合 ——
        'baidu'         => ['name' => '百度热搜', 'code' => 'baidu', 'cat' => 'news', 'color' => '#2932e1'],
        'weibo'         => ['name' => '微博热搜', 'code' => 'weibo', 'cat' => 'news', 'color' => '#e6162d'],
        'zhihu'         => ['name' => '知乎热榜', 'code' => 'zhihu', 'cat' => 'news', 'color' => '#0084ff'],
        'jinritoutiao'  => ['name' => '今日头条', 'code' => 'jinritoutiao', 'cat' => 'news', 'color' => '#ff6b35'],
        'tenxunwang'    => ['name' => '腾讯网', 'code' => 'tenxunwang', 'cat' => 'news', 'color' => '#0085ff'],
        // —— 财经 ——
        'sina_finance'  => ['name' => '新浪财经', 'code' => 'sina_finance', 'cat' => 'finance', 'color' => '#e60012'],
        'eastmoney'     => ['name' => '东方财富', 'code' => 'eastmoney', 'cat' => 'finance', 'color' => '#c8161d'],
        'xueqiu'        => ['name' => '雪球', 'code' => 'xueqiu', 'cat' => 'finance', 'color' => '#0077cc'],
        'cls'           => ['name' => '财联社', 'code' => 'cls', 'cat' => 'finance', 'color' => '#e33e3e'],
        // —— 娱乐 ——
        'bilibili'      => ['name' => '哔哩哔哩', 'code' => 'bilibili', 'cat' => 'media', 'color' => '#fb7299'],
        'douyin'        => ['name' => '抖音', 'code' => 'douyin', 'cat' => 'media', 'color' => '#fe2c55'],
        'douban'        => ['name' => '豆瓣', 'code' => 'douban', 'cat' => 'media', 'color' => '#2db06d'],
        'hupu'          => ['name' => '虎扑', 'code' => 'hupu', 'cat' => 'media', 'color' => '#ff7d00'],
        // —— 社区 ——
        '52pojie'       => ['name' => '吾爱破解', 'code' => '52pojie', 'cat' => 'community', 'color' => '#ff8a00'],
        'tieba'         => ['name' => '百度贴吧', 'code' => 'tieba', 'cat' => 'community', 'color' => '#4e6ef2'],
    ];
}

function today_hot_categories(): array
{
    return ['all' => '全部', 'tech' => '科技', 'news' => '综合', 'finance' => '财经', 'media' => '娱乐', 'community' => '社区'];
}

function today_hot_sidebar_page_options(): array
{
    return ['home' => '首页', 'forum' => '版块列表', 'topic' => '看帖页'];
}

function today_hot_selected_sidebar_pages(mixed $value): array
{
    if (is_string($value)) $value = explode(',', $value);
    if (!is_array($value)) return [];
    $selected = [];
    foreach (today_hot_sidebar_page_options() as $page => $_label) {
        if (!empty($value[$page]) || in_array($page, $value, true)) $selected[$page] = true;
    }
    return $selected;
}

function today_hot_config_defaults(): array
{
    $enabled = [];
    foreach (today_hot_sources() as $key => $_def) $enabled[$key] = 1;
    return $enabled;
}

function today_hot_config(): array
{
    $raw = plugin_config('today_hot', []);
    $enabled = [];
    foreach (today_hot_sources() as $key => $_def) $enabled[$key] = !empty($raw['enabled'][$key]);
    if (array_filter($enabled) === []) $enabled = today_hot_config_defaults(); // 默认全部启用
    return [
        'menu_name' => cut(trim((string)($raw['menu_name'] ?? '今日热点')), 20),
        'enabled' => $enabled,
        'limit' => min(80, max(10, (int)($raw['limit'] ?? 40))),
        'per_source' => min(20, max(3, (int)($raw['per_source'] ?? 8))),
        'cache_ttl' => min(7200, max(120, (int)($raw['cache_ttl'] ?? 600))),
        'refresh_seconds' => min(3600, max(60, (int)($raw['refresh_seconds'] ?? 600))),
        'sidebar' => array_key_exists('sidebar', $raw) ? (empty($raw['sidebar']) ? 0 : 1) : 1,
        'sidebar_random' => array_key_exists('sidebar_random', $raw) ? (empty($raw['sidebar_random']) ? 0 : 1) : 1,
        'sidebar_limit' => min(20, max(5, (int)($raw['sidebar_limit'] ?? 8))),
        'sidebar_pages' => today_hot_selected_sidebar_pages($raw['sidebar_pages'] ?? []),
        'cron_interval' => min(86400, max(120, (int)($raw['cron_interval'] ?? 600))),
    ];
}

/* ---------- HTTP ---------- */

function today_hot_http_get(string $url, array $headers = []): string
{
    if (!function_exists('curl_init')) throw new RuntimeException('需要启用 cURL 扩展');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 4,
        CURLOPT_CONNECTTIMEOUT => 12,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_ENCODING => '',
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        CURLOPT_HTTPHEADER => array_merge(['Accept' => 'application/json,text/html,application/xml,*/*;q=0.8'], $headers),
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $error = curl_error($ch);
    if (PHP_VERSION_ID < 80000) curl_close($ch);
    if ($body === false || $code >= 400) throw new RuntimeException('HTTP ' . $code . ' ' . $error);
    return (string)$body;
}

function today_hot_json_get(string $url, array $headers = []): array
{
    $j = json_decode(today_hot_http_get($url, $headers), true);
    return is_array($j) ? $j : [];
}

function today_hot_now(): int
{
    return (int)time();
}

function today_hot_count(int $n): string
{
    if ($n >= 10000) return rtrim(rtrim(sprintf('%.1f', $n / 10000), '0'), '.') . ' 万';
    if ($n >= 1000) return rtrim(rtrim(sprintf('%.1f', $n / 1000), '0'), '.') . 'k';
    return (string)$n;
}

/* ---------- 数据源：orz-ai/hot_news API（一次拉取全部平台） ---------- */

function today_hot_fetch_orbit_all(int $per_source): array
{
    $j = today_hot_json_get('https://news.orz.ai/api/v1/dailynews/all');
    if (empty($j['status']) || (string)$j['status'] !== '200') return [];
    $data = $j['data'] ?? [];
    if (!is_array($data)) return [];
    $out = [];
    foreach ($data as $platform => $list) {
        if (!is_array($list)) continue;
        $items = [];
        foreach ($list as $row) {
            if (!is_array($row) || empty($row['title'])) continue;
            $score = (int)($row['score'] ?? 0);
            $content = trim((string)($row['content'] ?? ''));
            $url = trim((string)($row['url'] ?? ''));
            if ($url === '') $url = '#';
            $ts = (int)@strtotime((string)($row['publish_time'] ?? ''));
            $items[] = [
                'key' => $platform,
                'source' => $platform,
                'title' => cut((string)$row['title'], 200),
                'url' => $url,
                'desc' => $content,
                'meta' => $score > 0 ? today_hot_count($score) : '',
                'time' => $ts > 0 ? $ts : 0,
            ];
        }
        if ($per_source > 0) $items = array_slice($items, 0, $per_source);
        $out[$platform] = $items;
    }
    return $out;
}

/* ---------- 缓存 ---------- */

function today_hot_cache_path(string $key): string
{
    return DATA_DIR . '/' . TODAY_HOT_CACHE_PREFIX . $key . '.json';
}

function today_hot_cache_read(string $key): ?array
{
    $f = today_hot_cache_path($key);
    if (!is_file($f)) return null;
    $d = json_decode((string)file_get_contents($f), true);
    return is_array($d) ? $d : null;
}

function today_hot_cache_write(string $key, array $data): void
{
    @file_put_contents(today_hot_cache_path($key), json_encode($data, JSON_UNESCAPED_UNICODE));
}

// 仅读缓存，不触发任何外部抓取（页面访问走此函数，保证快速）
function today_hot_cache_items(string $key): array
{
    $cache = today_hot_cache_read($key);
    return $cache !== null ? (array)($cache['items'] ?? []) : [];
}

function today_hot_merged(array $config, string $cat = 'all', ?int $limit = null): array
{
    $sources = today_hot_sources();
    $limit = $limit ?? (int)$config['limit'];
    $all = [];
    foreach ($sources as $key => $def) {
        if (empty($config['enabled'][$key])) continue;
        if ($cat !== 'all' && $def['cat'] !== $cat) continue;
        $all = array_merge($all, today_hot_cache_items($key)); // 仅读缓存
        if (count($all) >= $limit) break;
    }
    return array_slice($all, 0, $limit);
}

function today_hot_update_cache(bool $force = true): void
{
    $config = today_hot_config();
    // 非强制时按“上次拉取时间 + TTL”跳过，避免频繁请求
    if (!$force) {
        $mark = DATA_DIR . '/today_hot_last_fetch';
        $last = is_file($mark) ? (int)trim((string)@file_get_contents($mark)) : 0;
        if (today_hot_now() - $last < (int)$config['cache_ttl']) return;
    }
    try {
        $all = today_hot_fetch_orbit_all((int)$config['per_source']);
    } catch (Throwable $e) {
        $all = []; // 抓取失败时不覆盖旧缓存，页面回退显示
    }
    if ($all === []) return;
    foreach (today_hot_sources() as $key => $def) {
        if (empty($config['enabled'][$key])) continue;
        $code = (string)($def['code'] ?? $key);
        if (!isset($all[$code])) continue;
        today_hot_cache_write($key, ['fetched_at' => today_hot_now(), 'items' => $all[$code]]);
    }
    @file_put_contents(DATA_DIR . '/today_hot_last_fetch', (string)today_hot_now());
}

/* ---------- 渲染 ---------- */

function today_hot_cat_href(string $cat): string
{
    return route_url('today_hot', $cat === 'all' ? [] : ['cat' => $cat]);
}

function today_hot_rel_time(int $ts): string
{
    $diff = today_hot_now() - $ts;
    if ($diff < 60) return '刚刚';
    if ($diff < 3600) return intdiv($diff, 60) . ' 分钟前';
    if ($diff < 86400) return intdiv($diff, 3600) . ' 小时前';
    return intdiv($diff, 86400) . ' 天前';
}

function today_hot_badge_def(string $key): array
{
    $sources = today_hot_sources();
    return $sources[$key] ?? ['name' => $key, 'color' => '#999'];
}

function today_hot_source_rgba(string $hex, float $alpha = 0.10): string
{
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return sprintf('rgba(%d,%d,%d,%.2f)', $r, $g, $b, $alpha);
}

function today_hot_source_card_html(string $key, array $def, array $items): string
{
    $color = (string)($def['color'] ?? '#666');
    $name = (string)($def['name'] ?? $key);
    $count = count($items);
    $list = '';
    $rank = 1;
    foreach ($items as $item) {
        $inline = '';
        if ((string)($item['meta'] ?? '') !== '') $inline .= '<span class="t-inline">' . h((string)$item['meta']) . '</span>';
        if ((int)($item['time'] ?? 0) > 0) $inline .= '<span class="t-rel">' . h(today_hot_rel_time((int)$item['time'])) . '</span>';
        $desc = (string)($item['desc'] ?? '');
        $desc_html = ($desc !== '' && $desc !== (string)($item['title'] ?? ''))
            ? '<span class="t-desc">' . h(cut($desc, 140)) . '</span>' : '';
        $list .= '<li class="t-row">'
            . '<span class="t-rank' . ($rank <= 3 ? ' t-rank-top' : '') . '">' . $rank . '</span>'
            . '<a class="t-link" href="' . h((string)($item['url'] ?? '#')) . '" target="_blank" rel="noopener noreferrer nofollow"'
            . ' title="' . h((string)($item['desc'] ?? '')) . '">'
            . '<span class="t-title">' . h((string)($item['title'] ?? '')) . '</span>'
            . $desc_html
            . ($inline !== '' ? '<span class="t-extra">' . $inline . '</span>' : '')
            . '</a></li>';
        $rank++;
    }
    if ($list === '') $list = '<li class="t-row t-empty">暂无内容</li>';
    return '<section class="today-card" style="--src:' . h($color) . ';--src-soft:' . today_hot_source_rgba($color) . '">'
        . '<div class="today-card-head">'
        . '<span class="today-card-icon" style="background:var(--src)"><span class="today-card-letter">' . h(function_exists('mb_substr') ? mb_substr($name, 0, 1) : substr($name, 0, 1)) . '</span></span>'
        . '<div class="today-card-titlewrap"><span class="today-card-name">' . h($name) . '</span>'
        . '<span class="today-card-cat">' . h(today_hot_categories()[$def['cat']] ?? '') . '</span></div>'
        . '<span class="today-card-count">' . $count . ' 条</span>'
        . '</div>'
        . '<ol class="today-card-list">' . $list . '</ol></section>';
}

function today_hot_feed_html(array $config, string $cat = 'all'): string
{
    $cards = '';
    foreach (today_hot_sources() as $key => $def) {
        if (empty($config['enabled'][$key])) continue;
        if ($cat !== 'all' && $def['cat'] !== $cat) continue;
        $cards .= today_hot_source_card_html($key, $def, today_hot_cache_items($key));
    }
    if ($cards === '') return '<div class="today-hot-empty">暂无符合条件的内容，请稍后刷新重试。</div>';
    return '<div class="today-hot-grid">' . $cards . '</div>';
}

function today_hot_partial(array $config, string $cat): array
{
    $tabs = '';
    foreach (today_hot_categories() as $key => $label) {
        $tabs .= '<a class="today-hot-tab' . ($key === $cat ? ' active' : '') . '" data-cat="' . h($key) . '" href="' . h(today_hot_cat_href($key)) . '">' . h($label) . '</a>';
    }
    $tabs_html = '<div class="today-hot-tabs">' . $tabs . '</div>';

    $header_html = '<div class="today-hot-header"><div class="today-hot-head-main"><h1 class="today-hot-title">' . h($config['menu_name']) . '</h1>'
        . '<p class="today-hot-subtitle">聚合多平台实时热点 · 自动更新</p></div>'
        . '<div class="today-hot-meta"><span class="today-hot-updated" data-today-hot-updated>更新于 ' . h(date('H:i:s')) . '</span>'
        . '<button type="button" class="today-hot-refresh" data-today-hot-refresh>刷新</button></div></div>';

    $feed = today_hot_feed_html($config, $cat);

    return [
        'refresh_base' => route_url('today_hot_refresh', ['cat' => '__CAT__']),
        'header' => $header_html,
        'topbar' => '<div class="today-hot-topbar">' . $tabs_html . '</div>',
        'feed' => $feed,
        'cat' => $cat,
        'title' => $config['menu_name'],
        'refresh_ms' => (int)$config['refresh_seconds'] * 1000,
    ];
}

function today_hot_page(array $plugin): void
{
    $config = today_hot_config();
    $cat = (string)($_GET['cat'] ?? 'all');
    if (!isset(today_hot_categories()[$cat])) $cat = 'all';

    $p = today_hot_partial($config, $cat);
    $html = '<div class="today-hot-page" data-today-hot'
        . ' data-refresh-base="' . h($p['refresh_base']) . '"'
        . ' data-refresh-ms="' . $p['refresh_ms'] . '"'
        . ' data-cat="' . h($p['cat']) . '">'
        . $p['header'] . $p['topbar'] . $p['feed'] . '</div>';

    if (ajax_request()) {
        json_response(['ok' => 1, 'html' => $html, 'page_title' => $p['title']]);
    }

    $main = $html;
    $sidebar = sidebar_stack_html([sidebar_user_card_html()], ['route' => 'today_hot']);

    page($config['menu_name'], shell_html($main, $sidebar), ['description' => '今日热点：数据源使用 orz-ai/hot_news API，聚合 22 个平台（GitHub/微博/知乎/百度/掘金/V2EX/财经等）的实时热门。']);
}
function today_hot_refresh_page(array $plugin): void
{
    $config = today_hot_config();
    $cat = (string)($_GET['cat'] ?? 'all');
    if (!isset(today_hot_categories()[$cat])) $cat = 'all';
    $p = today_hot_partial($config, $cat);
    json_response(['ok' => 1, 'html' => $p['feed']]);
}

/* ---------- 侧边栏与快捷功能 ---------- */

function today_hot_feature_links($links, array $ctx): array
{
    $links = is_array($links) ? $links : [];
    $config = today_hot_config();
    $links[] = ['text' => $config['menu_name'], 'url' => route_url('today_hot')];
    return $links;
}

/* 顶部菜单入口：追加“今日热点”到顶部导航 */
function today_hot_menu_links($links, array $ctx): array
{
    $links = is_array($links) ? $links : [];
    $config = today_hot_config();
    $url = route_url('today_hot');
    foreach ($links as $l) {
        if (is_array($l) && (string)($l['url'] ?? $l['href'] ?? '') === $url) return $links;
    }
    $links[] = ['text' => $config['menu_name'], 'url' => $url];
    return $links;
}

function today_hot_card_html(array $config): string
{
    // 随机模式：每次访问随机展示一个媒体源卡片
    if (!empty($config['sidebar_random'])) {
        return today_hot_random_card_html($config);
    }
    $items = today_hot_merged($config, 'all', (int)$config['sidebar_limit']);
    $items_html = '';
    $rank = 1;
    foreach ($items as $item) {
        $badge = today_hot_badge_def((string)($item['source'] ?? ''));
        $rank_cls = $rank <= 3 ? ' today-hot-card-rank-top' : '';
        $items_html .= '<li><a href="' . h((string)($item['url'] ?? '#')) . '" target="_blank" rel="noopener noreferrer nofollow">'
            . '<span class="today-hot-card-badge" style="background:' . h((string)$badge['color']) . '">' . h((string)$badge['name']) . '</span>'
            . '<span class="today-hot-card-content"><span class="today-hot-card-title">' . h((string)($item['title'] ?? '')) . '</span></span>'
            . '<span class="today-hot-card-rank' . $rank_cls . '">' . $rank . '</span>'
            . '</a></li>';
        $rank++;
    }
    if ($items_html === '') $items_html = '<li class="today-hot-card-empty">暂无数据</li>';

    return '<div class="card sidebar-card quick-card today-hot-card">'
        . '<div class="quick-wrap"><div class="today-hot-card-head"><div class="quick-title">' . h($config['menu_name']) . '</div>'
        . '<a class="today-hot-card-more" href="' . h(route_url('today_hot')) . '" target="_blank">更多</a></div>'
        . '<ul class="quick-links today-hot-card-list">' . $items_html . '</ul></div></div>';
}

function today_hot_sidebar($parts, array $ctx): array
{
    $parts = is_array($parts) ? $parts : [];
    $config = today_hot_config();
    if (empty($config['sidebar'])) return $parts;
    $route = (string)($ctx['route'] ?? '');
    if ($route === '') $route = (string)($_GET['a'] ?? 'home'); // sidebar hooks 不携带 route，故从请求推导
    if (!in_array($route, ['home', 'forum', 'topic'], true)) return $parts;
    if ($config['sidebar_pages'] && !isset($config['sidebar_pages'][$route])) return $parts;
    array_splice($parts, min(1, count($parts)), 0, [today_hot_card_html($config)]);
    return $parts;
}

/* 随机模式侧边栏卡片：每次随机展示一个媒体源的完整卡片 */
function today_hot_random_card_html(array $config): string
{
    $enabled = [];
    foreach (today_hot_sources() as $key => $def) {
        if (!empty($config['enabled'][$key])) $enabled[] = $key;
    }
    if ($enabled === []) return '';
    $key = $enabled[array_rand($enabled)];
    $def = today_hot_sources()[$key];
    $color = (string)($def['color'] ?? '#666');
    $name = (string)($def['name'] ?? $key);
    $items = array_slice(today_hot_cache_items($key), 0, (int)$config['sidebar_limit']);
    $rows = '';
    $rank = 1;
    foreach ($items as $it) {
        $rank_cls = $rank <= 3 ? ' today-hot-card-rank-top' : '';
        $rows .= '<li><a href="' . h((string)($it['url'] ?? '#')) . '" target="_blank" rel="noopener noreferrer nofollow">'
            . '<span class="today-hot-card-rank' . $rank_cls . '">' . $rank . '</span>'
            . '<span class="today-hot-card-content"><span class="today-hot-card-title">' . h((string)($it['title'] ?? '')) . '</span></span>'
            . '</a></li>';
        $rank++;
    }
    if ($rows === '') $rows = '<li class="today-hot-card-empty">暂无数据</li>';
    return '<div class="card sidebar-card quick-card today-hot-card">'
        . '<div class="quick-wrap">'
        . '<div class="today-hot-card-head"><div class="quick-title">' . h($config['menu_name']) . '</div>'
        . '<a class="today-hot-card-more" href="' . h(route_url('today_hot')) . '" target="_blank">换一换</a></div>'
        . '<div class="today-hot-random-src" style="--r:' . h($color) . '"><span class="today-hot-random-dot"></span><span class="today-hot-random-name">' . h($name) . '</span></div>'
        . '<ul class="quick-links today-hot-card-list">' . $rows . '</ul>'
        . '</div></div>';
}

/* ---------- 管理页 ---------- */

function today_hot_admin_sources_row(array $config): string
{
    $out = '';
    foreach (today_hot_sources() as $key => $def) {
        $cat = today_hot_categories()[$def['cat']] ?? '';
        $checked = !empty($config['enabled'][$key]) ? ' checked' : '';
        $out .= '<label class="grid today-hot-source-row"><span>' . h($def['name'])
            . ' <small class="today-hot-admin-cat">' . h($cat) . '</small></span>'
            . '<input type="checkbox" name="enabled[' . h($key) . ']" value="1"' . $checked . '></label>';
    }
    return $out;
}

function today_hot_duration_str(int $seconds): string
{
    if ($seconds < 120) return $seconds . ' 秒前';
    if ($seconds < 7200) return rtrim(rtrim(sprintf('%.1f', $seconds / 60), '0'), '.') . ' 分钟前';
    return rtrim(rtrim(sprintf('%.1f', $seconds / 3600), '0'), '.') . ' 小时前';
}

function today_hot_admin_page(array $plugin): string
{
    need_admin();
    if (is_post_request()) {
        require_post();
        $enabled = [];
        foreach (today_hot_sources() as $key => $_def) $enabled[$key] = !empty($_POST['enabled'][$key]);
        plugin_save_config('today_hot', [
            'menu_name' => cut(trim((string)($_POST['menu_name'] ?? '今日热点')), 20),
            'enabled' => $enabled,
            'limit' => max(10, min(80, (int)($_POST['limit'] ?? 40))),
            'per_source' => max(3, min(20, (int)($_POST['per_source'] ?? 8))),
            'cache_ttl' => max(120, min(7200, (int)($_POST['cache_ttl'] ?? 600))),
            'refresh_seconds' => max(60, min(3600, (int)($_POST['refresh_seconds'] ?? 600))),
            'sidebar' => empty($_POST['sidebar']) ? 0 : 1,
            'sidebar_random' => empty($_POST['sidebar_random']) ? 0 : 1,
            'sidebar_limit' => max(5, min(20, (int)($_POST['sidebar_limit'] ?? 8))),
            'sidebar_pages' => array_keys(today_hot_selected_sidebar_pages($_POST['sidebar_pages'] ?? [])),
            'cron_interval' => max(120, min(86400, (int)($_POST['cron_interval'] ?? 600))),
        ]);
        foreach (glob(DATA_DIR . '/' . TODAY_HOT_CACHE_PREFIX . '*.json') ?: [] as $f) @unlink($f);
        today_hot_update_cache();
        set_flash('今日热点设置已保存，缓存已刷新');
        go(admin_url(['tab' => 'today_hot']));
    }
    $config = today_hot_config();

    $cache_info = '';
    foreach (today_hot_sources() as $key => $def) {
        $c = today_hot_cache_read($key);
        if ($c !== null) {
            $age = today_hot_now() - (int)($c['fetched_at'] ?? 0);
            $cache_info .= '<div class="today-hot-status-row"><span>' . h($def['name']) . '</span>'
                . '<span class="today-hot-status-age">缓存于 ' . h(today_hot_duration_str(max(0, $age))) . ' · ' . count((array)($c['items'] ?? [])) . ' 条</span></div>';
        } else {
            $cache_info .= '<div class="today-hot-status-row"><span>' . h($def['name']) . '</span>'
                . '<span class="today-hot-status-age today-hot-status-empty">未缓存，保存设置后自动拉取</span></div>';
        }
    }

    $form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'today_hot'])) . '">'
        . form_token()
        . input('菜单名称', 'menu_name', $config['menu_name'], 'text', false, '页面标题、侧边栏卡片与快捷功能中的名称，默认"今日热点"。')
        . number_input('页面总条数', 'limit', $config['limit'], 10, 80, true, '热点页合并后最多显示的条目数，默认 40。')
        . number_input('每来源条数', 'per_source', $config['per_source'], 3, 20, true, '每个资讯源各抓取多少条，默认 8。')
        . '<div class="form-section-title">数据来源（勾选启用）</div>'
        . today_hot_admin_sources_row($config)
        . '<div class="form-section-title">刷新与缓存</div>'
        . number_input('页面自动刷新（秒）', 'refresh_seconds', $config['refresh_seconds'], 60, 3600, true, '前端自动重新读缓存以展示新数据。页面永不实时采集，真正抓取由下方计划任务完成。')
        . number_input('计划任务抓取间隔（秒）', 'cron_interval', $config['cron_interval'], 120, 86400, true, '计划任务定时代理拉取各来源并写入缓存，页面只读缓存所以访问不会慢。默认 600 秒（10分钟），请确保已配置 cron 访问。')
        . number_input('抓取缓存有效期（秒）', 'cache_ttl', $config['cache_ttl'], 120, 7200, true, '计划任务两次抓取同一来源的最小间隔，避免频繁请求，默认 600 秒。')
        . '<div class="form-section-title">侧边栏卡片</div>'
        . checkbox('显示侧边栏今日热点卡片', 'sidebar', (bool)$config['sidebar'], '侧边栏展示热点条目，点击"更多"进入聚合页。')
        . checkbox('每次随机展示一个媒体源卡片', 'sidebar_random', (bool)$config['sidebar_random'], '开启后侧边栏每次访问随机展示某一个平台的卡片（而非合并榜单），按钮变为"换一换"。需先勾选上方"显示侧边栏卡片"。')
        . number_input('卡片显示条数', 'sidebar_limit', $config['sidebar_limit'], 5, 20, true, '侧边栏卡片显示条目数，默认 8。')
        . '<div class="form-section-title">侧边栏显示范围</div>'
        . checkbox('首页', 'sidebar_pages[home]', !empty($config['sidebar_pages']['home']), '不勾选任何页面时默认仅在首页显示卡片。')
        . checkbox('版块列表', 'sidebar_pages[forum]', !empty($config['sidebar_pages']['forum']))
        . checkbox('看帖页', 'sidebar_pages[topic]', !empty($config['sidebar_pages']['topic']))
        . '<button type="submit">保存设置</button></form>';

    $head = '<div class="admin-plugin-summary"><strong>今日热点设置</strong><span>配置数据源、刷新与侧边栏</span></div>';
    $status_head = '<div class="admin-plugin-summary"><strong>来源缓存状态</strong><span>各来源最近一次抓取时间与条数</span></div>';

    return '<div class="admin-list-panel plugin-manage-panel"><div class="plugin-panel-body">'
        . admin_list_head($head, '') . $form . '</div></div>'
        . '<div class="admin-list-panel plugin-manage-panel"><div class="plugin-panel-body">'
        . admin_list_head($status_head, '') . '<div class="today-hot-status">' . $cache_info . '</div></div></div>';
}

/* ---------- 计划任务 ---------- */

function today_hot_cron_refresh(): string
{
    // 计划任务按缓存 TTL 决定是否重新拉取（未过期则跳过，避免频繁请求）
    today_hot_update_cache(false);
    return '今日热点缓存已刷新';
}

function today_hot_cron_interval(): int
{
    return today_hot_config()['cron_interval'];
}

/* ---------- 安装 / 卸载 ---------- */

function today_hot_install(array $plugin): void
{
    // 纯外部数据聚合，无本地表结构
}

function today_hot_uninstall(array $plugin, bool $keep_data = true): void
{
    if ($keep_data) return;
    foreach (glob(DATA_DIR . '/' . TODAY_HOT_CACHE_PREFIX . '*.json') ?: [] as $f) @unlink($f);
}

/* ---------- 前端样式 ---------- */
function today_hot_css(): string
{
    return <<<'CSS'
/* ===== Today Hot Page（瀑布流 masonry） ===== */
.today-hot-page{min-width:0}
.today-hot-header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:20px 0 12px}
.today-hot-head-main{flex:1;min-width:0}
.today-hot-title{margin:0;font-size:var(--font-size-xl);font-weight:800;color:var(--text);line-height:1.25;letter-spacing:.2px;display:flex;align-items:center}
.today-hot-title::after{content:"";flex:0 0 9px;width:9px;height:9px;border-radius:50%;background:var(--brand);margin-left:10px;box-shadow:0 0 0 5px var(--brand-soft)}
.today-hot-subtitle{margin:6px 0 0;font-size:var(--font-size-sm);color:var(--text-subtle);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

.today-hot-topbar{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:0 0 18px;flex-wrap:wrap}
.today-hot-tabs{display:inline-flex;align-items:center;gap:4px;padding:4px;background:var(--bg);border:1px solid var(--line-soft);border-radius:14px;flex-wrap:wrap;box-shadow:inset 0 1px 2px rgba(0,0,0,.03)}
.today-hot-tab{padding:5px 16px;border-radius:11px;font-size:var(--font-size-sm);font-weight:600;color:var(--text-muted);text-decoration:none;transition:all .18s ease;white-space:nowrap}
.today-hot-tab:hover{color:var(--brand)}
.today-hot-tab.active{background:var(--brand);color:var(--inverse-text);box-shadow:0 3px 10px -4px var(--brand)}
.today-hot-meta{display:flex;align-items:center;flex:0 0 auto;gap:10px}
.today-hot-updated{color:var(--text-subtle);font-size:var(--font-size-xs);white-space:nowrap}
.today-hot-refresh{min-height:30px;margin:0;padding:0 16px;border:1px solid var(--line);border-radius:9px;background:var(--panel);color:var(--text-muted);cursor:pointer;transition:all .18s ease;font-size:var(--font-size-sm);font-weight:600}
.today-hot-refresh:hover{border-color:var(--brand);color:var(--brand);box-shadow:0 3px 8px -4px var(--brand)}

/* 瀑布流：CSS 多列，卡片高度自适应错落排布 */
.today-hot-grid{columns:3;column-gap:14px;padding:0 0 30px}
.today-card{break-inside:avoid;-webkit-column-break-inside:avoid;margin:0 0 16px;border-radius:16px;overflow:hidden;background:var(--panel);border:1px solid color-mix(in srgb,var(--src) 14%,var(--line-soft));box-shadow:0 1px 2px rgba(0,0,0,.04),0 10px 30px -22px rgba(0,0,0,.25);transition:transform .22s ease,box-shadow .22s ease,border-color .22s ease;animation:todayCardIn .5s ease both}
@keyframes todayCardIn{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}
@keyframes todayFadeIn{from{opacity:0}to{opacity:1}}
.today-card:hover{transform:translateY(-3px);border-color:color-mix(in srgb,var(--src) 36%,var(--line-soft));box-shadow:0 16px 38px -18px rgba(0,0,0,.3)}
.today-card-head{display:flex;align-items:center;gap:10px;padding:14px 15px 11px;background:linear-gradient(180deg,var(--src-soft),transparent 72%);border-bottom:1px solid color-mix(in srgb,var(--src) 12%,var(--line-soft))}
.today-card-icon{flex:0 0 34px;width:34px;height:34px;border-radius:11px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 10px -4px var(--src)}
.today-card-letter{color:#fff;font-weight:800;font-size:var(--font-size-md);line-height:1}
.today-card-titlewrap{flex:1;min-width:0;display:flex;align-items:center;gap:8px}
.today-card-name{font-size:var(--font-size-md);font-weight:700;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.today-card-cat{flex:0 0 auto;padding:1px 8px;border-radius:999px;background:var(--bg);color:var(--src);font-size:11px;font-weight:600}
.today-card-count{flex:0 0 auto;font-size:var(--font-size-xs);color:var(--text-subtle);background:var(--bg);border:1px solid var(--line-soft);border-radius:999px;padding:1px 8px;white-space:nowrap}
.today-card-list{list-style:none;margin:0;padding:7px 9px 9px}
.t-row{display:flex;align-items:flex-start;gap:10px;padding:7px 6px;border-radius:10px;transition:background .15s ease}
.t-row:hover{background:color-mix(in srgb,var(--src) 6%,transparent)}
.t-rank{flex:0 0 22px;height:22px;display:flex;align-items:center;justify-content:center;background:var(--bg);color:var(--text-muted);font-size:11px;font-weight:800;border-radius:7px;line-height:1;border:1px solid var(--line-soft);margin-top:1px}
.t-rank.t-rank-top{color:#fff;background:var(--src);border-color:var(--src);box-shadow:0 2px 6px -2px var(--src)}
.t-link{flex:1;min-width:0;color:var(--text);font-size:var(--font-size-sm);line-height:1.45;text-decoration:none}
.t-title{display:block;font-weight:600;line-height:1.45;overflow-wrap:break-word;word-break:break-word}
.t-row:hover .t-title{color:var(--src)}
.t-desc{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-top:2px;color:var(--text-subtle);font-size:var(--font-size-xs);line-height:1.5}
.t-extra{display:flex;gap:8px;align-items:center;margin-top:3px;flex-wrap:wrap}
.t-inline{color:var(--src);font-size:var(--font-size-xs);font-weight:700;white-space:nowrap}
.t-rel{color:var(--text-subtle);font-size:var(--font-size-xs);white-space:nowrap}
.t-empty{color:var(--text-subtle);font-size:var(--font-size-sm);padding:16px 6px}
.today-hot-empty{padding:50px 20px;text-align:center;color:var(--text-subtle);font-size:var(--font-size-sm)}
@media(min-width:1200px){.today-hot-grid{columns:3}}
@media(min-width:860px) and (max-width:1199px){.today-hot-grid{columns:3}}
@media(min-width:560px) and (max-width:859px){.today-hot-grid{columns:2}}
@media(max-width:559px){
    /* 移动端：横向滑动卡片流（scroll-snap 吸附 + 边缘渐隐提示） */
    .today-hot-grid{display:flex;gap:12px;padding:4px 0 22px;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;scrollbar-width:none;-webkit-mask-image:linear-gradient(90deg,#000 calc(100% - 14px),transparent);mask-image:linear-gradient(90deg,#000 calc(100% - 14px),transparent)}
    .today-hot-grid::-webkit-scrollbar{display:none}
    .today-card{flex:0 0 82%;max-width:360px;margin:0;scroll-snap-align:center;animation:todayFadeIn .4s ease both}
    .today-card:hover{transform:none}
    .t-desc{-webkit-line-clamp:1}
}
@media(max-width:600px){
    .today-hot-header{padding:14px 0 10px;gap:10px}
    .today-hot-title{font-size:var(--font-size-lg)}
    .today-hot-topbar{padding:0 0 14px;gap:8px}
    /* 分类 tab 不换行，横向滑动浏览 */
    .today-hot-tabs{flex-wrap:nowrap;min-width:0;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;-webkit-mask-image:linear-gradient(90deg,#000 calc(100% - 14px),transparent);mask-image:linear-gradient(90deg,#000 calc(100% - 14px),transparent)}
    .today-hot-tabs::-webkit-scrollbar{display:none}
    .today-hot-tab{flex:0 0 auto;padding:5px 12px;font-size:12px}
    .today-hot-refresh{min-height:30px;padding:0 12px}
}

/* ======侧边栏卡片====== */
.today-hot-card .today-hot-card-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.today-hot-card .today-hot-card-more{color:var(--text-subtle);font-size:var(--font-size-xs);white-space:nowrap;text-decoration:none}
.today-hot-card .today-hot-card-more:hover{color:var(--brand)}
.today-hot-card .today-hot-card-list a{display:flex;align-items:center;gap:8px;padding:6px 0;min-width:0}
.today-hot-card .today-hot-card-list a:before{display:none}
.today-hot-card .today-hot-card-badge{flex:0 0 auto;padding:1px 6px;border-radius:4px;color:#fff;font-size:10px;font-weight:600;line-height:1.6;white-space:nowrap}
.today-hot-card .today-hot-card-content{flex:1;min-width:0;display:block}
.today-hot-card .today-hot-card-title{display:block;font-size:var(--font-size-sm);color:var(--text);line-height:1.45;overflow-wrap:break-word;word-break:break-word}
.today-hot-card .today-hot-card-list a:hover .today-hot-card-title{color:var(--brand)}
.today-hot-card .today-hot-card-rank{flex:0 0 18px;width:18px;height:18px;display:flex;align-items:center;justify-content:center;border-radius:5px;background:var(--line-soft);color:var(--text-muted);font-size:11px;font-weight:700;line-height:1}
.today-hot-card .today-hot-card-rank-top{background:var(--brand-soft);color:var(--brand)}
.today-hot-card .today-hot-card-empty{padding:9px 0;color:var(--text-subtle);font-size:var(--font-size-sm)}
.today-hot-card .today-hot-random-src{display:flex;align-items:center;gap:8px;margin:2px 0 4px;padding:7px 0 4px;border-bottom:1px dashed var(--line-soft)}
.today-hot-card .today-hot-random-dot{flex:0 0 10px;width:10px;height:10px;border-radius:50%;background:var(--r);box-shadow:0 0 0 4px color-mix(in srgb,var(--r) 18%,transparent)}
.today-hot-card .today-hot-random-name{flex:1;min-width:0;font-size:var(--font-size-sm);font-weight:700;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ====== 管理页 ===== */
.today-hot-source-row{border-bottom:1px solid var(--line-soft);padding:6px 0}
.today-hot-source-row:last-child{border-bottom:none}
.today-hot-admin-cat{opacity:.7}
.today-hot-status{display:grid;gap:4px}
.today-hot-status-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:6px 0;border-bottom:1px solid var(--line-soft)}
.today-hot-status-row:last-child{border-bottom:none}
.today-hot-status-age{color:var(--text-subtle);font-size:var(--font-size-xs);white-space:nowrap}
.today-hot-status-empty{color:var(--text-muted)}
CSS;
}

function today_hot_js(): string
{
    return <<<'JS'
document.addEventListener('click', function (e) {
    var root = e.target.closest('[data-today-hot]');
    var tab = e.target.closest('.today-hot-tab');
    if (root && tab) {
        e.preventDefault();
        if (root.dataset.todayHotLoading) return;
        root.dataset.todayHotLoading = '1';
        root.style.opacity = '.5';
        var base = root.dataset.refreshBase || '';
        var url = base.replace('__CAT__', encodeURIComponent(tab.dataset.cat));
        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok) throw new Error(d.message || '加载失败');
                applyHot(root, d.html, tab.dataset.cat);
            })
            .catch(function () { window.location.href = tab.href; })
            .finally(function () { root.style.opacity = ''; delete root.dataset.todayHotLoading; });
        return;
    }
    var btn = e.target.closest('[data-today-hot-refresh]');
    if (btn && root) {
        e.preventDefault();
        btn.disabled = true;
        var base = root.dataset.refreshBase || '';
        var cat = root.dataset.cat || 'all';
        var url = base.replace('__CAT__', encodeURIComponent(cat));
        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok) throw new Error(d.message || '加载失败');
                var list = document.querySelector('[data-today-hot] .today-hot-grid');
                if (list) list.outerHTML = d.html;
                var up = document.querySelector('[data-today-hot-updated]');
                if (up) up.textContent = '更新于 ' + new Date().toTimeString().slice(0, 8);
            })
            .catch(function () {})
            .finally(function () { btn.disabled = false; });
    }
});
function applyHot(root, html, cat) {
    var grid = root.querySelector('.today-hot-grid');
    if (grid) grid.outerHTML = html;
    root.dataset.cat = cat;
    var tabs = root.querySelectorAll('.today-hot-tab');
    tabs.forEach(function (t) {
        if (t.dataset.cat === cat) t.classList.add('active');
        else t.classList.remove('active');
    });
    root.style.opacity = '';
}
(function poll(ms){
    var root = document.querySelector('[data-today-hot]');
    if (root) {
        var rms = parseInt(root.dataset.refreshMs || '0', 10);
        if (rms > 0 && !root._todayHotTimer) {
            root._todayHotTimer = setInterval(function () {
                var btn = root.querySelector('[data-today-hot-refresh]');
                if (btn) btn.click();
            }, rms);
        }
    }
})();
JS;
}

return [
    'id' => 'today_hot',
    'name' => '今日热点',
    'version' => '2.3.4',
    'description' => '布局参考 newsnow 的栏目卡片栅格，数据源统一使用 orz-ai/hot_news 项目 API，覆盖其提供的全部 22 个平台（GitHub/百度/微博/知乎/哔哩/财经等）实时热点，支持分类、计划任务刷新、缓存与侧边栏卡片。',
    'author' => 'bbs1org',
    'assets' => ['css' => 'today_hot_css', 'js' => 'today_hot_js'],
    'hooks' => [
        'top.menu_links' => 'today_hot_menu_links',
        'sidebar.feature_links' => 'today_hot_feature_links',
        'sidebar.stack' => 'today_hot_sidebar',
    ],
    'routes' => [
        'today_hot' => 'today_hot_page',
        'today_hot_refresh' => 'today_hot_refresh_page',
    ],
    'admin_tabs' => [
        'today_hot' => 'today_hot_admin_page',
    ],
    'cron' => [
        'refresh' => ['callback' => 'today_hot_cron_refresh', 'interval' => 'today_hot_cron_interval'],
    ],
    'install' => 'today_hot_install',
    'uninstall' => 'today_hot_uninstall',
];
