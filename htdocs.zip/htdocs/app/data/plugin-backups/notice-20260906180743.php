<?php
if (!defined('APP_ROOT')) exit;

// ============ 通知中心 2.1.10 ============
// 独立公告内容管理：所有用户可查看；拥有“用户和内容管理”权限的用户组可管理。
// 一个插件可管理多个通知，不需要为每个通知安装一个插件。
// 编辑表单同时提供 topic.form_extra 与 attachment.uploader，尽量复用论坛现有内容编辑扩展。

const NOTICE_DEFAULT_NAME = '站点公告';
const NOTICE_DEFAULT_TITLE = '欢迎来到 bbs1.org';
const NOTICE_DEFAULT_BODY = "这里是一个通知示例。\n\n拥有“用户和内容管理”权限的用户可以编辑、添加和管理通知。";
function notice_default_ui(): array
{
    return [
        'menu_label' => '通知中心',
        'menu_labels' => "😍通知中心\n😮通知中心",
        'menu_rotation_enabled' => '1',
        'menu_rotation_interval' => '0.4',
        'menu_rotation_font_size' => 'inherit',
        'menu_rotation_color' => 'inherit',
        'page_title' => '通知中心',
        'page_subtitle' => '发布站点公告与社区消息',
        'add_label' => '发布公告',
        'edit_label' => '编辑公告',
        'disabled_label' => '未公开',
        'empty_label' => '暂无公告。',
        'edit_title' => '编辑公告',
        'new_title' => '发布公告',
        'back_label' => '返回通知中心',
        'name_label' => '公告名称',
        'name_help' => '用于标识公告，列表中会显示此名称。',
        'title_label' => '公告标题',
        'body_label' => '公告内容',
        'body_help' => '使用论坛现有 Markdown 内容格式，可配合已安装的编辑器和附件功能。',
        'enabled_label' => '公开显示',
        'enabled_help' => '关闭后普通用户不会看到此公告，但内容管理员仍可管理。',
        'sort_label' => '显示顺序',
        'sort_help' => '数字越小越靠前。',
        'edit_help' => '公告内容使用论坛现有 Markdown 渲染机制；已安装的内容编辑和附件扩展可在此继续使用。',
        'save_label' => '保存公告',
        'delete_label' => '删除公告',
        'cancel_label' => '取消',
        'deleted_flash' => '公告已删除',
        'saved_flash' => '公告已保存',
        'settings_title' => '通知中心设置',
        'settings_desc' => '设置通知中心对外显示的名称和界面文字，不影响公告正文内容。',
        'settings_save_label' => '保存通知中心设置',
        'settings_link_label' => '通知中心设置',
        'delete_confirm' => '确认删除这条公告吗？删除后无法恢复。',
        'settings_saved_flash' => '通知中心设置已保存',
        'empty_content_label' => '暂无公告内容。',
        'resources_label' => '资源管理',
        'resources_title' => '通知中心资源管理',
        'resources_desc' => '查看公告正文引用的附件资源。这里只做引用关系查看，不删除 upload 中的物理文件。',
        'resources_back_label' => '返回通知中心',
        'resources_empty_label' => '暂无附件资源。',
        'resources_all_label' => '附件资源',
        'resources_referenced_label' => '已引用',
        'resources_unreferenced_label' => '未被公告引用',
        'resources_missing_count_label' => '引用但缺少元数据',
        'resources_name_label' => '文件',
        'resources_size_label' => '大小',
        'resources_type_label' => '类型',
        'resources_created_label' => '上传时间',
        'resources_notice_label' => '引用公告',
        'resources_open_label' => '查看资源',
        'resources_missing_label' => '正文中有引用，但数据库没有对应元数据。',
        'resources_attachment_missing_label' => '附件元数据不可用，请确认附件上传插件已安装。',
    ];
}

function notice_ui(array $plugin): array
{
    $config = plugin_config((string)($plugin['id'] ?? 'notice'), []);
    $defaults = notice_default_ui();
    $saved = is_array($config['ui'] ?? null) ? $config['ui'] : [];
    $ui = [];
    foreach ($defaults as $key => $value) {
        $candidate = trim((string)($saved[$key] ?? ''));
        $ui[$key] = $candidate !== '' ? cut($candidate, 500) : $value;
    }
    return $ui;
}

function notice_save_ui(array $plugin, array $ui): void
{
    $config = plugin_config((string)($plugin['id'] ?? 'notice'), []);
    $defaults = notice_default_ui();
    $clean = [];
    foreach ($defaults as $key => $default) {
        $value = trim((string)($ui[$key] ?? $default));
        if ($key === 'menu_labels') {
            $lines = preg_split('/\R/u', $value) ?: [];
            $lines = array_values(array_filter(array_map(static fn($line) => cut(trim((string)$line), 120), $lines), static fn($line) => $line !== ''));
            if (!$lines) $lines = ['通知中心'];
            $clean[$key] = implode("\n", array_slice($lines, 0, 20));
        } elseif ($key === 'menu_rotation_enabled') {
            $clean[$key] = !empty($ui[$key]) ? '1' : '0';
        } elseif ($key === 'menu_rotation_interval') {
            $interval = max(0.1, min(60.0, (float)$value));
            $clean[$key] = number_format($interval, 1, '.', '');
        } elseif ($key === 'menu_rotation_font_size') {
            $font_size = trim((string)$value);
            $clean[$key] = preg_match('/^(inherit|[0-9]{1,3}(?:px|rem|em|%)?)$/i', $font_size) ? cut($font_size, 30) : 'inherit';
        } elseif ($key === 'menu_rotation_color') {
            $color = trim((string)$value);
            $clean[$key] = preg_match('/^(inherit|#[0-9a-f]{3,8}|[a-z]{1,30})$/i', $color) ? cut($color, 40) : 'inherit';
        } else {
            $clean[$key] = cut($value !== '' ? $value : $default, 500);
        }
    }
    $config['ui'] = $clean;
    plugin_save_config((string)$plugin['id'], $config);
}

function notice_install(array $plugin): void
{
    $t = app_db_types();
    app_db_create_table('plugin_notice_items',
        "id {$t['id']},notice_key {$t['key']} NOT NULL UNIQUE,name {$t['string']} NOT NULL,title {$t['string']} NOT NULL,body {$t['text']} NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,sort {$t['uint']} NOT NULL DEFAULT 10,created_at {$t['uint']} NOT NULL,updated_at {$t['uint']} NOT NULL"
    );
    app_db_create_index('plugin_notice_items_sort_idx', 'plugin_notice_items(sort)');

    // 将 1.0.0 的配置数据迁移到数据库；已有数据库数据保持不变。
    $count = (int)val('SELECT COUNT(*) FROM plugin_notice_items');
    if ($count > 0) return;

    $config = plugin_config((string)($plugin['id'] ?? 'notice'), []);
    $items = [];
    if (is_array($config['notices'] ?? null)) {
        foreach ($config['notices'] as $index => $item) {
            if (is_array($item)) $items[] = notice_normalize_item($item, (int)$index);
        }
    } elseif (isset($config['title']) || isset($config['body'])) {
        $items[] = notice_normalize_item([
            'id' => 'notice_1',
            'name' => NOTICE_DEFAULT_NAME,
            'title' => (string)($config['title'] ?? NOTICE_DEFAULT_TITLE),
            'body' => (string)($config['body'] ?? NOTICE_DEFAULT_BODY),
            'enabled' => 1,
            'sort' => 10,
        ], 0);
    }
    if (!$items) $items[] = notice_default_item();

    $created_at = now();
    foreach ($items as $item) {
        app_db_insert_ignore('plugin_notice_items', [
            'notice_key' => (string)$item['id'],
            'name' => (string)$item['name'],
            'title' => (string)$item['title'],
            'body' => (string)$item['body'],
            'enabled' => !empty($item['enabled']) ? 1 : 0,
            'sort' => (int)$item['sort'],
            'created_at' => $created_at,
            'updated_at' => $created_at,
        ], ['notice_key']);
    }
}

function notice_uninstall(array $plugin): void
{
    app_db_drop_index('plugin_notice_items_sort_idx', 'plugin_notice_items');
    app_db_drop_table('plugin_notice_items');
}

function notice_default_item(): array
{
    return [
        'id' => 'notice_1',
        'name' => NOTICE_DEFAULT_NAME,
        'title' => NOTICE_DEFAULT_TITLE,
        'body' => NOTICE_DEFAULT_BODY,
        'enabled' => 1,
        'sort' => 10,
    ];
}

function notice_normalize_item(array $item, int $index = 0): array
{
    $id = trim((string)($item['id'] ?? ''));
    if ($id === '') $id = 'notice_' . max(1, $index + 1);
    $id = preg_replace('/[^A-Za-z0-9_-]/', '_', $id) ?: ('notice_' . max(1, $index + 1));
    return [
        'id' => $id,
        'name' => cut(trim((string)($item['name'] ?? '')), 120) ?: NOTICE_DEFAULT_NAME,
        'title' => cut(trim((string)($item['title'] ?? '')), 120) ?: NOTICE_DEFAULT_TITLE,
        'body' => cut(trim((string)($item['body'] ?? '')), 20000),
        'enabled' => !empty($item['enabled']) ? 1 : 0,
        'sort' => max(0, (int)($item['sort'] ?? 10)),
    ];
}

function notice_config(array $plugin): array
{
    $rows = q('SELECT notice_key,name,title,body,enabled,sort FROM plugin_notice_items ORDER BY sort ASC,name ASC')->fetchAll();
    $items = [];
    foreach ($rows as $index => $row) {
        $items[] = notice_normalize_item([
            'id' => (string)($row['notice_key'] ?? ''),
            'name' => (string)($row['name'] ?? ''),
            'title' => (string)($row['title'] ?? ''),
            'body' => (string)($row['body'] ?? ''),
            'enabled' => !empty($row['enabled']) ? 1 : 0,
            'sort' => (int)($row['sort'] ?? 10),
        ], (int)$index);
    }
    return ['notices' => $items];
}

function notice_find(array $config, string $id): ?array
{
    foreach ($config['notices'] as $item) {
        if ((string)$item['id'] === $id) return $item;
    }
    return null;
}

function notice_menu_meta(array $ui): array
{
    $labels = preg_split('/\R/u', (string)($ui['menu_labels'] ?? $ui['menu_label'])) ?: [];
    $labels = array_values(array_filter(array_map('trim', $labels), static fn($label) => $label !== ''));
    if (!$labels) $labels = [$ui['menu_label']];

    $interval = max(0.1, min(60.0, (float)($ui['menu_rotation_interval'] ?? 4.0)));
    $font_size = trim((string)($ui['menu_rotation_font_size'] ?? 'inherit'));
    $color = trim((string)($ui['menu_rotation_color'] ?? 'inherit'));

    return [
        'labels' => $labels,
        'json_labels' => json_encode(
            array_values($labels),
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        ),
        'rotation' => !empty($ui['menu_rotation_enabled']) ? '1' : '0',
        'interval' => $interval,
        'font_size' => preg_match('/^(inherit|[0-9]{1,3}(?:px|rem|em|%)?)$/i', $font_size) ? $font_size : 'inherit',
        'color' => preg_match('/^(inherit|#[0-9a-f]{3,8}|[a-z]{1,30})$/i', $color) ? $color : 'inherit',
    ];
}

function notice_menu_link_html(array $meta, string $class, string $url): string
{
    return '<a class="' . h($class) . '" href="' . h($url) . '"'
        . ' data-notice-labels="' . h((string)$meta['json_labels']) . '"'
        . ' data-notice-rotation="' . h((string)$meta['rotation']) . '"'
        . ' data-notice-interval="' . h((string)$meta['interval']) . '"'
        . ' data-notice-font-size="' . h((string)$meta['font_size']) . '"'
        . ' data-notice-color="' . h((string)$meta['color']) . '">'
        . h((string)$meta['labels'][0])
        . '</a>';
}

function notice_top_menu($links, array $ctx): array
{
    $links = is_array($links) ? $links : [];
    $ui = notice_ui(['id' => 'notice']);
    $meta = notice_menu_meta($ui);
    // top.menu_links 是 v9.0 当前的正式“顶部版块导航/移动端版块列表”接口。
    // 核心会把这里的 text/url 同时用于 forum-nav 与 mobile-menu，避免重复注册两个入口。
    $links[] = [
        'text' => (string)$meta['labels'][0],
        'url' => route_url('notifications'),
    ];
    return $links;
}

function notice_render_body(string $body): string
{
    $body = trim($body);
    if ($body === '') {
        $ui = notice_ui(['id' => 'notice']);
        return '<p class="notice-empty">' . h($ui['empty_content_label']) . '</p>';
    }
    return '<div class="post-content notice-content">' . markdown_html($body) . '</div>';
}

function notice_save(array $plugin): void
{
    require_post();
    need_manage();

    $id = trim((string)($_POST['notice_id'] ?? ''));
    $action = (string)($_POST['notice_action'] ?? 'save');

    if ($action === 'delete') {
        if ($id !== '') {
            q('DELETE FROM plugin_notice_items WHERE notice_key = ?', [$id]);
        }
        $ui = notice_ui($plugin);
        set_flash($ui['deleted_flash']);
        go(route_url('notifications'));
    }

    $name = cut(trim((string)($_POST['name'] ?? '')), 120);
    $title = cut(trim((string)($_POST['title'] ?? '')), 120);
    $body = cut(trim((string)($_POST['body'] ?? '')), 20000);
    $enabled = !empty($_POST['enabled']) ? 1 : 0;
    $sort = max(0, (int)($_POST['sort'] ?? 10));

    if ($name === '') $name = NOTICE_DEFAULT_NAME;
    if ($title === '') $title = $name;

    $now = now();
    if ($id === '') {
        $id = 'notice_' . (string)(time() . '_' . random_int(100, 999));
        app_db_insert_ignore('plugin_notice_items', [
            'notice_key' => $id,
            'name' => $name,
            'title' => $title,
            'body' => $body,
            'enabled' => $enabled,
            'sort' => $sort,
            'created_at' => $now,
            'updated_at' => $now,
        ], ['notice_key']);
    } else {
        $exists = (int)val('SELECT COUNT(*) FROM plugin_notice_items WHERE notice_key = ?', [$id]);
        if ($exists < 1) err('公告不存在');
        q(
            'UPDATE plugin_notice_items SET name = ?,title = ?,body = ?,enabled = ?,sort = ?,updated_at = ? WHERE notice_key = ?',
            [$name, $title, $body, $enabled, $sort, $now, $id]
        );
    }

    $ui = notice_ui($plugin);
    set_flash($ui['saved_flash']);
    go(route_url('notifications'));
}

function notice_resource_references(array $items): array
{
    $references = [];
    foreach ($items as $item) {
        $body = (string)($item['body'] ?? '');
        if ($body === '') continue;
        if (preg_match_all('/(?<![a-f0-9])([a-f0-9]{64})\.([a-z0-9]{1,25})(?![a-z0-9])/i', $body, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $hash = strtolower((string)$match[1]);
                $file = $hash . '.' . strtolower((string)$match[2]);
                $references[$hash] ??= [
                    'hash' => $hash,
                    'file_names' => [],
                    'notices' => [],
                ];
                if (!in_array($file, $references[$hash]['file_names'], true)) {
                    $references[$hash]['file_names'][] = $file;
                }
                $references[$hash]['notices'][] = [
                    'id' => (string)($item['id'] ?? ''),
                    'name' => (string)($item['name'] ?? ''),
                    'title' => (string)($item['title'] ?? ''),
                ];
            }
        }
    }
    foreach ($references as &$reference) {
        $seen = [];
        $reference['notices'] = array_values(array_filter($reference['notices'], static function (array $notice) use (&$seen): bool {
            $key = (string)$notice['id'];
            if (isset($seen[$key])) return false;
            $seen[$key] = true;
            return true;
        }));
    }
    unset($reference);
    return $references;
}

function notice_resource_rows(array $references): ?array
{
    try {
        // 资源管理页必须展示全部附件元数据，而不只是正文当前引用的附件。
        // 这样管理员后续可以据此人工核对并清理 upload 中长期未使用的物理文件。
        $rows = q(
            'SELECT a.id,a.user_id,a.hash,a.file_name,a.original_name,a.ext,a.mime,a.size,a.created_at,u.username '
            . 'FROM app_attachments a LEFT JOIN app_users u ON u.id=a.user_id '
            . 'ORDER BY a.created_at DESC,a.id DESC'
        )->fetchAll();
    } catch (Throwable $e) {
        return null;
    }

    $grouped = [];
    foreach ($rows as $row) {
        $hash = strtolower((string)($row['hash'] ?? ''));
        if ($hash === '') continue;
        $grouped[$hash] ??= [
            'hash' => $hash,
            'rows' => [],
            'notices' => $references[$hash]['notices'] ?? [],
            'file_names' => $references[$hash]['file_names'] ?? [],
        ];
        $grouped[$hash]['rows'][] = $row;
    }
    return array_values($grouped);
}

function notice_resource_time_label($value): string
{
    $timestamp = (int)$value;
    if ($timestamp <= 0) return '-';
    return date('Y-m-d H:i:s', $timestamp);
}

function notice_resources_page(array $plugin, array $config): void
{
    need_manage();
    $ui = notice_ui($plugin);
    $references = notice_resource_references($config['notices']);
    $resources = notice_resource_rows($references);
    $resource_query_failed = $resources === null;
    if ($resource_query_failed) $resources = [];

    $referenced_count = 0;
    $unreferenced_count = 0;
    $resource_hashes = [];
    foreach ($resources as $group) {
        $hash = (string)$group['hash'];
        $resource_hashes[$hash] = true;
        if (!empty($group['notices'])) $referenced_count += count($group['rows']);
        else $unreferenced_count += count($group['rows']);
    }
    $missing_count = 0;
    foreach ($references as $hash => $_reference) {
        if (!isset($resource_hashes[$hash])) $missing_count++;
    }
    $total_count = $referenced_count + $unreferenced_count;

    $body = '<div class="notice-resources form-panel">'
        . '<div class="notice-edit-head"><div><h1>' . h($ui['resources_title']) . '</h1><p class="notice-settings-desc">' . h($ui['resources_desc']) . '</p></div>'
        . '<a href="' . h(route_url('notifications')) . '">' . h($ui['resources_back_label']) . '</a></div>';

    $body .= '<div class="notice-resource-summary">'
        . '<span>' . h($ui['resources_all_label']) . ' <strong>' . $total_count . '</strong></span>'
        . '<span>' . h($ui['resources_referenced_label']) . ' <strong>' . $referenced_count . '</strong></span>'
        . '<span>' . h($ui['resources_unreferenced_label']) . ' <strong>' . $unreferenced_count . '</strong></span>'
        . ($missing_count > 0 ? '<span>' . h($ui['resources_missing_count_label']) . ' <strong>' . $missing_count . '</strong></span>' : '')
        . '</div>';

    if ($resource_query_failed) {
        $body .= '<p class="notice-empty">' . h($ui['resources_attachment_missing_label']) . '</p>';
    } elseif (!$resources && !$missing_count) {
        $body .= '<p class="notice-empty">' . h($ui['resources_empty_label']) . '</p>';
    } else {
        $body .= '<div class="notice-resource-list">';

        foreach ($resources as $group) {
            $notice_names = implode('、', array_map(static fn(array $n): string => (string)$n['name'], $group['notices']));
            $is_referenced = $notice_names !== '';

            foreach ($group['rows'] as $row) {
                $file_name = (string)($row['file_name'] ?? '');
                $original = trim((string)($row['original_name'] ?? ''));
                $display_name = $original !== '' ? $original : $file_name;
                $open = $file_name !== ''
                    ? '<a href="' . h(route_url('attachment', [
                        'f' => $file_name,
                        'name' => $display_name,
                    ])) . '" target="_blank" rel="noopener">' . h($ui['resources_open_label']) . '</a>'
                    : '';
                $status = $is_referenced
                    ? '<span class="notice-resource-status">' . h($ui['resources_referenced_label']) . '</span>'
                    : '<span class="notice-resource-status notice-resource-status-unreferenced">' . h($ui['resources_unreferenced_label']) . '</span>';

                $body .= '<article class="notice-resource-card' . ($is_referenced ? '' : ' notice-resource-unreferenced') . '">'
                    . '<div class="notice-resource-card-head"><div><strong>' . h($display_name !== '' ? $display_name : $ui['resources_all_label']) . '</strong> ' . $status
                    . ($original !== '' && $original !== $file_name ? '<span class="notice-resource-stored">' . h($file_name) . '</span>' : '')
                    . '</div><div class="notice-resource-actions">' . $open . '</div></div>'
                    . '<div class="notice-resource-meta">'
                    . '<span>' . h($ui['resources_size_label']) . '：' . h(notice_resource_size_label((int)($row['size'] ?? 0))) . '</span>'
                    . '<span>' . h($ui['resources_type_label']) . '：' . h((string)($row['mime'] ?? 'application/octet-stream')) . '</span>'
                    . '<span>' . h($ui['resources_created_label']) . '：' . h(notice_resource_time_label($row['created_at'] ?? 0)) . '</span>'
                    . '</div>'
                    . '<div class="notice-resource-notices">' . h($ui['resources_notice_label']) . '：' . h($notice_names !== '' ? $notice_names : '-') . '</div>'
                    . '</article>';
            }
        }

        foreach ($references as $hash => $reference) {
            if (isset($resource_hashes[$hash])) continue;
            $body .= '<article class="notice-resource-card notice-resource-missing">'
                . '<div class="notice-resource-card-head"><strong>' . h($reference['file_names'][0] ?? $hash) . '</strong><span>' . h($ui['resources_missing_label']) . '</span></div>'
                . '<div class="notice-resource-meta"><code>' . h($hash) . '</code></div>'
                . '<div class="notice-resource-notices">' . h($ui['resources_notice_label']) . '：'
                . h(implode('、', array_map(static fn(array $n): string => (string)$n['name'], $reference['notices']))) . '</div>'
                . '</article>';
        }
        $body .= '</div>';
    }

    $body .= '</div>';
    page($ui['resources_title'], shell_html($body, sidebar_stack_html([sidebar_user_card_html()])));
}

function notice_resource_size_label(int $bytes): string
{
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return round($bytes / 1024, 1) . ' KB';
    if ($bytes < 1073741824) return round($bytes / 1048576, 1) . ' MB';
    return round($bytes / 1073741824, 2) . ' GB';
}

function notice_settings_save(array $plugin): void
{
    require_post();
    need_manage();
    $defaults = notice_default_ui();
    $current = notice_ui($plugin);
    $posted = is_array($_POST['ui'] ?? null) ? $_POST['ui'] : [];
    $ui = [];
    foreach ($defaults as $key => $default) {
        // checkbox 未勾选时浏览器不会提交字段；此处必须明确保存为 0，不能回退到默认值 1。
        if ($key === 'menu_rotation_enabled') {
            $ui[$key] = array_key_exists($key, $posted) ? (string)$posted[$key] : '0';
            continue;
        }
        $ui[$key] = array_key_exists($key, $posted)
            ? trim((string)$posted[$key])
            : (string)($current[$key] ?? $default);
    }
    notice_save_ui($plugin, $ui);
    $ui = notice_ui($plugin);
    set_flash($ui['settings_saved_flash']);
    go(route_url('notifications'));
}

function notice_settings_page(array $plugin): void
{
    need_manage();
    $ui = notice_ui($plugin);
    $fields = [
        ['menu_label', '顶部导航名称', '兼容旧设置；当下方自定义名称列表为空时使用。'],
        ['menu_labels', '顶部导航名称列表', '每行填写一个名称，最多 20 个；顶部导航会按顺序动态切换。'],
        ['menu_rotation_enabled', '顶部导航动态切换', '开启后且名称列表有多个名称时自动轮播；关闭后固定显示第一个名称。'],
        ['menu_rotation_interval', '名称切换间隔（秒）', '动态切换每隔多少秒更换一次，范围 0.1～60.0 秒，步进 0.1 秒。'],
        ['menu_rotation_font_size', '轮播字体大小', '可使用 inherit、px、rem、em 或百分比；默认跟随顶部导航。'],
        ['menu_rotation_color', '轮播文字颜色', '可使用 inherit、颜色名称或十六进制颜色；默认跟随顶部导航。'],
        ['page_title', '中心标题', '通知中心顶部的大标题。'],
        ['page_subtitle', '中心副标题', '中心标题下面的说明文字。'],
        ['add_label', '发布按钮文字', '公告列表右上角的发布按钮。'],
        ['edit_label', '编辑按钮文字', '每条公告右上角的编辑按钮。'],
        ['disabled_label', '未公开状态文字', '管理员查看未公开公告时显示。'],
        ['empty_label', '空列表文字', '没有可显示公告时使用。'],
        ['edit_title', '编辑页标题', '编辑已有公告时的页面标题。'],
        ['new_title', '发布页标题', '发布公告时的页面标题。'],
        ['back_label', '返回按钮文字', '编辑页面返回通知中心的链接。'],
        ['name_label', '名称字段文字', '公告编辑页的名称字段标题。'],
        ['name_help', '名称字段说明', '公告名称字段下方的说明。'],
        ['title_label', '标题字段文字', '公告编辑页的标题字段标题。'],
        ['body_label', '内容字段文字', '公告编辑页的正文编辑框标题。'],
        ['body_help', '内容字段说明', '公告正文编辑框下方的说明。'],
        ['enabled_label', '公开显示字段文字', '公开/未公开开关的标题。'],
        ['enabled_help', '公开显示字段说明', '公开/未公开开关的说明。'],
        ['sort_label', '显示顺序字段文字', '显示顺序数字字段标题。'],
        ['sort_help', '显示顺序字段说明', '显示顺序数字字段说明。'],
        ['edit_help', '编辑器说明文字', '编辑页面底部的提示文字。'],
        ['save_label', '保存按钮文字', '编辑页面保存按钮。'],
        ['delete_label', '删除按钮文字', '编辑已有通知时的删除按钮。'],
        ['cancel_label', '取消按钮文字', '编辑页面取消链接。'],
        ['deleted_flash', '删除成功提示', '删除公告后显示的提示。'],
        ['saved_flash', '保存成功提示', '保存公告后显示的提示。'],
        ['settings_title', '设置页标题', '管理通知中心显示文字时使用的标题。'],
        ['settings_desc', '设置页说明', '管理通知中心显示文字时使用的说明。'],
        ['settings_save_label', '设置保存按钮文字', '保存通知中心设置的按钮。'],
        ['settings_link_label', '设置入口文字', '通知中心右上角进入设置的链接。'],
        ['delete_confirm', '删除确认文字', '点击删除通知后显示的确认提示。'],
        ['settings_saved_flash', '设置保存成功提示', '保存通知中心设置后显示的提示。'],
        ['empty_content_label', '空公告内容文字', '公告正文为空时显示的文字。'],
        ['resources_label', '资源管理入口文字', '通知中心右上角进入资源管理页面的链接。'],
        ['resources_title', '资源管理标题', '资源管理页面顶部标题。'],
        ['resources_desc', '资源管理说明', '资源管理页面顶部说明文字。'],
        ['resources_back_label', '资源管理返回文字', '资源管理页面返回通知中心的链接。'],
        ['resources_empty_label', '资源为空文字', '没有公告引用附件时显示的文字。'],
        ['resources_referenced_label', '已引用统计文字', '资源管理页面的引用数量统计。'],
        ['resources_unreferenced_label', '未引用统计文字', '资源管理页面的未引用资源统计。'],
        ['resources_missing_count_label', '缺少元数据统计文字', '资源管理页面中正文有引用但附件元数据不存在时的统计文字。'],
        ['resources_size_label', '资源大小字段文字', '资源卡片中的文件大小字段。'],
        ['resources_type_label', '资源类型字段文字', '资源卡片中的 MIME 类型字段。'],
        ['resources_created_label', '资源时间字段文字', '资源卡片中的上传时间字段。'],
        ['resources_notice_label', '引用公告字段文字', '资源卡片中显示引用它的公告。'],
        ['resources_open_label', '查看资源按钮文字', '资源卡片中的资源查看链接。'],
        ['resources_missing_label', '缺少元数据提示', '正文引用存在，但 app_attachments 没有对应记录。'],
        ['resources_attachment_missing_label', '附件插件缺失提示', '无法读取附件元数据时使用的提示。'],
    ];
    $body = '<div class="notice-edit form-panel topic-form-panel">'
        . '<div class="notice-edit-head"><div><h1>' . h($ui['settings_title']) . '</h1><p class="notice-settings-desc">' . h($ui['settings_desc']) . '</p></div><a href="' . h(route_url('notifications')) . '">' . h($ui['back_label']) . '</a></div>'
        . '<form method="post" action="' . h(route_url('notifications')) . '">' . form_token()
        . '<input type="hidden" name="do" value="settings_save">';
    foreach ($fields as [$key, $label, $help]) {
        if ($key === 'menu_labels') {
            $body .= textarea($label, 'ui[' . $key . ']', $ui[$key], false, $help);
        } elseif ($key === 'menu_rotation_enabled') {
            $body .= checkbox($label, 'ui[' . $key . ']', !empty($ui[$key]), $help);
        } elseif ($key === 'menu_rotation_interval') {
            $body .= '<label>' . h($label)
                . '<input type="number" name="ui[' . h($key) . ']" value="' . h($ui[$key])
                . '" min="0.1" max="60.0" step="0.1" inputmode="decimal">'
                . '<small>' . h($help) . '</small></label>';
        } else {
            $body .= input($label, 'ui[' . $key . ']', $ui[$key], 'text', true, $help);
        }
    }
    $body .= '<div class="form-actions"><button type="submit">' . h($ui['settings_save_label']) . '</button><a href="' . h(route_url('notifications')) . '">' . h($ui['cancel_label']) . '</a></div>'
        . '</form></div>';
    page($ui['settings_title'], shell_html($body, sidebar_stack_html([sidebar_user_card_html()] )));
}

function notice_edit_page(array $plugin, array $config): void
{
    need_manage();
    $ui = notice_ui($plugin);

    $id = trim((string)($_GET['id'] ?? ''));
    $editing = $id !== '';
    $item = $editing ? notice_find($config, $id) : null;
    if ($editing && !$item) err('公告不存在');
    if (!$editing) $item = [
        'id' => '',
        'name' => NOTICE_DEFAULT_NAME,
        'title' => NOTICE_DEFAULT_TITLE,
        'body' => '',
        'enabled' => 1,
        'sort' => 10,
    ];

    $fake_topic = [
        'id' => 0,
        'title' => $item['title'],
        'body' => $item['body'],
        'user_id' => uid(),
    ];
    $form_extra = (string)hook('topic.form_extra', '', ['topic' => $fake_topic, 'editing' => $editing, 'notice' => true]);
    $attachments = (string)hook('attachment.uploader', '', ['muted' => true, 'notice' => true]);

    $delete = '';
    if ($editing) {
        $confirm_js = h(json_encode($ui['delete_confirm'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $delete = '<button type="submit" name="notice_action" value="delete" formnovalidate data-notice-delete="1" onclick="return confirm(' . $confirm_js . ')">' . h($ui['delete_label']) . '</button>';
    }

    $body = '<div class="notice-edit form-panel topic-form-panel">'
        . '<div class="notice-edit-head"><h1>' . h($editing ? $ui['edit_title'] : $ui['new_title']) . '</h1><a href="' . h(route_url('notifications')) . '">' . h($ui['back_label']) . '</a></div>'
        . '<form method="post" action="' . h(route_url('notifications')) . '">'
        . form_token()
        . '<input type="hidden" name="notice_id" value="' . h($item['id']) . '">'
        . '<input type="hidden" name="do" value="save">'
        . '<input type="hidden" name="notice_action" value="save">'
        . input($ui['name_label'], 'name', $item['name'], 'text', true, $ui['name_help'])
        . input($ui['title_label'], 'title', $item['title'], 'text', true)
        . textarea($ui['body_label'], 'body', $item['body'], false, $ui['body_help'])
        . $attachments
        . $form_extra
        . checkbox($ui['enabled_label'], 'enabled', !empty($item['enabled']), $ui['enabled_help'])
        . number_input($ui['sort_label'], 'sort', (int)$item['sort'], 0, 9999, true, $ui['sort_help'])
        . '<p class="notice-edit-help">' . h($ui['edit_help']) . '</p>'
        . '<div class="form-actions"><button type="submit" data-loading-text="保存中">' . h($ui['save_label']) . '</button>' . $delete . '<a href="' . h(route_url('notifications')) . '">' . h($ui['cancel_label']) . '</a></div>'
        . '</form>'
        . '</div>';

    page($editing ? $ui['edit_title'] : $ui['new_title'], shell_html($body, sidebar_stack_html([sidebar_user_card_html()] )));
}

function notice_page(array $plugin): void
{
    $config = notice_config($plugin);
    $ui = notice_ui($plugin);
    $do = (string)($_GET['do'] ?? $_POST['do'] ?? '');

    if ($do === 'settings_save') {
        notice_settings_save($plugin);
        return;
    }
    if ($do === 'save' || $do === 'delete') {
        notice_save($plugin);
        return;
    }
    if ($do === 'edit') {
        notice_edit_page($plugin, $config);
        return;
    }
    if ($do === 'settings') {
        notice_settings_page($plugin);
        return;
    }
    if ($do === 'resources') {
        notice_resources_page($plugin, $config);
        return;
    }

    $actions = can_manage()
        ? '<span class="notice-admin-actions"><a class="notice-edit-link" href="' . h(route_url('notifications', ['do' => 'edit'])) . '">' . h($ui['add_label']) . '</a> <a class="notice-edit-link notice-settings-link" href="' . h(route_url('notifications', ['do' => 'resources'])) . '">' . h($ui['resources_label']) . '</a> <a class="notice-edit-link notice-settings-link" href="' . h(route_url('notifications', ['do' => 'settings'])) . '">' . h($ui['settings_link_label']) . '</a></span>'
        : '';

    $cards = '';
    foreach ($config['notices'] as $item) {
        if (empty($item['enabled']) && !can_manage()) continue;
        $admin = can_manage()
            ? '<a class="notice-card-edit" href="' . h(route_url('notifications', ['do' => 'edit', 'id' => $item['id']])) . '">' . h($ui['edit_label']) . '</a>'
            : '';
        $status = !empty($item['enabled']) ? '' : '<span class="notice-disabled">' . h($ui['disabled_label']) . '</span>';
        $cards .= '<article class="notice-card' . (empty($item['enabled']) ? ' notice-card-disabled' : '') . '">'
            . '<div class="notice-card-head"><div><div class="notice-card-name">' . h($item['name']) . ' ' . $status . '</div><h2>' . h($item['title']) . '</h2></div>' . $admin . '</div>'
            . notice_render_body($item['body'])
            . '</article>';
    }

    if ($cards === '') $cards = '<p class="notice-empty">' . h($ui['empty_label']) . '</p>';

    $body = '<div class="notice-page">'
        . '<div class="notice-head"><div><h1 class="notice-title">' . h($ui['page_title']) . '</h1><p class="notice-sub">' . h($ui['page_subtitle']) . '</p></div>' . $actions . '</div>'
        . $cards
        . '</div>';

    page($ui['page_title'], shell_html($body, sidebar_stack_html([sidebar_user_card_html(null, true)])));
}

function notice_top_menu_enabled(): bool
{
    $plugin = plugins()['notice'] ?? null;
    return is_array($plugin) && plugin_entry_enabled($plugin, 'top_menu');
}

function notice_page_before_render($value, array $ctx): string
{
    $html = (string)$value;
    // 后台关闭“顶部菜单”展示位置后，首页移动版块横条也必须同步隐藏通知入口。
    if (!notice_top_menu_enabled()) return $html;
    if ($html === '' || strpos($html, 'mobile-forum-strip') === false) return $html;

    $meta = notice_menu_meta(notice_ui(['id' => 'notice']));
    $link = notice_menu_link_html($meta, 'mobile-forum-link notice-mobile-forum-link', route_url('notifications'));

    $pattern = '~(<div class="mobile-forum-strip">.*?)(</div>)~s';
    $updated = preg_replace($pattern, '$1' . $link . '$2', $html, 1);
    return is_string($updated) ? $updated : $html;
}

function notice_js(): string
{
    $ui = notice_ui(['id' => 'notice']);
    $meta = notice_menu_meta($ui);
    $route = json_encode(route_url('notifications'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $labels = (string)$meta['json_labels'];
    $rotation = !empty($ui['menu_rotation_enabled']) ? 'true' : 'false';
    $interval = (string)$meta['interval'];
    $font = json_encode((string)$meta['font_size'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $color = json_encode((string)$meta['color'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

    return strtr(<<<'JS'
(function () {
    'use strict';

    var notice_js_route = __ROUTE__;
    var notice_js_labels = __LABELS__;
    var notice_js_rotation = __ROTATION__;
    var notice_js_interval = __INTERVAL__;
    var notice_js_font_size = __FONT__;
    var notice_js_color = __COLOR__;

    function notice_js_is_route(link) {
        if (!link) return false;
        var href = link.getAttribute('href') || '';
        return href === notice_js_route || (notice_js_route && href.indexOf(notice_js_route + '?') === 0);
    }

    function notice_js_parse_labels(value) {
        try {
            var labels = JSON.parse(value || '[]');
            if (!Array.isArray(labels)) return [];
            return labels.filter(function (label) {
                return typeof label === 'string' && label.trim() !== '';
            });
        } catch (error) {
            return [];
        }
    }

    function notice_js_apply(link, label) {
        if (!link) return;
        link.textContent = label;
        if (notice_js_font_size !== 'inherit') link.style.fontSize = notice_js_font_size;
        else link.style.removeProperty('font-size');
        if (notice_js_color !== 'inherit') link.style.color = notice_js_color;
        else link.style.removeProperty('color');
    }

    function notice_js_collect_links(root) {
        if (!root || !root.querySelectorAll) return [];
        var nodes = root.querySelectorAll(
            '[data-slot~="top.menu_links"] a, .mobile-forum-strip a, .mobile-menu-links a'
        );
        var out = [];
        for (var i = 0; i < nodes.length; i++) {
            if (notice_js_is_route(nodes[i])) out.push(nodes[i]);
        }
        return out;
    }

    function notice_js_scan(root, state) {
        var links = notice_js_collect_links(root);
        for (var i = 0; i < links.length; i++) {
            var link = links[i];
            if (link.getAttribute('data-notice-js-ready') === '1') continue;
            notice_js_apply(link, notice_js_labels[0] || '通知中心');
            link.setAttribute('data-notice-js-ready', '1');
            state.links.push(link);
        }
    }

    function notice_js_init() {
        var state = {links: []};
        notice_js_scan(document, state);

        if (notice_js_rotation && notice_js_labels.length > 1) {
            window.setInterval(function () {
                state.links = state.links.filter(function (link) {
                    return link && link.isConnected;
                });
                if (!state.links.length) return;
                state.index = (typeof state.index === 'number' ? state.index + 1 : 1) % notice_js_labels.length;
                state.links.forEach(function (link) {
                    notice_js_apply(link, notice_js_labels[state.index]);
                });
            }, Math.max(100, Math.min(60000, notice_js_interval * 1000)));
        }

        if (window.MutationObserver && document.body) {
            var observer = new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    for (var i = 0; i < mutation.addedNodes.length; i++) {
                        var node = mutation.addedNodes[i];
                        if (node.nodeType === 1) notice_js_scan(node, state);
                    }
                });
            });
            observer.observe(document.body, {childList: true, subtree: true});
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', notice_js_init);
    else notice_js_init();
}());
JS
    , [
        '__ROUTE__' => $route,
        '__LABELS__' => $labels,
        '__ROTATION__' => $rotation,
        '__INTERVAL__' => $interval,
        '__FONT__' => $font,
        '__COLOR__' => $color,
    ]);
}

function notice_css(): string
{
    return <<<'CSS'
.notice-top-menu-link{display:inline-flex;align-items:center;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-muted);font-size:var(--font-size-sm);text-decoration:none}.notice-top-menu-link:hover{color:var(--text)}.notice-page{max-width:860px;margin:0 auto;padding:var(--space-lg,16px)}.notice-head{display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-md,14px);margin-bottom:var(--space-md,14px)}.notice-title{font-size:var(--font-size-xl);margin:0;color:var(--text)}.notice-sub{font-size:var(--font-size-sm);color:var(--text-muted);margin:4px 0 0}.notice-edit-link,.notice-card-edit{color:var(--brand-hover);font-size:var(--font-size-sm);font-weight:600;text-decoration:none}.notice-edit-link:hover,.notice-card-edit:hover{color:var(--brand)}.notice-card{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);padding:var(--space-lg,16px);margin-bottom:var(--space-md,14px)}.notice-card-disabled{opacity:.65}.notice-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-md,14px);margin-bottom:var(--space-md,14px)}.notice-card-name{font-size:var(--font-size-sm);color:var(--text-muted);margin-bottom:4px}.notice-card h2{font-size:var(--font-size-lg);margin:0;color:var(--text)}.notice-disabled{display:inline-block;margin-left:6px;padding:2px 6px;border:1px solid var(--line);border-radius:999px;font-size:var(--font-size-xs)}.notice-content,.notice-empty{color:var(--text);font-size:var(--font-size-md);line-height:1.8}.notice-content p:first-child{margin-top:0}.notice-content p:last-child{margin-bottom:0}.notice-empty{color:var(--text-muted);margin:0}.notice-edit{max-width:860px;margin:0 auto}.notice-edit-head{display:flex;align-items:center;justify-content:space-between;gap:var(--space-md,14px);margin-bottom:var(--space-md,14px)}.notice-edit-head h1{font-size:var(--font-size-xl);margin:0}.notice-edit-head a,.notice-edit .form-actions a{color:var(--brand-hover);text-decoration:none}.notice-edit textarea{min-height:320px}.notice-settings-desc{font-size:var(--font-size-sm);color:var(--text-muted);margin:4px 0 0}.notice-edit-help{font-size:var(--font-size-sm);color:var(--text-muted);margin:var(--space-sm,8px) 0}.notice-edit .form-actions{display:flex;align-items:center;gap:var(--space-md,14px);margin-top:var(--space-md,14px);flex-wrap:wrap}.notice-edit .form-actions button[name="notice_action"][value="delete"]{margin-left:auto}.notice-resources{max-width:980px;margin:0 auto}.notice-resource-summary{display:flex;gap:12px;margin-bottom:var(--space-md,14px);color:var(--text-muted);font-size:var(--font-size-sm)}.notice-resource-list{display:grid;gap:10px}.notice-resource-card{padding:12px 14px;border:1px solid var(--line);border-radius:var(--radius);background:var(--panel)}.notice-resource-unreferenced{opacity:.82}.notice-resource-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.notice-resource-card-head strong{color:var(--text);overflow-wrap:anywhere}.notice-resource-actions a{color:var(--brand-hover);font-size:var(--font-size-sm);font-weight:600;text-decoration:none;white-space:nowrap}.notice-resource-actions a:hover{color:var(--brand)}.notice-resource-status{display:inline-block;margin-left:6px;padding:2px 6px;border:1px solid var(--line);border-radius:999px;font-size:var(--font-size-xxs);color:var(--text-muted)}.notice-resource-status-unreferenced{color:var(--text-subtle)}.notice-resource-stored{display:block;margin-top:3px;color:var(--text-subtle);font-size:var(--font-size-xs);overflow-wrap:anywhere}.notice-resource-meta{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:8px;color:var(--text-muted);font-size:var(--font-size-xs)}.notice-resource-notices{margin-top:8px;color:var(--text-muted);font-size:var(--font-size-sm);line-height:1.5}.notice-resource-missing{opacity:.8}.notice-resource-missing code{color:var(--text-subtle);font-size:var(--font-size-xs);overflow-wrap:anywhere}@media (max-width:640px){.notice-top-menu-link{display:inline-flex}.notice-mobile-forum-link{display:inline-flex}.notice-head,.notice-card-head{flex-direction:column}.notice-edit-head{align-items:flex-start;flex-direction:column}.notice-edit .form-actions button[name="notice_action"][value="delete"]{margin-left:0}.notice-resource-card-head{flex-direction:column}.notice-resource-actions{align-self:flex-start}}
CSS;
}

return [
    'id' => 'notice',
    'name' => '通知中心',
    'version' => '2.2.0',
    'description' => '提供可自定义的通知中心，灵感来自“开发者文档中心”插件：拥有“用户和内容管理”权限的用户可以公告发布、编辑、删除、排序、公开状态，和全方位通知中心界面文字自定义。',
    'author' => 'bbc',
    'assets' => [
        'css' => 'notice_css',
        'js' => 'notice_js',
    ],
    'hooks' => [
        // top.menu_links 是 v9.0 当前正式接口：桌面顶部版块导航与移动端菜单版块列表共用。
        // 只注册一次，避免 top.bar.actions 与 forum-nav 同时出现造成重复。
        'top.menu_links' => 'notice_top_menu',
        // 首页移动版块横条没有独立 PHP Hook，在 page.before_render 中追加同一个入口。
        'page.before_render' => 'notice_page_before_render',
    ],
    'entries' => ['top_menu' => true],
    'routes' => [
        'notifications' => 'notice_page',
    ],
    'install' => 'notice_install',
    'uninstall' => 'notice_uninstall',
];