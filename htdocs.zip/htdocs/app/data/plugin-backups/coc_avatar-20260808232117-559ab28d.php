<?php

if (!defined('APP_ROOT')) exit;

function coc_avatar_config(): array
{
    return [
        'style' => 'coc',
        'label' => 'COC',
        'seed_count' => 48,
        'avatar_dir' => AVATAR_DIR,
    ];
}

function coc_avatar_base_url(): string
{
    return asset_url('app/avatars/');
}

function coc_avatar_file(string $seed): string
{
    $seed = ctype_digit($seed) ? (int)$seed : 0;
    if ($seed < 1 || $seed > 48) return '';
    return AVATAR_DIR . '/coc_' . $seed . '.svg';
}

function coc_avatar_url(string $value, array $ctx): string
{
    if ((string)($ctx['style'] ?? '') !== 'coc') return $value;

    $seed = (string)($ctx['seed'] ?? '');
    $file = coc_avatar_file($seed);
    if ($file === '' || !is_file($file)) return $value;

    return asset_url('app/avatars/coc_' . (int)$seed . '.svg');
}

function coc_avatar_picker(mixed $value, array $ctx): mixed
{
    if (!is_array($value)) return $value;

    $value['base_url'] = coc_avatar_base_url();

    $styles = is_array($value['styles'] ?? null) ? $value['styles'] : [];

    // The core picker intersects this list with avatar_styles().
    // Therefore the core must expose the "coc" key for this option to appear.
    $styles['coc'] = 'COC';
    $value['styles'] = $styles;

    return $value;
}

function coc_avatar_user_before_save(mixed $value, array $ctx): mixed
{
    if (!is_array($value)) return $value;

    // Only new registrations get the COC default.
    // Existing users keep their selected avatar unless they explicitly choose one.
    if (!empty($ctx['creating']) && trim((string)($value['avatar_style'] ?? '')) === '') {
        $value['avatar_style'] = 'coc';
    }

    return $value;
}

function coc_avatar_js(): string
{
    return <<<'JS'
(function () {
    "use strict";

    function isPickerCoc(p) {
        return p?.querySelector('select[name="avatar_style"]')?.value === "coc";
    }

    function normalizeSeed(seed, fallback) {
        const raw = String(seed || fallback || "1").replace(/\D/g, "") || "1";
        const number = parseInt(raw, 10) || 1;
        return String(((number - 1) % 48) + 1);
    }

    function cocUrl(p, seed) {
        const base = String(p?.dataset?.avatarBase || "");
        if (!base) return "";
        return base + "coc_" + normalizeSeed(seed, p?.dataset?.seed) + ".svg";
    }

    function refreshCocPicker(p) {
        if (!p || !isPickerCoc(p)) return;

        const hidden = p.querySelector('input[name="avatar_seed"]');
        const seed = hidden?.value || p.dataset.seed || "1";
        const urlFor = value => cocUrl(p, value);

        p.querySelectorAll("img.avatar-img").forEach(img => {
            const option = img.closest(".avatar-option");
            img.src = urlFor(option?.dataset?.seed || seed);
        });
    }

    function refreshAll() {
        document.querySelectorAll(".avatar-picker").forEach(refreshCocPicker);
    }

    document.addEventListener("change", function (event) {
        const picker = event.target.closest(".avatar-picker");
        if (!picker) return;
        if (event.target.matches('select[name="avatar_style"]')) {
            requestAnimationFrame(function () {
                refreshCocPicker(picker);
            });
        }
    });

    document.addEventListener("click", function (event) {
        const option = event.target.closest(".avatar-option");
        if (!option) return;
        const picker = option.closest(".avatar-picker");
        if (!picker) return;
        requestAnimationFrame(function () {
            refreshCocPicker(picker);
        });
    });

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", refreshAll);
    } else {
        refreshAll();
    }
})();
JS;
}

return [
    'id' => 'coc_avatar',
    'name' => 'COC头像',
    'version' => '1.0.0',
    'description' => '增加 COC 本地头像池，并让新注册用户默认使用 COC 头像。',
    'author' => 'bbs1.org',
    'assets' => [
        'js' => 'coc_avatar_js',
    ],
    'hooks' => [
        'avatar.picker' => 'coc_avatar_picker',
        'avatar.url' => 'coc_avatar_url',
        'user.before_save' => 'coc_avatar_user_before_save',
    ],
];
