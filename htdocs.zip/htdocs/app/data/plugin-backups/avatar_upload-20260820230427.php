<?php
if (!defined('APP_ROOT')) exit;

const AVATAR_UPLOAD_SIZE = 200;
const AVATAR_UPLOAD_MAX_BYTES = 1048576;
const AVATAR_UPLOAD_INDEX_VERSION = '1';
const AVATAR_UPLOAD_RATE_WINDOW = 600;
const AVATAR_UPLOAD_USER_RATE_LIMIT = 5;
const AVATAR_UPLOAD_IP_RATE_LIMIT = 20;
const AVATAR_UPLOAD_CHANGE_INTERVAL = 86400;

class AvatarUploadActionException extends RuntimeException {}

function avatar_upload_schema(): void
{
    $t = app_db_types();
    app_db_create_table('plugin_avatar_uploads', "user_id {$t['uint']} NOT NULL PRIMARY KEY,version {$t['uint']} NOT NULL");
    app_db_create_table('plugin_avatar_upload_changes', "user_id {$t['uint']} NOT NULL PRIMARY KEY,last_changed_at {$t['uint']} NOT NULL DEFAULT 0");
    avatar_upload_rate_schema();
}

function avatar_upload_rate_schema(): void
{
    $t = app_db_types();
    app_db_create_table('plugin_avatar_upload_rates', "rate_key {$t['key']} NOT NULL PRIMARY KEY,hit_count {$t['uint']} NOT NULL DEFAULT 0,window_started_at {$t['uint']} NOT NULL DEFAULT 0,updated_at {$t['uint']} NOT NULL DEFAULT 0");
}

function avatar_upload_initialize(): void
{
    avatar_upload_schema();
    q('DELETE FROM plugin_avatar_uploads');
    foreach (glob(UPLOAD_DIR . '/avatar_upload/*/*.jpg') ?: [] as $file) {
        $uid = (int)pathinfo($file, PATHINFO_FILENAME);
        if ($uid < 1) continue;
        app_db_upsert('plugin_avatar_uploads', ['user_id' => $uid, 'version' => max(1, (int)@filemtime($file))], ['user_id']);
    }
    save_settings_values(['plugin_avatar_upload_index_version' => AVATAR_UPLOAD_INDEX_VERSION]);
    unset($GLOBALS['__avatar_upload_versions']);
}

function avatar_upload_install(array $plugin): void
{
    avatar_upload_initialize();
}

function avatar_upload_uninstall(array $plugin): void
{
    app_db_drop_table('plugin_avatar_upload_rates');
    app_db_drop_table('plugin_avatar_upload_changes');
    app_db_drop_table('plugin_avatar_uploads');
    save_settings_values(['plugin_avatar_upload_index_version' => '']);
    unset($GLOBALS['__avatar_upload_versions']);
}

function avatar_upload_boot($value = null, array $ctx = []): void
{
    if (setting('plugin_avatar_upload_index_version') !== AVATAR_UPLOAD_INDEX_VERSION) avatar_upload_initialize();
    avatar_upload_versions();
}

function avatar_upload_rate_hit(string $key, int $limit, int $time): array
{
    $expired = $time - AVATAR_UPLOAD_RATE_WINDOW;
    if (db_driver() === 'mysql') {
        q('INSERT INTO plugin_avatar_upload_rates(rate_key,hit_count,window_started_at,updated_at) VALUES(?,1,?,?) ON DUPLICATE KEY UPDATE hit_count=IF(window_started_at<?,1,hit_count+1),window_started_at=IF(window_started_at<?,VALUES(window_started_at),window_started_at),updated_at=VALUES(updated_at)', [$key, $time, $time, $expired, $expired]);
    } else {
        q('INSERT INTO plugin_avatar_upload_rates(rate_key,hit_count,window_started_at,updated_at) VALUES(?,1,?,?) ON CONFLICT(rate_key) DO UPDATE SET hit_count=CASE WHEN plugin_avatar_upload_rates.window_started_at<? THEN 1 ELSE plugin_avatar_upload_rates.hit_count+1 END,window_started_at=CASE WHEN plugin_avatar_upload_rates.window_started_at<? THEN excluded.window_started_at ELSE plugin_avatar_upload_rates.window_started_at END,updated_at=excluded.updated_at', [$key, $time, $time, $expired, $expired]);
    }
    $row = one('SELECT hit_count,window_started_at FROM plugin_avatar_upload_rates WHERE rate_key=?', [$key]) ?: [];
    return [
        'allowed' => (int)($row['hit_count'] ?? ($limit + 1)) <= $limit,
        'retry_after' => max(1, (int)($row['window_started_at'] ?? $time) + AVATAR_UPLOAD_RATE_WINDOW - $time),
    ];
}

function avatar_upload_enforce_rate_limit(int $uid): void
{
    $time = time();
    $checks = [
        ['user:' . $uid, AVATAR_UPLOAD_USER_RATE_LIMIT],
        ['ip:' . hash('sha256', ip_addr()), AVATAR_UPLOAD_IP_RATE_LIMIT],
    ];
    $retry_after = 0;
    foreach ($checks as [$key, $limit]) {
        $result = avatar_upload_rate_hit($key, $limit, $time);
        if (!$result['allowed']) $retry_after = max($retry_after, (int)$result['retry_after']);
    }
    if ($retry_after < 1) return;
    header('Retry-After: ' . $retry_after);
    err('头像更新过于频繁，请稍后再试', 429);
}

function avatar_upload_points_cost(): int
{
    return max(0, min(100000, (int)setting('avatar_upload_points_cost', '10')));
}

function avatar_upload_last_changed_at(int $uid): int
{
    return (int)(val('SELECT last_changed_at FROM plugin_avatar_upload_changes WHERE user_id=?', [$uid]) ?: 0);
}

function avatar_upload_change_error(int $last_changed_at, int $points): string
{
    $available_at = $last_changed_at + AVATAR_UPLOAD_CHANGE_INTERVAL;
    if ($last_changed_at > 0 && $available_at > time()) return '头像每 24 小时只能更新一次，下次可更新时间：' . date('Y-m-d H:i', $available_at);
    $cost = avatar_upload_points_cost();
    if ($points < $cost) return '积分不足，更新头像需要 ' . $cost . ' 积分';
    return '';
}

function avatar_upload_assert_can_change(int $uid): void
{
    $user = one('SELECT points FROM app_users WHERE id=?', [$uid]) ?: [];
    $error = avatar_upload_change_error(avatar_upload_last_changed_at($uid), (int)($user['points'] ?? 0));
    if ($error !== '') err($error);
}

function avatar_upload_commit_change(int $uid, callable $apply): mixed
{
    return tx(function () use ($uid, $apply) {
        $lock = db_driver() === 'sqlite' ? '' : ' FOR UPDATE';
        $user = one('SELECT points FROM app_users WHERE id=?' . $lock, [$uid]);
        if (!$user) throw new AvatarUploadActionException('用户不存在');
        $error = avatar_upload_change_error(avatar_upload_last_changed_at($uid), (int)$user['points']);
        if ($error !== '') throw new AvatarUploadActionException($error);
        $result = $apply();
        $cost = avatar_upload_points_cost();
        if ($cost > 0) q('UPDATE app_users SET points=points-? WHERE id=?', [$cost, $uid]);
        app_db_upsert('plugin_avatar_upload_changes', ['user_id' => $uid, 'last_changed_at' => time()], ['user_id']);
        unset($GLOBALS['__me_cache']);
        return $result;
    });
}

function avatar_upload_versions(): array
{
    if (is_array($GLOBALS['__avatar_upload_versions'] ?? null)) return $GLOBALS['__avatar_upload_versions'];
    if (setting('plugin_avatar_upload_index_version') !== AVATAR_UPLOAD_INDEX_VERSION) avatar_upload_initialize();
    return $GLOBALS['__avatar_upload_versions'] = array_map('intval', array_column(q('SELECT user_id,version FROM plugin_avatar_uploads')->fetchAll(), 'version', 'user_id'));
}

function avatar_upload_version(int $uid): ?int
{
    $versions = avatar_upload_versions();
    return isset($versions[$uid]) ? (int)$versions[$uid] : null;
}

function avatar_upload_mark_uploaded(int $uid): int
{
    $versions = avatar_upload_versions();
    $version = max(time(), (int)($versions[$uid] ?? 0) + 1);
    app_db_upsert('plugin_avatar_uploads', ['user_id' => $uid, 'version' => $version], ['user_id']);
    $GLOBALS['__avatar_upload_versions'][$uid] = $version;
    return $version;
}

function avatar_upload_mark_deleted(int $uid): void
{
    q('DELETE FROM plugin_avatar_uploads WHERE user_id=?', [$uid]);
    unset($GLOBALS['__avatar_upload_versions'][$uid]);
}

function avatar_upload_style(): string
{
    $style = avatar_style(setting('avatar_upload_style', 'dylan'));
    return $style !== '' ? $style : 'dylan';
}

function avatar_upload_relative_file(int $uid): string
{
    $hash = hash('sha256', 'avatar-upload:' . max(1, $uid));
    return 'avatar_upload/' . upload_hash_dir($hash) . '/' . max(1, $uid) . '.jpg';
}

function avatar_upload_file(int $uid): string
{
    return UPLOAD_DIR . '/' . avatar_upload_relative_file($uid);
}

function avatar_upload_url(int $uid, ?int $version = null): string
{
    $version ??= avatar_upload_version($uid) ?? 0;
    return asset_url('app/upload/' . avatar_upload_relative_file($uid)) . '?v=' . $version;
}

function avatar_upload_avatar_url($url, array $ctx): string
{
    $uid = (int)($ctx['uid'] ?? 0);
    $version = $uid > 0 ? avatar_upload_version($uid) : null;
    return $version !== null ? avatar_upload_url($uid, $version) : (string)$url;
}

function avatar_upload_picker($picker, array $ctx): array
{
    $picker = is_array($picker) ? $picker : [];
    $style = avatar_upload_style();
    $picker['style'] = $style;
    $picker['styles'] = [$style => avatar_styles()[$style]];
    $picker['local_only'] = false;
    $picker['base_url'] = '';
    return $picker;
}

function avatar_upload_user_before_save($user, array $ctx): array
{
    if (!is_array($user)) return [];
    $user['avatar_style'] = avatar_upload_style();
    return $user;
}

function avatar_upload_delete_user_avatar($deleted, array $ctx): bool
{
    $user = is_array($ctx['user'] ?? null) ? $ctx['user'] : [];
    $uid = (int)($user['id'] ?? 0);
    if ($uid < 1) return (bool)$deleted;
    $file = avatar_upload_file($uid);
    if (is_file($file) && !@unlink($file)) err('头像删除失败');
    avatar_upload_mark_deleted($uid);
    $style = avatar_upload_style();
    q('UPDATE app_users SET avatar_style=?,avatar_seed=? WHERE id=?', [$style, avatar_seed($style, '', $uid), $uid]);
    fire('user.after_save', ['id' => $uid, 'admin' => true, 'creating' => false]);
    return true;
}

function avatar_upload_json(array $data): never
{
    json_response($data);
}

function avatar_upload_route(array $plugin): void
{
    need_login();
    require_post();
    $uid = uid();
    avatar_upload_enforce_rate_limit($uid);
    avatar_upload_assert_can_change($uid);
    $action = (string)($_POST['avatar_upload_action'] ?? 'upload');
    $file = avatar_upload_file($uid);
    if ($action === 'delete') {
        try {
            avatar_upload_commit_change($uid, function () use ($uid, $file): void {
                if (is_file($file) && !@unlink($file)) throw new AvatarUploadActionException('头像删除失败');
                avatar_upload_mark_deleted($uid);
            });
        } catch (AvatarUploadActionException $e) {
            err($e->getMessage());
        }
        avatar_upload_json(['ok' => true, 'message' => '已恢复预置头像', 'redirect' => route_url('profile')]);
    }
    if ($action === 'preset') {
        $style = avatar_upload_style();
        $seed = avatar_seed($style, (string)($_POST['avatar_seed'] ?? ''), $uid);
        try {
            avatar_upload_commit_change($uid, function () use ($uid, $file, $style, $seed): void {
                if (is_file($file) && !@unlink($file)) throw new AvatarUploadActionException('头像切换失败');
                avatar_upload_mark_deleted($uid);
                q('UPDATE app_users SET avatar_style=?,avatar_seed=? WHERE id=?', [$style, $seed, $uid]);
            });
        } catch (AvatarUploadActionException $e) {
            err($e->getMessage());
        }
        fire('user.after_save', ['id' => $uid, 'admin' => false, 'creating' => false]);
        avatar_upload_json(['ok' => true, 'message' => '已切换预置头像', 'redirect' => route_url('profile')]);
    }
    $upload = (array)($_FILES['avatar'] ?? []);
    if ((int)($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) err('请选择头像图片');
    $tmp = (string)($upload['tmp_name'] ?? '');
    $bytes = (int)($upload['size'] ?? 0);
    if ($tmp === '' || !is_uploaded_file($tmp) || $bytes < 1 || $bytes > AVATAR_UPLOAD_MAX_BYTES) err('裁切后的头像不能超过 1MB');
    $info = @getimagesize($tmp);
    if (!is_array($info) || (int)($info[0] ?? 0) !== AVATAR_UPLOAD_SIZE || (int)($info[1] ?? 0) !== AVATAR_UPLOAD_SIZE || (string)($info['mime'] ?? '') !== 'image/jpeg') {
        err('头像格式无效，请重新裁切');
    }
    $dir = dirname($file);
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) err('头像目录创建失败');
    require_writable_dir($dir, '头像目录不可写');
    $target = $file . '.tmp.' . bin2hex(random_bytes(4));
    if (!move_uploaded_file($tmp, $target)) err('头像保存失败');
    @chmod($target, 0644);
    try {
        $version = avatar_upload_commit_change($uid, function () use ($uid, $target, $file): int {
            if (!rename($target, $file)) throw new AvatarUploadActionException('头像保存失败');
            return avatar_upload_mark_uploaded($uid);
        });
    } catch (AvatarUploadActionException $e) {
        @unlink($target);
        err($e->getMessage());
    }
    avatar_upload_json(['ok' => true, 'message' => '头像已更新，已扣除 ' . avatar_upload_points_cost() . ' 积分', 'url' => avatar_upload_url($uid, (int)$version), 'redirect' => route_url('profile')]);
}

function avatar_upload_profile_html($html, array $ctx): string
{
    $user = is_array($ctx['user'] ?? null) ? $ctx['user'] : [];
    $uid = (int)($user['id'] ?? 0);
    if ($uid < 1 || $uid !== uid()) return (string)$html;
    $has_upload = avatar_upload_version($uid) !== null;
    $style = avatar_upload_style();
    $seed = avatar_seed($style, (string)($user['avatar_seed'] ?? ''), $uid);
    $current = avatar_tag($uid, (string)($user['username'] ?? ''), $style, '', $seed);
    $cost = avatar_upload_points_cost();
    $available_at = avatar_upload_last_changed_at($uid) + AVATAR_UPLOAD_CHANGE_INTERVAL;
    $rule = $available_at > time()
        ? '每 24 小时只能更新一次，下次可更新时间：' . date('Y-m-d H:i', $available_at) . '。'
        : '每次更新消耗 ' . $cost . ' 积分，24 小时内只能更新一次。当前积分：' . (int)($user['points'] ?? 0) . '。';
    $presets = '<div class="avatar-options avatar-upload-preset-options" data-avatar-preset-options hidden>';
    foreach (range(1, avatar_seed_count($style)) as $preset_seed) {
        $preset_seed = (string)$preset_seed;
        $presets .= '<button class="avatar-option' . (!$has_upload && $preset_seed === $seed ? ' active' : '') . '" type="button" data-avatar-preset-seed="' . h($preset_seed) . '"><img class="avatar-img" src="' . h(avatar_remote_url($style, $preset_seed)) . '" alt="预置头像" loading="lazy"></button>';
    }
    $presets .= '</div>';
    return (string)$html . '<section class="avatar-upload-panel profile-disclosure" data-avatar-upload data-upload-url="' . h(route_url('avatar_upload')) . '"><div class="avatar-upload-row"><span class="avatar-upload-current">' . $current . '</span><div><strong>头像</strong><p>上传图片可拖动和缩放裁切，也可以选择统一的预置头像。' . h($rule) . '</p><div class="avatar-upload-actions"><label class="btn avatar-upload-select">上传头像<input type="file" accept="image/jpeg,image/png,image/webp" data-avatar-upload-input hidden></label><button type="button" class="btn alt" data-avatar-preset-toggle>选择预置头像</button></div></div></div>' . $presets . form_token() . '<div class="avatar-upload-status" data-avatar-upload-status></div></section><div class="modal-backdrop avatar-crop-modal" data-avatar-crop-modal hidden><div class="modal-panel avatar-crop-dialog"><div class="modal-head"><strong>裁切头像</strong><button type="button" class="modal-close" data-avatar-crop-close aria-label="关闭">×</button></div><div class="modal-body"><canvas width="280" height="280" data-avatar-crop-canvas></canvas><label class="avatar-crop-zoom"><span>缩放</span><input type="range" min="100" max="300" value="100" data-avatar-crop-zoom></label><div class="confirm-actions"><button type="button" class="btn alt" data-avatar-crop-close>取消</button><button type="button" data-avatar-crop-save>保存头像</button></div></div></div></div>';
}

function avatar_upload_admin_page(array $plugin): string
{
    need_admin();
    if (is_post_request()) {
        $style = avatar_style((string)($_POST['avatar_upload_style'] ?? ''));
        if ($style === '') err('请选择预置头像风格');
        $points_cost = max(0, min(100000, (int)($_POST['avatar_upload_points_cost'] ?? 10)));
        save_settings_values(['avatar_upload_style' => $style, 'avatar_upload_points_cost' => (string)$points_cost]);
        set_flash('头像设置已保存');
        go(admin_url(['tab' => 'avatar_upload']));
    }
    $options = '';
    $selected = avatar_upload_style();
    foreach (avatar_styles() as $style => $label) {
        $options .= '<option value="' . h($style) . '"' . ($style === $selected ? ' selected' : '') . '>' . h($label) . '</option>';
    }
    $form = '<form class="plugin-settings-form" method="post" action="' . h(admin_url(['tab' => 'avatar_upload'])) . '">' . form_token() . '<label class="grid"><span>用户预置头像风格<small>个人资料中只显示这一组预置头像，已上传的本地头像不受影响。</small></span><select name="avatar_upload_style">' . $options . '</select></label>' . number_input('每次更新消耗积分', 'avatar_upload_points_cost', avatar_upload_points_cost(), 0, 100000, true, '更新成功后扣除；失败请求不扣积分。每个账号 24 小时只能成功更新一次。') . '<button type="submit">保存设置</button></form>';
    return '<section class="admin-list-panel plugin-manage-panel">' . admin_list_head('<div class="admin-plugin-summary"><strong>本地头像</strong><span>设置用户可选的统一预置头像风格</span></div>', '') . '<div class="plugin-panel-body">' . $form . '</div></section>';
}

function avatar_upload_css(): string
{
    return '.avatar-upload-panel{min-width:0}.avatar-upload-row{display:grid;grid-template-columns:72px minmax(0,1fr);gap:12px;align-items:center}.avatar-upload-current{display:flex;width:72px;height:72px;overflow:hidden;border:1px solid var(--line);border-radius:50%;background:var(--bg)}.avatar-upload-row strong{display:block;margin-bottom:3px}.avatar-upload-row p{margin:0 0 10px;color:var(--text-muted)}.avatar-upload-actions{display:flex;flex-wrap:wrap;gap:8px}.avatar-upload-select{width:auto}.avatar-upload-status{min-height:0;margin-top:8px;color:var(--text-muted)}.avatar-upload-status:empty{display:none}.avatar-upload-status.error{color:var(--danger)}.avatar-upload-preset-options[hidden]{display:none!important}.avatar-upload-preset-options{margin-top:10px;padding-top:10px;border-top:1px solid var(--line-soft)}.avatar-crop-modal{z-index:1200}.avatar-crop-dialog{width:min(360px,calc(100vw - 24px))}.avatar-crop-dialog canvas{display:block;width:min(280px,100%);height:auto;margin:0 auto;border-radius:var(--radius);background:var(--bg);cursor:grab;touch-action:none}.avatar-crop-dialog canvas.dragging{cursor:grabbing}.avatar-crop-zoom{display:grid;grid-template-columns:42px minmax(0,1fr);gap:10px;align-items:center;margin-top:14px}.avatar-crop-zoom input{padding:0}.avatar-field{display:none!important}@media(max-width:600px){.avatar-upload-row{grid-template-columns:56px minmax(0,1fr)}.avatar-upload-current{width:56px;height:56px}}';
}

function avatar_upload_js(): string
{
    return <<<'JS'
(() => {
    const panel = document.querySelector('[data-avatar-upload]');
    if (!panel) return;
    const input = panel.querySelector('[data-avatar-upload-input]');
    const status = panel.querySelector('[data-avatar-upload-status]');
    const modal = document.querySelector('[data-avatar-crop-modal]');
    const canvas = modal?.querySelector('[data-avatar-crop-canvas]');
    const zoom = modal?.querySelector('[data-avatar-crop-zoom]');
    const save = modal?.querySelector('[data-avatar-crop-save]');
    const csrf = panel.querySelector('input[name=_csrf]')?.value || '';
    const ctx = canvas?.getContext('2d');
    const avatarField = document.querySelector('.avatar-field');
    if (avatarField) avatarField.before(panel);
    const presets = panel.querySelector('[data-avatar-preset-options]');
    let image = null, objectUrl = '', scale = 1, minScale = 1, x = 0, y = 0, dragging = false, px = 0, py = 0;
    const setStatus = (text, error = false) => {
        if (!status) return;
        status.textContent = text || '';
        status.classList.toggle('error', error);
    };
    const clamp = () => {
        if (!image || !canvas) return;
        x = Math.min(0, Math.max(canvas.width - image.naturalWidth * scale, x));
        y = Math.min(0, Math.max(canvas.height - image.naturalHeight * scale, y));
    };
    const draw = () => {
        if (!ctx || !canvas || !image) return;
        clamp();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(image, x, y, image.naturalWidth * scale, image.naturalHeight * scale);
    };
    const close = () => {
        if (modal) modal.hidden = true;
        if (input) input.value = '';
        if (objectUrl) URL.revokeObjectURL(objectUrl);
        objectUrl = '';
        image = null;
    };
    input?.addEventListener('change', () => {
        const file = input.files?.[0];
        if (!file || !file.type.startsWith('image/')) return setStatus('请选择图片文件', true);
        if (file.size > 10 * 1024 * 1024) return setStatus('原图不能超过 10MB', true);
        objectUrl = URL.createObjectURL(file);
        const next = new Image();
        next.onload = () => {
            image = next;
            minScale = Math.max(canvas.width / image.naturalWidth, canvas.height / image.naturalHeight);
            scale = minScale;
            x = (canvas.width - image.naturalWidth * scale) / 2;
            y = (canvas.height - image.naturalHeight * scale) / 2;
            zoom.value = '100';
            draw();
            modal.hidden = false;
        };
        next.onerror = () => { close(); setStatus('图片读取失败', true); };
        next.src = objectUrl;
    });
    zoom?.addEventListener('input', () => {
        if (!image) return;
        const old = scale;
        scale = minScale * Number(zoom.value || 100) / 100;
        const cx = canvas.width / 2, cy = canvas.height / 2;
        x = cx - (cx - x) * scale / old;
        y = cy - (cy - y) * scale / old;
        draw();
    });
    canvas?.addEventListener('pointerdown', e => {
        if (!image) return;
        dragging = true; px = e.clientX; py = e.clientY;
        canvas.classList.add('dragging'); canvas.setPointerCapture(e.pointerId);
    });
    canvas?.addEventListener('pointermove', e => {
        if (!dragging) return;
        const ratio = canvas.width / canvas.getBoundingClientRect().width;
        x += (e.clientX - px) * ratio; y += (e.clientY - py) * ratio;
        px = e.clientX; py = e.clientY; draw();
    });
    const stopDrag = () => { dragging = false; canvas?.classList.remove('dragging'); };
    canvas?.addEventListener('pointerup', stopDrag);
    canvas?.addEventListener('pointercancel', stopDrag);
    modal?.querySelectorAll('[data-avatar-crop-close]').forEach(button => button.addEventListener('click', close));
    save?.addEventListener('click', () => {
        if (!image) return;
        const output = document.createElement('canvas');
        output.width = output.height = 200;
        const out = output.getContext('2d');
        out.fillStyle = '#fff'; out.fillRect(0, 0, 200, 200);
        out.drawImage(image, -x / scale, -y / scale, canvas.width / scale, canvas.height / scale, 0, 0, 200, 200);
        save.disabled = true;
        output.toBlob(async blob => {
            try {
                if (!blob) throw new Error('头像生成失败');
                const body = new FormData();
                body.append('_csrf', csrf); body.append('avatar_upload_action', 'upload'); body.append('avatar', blob, 'avatar.jpg');
                const response = await fetch(panel.dataset.uploadUrl, {method: 'POST', body, headers: {'X-Requested-With': 'XMLHttpRequest'}});
                const data = await response.json();
                if (!data.ok) throw new Error(data.message || '头像上传失败');
                window.location.href = data.redirect || window.location.href;
            } catch (error) {
                setStatus(error?.message || '头像上传失败', true); close();
            } finally { save.disabled = false; }
        }, 'image/jpeg', .9);
    });
    panel.querySelector('[data-avatar-preset-toggle]')?.addEventListener('click', button => {
        if (!presets) return;
        presets.hidden = !presets.hidden;
        button.textContent = presets.hidden ? '选择预置头像' : '收起预置头像';
    });
    presets?.querySelectorAll('[data-avatar-preset-seed]').forEach(option => option.addEventListener('click', async () => {
        presets.querySelectorAll('[data-avatar-preset-seed]').forEach(button => button.disabled = true);
        setStatus('正在切换头像');
        try {
            const body = new FormData();
            body.append('_csrf', csrf);
            body.append('avatar_upload_action', 'preset');
            body.append('avatar_seed', option.dataset.avatarPresetSeed || '1');
            const response = await fetch(panel.dataset.uploadUrl, {method: 'POST', body, headers: {'X-Requested-With': 'XMLHttpRequest'}});
            const data = await response.json();
            if (!data.ok) throw new Error(data.message || '头像切换失败');
            window.location.href = data.redirect || window.location.href;
        } catch (error) {
            setStatus(error?.message || '头像切换失败', true);
            presets.querySelectorAll('[data-avatar-preset-seed]').forEach(button => button.disabled = false);
        }
    }));
})();
JS;
}

return [
    'id' => 'avatar_upload',
    'name' => '本地头像',
    'version' => '1.4.1',
    'description' => '允许用户上传并裁切自己的头像，统一预置头像风格，并通过积分与更新间隔减少频繁更换。',
    'author' => 'bbs1org',
    'install' => 'avatar_upload_install',
    'uninstall' => 'avatar_upload_uninstall',
    'assets' => ['css' => 'avatar_upload_css', 'js' => 'avatar_upload_js'],
    'hooks' => [
        'app.boot' => 'avatar_upload_boot',
        'avatar.url' => 'avatar_upload_avatar_url',
        'avatar.picker' => 'avatar_upload_picker',
        'user.before_save' => 'avatar_upload_user_before_save',
        'user.avatar_delete' => 'avatar_upload_delete_user_avatar',
        'profile.after_form' => 'avatar_upload_profile_html',
    ],
    'routes' => ['avatar_upload' => 'avatar_upload_route'],
    'admin_tabs' => ['avatar_upload' => 'avatar_upload_admin_page'],
];