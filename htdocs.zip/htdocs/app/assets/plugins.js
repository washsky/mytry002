/* ai_cron_menu_trigger */
(function () {
    'use strict';

    function ai_cron_menu_trigger_init() {
        var ai_cron_menu_trigger_config = document.getElementById('ai-cron-menu-trigger-config');
        if (!ai_cron_menu_trigger_config) return;

        var ai_cron_menu_trigger_interval = parseInt(ai_cron_menu_trigger_config.getAttribute('data-ai-cron-menu-trigger-interval') || '3600', 10);
        var ai_cron_menu_trigger_cron_url = ai_cron_menu_trigger_config.getAttribute('data-ai-cron-menu-trigger-cron-url') || '';
        var ai_cron_menu_trigger_names = [];
        try {
            var ai_cron_menu_trigger_raw_names = JSON.parse(ai_cron_menu_trigger_config.getAttribute('data-ai-cron-menu-trigger-menu-names') || '[]');
            if (Array.isArray(ai_cron_menu_trigger_raw_names)) {
                ai_cron_menu_trigger_names = ai_cron_menu_trigger_raw_names.map(function (ai_cron_menu_trigger_name) {
                    return String(ai_cron_menu_trigger_name || '').trim();
                }).filter(Boolean);
            }
        } catch (ai_cron_menu_trigger_error) {
            return;
        }

        ai_cron_menu_trigger_interval = Math.max(60, ai_cron_menu_trigger_interval);
        if (!ai_cron_menu_trigger_cron_url || !ai_cron_menu_trigger_names.length) return;

        var ai_cron_menu_trigger_storage_key = 'ai_cron_menu_trigger_last_at';

        function ai_cron_menu_trigger_get_last_at() {
            try {
                var ai_cron_menu_trigger_value = window.localStorage.getItem(ai_cron_menu_trigger_storage_key);
                var ai_cron_menu_trigger_last_at = parseInt(ai_cron_menu_trigger_value || '0', 10);
                return Number.isFinite(ai_cron_menu_trigger_last_at) ? ai_cron_menu_trigger_last_at : 0;
            } catch (ai_cron_menu_trigger_error) {
                return 0;
            }
        }

        function ai_cron_menu_trigger_mark_now() {
            try {
                window.localStorage.setItem(ai_cron_menu_trigger_storage_key, String(Date.now()));
                return true;
            } catch (ai_cron_menu_trigger_error) {
                return false;
            }
        }

        function ai_cron_menu_trigger_should_run() {
            return Date.now() - ai_cron_menu_trigger_get_last_at() >= ai_cron_menu_trigger_interval * 1000;
        }

        function ai_cron_menu_trigger_match(ai_cron_menu_trigger_link) {
            if (!ai_cron_menu_trigger_link) return false;
            var ai_cron_menu_trigger_text = String(ai_cron_menu_trigger_link.textContent || '').replace(/\s+/g, ' ').trim();
            return ai_cron_menu_trigger_names.indexOf(ai_cron_menu_trigger_text) !== -1;
        }

        function ai_cron_menu_trigger_send() {
            if (!ai_cron_menu_trigger_should_run()) return;
            if (!ai_cron_menu_trigger_mark_now()) return;
            try {
                window.fetch(ai_cron_menu_trigger_cron_url, {
                    method: 'GET',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    keepalive: true
                }).catch(function () {});
            } catch (ai_cron_menu_trigger_error) {}
        }

        document.addEventListener('click', function (ai_cron_menu_trigger_event) {
            if (ai_cron_menu_trigger_event.defaultPrevented) return;
            if (ai_cron_menu_trigger_event.button !== 0) return;
            if (ai_cron_menu_trigger_event.metaKey || ai_cron_menu_trigger_event.ctrlKey || ai_cron_menu_trigger_event.shiftKey || ai_cron_menu_trigger_event.altKey) return;

            var ai_cron_menu_trigger_link = ai_cron_menu_trigger_event.target && ai_cron_menu_trigger_event.target.closest
                ? ai_cron_menu_trigger_event.target.closest('a')
                : null;
            if (!ai_cron_menu_trigger_link || !ai_cron_menu_trigger_match(ai_cron_menu_trigger_link)) return;

            var ai_cron_menu_trigger_is_top_menu = !!ai_cron_menu_trigger_link.closest('[data-slot~="top.menu_links"]');
            var ai_cron_menu_trigger_is_mobile_menu = !!ai_cron_menu_trigger_link.closest('.mobile-menu-body');
            if (!ai_cron_menu_trigger_is_top_menu && !ai_cron_menu_trigger_is_mobile_menu) return;

            ai_cron_menu_trigger_send();
        }, true);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', ai_cron_menu_trigger_init, { once: true });
    } else {
        ai_cron_menu_trigger_init();
    }
}());
/* attachment_upload */
(function(){
"use strict";
const historyPrefix="bbs1_attachment_upload_history_v1_",states=new WeakMap(),limit=100;
const toast=message=>{const el=document.getElementById("toast");if(!el)return;el.textContent=message;el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>{el.hidden=true},2200)};
const insertText=(field,text)=>{const start=field.selectionStart??field.value.length,end=field.selectionEnd??start,prefix=start>0&&!field.value.slice(0,start).endsWith("\n")?"\n":"",suffix=end<field.value.length&&!field.value.slice(end).startsWith("\n")?"\n":"";field.setRangeText(prefix+text+suffix,start,end,"end");field.dispatchEvent(new Event("input",{bubbles:true}));field.focus()};
const read=key=>{if(!key)return[];try{const data=JSON.parse(localStorage.getItem(key)||"[]"),keys=new Set();if(!Array.isArray(data))return[];return data.filter(x=>{if(!x||typeof x.key!=="string"||typeof x.markdown!=="string"||!x.key||!x.markdown||keys.has(x.key))return false;keys.add(x.key);return true}).slice(-limit)}catch(_){return[]}};
const write=(key,items)=>{if(!key)return;try{localStorage.setItem(key,JSON.stringify(items.slice(-limit)))}catch(_){}};
const row=(list,file,key)=>{const item=document.createElement("div");item.className="attachment-upload-item";item.dataset.state="waiting";item.dataset.attachmentKey=key;const head=document.createElement("div");head.className="attachment-upload-head";const name=document.createElement("span");name.className="attachment-upload-name";name.textContent=file.name||"未命名附件";name.title=file.name||"";const actions=document.createElement("div");actions.className="attachment-upload-head-actions";const status=document.createElement("span");status.className="attachment-upload-status";status.textContent="等待上传";const remove=document.createElement("button");remove.type="button";remove.className="attachment-upload-remove";remove.dataset.attachmentRemove="";remove.setAttribute("aria-label","不插入此附件");remove.title="不插入内容";remove.textContent="×";actions.append(status,remove);head.append(name,actions);const progress=document.createElement("span");progress.className="attachment-upload-progress";progress.setAttribute("role","progressbar");progress.setAttribute("aria-valuemin","0");progress.setAttribute("aria-valuemax","100");progress.setAttribute("aria-valuenow","0");progress.append(document.createElement("span"));item.append(head,progress);list.append(item);return{item,status,progress,bar:progress.firstElementChild}};
const update=(item,state,percent,message)=>{if(!item)return;const value=Math.max(0,Math.min(100,Math.round(percent||0)));item.item.dataset.state=state;item.bar.style.width=value+"%";item.progress.setAttribute("aria-valuenow",String(value));item.status.textContent=message||(state==="uploading"?"上传中 "+value+"%":state==="error"?"上传失败":"等待上传")};
const success=(item,entry,restored=false)=>{if(!item)return;item.item.dataset.markdown=entry.markdown;item.item.tabIndex=0;item.item.setAttribute("role","button");item.item.setAttribute("aria-label","复制 "+entry.name+" 的 Markdown");update(item,"success",100,restored?"历史记录 · 点击复制":"上传完成 · 点击复制")};
const toolbar=(uploader,state)=>{const bar=uploader.querySelector("[data-attachment-upload-toolbar]"),summary=uploader.querySelector("[data-attachment-upload-summary]"),button=uploader.querySelector("[data-attachment-insert-all]"),pending=state.history.filter(x=>!state.inserted.has(x.key)).length;if(bar)bar.hidden=state.history.length===0;if(summary)summary.textContent="已上传 "+state.history.length+" 个";if(button){button.disabled=pending===0;button.textContent=pending>0?"批量插入（"+pending+"）":"已全部插入"}};
const stateFor=uploader=>{let state=states.get(uploader);if(state)return state;const storageKey=uploader.dataset.uploadStorageKey||"",history=read(storageKey);state={storageKey,history,selected:new Set(history.map(x=>x.key)),inserted:new Set(),dismissed:new Set()};states.set(uploader,state);const list=uploader.querySelector("[data-attachment-upload-list]");if(list&&history.length){list.hidden=false;history.forEach(entry=>success(row(list,entry,entry.key),entry,true))}toolbar(uploader,state);return state};
const dismiss=(uploader,key,item)=>{if(!uploader||!key)return;const state=stateFor(uploader);state.dismissed.add(key);state.history=state.history.filter(x=>x.key!==key);state.inserted.delete(key);write(state.storageKey,state.history);item?.remove();const list=uploader.querySelector("[data-attachment-upload-list]");if(list&&!list.children.length)list.hidden=true;toolbar(uploader,state)};
const beforeSubmit=form=>{const textarea=form?.querySelector("textarea[name=body]");if(!textarea)return 0;const pending=[],seen=new Set(),uploaders=Array.from(form.querySelectorAll(".attachment-uploader[data-upload-storage-key]"));uploaders.forEach(uploader=>{const state=stateFor(uploader);state.history.forEach(entry=>{if(state.inserted.has(entry.key)||seen.has(entry.key))return;seen.add(entry.key);if(textarea.value.includes(entry.markdown)){state.inserted.add(entry.key);return}pending.push({entry,state})})});if(pending.length){const prefix=textarea.value===""||textarea.value.endsWith("\n")?"":"\n";textarea.value+=prefix+pending.map(x=>x.entry.markdown).join("\n");textarea.dispatchEvent(new Event("input",{bubbles:true}));pending.forEach(x=>x.state.inserted.add(x.entry.key))}uploaders.forEach(x=>toolbar(x,stateFor(x)));return pending.length};
const clear=storageKey=>{if(!storageKey)return;try{localStorage.removeItem(storageKey)}catch(_){}document.querySelectorAll(".attachment-uploader[data-upload-storage-key]").forEach(uploader=>{if(uploader.dataset.uploadStorageKey!==storageKey)return;const state=stateFor(uploader);state.history.length=0;state.selected.clear();state.inserted.clear();state.dismissed.clear();const list=uploader.querySelector("[data-attachment-upload-list]");if(list){list.replaceChildren();list.hidden=true}toolbar(uploader,state)})};
const afterSubmit=()=>{const marker=document.cookie.split("; ").find(x=>x.startsWith("__attachment_upload_history_clear="));if(!marker)return false;const userId=marker.slice(marker.indexOf("=")+1);if(/^\d+$/.test(userId))clear(historyPrefix+userId);document.cookie="__attachment_upload_history_clear=; Max-Age=0; path=/; SameSite=Lax"+(location.protocol==="https:"?"; Secure":"");return true};
const copy=async item=>{const markdown=item?.dataset?.markdown||"";if(!markdown||item.dataset.state!=="success")return;const status=item.querySelector(".attachment-upload-status");try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(markdown);else{const field=document.createElement("textarea");field.value=markdown;field.setAttribute("readonly","");field.style.position="fixed";field.style.opacity="0";document.body.append(field);field.select();const copied=document.execCommand("copy");field.remove();if(!copied)throw new Error()}if(status)status.textContent="已复制 Markdown";toast("Markdown 已复制");item.closest("form")?.querySelector("textarea[name=body]")?.focus()}catch(_){if(status)status.textContent="复制失败 · 点击重试";toast("复制失败")}};
const send=(url,csrf,file,onProgress)=>new Promise((resolve,reject)=>{const request=new XMLHttpRequest();request.open("POST",url,true);request.setRequestHeader("X-Requested-With","XMLHttpRequest");request.upload.addEventListener("progress",event=>{if(event.lengthComputable)onProgress(event.loaded*100/event.total)});request.addEventListener("load",()=>{let data;try{data=JSON.parse(request.responseText||"")}catch(_){reject(new Error("上传失败"));return}if(request.status<200||request.status>=300||!data.ok){reject(new Error(data.message||"上传失败"));return}resolve(data)});request.addEventListener("error",()=>reject(new Error("上传失败")));request.addEventListener("abort",()=>reject(new Error("上传已取消")));const body=new FormData();body.append("_csrf",csrf);body.append("attachment",file);request.send(body)});
const floatIcon=uploader=>{const form=uploader.closest("form"),area=form?form.querySelector("textarea[name=body]"):null,anchor=area?area.closest("label"):null,drop=uploader.querySelector(".attachment-drop"),input=uploader.querySelector("[data-attachment-input]");if(!form||!anchor||!drop||!input||drop.dataset.attachmentFloat)return;if(getComputedStyle(anchor).position==="static")anchor.style.position="relative";const strong=drop.querySelector("strong"),box=document.createElement("span");box.className="attachment-drop attachment-drop-float";box.title="上传附件";box.setAttribute("role","button");box.tabIndex=0;box.innerHTML=strong?strong.outerHTML:"";box.style.cssText="position:absolute;right:8px;bottom:4px;z-index:3;display:inline-flex;align-items:center;justify-content:center;padding:6px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--panel);color:var(--text-muted);cursor:pointer;line-height:0";drop.dataset.attachmentFloat="1";drop.style.display="none";box.addEventListener("click",()=>input.click());box.addEventListener("keydown",event=>{if(event.key!=="Enter"&&event.key!==" ")return;event.preventDefault();input.click()});anchor.appendChild(box)};
afterSubmit();document.querySelectorAll(".attachment-uploader[data-upload-storage-key]").forEach(uploader=>{stateFor(uploader);floatIcon(uploader)});
document.addEventListener("change",async event=>{const input=event.target.closest("[data-attachment-input]");if(!input)return;const uploader=input.closest(".attachment-uploader"),form=input.closest("form"),textarea=form?.querySelector("textarea[name=body]"),url=uploader?.dataset?.uploadUrl||"",csrf=form?.querySelector("input[name=_csrf]")?.value||"",selected=Array.from(input.files||[]);if(!uploader||!textarea||!url||!selected.length)return;const state=stateFor(uploader),batch=new Set(),entries=[];let duplicates=0;selected.forEach(file=>{const key=[file.name,file.size,file.lastModified].join("\u001f");if(state.selected.has(key)||batch.has(key)){duplicates++;return}batch.add(key);entries.push({file,key})});if(duplicates)toast("已忽略"+duplicates+"个重复文件");if(!entries.length){input.value="";return}entries.forEach(x=>state.selected.add(x.key));const maxMb=parseInt(uploader.dataset.uploadMaxMb||"20",10)||20,list=uploader.querySelector("[data-attachment-upload-list]");if(list)list.hidden=false;const rows=entries.map(x=>list?row(list,x.file,x.key):null);input.disabled=true;for(const [index,entry] of entries.entries()){const item=rows[index],file=entry.file;uploader.dataset.uploadingCount=String((parseInt(uploader.dataset.uploadingCount||"0",10)||0)+1);try{if(file.size>maxMb*1024*1024)throw new Error("超过"+maxMb+"MB");if(item)update(item,"uploading",0);const data=await send(url,csrf,file,percent=>{if(item)update(item,"uploading",percent)}),markdown=String(data.markdown||""),saved={key:entry.key,name:file.name||"未命名附件",size:file.size||0,lastModified:file.lastModified||0,markdown,createdAt:Date.now()};if(markdown&&!state.dismissed.has(saved.key)){state.history.push(saved);write(state.storageKey,state.history);if(item)success(item,saved);toolbar(uploader,state)}else if(item)update(item,"success",100,"上传完成")}catch(error){const message=error?.message||"上传失败";if(item)update(item,"error",100,message);toast((file.name?file.name+"：":"")+message)}finally{uploader.dataset.uploadingCount=String(Math.max(0,(parseInt(uploader.dataset.uploadingCount||"0",10)||0)-1))}}input.disabled=false;input.value=""});
document.addEventListener("click",event=>{const remove=event.target.closest("[data-attachment-remove]");if(remove){event.preventDefault();event.stopPropagation();const item=remove.closest(".attachment-upload-item");dismiss(item?.closest(".attachment-uploader"),item?.dataset.attachmentKey||"",item);return}const insert=event.target.closest("[data-attachment-insert-all]");if(insert){const uploader=insert.closest(".attachment-uploader"),textarea=uploader?.closest("form")?.querySelector("textarea[name=body]");if(!uploader||!textarea)return;const state=stateFor(uploader),entries=state.history.filter(x=>!state.inserted.has(x.key));if(!entries.length)return;insertText(textarea,entries.map(x=>x.markdown).join("\n"));entries.forEach(x=>state.inserted.add(x.key));toolbar(uploader,state);toast("已插入 "+entries.length+" 个附件");return}const item=event.target.closest(".attachment-upload-item[data-state='success'][data-markdown]");if(item)copy(item)});
document.addEventListener("keydown",event=>{if(event.target.closest("[data-attachment-remove]"))return;const item=event.target.closest(".attachment-upload-item[data-state='success'][data-markdown]");if(!item||(event.key!=="Enter"&&event.key!==" "))return;event.preventDefault();copy(item)});
window.bbs1AttachmentUpload={beforeSubmit,afterSubmit,isUploading:form=>!!form?.querySelector?.(".attachment-uploader[data-uploading-count]:not([data-uploading-count='0'])")};
})();
/* avatar_library */
(() => {
    const cfg = document.querySelector('[data-avatar-library-config]');
    const profileSlot = cfg ? (cfg.closest('[data-slot~="profile.after_form"]') || document) : document;
    const picker = profileSlot.querySelector('.avatar-picker');

    if (!cfg || !picker) {
        const logoInput = document.querySelector('[data-avatar-library-logo-upload]');
        const logoForm = logoInput?.closest('form');
        const logoSubmit = logoForm?.querySelector('[data-avatar-library-logo-submit]');
        const logoEditor = document.querySelector('[data-avatar-library-logo-editor]');
        if (logoInput && logoEditor && logoForm) {
            const logoCanvas = logoEditor.querySelector('[data-avatar-library-logo-canvas]');
            const logoZoom = logoEditor.querySelector('[data-avatar-library-logo-zoom]');
            const logoApply = logoEditor.querySelector('[data-avatar-library-logo-apply]');
            const logoCtx = logoCanvas?.getContext('2d');
            let logoImage=null, logoObjectUrl='', logoScale=1, logoMinScale=1, logoX=0, logoY=0, logoDrag=false, logoPX=0, logoPY=0;
            const logoClamp=()=>{if(!logoImage||!logoCanvas)return;const w=logoImage.naturalWidth*logoScale,h=logoImage.naturalHeight*logoScale;logoX=w<=logoCanvas.width?Math.min(logoCanvas.width-w,Math.max(0,logoX)):Math.min(0,Math.max(logoCanvas.width-w,logoX));logoY=h<=logoCanvas.height?Math.min(logoCanvas.height-h,Math.max(0,logoY)):Math.min(0,Math.max(logoCanvas.height-h,logoY));};
            const logoDraw=()=>{if(!logoCtx||!logoCanvas||!logoImage)return;logoClamp();logoCtx.clearRect(0,0,logoCanvas.width,logoCanvas.height);logoCtx.drawImage(logoImage,logoX,logoY,logoImage.naturalWidth*logoScale,logoImage.naturalHeight*logoScale);};
            const logoRelease=()=>{if(logoObjectUrl)URL.revokeObjectURL(logoObjectUrl);logoObjectUrl='';logoImage=null;};
            const logoClose=(clearInput=true)=>{logoEditor.hidden=true;logoRelease();if(clearInput)logoInput.value='';};
            const logoSubmitForm=()=>{
                if (typeof logoForm.requestSubmit === 'function') {
                    logoForm.requestSubmit(logoSubmit || undefined);
                } else {
                    logoForm.submit();
                }
            };
            logoInput.addEventListener('change',()=>{
                const file=logoInput.files?.[0];
                if(!file)return;
                // SVG 不需要裁剪，保留原 SVG，直接交给下面的“直接上传并应用”。
                if(file.type==='image/svg+xml' || /\.svg$/i.test(file.name||'')) { logoClose(false); return; }
                if(!/^image\/(?:png|jpeg|webp)$/i.test(file.type)){logoInput.value='';alert('仅支持 SVG、PNG、JPG、WebP');return;}
                if(file.size>10*1024*1024){logoInput.value='';alert('位图图标不能超过 10MB');return;}
                logoRelease();
                logoObjectUrl=URL.createObjectURL(file);
                logoImage=new Image();
                logoImage.onload=()=>{
                    logoEditor.hidden=false;
                    // 初始状态保证整张图片完整落在裁剪框内；随后用户可以继续缩放到 500%。
                    logoMinScale=Math.min(logoCanvas.width/logoImage.naturalWidth,logoCanvas.height/logoImage.naturalHeight);
                    if(!isFinite(logoMinScale)||logoMinScale<=0)logoMinScale=1;
                    logoScale=logoMinScale;
                    logoX=(logoCanvas.width-logoImage.naturalWidth*logoScale)/2;
                    logoY=(logoCanvas.height-logoImage.naturalHeight*logoScale)/2;
                    if(logoZoom)logoZoom.value='100';
                    logoDraw();
                };
                logoImage.onerror=()=>{logoClose();alert('图标图片无法读取');};
                logoImage.src=logoObjectUrl;
            });
            logoZoom?.addEventListener('input',()=>{if(!logoImage)return;const old=logoScale;logoScale=logoMinScale*Number(logoZoom.value||100)/100;const cx=logoCanvas.width/2,cy=logoCanvas.height/2;logoX=cx-(cx-logoX)*logoScale/old;logoY=cy-(cy-logoY)*logoScale/old;logoDraw();});
            logoCanvas?.addEventListener('pointerdown',e=>{if(!logoImage)return;logoDrag=true;logoPX=e.clientX;logoPY=e.clientY;logoCanvas.setPointerCapture(e.pointerId);logoCanvas.classList.add('dragging');});
            logoCanvas?.addEventListener('pointermove',e=>{if(!logoDrag)return;const r=logoCanvas.width/logoCanvas.getBoundingClientRect().width;logoX+=(e.clientX-logoPX)*r;logoY+=(e.clientY-logoPY)*r;logoPX=e.clientX;logoPY=e.clientY;logoDraw();});
            const logoStop=()=>{logoDrag=false;logoCanvas?.classList.remove('dragging')};logoCanvas?.addEventListener('pointerup',logoStop);logoCanvas?.addEventListener('pointercancel',logoStop);
            logoApply?.addEventListener('click',()=>{
                if(!logoImage)return;
                logoApply.disabled=true;
                const out=document.createElement('canvas');out.width=out.height=512;
                const oc=out.getContext('2d');
                oc.clearRect(0,0,512,512);
                // 把当前 320×320 预览框对应的原图区域输出到 512×512，透明背景保持不变。
                const sx=-logoX/logoScale, sy=-logoY/logoScale, sw=logoCanvas.width/logoScale, sh=logoCanvas.height/logoScale;
                oc.drawImage(logoImage,sx,sy,sw,sh,0,0,512,512);
                out.toBlob(blob=>{
                    if(!blob){logoApply.disabled=false;alert('裁剪失败');return;}
                    try{
                        const dt=new DataTransfer();
                        dt.items.add(new File([blob],'avatar_library_logo.png',{type:'image/png'}));
                        logoInput.files=dt.files;
                        // 不清空 file input，也不再停留在“选中了但没有提交”的中间状态。
                        // 直接提交，确保第一次裁剪就真正保存并刷新 favicon/顶部图标。
                        logoEditor.hidden=true;
                        logoRelease();
                        logoSubmitForm();
                    }catch(_){
                        logoApply.disabled=false;
                        alert('浏览器不支持裁剪结果回填，请改用“直接上传并应用”上传原图');
                    }
                },'image/png');
            });
        }
        document.querySelectorAll('[data-avatar-library-admin-upload]').forEach(input => {
            input.addEventListener('change', () => {
                const file=input.files?.[0]; if(!file || file.type==='image/svg+xml') return;
                if(!/^image\/(?:jpeg|png|webp)$/i.test(file.type)){input.value='';alert('仅支持 JPG、PNG、WebP、SVG');return;}
                if(file.size>10*1024*1024){input.value='';alert('原图不能超过 10MB');return;}
                const modal=document.createElement('div'); modal.className='modal-backdrop avatar-library-crop-modal';
                modal.innerHTML='<div class="modal-panel avatar-library-crop-dialog"><div class="modal-head"><strong>调整头像</strong><button type="button" class="modal-close" data-close>×</button></div><div class="modal-body"><canvas width="320" height="320"></canvas><label class="avatar-library-crop-zoom"><span>缩放</span><input type="range" min="100" max="300" value="100"></label><div class="confirm-actions"><button type="button" class="btn alt" data-close>取消</button><button type="button" data-save>确认并使用</button></div></div></div>';
                document.body.appendChild(modal); const canvas=modal.querySelector('canvas'), zoom=modal.querySelector('input[type=range]'), save=modal.querySelector('[data-save]'), ctx=canvas.getContext('2d'); let image=null,scale=1,minScale=1,x=0,y=0,drag=false,px=0,py=0,objectUrl='';
                const clamp=()=>{if(!image)return;x=Math.min(0,Math.max(canvas.width-image.naturalWidth*scale,x));y=Math.min(0,Math.max(canvas.height-image.naturalHeight*scale,y));}; const draw=()=>{if(!image)return;clamp();ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,x,y,image.naturalWidth*scale,image.naturalHeight*scale);}; const close=()=>{if(objectUrl)URL.revokeObjectURL(objectUrl);modal.remove();};
                modal.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',close)); objectUrl=URL.createObjectURL(file); image=new Image(); image.onload=()=>{minScale=Math.max(canvas.width/image.naturalWidth,canvas.height/image.naturalHeight);scale=minScale;x=(canvas.width-image.naturalWidth*scale)/2;y=(canvas.height-image.naturalHeight*scale)/2;draw();}; image.src=objectUrl;
                zoom.addEventListener('input',()=>{const old=scale;scale=minScale*Number(zoom.value||100)/100;const cx=canvas.width/2,cy=canvas.height/2;x=cx-(cx-x)*scale/old;y=cy-(cy-y)*scale/old;draw();}); canvas.addEventListener('pointerdown',e=>{drag=true;px=e.clientX;py=e.clientY;canvas.setPointerCapture(e.pointerId);canvas.classList.add('dragging');}); canvas.addEventListener('pointermove',e=>{if(!drag)return;const r=canvas.width/canvas.getBoundingClientRect().width;x+=(e.clientX-px)*r;y+=(e.clientY-py)*r;px=e.clientX;py=e.clientY;draw();}); const stop=()=>{drag=false;canvas.classList.remove('dragging')}; canvas.addEventListener('pointerup',stop);canvas.addEventListener('pointercancel',stop);
                save.addEventListener('click',()=>{if(!image)return;const out=document.createElement('canvas');out.width=out.height=512;const oc=out.getContext('2d');oc.drawImage(image,-x/scale,-y/scale,canvas.width/scale,canvas.height/scale,0,0,512,512);out.toBlob(blob=>{if(!blob){alert('裁剪失败');return;}try{const dt=new DataTransfer();dt.items.add(new File([blob],'avatar.jpg',{type:'image/jpeg'}));input.files=dt.files;close();}catch(_){alert('浏览器不支持裁剪结果回填，请直接上传原图');close();}},'image/jpeg',.9);});
            });
        });
        return;
    }

    let groups = {}, current = {};
    try { groups = JSON.parse(cfg.dataset.avatarLibraryGroups || '{}'); } catch (_) {}
    try { current = JSON.parse(cfg.dataset.avatarLibraryCurrent || '{}'); } catch (_) {}

    const route = cfg.dataset.avatarLibraryUrl || '';
    const localRoot = cfg.dataset.avatarLibraryLocalRoot || '';
    const defaultSource = cfg.dataset.avatarLibraryDefaultSource === 'local' ? 'local' : 'remote';
    const defaultGroup = String(cfg.dataset.avatarLibraryDefaultGroup || 'dylan');
    const defaultLabel = String(cfg.dataset.avatarLibraryDefaultLabel || '默认头像');
    const form = picker.closest('form');
    const select = picker.querySelector('select[name="avatar_style"]');
    const seedInput = picker.querySelector('input[name="avatar_seed"]');
    const options = picker.querySelector('.avatar-options');
    const preview = picker.querySelector('.avatar-picker-preview img');
    const summary = picker.querySelector('.profile-avatar-summary img');
    if (!select || !seedInput || !options) return;

    const LOCAL_PREFIX = '__avatar_library_local__:';
    const localUrl = (group, seed) => { const meta=groups[group]; const item=meta?.items?.[String(seed)] || meta?.items?.[Number(seed)] || {}; return item.url || '';  };
    const hidden = name => form?.querySelector(`input[name="${name}"]`);
    const ensureHidden = (name, value) => {
        if (!form) return null;
        let input = hidden(name);
        if (!input) { input = document.createElement('input'); input.type = 'hidden'; input.name = name; form.appendChild(input); }
        input.value = value;
        return input;
    };
    const removeHidden = name => hidden(name)?.remove();
    const setImages = url => {
        if (!url) return;
        if (preview) preview.src = url;
        if (summary) summary.src = url;
    };
    const remoteStyle = () => {
        const value = String(select.value || '');
        if (value === DEFAULT_VALUE) return defaultSource === 'remote' ? defaultGroup : 'dylan';
        return value.startsWith(LOCAL_PREFIX) ? (defaultSource === 'remote' ? defaultGroup : 'dylan') : value;
    };
    const remoteSeed = () => String(seedInput.value || '1');

    let source = current.source === 'local' ? 'local' : (current.source === 'default' ? 'default' : 'remote');
    let localGroup = source === 'local' ? String(current.group || '') : '';
    let localSeed = source === 'local' ? Number(current.seed || 1) : 1;
    let remoteOptionsHtml = options.innerHTML;

    // 核心的空 value“默认”固定等价于 Dylan；插件的“默认”必须表示
    // “后台当前配置的新用户默认头像”，因此使用独立的虚拟值，避免被核心
    // avatar_style 逻辑误认为 Dylan。提交时仍由 hidden source=default 告诉服务端
    // 真实来源是动态默认头像。
    const DEFAULT_VALUE = '__avatar_library_default__';
    const coreDefaultOption = [...select.options].find(option => option.value === '');
    if (coreDefaultOption) coreDefaultOption.remove();
    const defaultOption = document.createElement('option');
    defaultOption.value = DEFAULT_VALUE;
    defaultOption.textContent = defaultLabel;
    defaultOption.dataset.avatarLibraryDefault = '1';
    select.insertBefore(defaultOption, select.firstChild);

    Object.entries(groups).forEach(([key, meta]) => {
        const opt = document.createElement('option');
        opt.value = LOCAL_PREFIX + key;
        opt.textContent = String(meta.name || key);
        opt.dataset.avatarLibraryLocal = '1';
        opt.dataset.avatarLibraryGroup = key;
        select.appendChild(opt);
    });

    const clearLocalFields = () => {
        removeHidden('avatar_library_form_source');
        removeHidden('avatar_library_form_group');
        removeHidden('avatar_library_form_seed');
    };
    const setLocalFields = (group, seed) => {
        ensureHidden('avatar_library_form_source', 'local');
        ensureHidden('avatar_library_form_group', group);
        ensureHidden('avatar_library_form_seed', String(seed));
    };

    const renderRemoteOptions = () => {
        options.innerHTML = remoteOptionsHtml;
        const active = options.querySelector(`.avatar-option[data-seed="${CSS.escape(remoteSeed())}"]`) || options.querySelector('.avatar-option.active');
        options.querySelectorAll('.avatar-option').forEach(x => x.classList.toggle('active', x === active));
    };

    const renderLocalOptions = group => {
        options.innerHTML = '';
        const meta = groups[group];
        if (!meta) return;
        (meta.seeds || []).forEach(seed => {
            const n = Number(seed);
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'avatar-option' + (n === localSeed ? ' active' : '');
            button.dataset.seed = String(n);
            const img = document.createElement('img');
            img.className = 'avatar-img';
            img.src = localUrl(group, n);
            img.alt = '';
            img.loading = 'lazy';
            button.appendChild(img);
            button.addEventListener('click', () => {
                source = 'local';
                localGroup = group;
                localSeed = n;
                select.value = LOCAL_PREFIX + group;
                seedInput.value = String(n);
                setLocalFields(localGroup, localSeed);
                options.querySelectorAll('.avatar-option').forEach(x => x.classList.toggle('active', x === button));
                setImages(img.src);
            });
            options.appendChild(button);
        });
    };

    const chooseLocal = (group, seed) => {
        const meta = groups[group];
        if (!meta) return;
        source = 'local';
        localGroup = group;
        localSeed = Number(seed || meta.seeds?.[0] || 1);
        select.value = LOCAL_PREFIX + group;
        seedInput.value = String(localSeed);
        setLocalFields(localGroup, localSeed);
        renderLocalOptions(localGroup);
        setImages(localUrl(localGroup, localSeed));
    };

    const chooseRemote = () => {
        source = 'remote';
        localGroup = '';
        // 明确告诉服务端：这次是用户主动切换到远程。
        // 这里不能再由 renderRemoteOptions() 清理 hidden，否则“本地 -> 远程”
        // 时 after_save 无法确认这是一次真实的远程来源切换。
        ensureHidden('avatar_library_form_source', 'remote');
        ensureHidden('avatar_library_form_group', String(select.value || 'dylan'));
        ensureHidden('avatar_library_form_seed', remoteSeed());
        renderRemoteOptions();
    };

    // 捕获阶段接管本地头像格子的点击，必须阻止核心脚本继续执行 refreshAvatarPicker()；
    // 否则核心会把 __avatar_library_local__:group 当作 DiceBear style，产生幽灵 URL。
    options.addEventListener('click', event => {
        if (source !== 'local') return;
        const button = event.target.closest('.avatar-option');
        if (!button || !options.contains(button)) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        const seed = Number(button.dataset.seed || 1);
        localSeed = seed;
        seedInput.value = String(seed);
        setLocalFields(localGroup, localSeed);
        options.querySelectorAll('.avatar-option').forEach(x => x.classList.toggle('active', x === button));
        setImages(localUrl(localGroup, localSeed));
    }, true);

    // 捕获阶段拦截本地选项，避免核心脚本把虚拟值当作 DiceBear style。
    select.addEventListener('change', event => {
        const value = String(select.value || '');

        // “默认”是插件自己的动态默认值，不能使用核心空 value，因为核心会把
        // 空 value 当作 Dylan。这里在捕获阶段接管，保证后台改成任意远程/本地组后，
        // 用户选择器中的“默认”始终明确表示“当前后台默认头像”。
        if (value === DEFAULT_VALUE) {
            event.preventDefault();
            event.stopImmediatePropagation();
            source = 'default';
            localGroup = '';
            clearLocalFields();
            ensureHidden('avatar_library_form_source', 'default');
            removeHidden('avatar_library_form_group');
            removeHidden('avatar_library_form_seed');
            seedInput.value = '1';
            const defaultIsLocal = defaultSource === 'local' && groups[defaultGroup];
            if (defaultIsLocal) {
                localGroup = defaultGroup;
                localSeed = 1;
                renderLocalOptions(defaultGroup);
            } else {
                renderRemoteOptions();
                options.querySelectorAll('.avatar-option').forEach(x => x.classList.remove('active'));
            }
            setImages(String(cfg.dataset.avatarLibraryDefaultUrl || ''));
            return;
        }

        if (!value.startsWith(LOCAL_PREFIX)) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        const group = value.slice(LOCAL_PREFIX.length);
        chooseLocal(group, groups[group]?.seeds?.[0] || 1);
    }, true);

    // 远程选择仍然使用核心选择器；这里显式记录 remote 来源。
    select.addEventListener('change', () => {
        const value = String(select.value || '');
        if (value === DEFAULT_VALUE || value.startsWith(LOCAL_PREFIX)) return;
        chooseRemote();
    });

    // 远程头像格子点击时，核心会只更新 avatar_seed。
    // 插件同时把当前来源明确记为 remote，避免 local hidden 状态残留。
    options.addEventListener('click', event => {
        const button = event.target.closest('.avatar-option');
        if (!button || !options.contains(button)) return;
        if (source === 'local') return;
        source = 'remote';
        localGroup = '';
        ensureHidden('avatar_library_form_source', 'remote');
        ensureHidden('avatar_library_form_group', remoteStyle());
        ensureHidden('avatar_library_form_seed', String(button.dataset.seed || '1'));
    });

    // 页面首次打开：
    // 1. local：显示本地组；
    // 2. remote：显示远程组；
    // 3. default：明确选中“默认”，并把后台当前配置的默认头像作为预览。
    //    hidden source=default 保证保存后仍跟随后台默认头像组，而不是固化当前组。
    if (source === 'local' && localGroup && groups[localGroup]) {
        chooseLocal(localGroup, localSeed);
    } else if (source === 'default') {
        const defaultGroupKey = String(defaultGroup || '');
        const defaultIsLocal = defaultSource === 'local' && groups[defaultGroupKey];

        source = 'default';
        localGroup = defaultIsLocal ? defaultGroupKey : '';
        localSeed = 1;
        select.value = DEFAULT_VALUE;
        ensureHidden('avatar_library_form_source', 'default');
        removeHidden('avatar_library_form_group');
        removeHidden('avatar_library_form_seed');
        seedInput.value = '1';

        if (defaultIsLocal) {
            renderLocalOptions(defaultGroupKey);
        } else {
            renderRemoteOptions();
            options.querySelectorAll('.avatar-option').forEach(x => x.classList.remove('active'));
        }
        setImages(String(cfg.dataset.avatarLibraryDefaultUrl || ''));
    } else {
        source = 'remote';
        const style = String(current.group || select.value || 'dylan');
        if (style && [...select.options].some(o => o.value === style)) select.value = style;
        const seed = Number(current.seed || seedInput.value || 1);
        seedInput.value = String(seed);
        ensureHidden('avatar_library_form_source', 'remote');
        ensureHidden('avatar_library_form_group', style || 'dylan');
        ensureHidden('avatar_library_form_seed', String(seed));
        renderRemoteOptions();
    }

    // 不再依赖额外 AJAX。
    // 核心 save_user() 只接受合法的远程 avatar_style；本地头像的真实来源
    // 由下面三个 hidden 字段保存，user.before_save 保留 fallback，
    // user.after_save 再把 local/group/seed 写入插件表。
    if (form) form.addEventListener('submit', event => {
        if (source === 'default') {
            // 当前仍是默认来源时，不需要提交一个不存在的“默认”option。
            // 核心字段使用后台默认对应的有效远程 fallback。
            ensureHidden('avatar_library_form_source', 'default');
            removeHidden('avatar_library_form_group');
            removeHidden('avatar_library_form_seed');
            if (defaultSource === 'remote' && [...select.options].some(o => o.value === defaultGroup)) {
                select.value = defaultGroup;
            } else if (defaultSource === 'local') {
                const fallback = String(current.group || 'dylan');
                if ([...select.options].some(o => o.value === fallback)) select.value = fallback;
                else select.value = 'dylan';
            }
            seedInput.value = '1';
            return;
        }
        if (source !== 'local' || !localGroup) return;

        setLocalFields(localGroup, localSeed);

        let fallback = String(current.group || '');
        if (!fallback || fallback.startsWith(LOCAL_PREFIX) || ![...select.options].some(o => o.value === fallback)) {
            fallback = defaultSource === 'remote' ? defaultGroup : 'dylan';
        }

        // 关键：POST 给核心的 avatar_style 永远不能是 __avatar_library_local__:*。
        // 只在提交瞬间替换，页面上的本地头像选择状态仍由插件变量维护。
        if (String(select.value || '').startsWith(LOCAL_PREFIX)) {
            select.value = fallback;
        }
    });

    // 上传头像功能保持原有能力。
    // 把自定义上传面板放进核心头像选择器的“修改”展开区域。
    // 这样它会跟随 data-profile-edit 的展开/收起状态显示。
    const uploadPanel = profileSlot.querySelector('[data-avatar-library-upload-panel]');
    const profileDetail = profileSlot.querySelector('[data-profile-edit]');
    if (uploadPanel && profileDetail) {
        profileDetail.appendChild(uploadPanel);
        uploadPanel.hidden = false;
    }

    const uploadInput = document.querySelector('[data-avatar-library-upload-input]');
    const deleteUpload = document.querySelector('[data-avatar-library-delete-upload]');
    const panel = document.querySelector('[data-avatar-library-upload-panel]');
    const modal = panel?.querySelector('[data-avatar-library-crop-modal]');
    const canvas = modal?.querySelector('[data-avatar-library-crop-canvas]');
    const zoom = modal?.querySelector('[data-avatar-library-crop-zoom]');
    const save = modal?.querySelector('[data-avatar-library-crop-save]');
    const status = panel?.querySelector('[data-avatar-library-status]');
    const ctx2d = canvas?.getContext('2d');
    let image=null, objectUrl='', scale=1, minScale=1, x=0, y=0, dragging=false, px=0, py=0;
    const setStatus = (text, error=false) => { if(status){status.textContent=text;status.classList.toggle('error',error);} };
    const clamp=()=>{if(!image||!canvas)return;x=Math.min(0,Math.max(canvas.width-image.naturalWidth*scale,x));y=Math.min(0,Math.max(canvas.height-image.naturalHeight*scale,y));};
    const draw=()=>{if(!ctx2d||!canvas||!image)return;clamp();ctx2d.clearRect(0,0,canvas.width,canvas.height);ctx2d.drawImage(image,x,y,image.naturalWidth*scale,image.naturalHeight*scale);};
    const closeCrop=()=>{if(modal)modal.hidden=true;if(uploadInput)uploadInput.value='';if(objectUrl)URL.revokeObjectURL(objectUrl);objectUrl='';image=null;};
    uploadInput?.addEventListener('change',()=>{const file=uploadInput.files?.[0];if(!file||!file.type.startsWith('image/'))return setStatus('请选择图片文件',true);if(file.size>10*1024*1024)return setStatus('原图不能超过10MB',true);objectUrl=URL.createObjectURL(file);const next=new Image();next.onload=()=>{image=next;minScale=Math.max(canvas.width/image.naturalWidth,canvas.height/image.naturalHeight);scale=minScale;x=(canvas.width-image.naturalWidth*scale)/2;y=(canvas.height-image.naturalHeight*scale)/2;zoom.value='100';draw();modal.hidden=false;};next.onerror=()=>{closeCrop();setStatus('图片读取失败',true)};next.src=objectUrl;});
    zoom?.addEventListener('input',()=>{if(!image)return;const old=scale;scale=minScale*Number(zoom.value||100)/100;const cx=canvas.width/2,cy=canvas.height/2;x=cx-(cx-x)*scale/old;y=cy-(cy-y)*scale/old;draw();});
    canvas?.addEventListener('pointerdown',e=>{if(!image)return;dragging=true;px=e.clientX;py=e.clientY;canvas.classList.add('dragging');canvas.setPointerCapture(e.pointerId);});
    canvas?.addEventListener('pointermove',e=>{if(!dragging)return;const ratio=canvas.width/canvas.getBoundingClientRect().width;x+=(e.clientX-px)*ratio;y+=(e.clientY-py)*ratio;px=e.clientX;py=e.clientY;draw();});
    const stopDrag=()=>{dragging=false;canvas?.classList.remove('dragging')};canvas?.addEventListener('pointerup',stopDrag);canvas?.addEventListener('pointercancel',stopDrag);
    modal?.querySelectorAll('[data-avatar-library-crop-close]').forEach(button=>button.addEventListener('click',closeCrop));
    save?.addEventListener('click',()=>{if(!image)return;const output=document.createElement('canvas');output.width=output.height=200;const out=output.getContext('2d');out.fillStyle='#fff';out.fillRect(0,0,200,200);out.drawImage(image,-x/scale,-y/scale,canvas.width/scale,canvas.height/scale,0,0,200,200);save.disabled=true;output.toBlob(async blob=>{try{if(!blob)throw new Error('头像生成失败');const body=new FormData();body.append('_csrf',form?.querySelector('input[name="_csrf"]')?.value||'');body.append('avatar_library_action','upload');body.append('avatar',blob,'avatar.jpg');const response=await fetch(route,{method:'POST',body,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});const data=await response.json();if(!data.ok)throw new Error(data.message||'头像上传失败');window.location.href=data.redirect||window.location.href}catch(error){setStatus(error?.message||'头像上传失败',true);closeCrop()}finally{save.disabled=false}},'image/jpeg',.9);});
    deleteUpload?.addEventListener('click',async()=>{deleteUpload.disabled=true;setStatus('正在恢复头像库…');try{const body=new FormData();body.append('_csrf',form?.querySelector('input[name="_csrf"]')?.value||'');body.append('avatar_library_action','delete_upload');const response=await fetch(route,{method:'POST',body,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});const data=await response.json();if(!data.ok)throw new Error(data.message||'恢复失败');window.location.href=data.redirect||window.location.href}catch(error){setStatus(error?.message||'恢复失败',true);deleteUpload.disabled=false}});




})();
/* daily_checkin */
(() => {
    const showAutoCheckinNotice = () => {
        const message = String(window.__pageFlash || '');
        if (!message.startsWith('您是') || !message.includes('已帮您完成自动签到')) return;
        const toast = document.getElementById('toast');
        if (!toast) return;
        toast.textContent = message;
        clearTimeout(window.__toastTimer);
        toast.hidden = false;
        window.__toastTimer = setTimeout(() => { toast.hidden = true; }, 6000);
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', showAutoCheckinNotice);
    else showAutoCheckinNotice();
})();
/* forum_chat_room */
(function () {
    'use strict';

    function chatMenuRotation() {
        var selector = [
            '[data-slot~="top.menu_links"] a[href*="/chat"]',
            '[data-slot~="top.menu_links"] a[href*="?route=chat"]',
            '.mobile-menu-links a[href*="/chat"]',
            '.mobile-menu-links a[href*="?route=chat"]',
            '.mobile-forum-strip a.chat-mobile-forum-link'
        ].join(',');

        var links = document.querySelectorAll(selector);
        for (var i = 0; i < links.length; i++) {
            var link = links[i];
            if (link.getAttribute('data-chat-menu-rotation') === '1') continue;
            link.setAttribute('data-chat-menu-rotation', '1');

            (function (target) {
                var labels = ['💬 聊天室', '🟢 在线聊天'];
                var index = 0;
                var timer = null;

                function lockWidth() {
                    if (!target || !labels.length || !document.body) return;
                    var maxWidth = 0;
                    var probe = target.cloneNode(false);
                    probe.removeAttribute('data-chat-menu-rotation');
                    probe.style.position = 'fixed';
                    probe.style.left = '-100000px';
                    probe.style.top = '0';
                    probe.style.visibility = 'hidden';
                    probe.style.width = 'auto';
                    probe.style.minWidth = '0';
                    probe.style.maxWidth = 'none';
                    probe.style.display = 'inline-flex';
                    probe.style.whiteSpace = 'nowrap';
                    document.body.appendChild(probe);
                    for (var i = 0; i < labels.length; i++) {
                        probe.textContent = labels[i];
                        maxWidth = Math.max(maxWidth, Math.ceil(probe.getBoundingClientRect().width));
                    }
                    probe.remove();
                    if (maxWidth > 0) target.style.setProperty('--chat-menu-width', maxWidth + 'px');
                }

                function rotate() {
                    if (!target || !target.isConnected) {
                        if (timer) window.clearInterval(timer);
                        return;
                    }

                    var label = target.querySelector('.chat-menu-label');
                    if (!label) {
                        label = document.createElement('span');
                        label.className = 'chat-menu-label';
                        label.textContent = target.textContent.trim() || labels[index];
                        target.textContent = '';
                        target.appendChild(label);
                    }
                    label.classList.add('chat-menu-label-rotate-out');

                    window.setTimeout(function () {
                        if (!target || !target.isConnected || !label) return;
                        index = (index + 1) % labels.length;
                        label.textContent = labels[index];
                        label.classList.remove('chat-menu-label-rotate-out');
                        label.classList.add('chat-menu-label-rotate-in');

                        window.setTimeout(function () {
                            if (label) label.classList.remove('chat-menu-label-rotate-in');
                        }, 220);
                    }, 120);
                }

                var initialLabel = target.querySelector('.chat-menu-label');
                if (!initialLabel) {
                    initialLabel = document.createElement('span');
                    initialLabel.className = 'chat-menu-label';
                    initialLabel.textContent = target.textContent.trim() || labels[0];
                    target.textContent = '';
                    target.appendChild(initialLabel);
                } else if (!initialLabel.textContent.trim()) {
                    initialLabel.textContent = labels[0];
                }
                lockWidth();
                timer = window.setInterval(rotate, 4000);

                target.addEventListener('mouseenter', function () {
                    if (timer) window.clearInterval(timer);
                    timer = null;
                });
            }(link));
        }
    }

    chatMenuRotation();

    function chatSetupMobileSwitch() {
        var nav = document.querySelector('[data-chat-mobile-switch="1"]');
        if (!nav || nav.getAttribute('data-chat-mobile-ready') === '1') return;
        nav.setAttribute('data-chat-mobile-ready','1');
        var isPrivate = !!document.querySelector('[data-chat-private-app="1"]');
        var publicLink = null;
        if (isPrivate) {
            var back = document.querySelector('.chat-back-link');
            publicLink = back ? back.getAttribute('href') : null;
        } else {
            var activeRoom = document.querySelector('.chat-room-link.is-active') || document.querySelector('.chat-room-link');
            publicLink = activeRoom ? activeRoom.getAttribute('href') : null;
        }
        var privateLink = null;
        if (!isPrivate) {
            var privateLinkElement = document.querySelector('.chat-private-link');
            privateLink = privateLinkElement ? privateLinkElement.getAttribute('href') : null;
            if (!privateLink) {
                var base = document.querySelector('[data-private-open-base]');
                if (base) privateLink = base.getAttribute('data-private-page-url') || null;
            }
        } else {
            privateLink = window.location.href;
        }
        nav.innerHTML = (publicLink ? '<a class="' + (!isPrivate ? 'is-active' : '') + '" href="' + escAttr(publicLink) + '">公共聊天室</a>' : '') + (privateLink ? '<a class="' + (isPrivate ? 'is-active' : '') + '" href="' + escAttr(privateLink) + '">个人聊天室</a>' : '');
    }
    function escAttr(value) { var div=document.createElement('div'); div.textContent=value==null?'':String(value); return div.innerHTML.replace(/"/g,'&quot;'); }

    var observer = new MutationObserver(function () {
        chatMenuRotation();
    });
    if (document.body) observer.observe(document.body, {childList: true, subtree: true});

    var app = document.querySelector('[data-chat-app="1"]');
    if (!app) { chatSetupMobileSwitch(); return; }

    chatSetupMobileSwitch();

    var roomId = Number(app.getAttribute('data-room-id') || 0);
    var streamUrl = app.getAttribute('data-stream-url') || '';
    var sendUrl = app.getAttribute('data-send-url') || '';
    var readUrl = app.getAttribute('data-read-url') || '';
    var historyUrl = app.getAttribute('data-history-url') || '';
    var deleteUrl = app.getAttribute('data-delete-url') || '';
    var presenceUrl = app.getAttribute('data-presence-url') || '';
    var privateOpenBase = app.getAttribute('data-private-open-base') || '';
    var csrf = app.getAttribute('data-csrf') || '';
    var loggedIn = app.getAttribute('data-logged-in') === '1';
    var canManage = app.getAttribute('data-can-manage') === '1';
    var messages = app.querySelector('[data-chat-messages]');
    var scroll = app.querySelector('[data-chat-scroll]');
    var form = app.querySelector('[data-chat-form]');
    var input = app.querySelector('[data-chat-input]');
    var sendButton = app.querySelector('[data-chat-send]');
    var status = app.querySelector('[data-chat-status]');
    var attachmentToggle = app.querySelector('[data-chat-attachment-toggle]');
    var attachmentPanel = app.querySelector('[data-chat-attachment-panel]');
    var userFilesToggle = app.querySelector('[data-chat-user-files-toggle]');
    var userFilesPanel = app.querySelector('[data-chat-user-files-panel]');
    var connection = app.querySelector('[data-chat-connection]');
    var online = app.querySelector('[data-chat-online]');
    var newMarker = app.querySelector('[data-chat-new]');
    var lastId = 0;
    var lastDeletedAt = 0;
    var lastDeletedId = 0;
    var source = null;
    var reconnectTimer = null;
    var pendingReadTimer = null;
    var loadingHistory = false;
    var hasMoreHistory = true;
    var user = {};

    try { user = JSON.parse(app.getAttribute('data-me') || '{}'); } catch (e) { user = {}; }

    function esc(s) {
        var div = document.createElement('div');
        div.textContent = s == null ? '' : String(s);
        return div.innerHTML;
    }

    function isNearBottom() {
        return scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 100;
    }

    function scrollBottom(force) {
        if (force || isNearBottom()) scroll.scrollTop = scroll.scrollHeight;
    }

    function insertText(field, text) {
        if (!field || !text) return;
        var start = typeof field.selectionStart === 'number' ? field.selectionStart : field.value.length;
        var end = typeof field.selectionEnd === 'number' ? field.selectionEnd : start;
        var prefix = start > 0 && !field.value.slice(0, start).endsWith('\n') ? '\n' : '';
        var suffix = end < field.value.length && !field.value.slice(end).startsWith('\n') ? '\n' : '';
        field.setRangeText(prefix + text + suffix, start, end, 'end');
        field.dispatchEvent(new Event('input', {bubbles: true}));
        field.focus();
    }

    function togglePanel(panel, button, show) {
        if (!panel) return;
        panel.classList.toggle('is-hidden', !show);
        if (button) button.setAttribute('aria-expanded', show ? 'true' : 'false');
    }

    function copyText(text, button) {
        if (!text) return;
        var done = function () {
            if (!button) return;
            var old = button.textContent;
            button.textContent = '已复制';
            window.setTimeout(function () { if (button && button.isConnected) button.textContent = old; }, 1200);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done).catch(function () {
                var field = document.createElement('textarea');
                field.value = text;
                field.style.position = 'fixed';
                field.style.left = '-10000px';
                document.body.appendChild(field);
                field.focus();
                field.select();
                try { document.execCommand('copy'); done(); } catch (e) {}
                field.remove();
            });
            return;
        }
        var field = document.createElement('textarea');
        field.value = text;
        field.style.position = 'fixed';
        field.style.left = '-10000px';
        document.body.appendChild(field);
        field.focus();
        field.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        field.remove();
    }

    function messageHtml(m) {
        var mine = m.mine || (user.id && Number(m.user_id) === Number(user.id));
        var cls = 'chat-message' + (mine ? ' is-mine' : '') + (m.deleted ? ' is-deleted' : '');
        var profile = m.profile_url || '#';
        var avatar = '<button type="button" class="chat-avatar chat-avatar-button" data-chat-avatar-user="' + Number(m.user_id || 0) + '" data-chat-avatar-profile="' + esc(profile) + '" aria-label="查看用户">' + (m.avatar_html || esc((m.username || '?').slice(0, 1).toUpperCase())) + '</button>';
        var author = '<a class="chat-author" href="' + esc(profile) + '">' + esc(m.username || '用户删除') + '</a>';
        var op = (!m.deleted && (mine || canManage)) ? '<button type="button" class="chat-message-delete" data-chat-delete="' + Number(m.id) + '">删除</button>' : '';
        return '<article class="' + cls + '" id="chat-message-' + Number(m.id) + '" data-message-id="' + Number(m.id) + '">' + avatar + '<div class="chat-message-body"><div class="chat-message-head">' + author + '<time>' + esc(m.time || '') + '</time>' + op + '</div>' + (m.html || '') + '</div></article>';
    }

    function appendMessage(m, forceScroll) {
        if (!m || !m.id) return;
        if (messages.querySelector('[data-message-id="' + Number(m.id) + '"]')) return;
        var wasBottom = isNearBottom();
        messages.insertAdjacentHTML('beforeend', messageHtml(m));
        lastId = Math.max(lastId, Number(m.id));
        if (forceScroll || wasBottom) scrollBottom(true);
        else if (newMarker) newMarker.classList.remove('is-hidden');
        scheduleRead();
    }

    function renderInitial(list) {
        messages.innerHTML = '';
        (Array.isArray(list) ? list : []).forEach(function (m) {
            messages.insertAdjacentHTML('beforeend', messageHtml(m));
            lastId = Math.max(lastId, Number(m.id || 0));
        });
        scrollBottom(true);
        scheduleRead();
    }

    function setConnected(ok) {
        if (connection) connection.classList.toggle('is-online', ok);
        if (status) status.textContent = ok ? '' : '正在重新连接……';
    }

    function closeStream() {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
        if (source) {
            try { source.close(); } catch (e) {}
            source = null;
        }
        setConnected(false);
    }

    function scheduleReconnect(delay) {
        if (document.visibilityState === 'hidden') return;
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(function () {
            reconnectTimer = null;
            connect();
        }, Math.max(250, Number(delay) || 1500));
    }

    function connect() {
        if (document.visibilityState === 'hidden') return;
        if (!window.EventSource || !streamUrl) {
            if (status) status.textContent = '当前浏览器不支持实时连接。';
            return;
        }
        if (source) return;
        var url = streamUrl + (streamUrl.indexOf('?') >= 0 ? '&' : '?') + 'after=' + encodeURIComponent(lastId);
        source = new EventSource(url, {withCredentials: true});
        source.addEventListener('open', function () { setConnected(true); });
        source.addEventListener('message', function (event) {
            try { appendMessage(JSON.parse(event.data), false); } catch (e) {}
        });
        source.addEventListener('delete', function (event) {
            try {
                var data = JSON.parse(event.data || '{}');
                var id = Number(data.id || 0);
                if (!id) return;
                var item = messages.querySelector('[data-message-id="' + id + '"]');
                if (!item) return;
                item.classList.add('is-deleted');
                var content = item.querySelector('.chat-message-content');
                if (content) content.outerHTML = '<div class="chat-deleted-message">这条消息已删除</div>';
                var button = item.querySelector('[data-chat-delete]');
                if (button) button.remove();
            } catch (e) {}
        });
        source.addEventListener('server_close', function (event) {
            var data = {};
            try { data = JSON.parse(event.data || '{}'); } catch (e) {}
            lastId = Math.max(lastId, Number(data.last_id || 0));
            var delay = Number(data.reconnect_delay || 1500);
            closeStream();
            scheduleReconnect(delay);
        });
        source.onerror = function () {
            setConnected(false);
            if (source) {
                try { source.close(); } catch (e) {}
                source = null;
            }
            scheduleReconnect(Number(app.getAttribute('data-sse-reconnect-delay') || 1500));
        };
    }

    function post(url, data) {
        var body = new URLSearchParams();
        body.set('_csrf', csrf);
        Object.keys(data || {}).forEach(function (key) { body.set(key, data[key]); });
        return fetch(url, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest'}, body: body.toString()}).then(function (response) {
            return response.json();
        });
    }

    var presenceTimer = null;
    var presenceInFlight = false;
    var presenceStarted = false;

    function updatePresence() {
        if (!loggedIn || !presenceUrl || !roomId || presenceInFlight || document.visibilityState === 'hidden') return;
        presenceInFlight = true;
        post(presenceUrl, {room_id: roomId, action: 'online'}).then(function (data) {
            if (online && data && typeof data.online !== 'undefined') online.textContent = Number(data.online || 0) + ' 人活跃';
        }).catch(function () {}).finally(function () {
            presenceInFlight = false;
        });
    }

    function markPresenceOffline() {
        if (!loggedIn || !presenceUrl || !roomId) return;
        var body = new URLSearchParams();
        body.set('_csrf', csrf);
        body.set('room_id', roomId);
        body.set('action', 'offline');
        if (navigator.sendBeacon) {
            try {
                navigator.sendBeacon(presenceUrl, body);
                return;
            } catch (e) {}
        }
        fetch(presenceUrl, {method: 'POST', credentials: 'same-origin', keepalive: true, headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest'}, body: body.toString()}).catch(function () {});
    }

    function startPresence() {
        if (!loggedIn || !presenceUrl || !roomId || presenceStarted) return;
        presenceStarted = true;
        updatePresence();
        if (presenceTimer) clearInterval(presenceTimer);
        var presenceSeconds = Number(app.getAttribute('data-presence-interval') || 10);
        if (!isFinite(presenceSeconds) || presenceSeconds < 5) presenceSeconds = 10;
        presenceTimer = setInterval(updatePresence, presenceSeconds * 1000);
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'visible') {
                updatePresence();
                connect();
            } else if (document.visibilityState === 'hidden') {
                markPresenceOffline();
                closeStream();
            }
        });
        window.addEventListener('pagehide', function () {
            markPresenceOffline();
            closeStream();
        });
        window.addEventListener('pageshow', function () {
            updatePresence();
            connect();
        });
    }

    function scheduleRead() {
        if (!loggedIn || !lastId || !isNearBottom()) return;
        clearTimeout(pendingReadTimer);
        pendingReadTimer = setTimeout(function () {
            if (!isNearBottom()) return;
            post(readUrl, {room_id: roomId, message_id: lastId}).catch(function () {});
        }, 350);
    }

    function prependMessages(list) {
        if (!Array.isArray(list) || !list.length) return;
        var previousHeight = scroll.scrollHeight;
        var previousTop = scroll.scrollTop;
        var holder = document.createElement('div');
        for (var i = 0; i < list.length; i++) {
            var item = list[i];
            if (!item || !item.id || messages.querySelector('[data-message-id="' + Number(item.id) + '"]')) continue;
            holder.insertAdjacentHTML('beforeend', messageHtml(item));
        }
        while (holder.lastChild) messages.insertBefore(holder.lastChild, messages.firstChild);
        scroll.scrollTop = scroll.scrollHeight - previousHeight + previousTop;
    }

    function loadHistory() {
        if (!historyUrl || loadingHistory || !hasMoreHistory) return;
        var first = messages.querySelector('[data-message-id]');
        var before = first ? Number(first.getAttribute('data-message-id') || 0) : lastId;
        if (!before) return;
        loadingHistory = true;
        if (status) status.textContent = '正在加载更早消息……';
        var url = historyUrl + (historyUrl.indexOf('?') >= 0 ? '&' : '?') + 'room=' + encodeURIComponent(roomId) + '&before=' + encodeURIComponent(before);
        fetch(url, {credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}})
            .then(function (response) { return response.json(); })
            .then(function (data) {
                if (!data || !data.ok) throw new Error((data && data.error) || '历史消息加载失败');
                prependMessages(data.messages || []);
                hasMoreHistory = !!data.has_more;
                if (status) status.textContent = hasMoreHistory ? '' : '已经到最早的消息了';
            })
            .catch(function (error) { if (status) status.textContent = error.message || '历史消息加载失败'; })
            .finally(function () { loadingHistory = false; });
    }

    if (form && input) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            if (sendButton.disabled) return;
            if (window.bbs1AttachmentUpload && typeof window.bbs1AttachmentUpload.isUploading === 'function' && window.bbs1AttachmentUpload.isUploading(form)) {
                if (status) status.textContent = '附件仍在上传，请稍候……';
                return;
            }
            if (window.bbs1AttachmentUpload && typeof window.bbs1AttachmentUpload.beforeSubmit === 'function') {
                window.bbs1AttachmentUpload.beforeSubmit(form);
            }
            var body = input.value.trim();
            if (!body) return;
            sendButton.disabled = true;
            if (status) status.textContent = '发送中……';
            post(sendUrl, {room_id: roomId, body: body}).then(function (data) {
                if (!data || !data.ok) throw new Error((data && data.error) || '发送失败');
                input.value = '';
                input.style.height = 'auto';
                appendMessage(data.message, true);
                if (status) status.textContent = '';
                var key = 'bbs1_attachment_upload_history_v1_chat_' + (user.id || 0);
                try { if (key && Number(user.id) > 0) localStorage.removeItem(key); } catch (e) {}
                if (attachmentPanel) attachmentPanel.classList.add('is-hidden');
                if (attachmentToggle) attachmentToggle.setAttribute('aria-expanded', 'false');
            }).catch(function (error) {
                if (status) status.textContent = error.message || '发送失败';
            }).finally(function () { sendButton.disabled = false; });
        });
        input.addEventListener('input', function () {
            input.style.height = 'auto';
            input.style.height = Math.min(input.scrollHeight, 140) + 'px';
        });
        input.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
                event.preventDefault();
                form.requestSubmit();
            }
        });
    }

    messages.addEventListener('click', function (event) {
        var button = event.target.closest('[data-chat-delete]');
        if (!button) return;
        var id = Number(button.getAttribute('data-chat-delete') || 0);
        if (!id || !window.confirm('确认删除这条消息吗？')) return;
        button.disabled = true;
        post(deleteUrl, {message_id: id}).then(function (data) {
            if (!data || !data.ok) throw new Error((data && data.error) || '删除失败');
            var item = messages.querySelector('[data-message-id="' + id + '"]');
            if (item) {
                item.classList.add('is-deleted');
                var content = item.querySelector('.chat-message-content');
                if (content) content.outerHTML = '<div class="chat-deleted-message">这条消息已删除</div>';
                button.remove();
            }
        }).catch(function (error) {
            button.disabled = false;
            if (status) status.textContent = error.message || '删除失败';
        });
    });

    if (attachmentToggle) {
        attachmentToggle.addEventListener('click', function () {
            var show = attachmentPanel && attachmentPanel.classList.contains('is-hidden');
            togglePanel(attachmentPanel, attachmentToggle, show);
            if (show) togglePanel(userFilesPanel, userFilesToggle, false);
        });
    }
    if (userFilesToggle) {
        userFilesToggle.addEventListener('click', function () {
            var show = userFilesPanel && userFilesPanel.classList.contains('is-hidden');
            togglePanel(userFilesPanel, userFilesToggle, show);
            if (show) togglePanel(attachmentPanel, attachmentToggle, false);
        });
    }
    app.addEventListener('click', function (event) {
        var button = event.target.closest('[data-chat-copy-insert-link]');
        if (!button) return;
        event.preventDefault();
        copyText(button.getAttribute('data-copy-text') || '', button);
    });
    scroll.addEventListener('scroll', function () {
        if (isNearBottom() && newMarker) newMarker.classList.add('is-hidden');
        if (scroll.scrollTop < 100) loadHistory();
        scheduleRead();
    });
    if (newMarker) newMarker.addEventListener('click', function () { scrollBottom(true); newMarker.classList.add('is-hidden'); });

    // 移动端聊天室是一个完整的视口应用：页面本身不滚动，只允许消息区滚动。
    // 同时锁定 html/body，避免聊天内容把整个论坛页面一起撑出滚动条。
    function setChatPageScrollLock(enabled) {
        var root = document.documentElement;
        var body = document.body;
        if (!root || !body) return;
        if (enabled) {
            root.classList.add('chat-active-page');
            body.classList.add('chat-active-page');
        } else {
            root.classList.remove('chat-active-page');
            body.classList.remove('chat-active-page');
        }
    }
    setChatPageScrollLock(true);

    function syncChatViewport() {
        var page = app;
        if (!page) return;
        var rect = page.getBoundingClientRect();
        var top = Math.max(0, rect.top);
        // 只在聊天室移动端布局下计算可视高度；优先使用 innerHeight，避免
        // visualViewport 在地址栏/窗口滚动变化时把聊天室高度重新算大。
        var viewport = window.innerHeight;
        var height = Math.max(320, viewport - top);
        page.style.setProperty('--chat-viewport-height', height + 'px');
        page.style.height = height + 'px';
    }

    function syncChatScrollMode() {
        setChatPageScrollLock(window.matchMedia && window.matchMedia('(max-width: 860px)').matches);
    }
    syncChatViewport();
    syncChatScrollMode();

    // 移动端输入区固定在浏览器窗口底部时，消息区需要预留它的实际高度。
    // 用 ResizeObserver 跟随 textarea 自动增高、附件工具/状态提示等变化，避免消息被输入区遮住。
    function syncChatComposerHeight() {
        if (!app || !(window.matchMedia && window.matchMedia('(max-width: 860px)').matches)) return;
        var composer = app.querySelector('.chat-composer-wrap');
        if (!composer) return;
        var height = Math.ceil(composer.getBoundingClientRect().height);
        if (height > 0) app.style.setProperty('--chat-composer-height', height + 'px');
    }
    syncChatComposerHeight();
    if (window.ResizeObserver) {
        var chatComposerObserver = new ResizeObserver(syncChatComposerHeight);
        var chatComposer = app.querySelector('.chat-composer-wrap');
        if (chatComposer) chatComposerObserver.observe(chatComposer);
    }
    window.addEventListener('resize', syncChatComposerHeight);
    window.addEventListener('orientationchange', function () { setTimeout(syncChatComposerHeight, 50); });
    window.addEventListener('resize', syncChatViewport);
    window.addEventListener('resize', syncChatScrollMode);
    // 不监听 visualViewport.scroll：聊天室禁止页面滚动，避免浏览器 UI/地址栏变化
    // 被误判为页面滚动后重新放大 chat-page 高度。

    var initial = [];
    // 初始消息由页面内联数据提供，避免首次打开聊天室再等待一个 SSE 周期。
    try { initial = JSON.parse(app.getAttribute('data-initial') || '[]'); } catch (e) { initial = []; }
    renderInitial(initial);
    startPresence();
    connect();

    /* 头像菜单仅绑定当前 .chat-page，不修改论坛全局头像行为。 */
    var chatAvatarMenu = null;
    function closeChatAvatarMenu() {
        if (chatAvatarMenu) { chatAvatarMenu.remove(); chatAvatarMenu = null; }
    }
    function showChatAvatarMenu(button, clickEvent) {
        closeChatAvatarMenu();
        var userId = Number(button.getAttribute('data-chat-avatar-user') || 0);
        var profileUrl = button.getAttribute('data-chat-avatar-profile') || ''; if (!profileUrl) { var base = app.getAttribute('data-chat-profile-base') || ''; if (base) profileUrl = base + (base.indexOf('?') >= 0 ? '&' : '?') + 'id=' + encodeURIComponent(userId); }
        if (!userId) return;
        var menu = document.createElement('div');
        menu.className = 'chat-avatar-action-menu chat-public-avatar-action-menu';
        menu.innerHTML = '<a href="' + esc(profileUrl) + '" class="chat-avatar-action-item">个人信息</a><button type="button" class="chat-avatar-action-item" data-chat-avatar-private>私信TA</button>';
        document.body.appendChild(menu);
        chatAvatarMenu = menu;
        /* 公共聊天室菜单必须依据头像的真实视口坐标定位。若按钮的布局坐标暂时为 0，则退回点击坐标，避免菜单落到左上角。 */
        menu.style.position = 'fixed';
        var rect = button.getBoundingClientRect();
        var hasRect = rect && rect.width > 0 && rect.height > 0 && isFinite(rect.left) && isFinite(rect.top);
        var anchorX = hasRect ? rect.right : ((clickEvent && isFinite(clickEvent.clientX)) ? clickEvent.clientX : 12);
        var anchorY = hasRect ? rect.top : ((clickEvent && isFinite(clickEvent.clientY)) ? clickEvent.clientY : 12);
        var anchorLeft = hasRect ? rect.left : anchorX;
        var anchorBottom = hasRect ? rect.bottom : anchorY + 1;
        var gap = 8;
        var menuWidth = menu.offsetWidth || 136;
        var menuHeight = menu.offsetHeight || 80;
        var left = anchorX + gap;
        if (left + menuWidth > window.innerWidth - 8) left = anchorLeft - menuWidth - gap;
        left = Math.max(8, Math.min(left, Math.max(8, window.innerWidth - menuWidth - 8)));
        var top = anchorY;
        if (top + menuHeight > window.innerHeight - 8) top = anchorBottom - menuHeight;
        top = Math.max(8, Math.min(top, Math.max(8, window.innerHeight - menuHeight - 8)));
        menu.classList.toggle('is-left', left < anchorLeft);
        menu.style.left = Math.round(left) + 'px';
        menu.style.top = Math.round(top) + 'px';
        var privateButton = menu.querySelector('[data-chat-avatar-private]');
        if (privateButton) privateButton.addEventListener('click', function () {
            post(privateOpenBase, {user:userId}).then(function(r){ window.location.href = r.redirect; }).catch(function(e){
                closeChatAvatarMenu();
                if (status) status.textContent = e.message || '私聊创建失败';
            });
        });
        window.setTimeout(function(){
            document.addEventListener('click', function outside(ev){
                if (!chatAvatarMenu || chatAvatarMenu.contains(ev.target) || button.contains(ev.target)) return;
                closeChatAvatarMenu();
                document.removeEventListener('click', outside);
            }, {once:true});
        }, 0);
    }
    app.addEventListener('click', function(event){
        var avatarButton = event.target.closest('[data-chat-avatar-user]');
        if (avatarButton && app.contains(avatarButton)) {
            event.preventDefault(); event.stopPropagation(); showChatAvatarMenu(avatarButton, event);
        }
    });
    window.addEventListener('resize', closeChatAvatarMenu);
    window.addEventListener('scroll', closeChatAvatarMenu, true);
}());
(function(){
'use strict';
var app=document.querySelector('[data-chat-private-app=\"1\"]');
if(!app)return;
var messages=app.querySelector('[data-chat-private-messages]'),scroll=app.querySelector('[data-chat-private-scroll]'),form=app.querySelector('[data-chat-private-form]'),input=app.querySelector('[data-chat-private-input]'),send=app.querySelector('[data-chat-private-send]'),status=app.querySelector('[data-chat-private-status]'),dot=app.querySelector('[data-chat-private-connection]'),selfStatus=app.querySelector('[data-chat-private-self-status]'),otherDot=app.querySelector('[data-chat-private-other-connection]'),otherStatus=app.querySelector('[data-chat-private-other-status]'),newMarker=app.querySelector('[data-chat-private-new]');
var streamUrl=app.getAttribute('data-private-stream-url')||'',sendUrl=app.getAttribute('data-private-send-url')||'',readUrl=app.getAttribute('data-private-read-url')||'',deleteUrl=app.getAttribute('data-private-delete-url')||'',presenceUrl=app.getAttribute('data-private-presence-url')||'',csrf=app.getAttribute('data-csrf')||'',conversationId=Number(app.getAttribute('data-conversation-id')||0),lastId=0,source=null,reconnectTimer=null,presenceTimer=null,presenceStarted=false,loading=false;
function esc(s){return String(s==null?'':s).replace(/[&<>\"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c];});}
function nearBottom(){return scroll.scrollHeight-scroll.scrollTop-scroll.clientHeight<80;}
function bottom(){scroll.scrollTop=scroll.scrollHeight;}

// 个人聊天室也使用公共聊天室相同的“视口锁定 + composer 实际高度让位”机制。
// 关键点：个人页自己的运行时必须单独测量 composer，因为公共聊天室运行时不会接管它。
function setPrivatePageScrollLock(enabled){
    var root=document.documentElement,body=document.body;
    if(!root||!body)return;
    if(enabled){root.classList.add('chat-active-page');body.classList.add('chat-active-page');}
    else{root.classList.remove('chat-active-page');body.classList.remove('chat-active-page');}
}
function syncPrivateViewport(){
    if(!(window.matchMedia&&window.matchMedia('(max-width:860px)').matches))return;
    var rect=app.getBoundingClientRect();
    var top=Math.max(0,rect.top);
    var height=Math.max(320,window.innerHeight-top);
    app.style.setProperty('--chat-viewport-height',height+'px');
    app.style.height=height+'px';
}
function syncPrivateComposerHeight(keepBottom){
    if(!(window.matchMedia&&window.matchMedia('(max-width:860px)').matches))return;
    var composer=app.querySelector('.chat-composer-wrap');
    if(!composer||!scroll)return;
    var wasNear=nearBottom();
    var height=Math.ceil(composer.getBoundingClientRect().height);
    if(height>0)app.style.setProperty('--chat-composer-height',height+'px');
    // composer 增高（例如附件工具栏出现）后，如果原本就在底部，立即把滚动位置跟到新的底部。
    // 如果用户正在看历史消息，则不强行跳到底部。
    if(keepBottom!==false&&wasNear)requestAnimationFrame(bottom);
}
setPrivatePageScrollLock(true);
syncPrivateViewport();
syncPrivateComposerHeight(false);
if(window.ResizeObserver){
    var privateComposerObserver=new ResizeObserver(function(){syncPrivateComposerHeight(true);});
    var privateComposer=app.querySelector('.chat-composer-wrap');
    if(privateComposer)privateComposerObserver.observe(privateComposer);
}
window.addEventListener('resize',syncPrivateViewport);
window.addEventListener('resize',function(){syncPrivateComposerHeight(true);});
window.addEventListener('orientationchange',function(){setTimeout(function(){syncPrivateViewport();syncPrivateComposerHeight(true);},50);});
function html(m){var mine=!!m.mine;var a='<button type=\"button\" class=\"chat-avatar chat-avatar-button\" data-chat-avatar-user=\"'+Number(m.user_id||0)+'\">'+(m.avatar_html||esc((m.username||'?').slice(0,1)))+'</button>';var op=(!m.deleted&&(mine))?'<button type=\"button\" class=\"chat-message-delete\" data-chat-private-delete=\"'+Number(m.id)+'\">删除</button>':'';return '<article class=\"chat-message'+(mine?' is-mine':'')+'\" data-message-id=\"'+Number(m.id)+'\">'+a+'<div class=\"chat-message-body\"><div class=\"chat-message-head\"><span class=\"chat-author\">'+esc(m.username||'用户')+'</span><time>'+esc(m.time||'')+'</time>'+op+'</div>'+(m.html||'')+'</div></article>'; }
function append(m,force){if(!m||!m.id||messages.querySelector('[data-message-id=\"'+Number(m.id)+'\"]'))return;var was=nearBottom();messages.insertAdjacentHTML('beforeend',html(m));lastId=Math.max(lastId,Number(m.id));if(force||was)bottom();else if(newMarker)newMarker.classList.remove('is-hidden');}
function render(list){messages.innerHTML='';(Array.isArray(list)?list:[]).forEach(function(m){append(m,false);});bottom();}
function post(url,data){var body=new URLSearchParams();Object.keys(data||{}).forEach(function(k){body.set(k,data[k]);});body.set('_csrf',csrf);return fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest'},body:body.toString()}).then(function(r){return r.text().then(function(text){var x=null;try{x=JSON.parse(text);}catch(e){throw new Error('服务器返回异常，请检查插件数据库或 PHP 错误日志');}if(!r.ok||!x||!x.ok)throw new Error((x&&x.error)||'请求失败');return x;});});}
function read(){if(lastId)post(readUrl,{conversation_id:conversationId,message_id:lastId}).catch(function(){});}
function setSelfStatus(online,label){if(dot)dot.classList.toggle('is-online',!!online);if(selfStatus)selfStatus.textContent='我：'+(label|| (online?'已连接':'未连接'));}
function setOtherStatus(online,label){if(otherDot)otherDot.classList.toggle('is-online',!!online);if(otherStatus)otherStatus.textContent='对方：'+(label|| (online?'在线':'离线'));}
function updatePrivatePresence(action){if(!presenceUrl||!conversationId)return Promise.resolve();return post(presenceUrl,{conversation_id:conversationId,action:action||'online'}).then(function(d){setOtherStatus(!!d.other_online);}).catch(function(){if(action!=='offline')setOtherStatus(false,'暂不可用');});}
function startPrivatePresence(){if(presenceStarted||!presenceUrl||!conversationId)return;presenceStarted=true;updatePrivatePresence('online');var seconds=Number(app.getAttribute('data-presence-interval')||10);if(!isFinite(seconds)||seconds<5)seconds=10;presenceTimer=setInterval(function(){if(document.hidden)return;updatePrivatePresence('online');},seconds*1000);}
function stopPrivatePresence(){presenceStarted=false;if(presenceTimer){clearInterval(presenceTimer);presenceTimer=null;}if(!presenceUrl||!conversationId)return;var body=new URLSearchParams();body.set('conversation_id',String(conversationId));body.set('action','offline');body.set('_csrf',csrf);try{if(navigator.sendBeacon)navigator.sendBeacon(presenceUrl,body);else fetch(presenceUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString(),keepalive:true}).catch(function(){});}catch(e){}}
function connect(){if(document.hidden)return;if(source)return;var sep=streamUrl.indexOf('?')>=0?'&':'?';source=new EventSource(streamUrl+sep+'after='+encodeURIComponent(lastId),{withCredentials:true});source.addEventListener('open',function(){setSelfStatus(true,'已连接');});source.addEventListener('message',function(e){try{append(JSON.parse(e.data),false);read();}catch(x){}});source.addEventListener('server_close',function(e){var d={};try{d=JSON.parse(e.data||'{}');}catch(x){};lastId=Math.max(lastId,Number(d.last_id||0));if(source)source.close();source=null;setSelfStatus(false,'准备重连');var delay=Number(d.reconnect_delay||1500);clearTimeout(reconnectTimer);reconnectTimer=setTimeout(connect,delay);});source.onerror=function(){setSelfStatus(false,'连接断开');if(source)source.close();source=null;clearTimeout(reconnectTimer);reconnectTimer=setTimeout(connect,Number(app.getAttribute('data-sse-reconnect-delay')||1500));};}
if(form)form.addEventListener('submit',function(e){e.preventDefault();var body=(input.value||'').trim();if(!body||!send||send.disabled)return;send.disabled=true;post(sendUrl,{conversation_id:conversationId,body:body}).then(function(d){input.value='';if(d.message)append(d.message,true);read();}).catch(function(e){if(status)status.textContent=e.message||'发送失败';}).finally(function(){send.disabled=false;input.focus();});});
if(input)input.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();if(form)form.requestSubmit();}});
function showPrivateAvatarMenu(button){
    var old=document.querySelector('.chat-avatar-action-menu'); if(old) old.remove();
    var userId=Number(button.getAttribute('data-chat-avatar-user')||0); if(!userId)return;
    var profileBase=app.getAttribute('data-chat-profile-base')||'';
    var profileUrl=profileBase?profileBase+(profileBase.indexOf('?')>=0?'&':'?')+'id='+encodeURIComponent(userId):'#';
    var menu=document.createElement('div'); menu.className='chat-avatar-action-menu chat-private-avatar-action-menu';
    /* 个人聊天室中只保留“个人信息”，不再提供对当前私聊对象再次私信。 */
    menu.innerHTML='<a href="'+esc(profileUrl)+'" class="chat-avatar-action-item">个人信息</a>';
    document.body.appendChild(menu);
    menu.style.position='fixed';
    var rect=button.getBoundingClientRect(), gap=8, menuWidth=menu.offsetWidth, menuHeight=menu.offsetHeight;
    var left=rect.right+gap;
    if(left+menuWidth>window.innerWidth-8)left=rect.left-menuWidth-gap;
    left=Math.max(8,Math.min(left,window.innerWidth-menuWidth-8));
    var top=rect.top;
    if(top+menuHeight>window.innerHeight-8)top=rect.bottom-menuHeight;
    top=Math.max(8,Math.min(top,window.innerHeight-menuHeight-8));
    menu.style.left=Math.round(left)+'px'; menu.style.top=Math.round(top)+'px';
    window.setTimeout(function(){document.addEventListener('click',function outside(ev){if(menu.contains(ev.target)||button.contains(ev.target))return;menu.remove();document.removeEventListener('click',outside);},{once:true});},0);
}
app.addEventListener('click',function(event){
    var avatarButton=event.target.closest('[data-chat-avatar-user]');
    if(avatarButton && app.contains(avatarButton)){
        event.preventDefault(); event.stopPropagation(); showPrivateAvatarMenu(avatarButton);
    }
});
function togglePanel(button,panel){var show=panel.classList.contains('is-hidden');panel.classList.toggle('is-hidden',!show);button.setAttribute('aria-expanded',show?'true':'false');}
var pa=app.querySelector('[data-chat-private-attachment-toggle]'),pap=app.querySelector('[data-chat-private-attachment-panel]');
if(pa&&pap)pa.addEventListener('click',function(){togglePanel(pa,pap);});
var pf=app.querySelector('[data-chat-private-files-toggle]'),pfp=app.querySelector('[data-chat-private-files-panel]');
if(pf&&pfp)pf.addEventListener('click',function(){togglePanel(pf,pfp);});
if(newMarker)newMarker.addEventListener('click',function(){bottom();newMarker.classList.add('is-hidden');});
var initial=[];try{initial=JSON.parse(app.getAttribute('data-initial')||'[]');}catch(e){}render(initial);read();startPrivatePresence();connect();
if(document.addEventListener){document.addEventListener('visibilitychange',function(){if(document.hidden){stopPrivatePresence();if(source){source.close();source=null;}setSelfStatus(false,'后台暂停');}else{startPrivatePresence();connect();}});}
window.addEventListener('pagehide',function(){stopPrivatePresence();if(source){source.close();source=null;}});
window.addEventListener('pageshow',function(){startPrivatePresence();connect();});
}());
/* md_video */
(function(){
    const VIDEO_MARK = "![video](";
    
    function md_video_insert(textarea, text) {
        const s = textarea.selectionStart, e = textarea.selectionEnd;
        const before = textarea.value.substring(0, s);
        const after = textarea.value.substring(e);
        const prefix = before && !before.endsWith("\n") ? "\n" : "";
        const suffix = after && !after.startsWith("\n") ? "\n" : "";
        textarea.value = before + prefix + text + suffix + after;
        const pos = s + prefix.length + text.length + suffix.length;
        textarea.selectionStart = textarea.selectionEnd = pos;
        textarea.dispatchEvent(new Event("input", {bubbles: true}));
    }
    
    function md_video_isVideo(file) {
        return file && file.type && file.type.startsWith("video/");
    }
    
    function md_video_upload(file, textarea) {
        const form = textarea.closest("form");
        const csrf = form?.querySelector("input[name=_csrf]")?.value || "";
        const fd = new FormData();
        fd.append("video", file);
        fd.append("_csrf", csrf);
        
        const toast = document.getElementById("toast");
        if (toast) { toast.textContent = "视频上传中…"; toast.hidden = false; }
        
        fetch("/index.php?a=md_video_upload", {
            method: "POST",
            body: fd,
            headers: {"X-Requested-With": "XMLHttpRequest"}
        })
        .then(r => r.json())
        .then(data => {
            if (toast) toast.hidden = true;
            if (data.ok && data.url) {
                md_video_insert(textarea, VIDEO_MARK + data.url + ")");
                if (typeof showToast === "function") showToast("视频已插入");
            } else {
                if (typeof showToast === "function") showToast(data.message || "上传失败");
            }
        })
        .catch(() => {
            if (toast) toast.hidden = true;
            if (typeof showToast === "function") showToast("上传失败");
        });
    }
    
    document.addEventListener("paste", function(e) {
        const t = e.target.closest("textarea[name=body]");
        if (!t) return;
        const items = e.clipboardData?.items;
        if (!items) return;
        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            if (item.kind === "file" && md_video_isVideo(item.getAsFile())) {
                e.preventDefault();
                md_video_upload(item.getAsFile(), t);
                return;
            }
        }
    });

    document.addEventListener("dragover", function(e) {
        const t = e.target.closest("textarea[name=body]");
        if (!t) return;
        const hasFiles = e.dataTransfer?.types?.includes("Files");
        if (!hasFiles) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
    }, true);

    document.addEventListener("drop", function(e) {
        const t = e.target.closest("textarea[name=body]");
        if (!t) return;
        const files = e.dataTransfer?.files;
        if (!files || files.length === 0) return;
        const file = files[0];
        if (md_video_isVideo(file)) {
            e.preventDefault();
            e.stopPropagation();
            md_video_upload(file, t);
            if (typeof showToast === "function") {
                showToast("视频上传中...");
            }
        }
    }, true);
})();
/* message_bubbles */
(function () {
    'use strict';

    function message_bubbles_root() {
        return document.querySelector('.message-bubbles-page-root');
    }

    function message_bubbles_entries(root) {
        if (!root) return [];
        return Array.from(root.querySelectorAll('.message-bubbles-entry'));
    }

    function message_bubbles_find_reference_target(root, entry) {
        const floor = entry.getAttribute('data-message-bubbles-reference-floor') || '';
        if (!/^\d+$/.test(floor) || Number(floor) < 1) return null;
        return root.querySelector('.message-bubbles-entry[data-floor="' + floor + '"]');
    }

    function message_bubbles_mark_groups(root) {
        const entries = message_bubbles_entries(root);
        entries.forEach(function (entry) {
            entry.classList.remove('message-bubbles-group-first', 'message-bubbles-group-middle', 'message-bubbles-group-last', 'message-bubbles-group-single');
        });
        entries.forEach(function (entry, index) {
            const host = entry.querySelector('.message-bubbles-content');
            if (!host) return;
            // 主题首帖是独立视觉单元，绝不能和第一条回复合并。
            if (entry.classList.contains('message-bubbles-topic')) return;
            const merge = entry.classList.contains('message-bubbles-merge-enabled') || host.classList.contains('message-bubbles-merge-enabled');
            if (!merge) return;
            const previous = entries[index - 1];
            const next = entries[index + 1];
            const user = entry.getAttribute('data-message-bubbles-user') || '';
            const time = Number(entry.getAttribute('data-message-bubbles-time') || 0);
            const windowSeconds = Number(host.getAttribute('data-message-bubbles-merge-window') || 10) * 60;
            const same = function (other) {
                if (!other || !time) return false;
                return other.getAttribute('data-message-bubbles-user') === user && Math.abs(Number(other.getAttribute('data-message-bubbles-time') || 0) - time) <= windowSeconds;
            };
            const prev = same(previous);
            const nextMatch = same(next);
            if (prev && nextMatch) entry.classList.add('message-bubbles-group-middle');
            else if (prev) entry.classList.add('message-bubbles-group-last');
            else if (nextMatch) entry.classList.add('message-bubbles-group-first');
            else entry.classList.add('message-bubbles-group-single');
        });
    }

    function message_bubbles_prepare_reference_markers(root) {
        message_bubbles_entries(root).forEach(function (entry) {
            const ref = entry.querySelector('.message-bubbles-reference-link');
            if (!ref) return;
            const floor = entry.getAttribute('data-message-bubbles-reference-floor') || ref.getAttribute('data-message-bubbles-reference-floor') || '';
            if (!/^\d+$/.test(floor) || Number(floor) < 1) return;
            const target = message_bubbles_find_reference_target(root, entry);
            const linkEnabled = entry.getAttribute('data-message-bubbles-reference-link') !== '0';
            ref.classList.toggle('is-clickable', !!target && linkEnabled);
            ref.setAttribute('aria-label', '引用 ' + ref.textContent.trim());
            if (target && linkEnabled) {
                ref.title = '查看 #' + floor;
                if (ref.dataset.messageBubblesBound !== '1') {
                    ref.dataset.messageBubblesBound = '1';
                    ref.addEventListener('click', function (event) {
                        event.preventDefault();
                        target.classList.add('message-bubbles-reference-target');
                        target.scrollIntoView({behavior: 'smooth', block: 'center'});
                        window.setTimeout(function () { target.classList.remove('message-bubbles-reference-target'); }, 1200);
                    });
                }
            } else {
                ref.title = '引用 #' + floor;
            }
        });
    }

    function message_bubbles_draw_relations(root) {
        if (!root) return;
        const entries = message_bubbles_entries(root);
        const enabled = entries.some(function (entry) { return entry.classList.contains('message-bubbles-conversation-enabled'); });
        let svg = root.querySelector('.message-bubbles-relation-svg');
        if (!enabled) {
            if (svg) svg.remove();
            return;
        }
        if (!svg) {
            svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.classList.add('message-bubbles-relation-svg');
            svg.setAttribute('aria-hidden', 'true');
            root.insertBefore(svg, root.firstChild);
        }
        while (svg.firstChild) svg.removeChild(svg.firstChild);
        const rootRect = root.getBoundingClientRect();
        svg.setAttribute('width', String(Math.max(root.scrollWidth, root.clientWidth)));
        svg.setAttribute('height', String(Math.max(root.scrollHeight, root.clientHeight)));
        entries.forEach(function (entry) {
            if (!entry.classList.contains('message-bubbles-conversation-enabled')) return;
            const host = entry.querySelector('.message-bubbles-content');
            const target = message_bubbles_find_reference_target(root, entry);
            if (!host || !target || target === entry) return;
            const targetHost = target.querySelector('.message-bubbles-content');
            if (!targetHost) return;
            const a = targetHost.getBoundingClientRect();
            const b = host.getBoundingClientRect();
            const ax = a.left - rootRect.left;
            const ay = a.top - rootRect.top + a.height / 2;
            const bx = b.left - rootRect.left;
            const by = b.top - rootRect.top + Math.min(28, b.height / 2);
            const gutter = Math.max(8, Math.min(ax, bx) - 14);
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            path.classList.add('message-bubbles-relation-path');
            const style = host.getAttribute('data-message-bubbles-line-style') || 'curve';
            let d = 'M ' + ax + ' ' + ay + ' C ' + gutter + ' ' + ay + ', ' + gutter + ' ' + by + ', ' + bx + ' ' + by;
            if (style === 'straight') d = 'M ' + ax + ' ' + ay + ' L ' + gutter + ' ' + ay + ' L ' + gutter + ' ' + by + ' L ' + bx + ' ' + by;
            if (style === 'dot') path.classList.add('is-dashed');
            path.setAttribute('d', d);
            svg.appendChild(path);
            const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            dot.classList.add('message-bubbles-relation-dot');
            dot.setAttribute('cx', String(bx));
            dot.setAttribute('cy', String(by));
            dot.setAttribute('r', '2.5');
            svg.appendChild(dot);
        });
    }

    function message_bubbles_prepare_quotes(root) {
        root.querySelectorAll('.message-bubbles-content .message-bubbles-quote').forEach(function (quote) {
            if (quote.dataset.messageBubblesPrepared === '1') return;
            quote.dataset.messageBubblesPrepared = '1';
            const host = quote.closest('.message-bubbles-content');
            if (!host) return;
            const maxLines = Number(host.getAttribute('data-message-bubbles-quote-lines') || 0);
            if (!maxLines) return;
            const computed = window.getComputedStyle(quote);
            const lineHeight = parseFloat(computed.lineHeight);
            if (!lineHeight || quote.scrollHeight <= lineHeight * maxLines + 4) return;
            const body = document.createElement('div');
            body.className = 'message-bubbles-quote-body';
            while (quote.firstChild) body.appendChild(quote.firstChild);
            quote.appendChild(body);
            quote.classList.add('message-bubbles-quote-collapsible');
            quote.setAttribute('data-message-bubbles-expanded', '0');
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'message-bubbles-quote-toggle';
            button.setAttribute('aria-expanded', 'false');
            button.textContent = '展开引用';
            button.addEventListener('click', function () {
                const expanded = quote.getAttribute('data-message-bubbles-expanded') === '1';
                quote.setAttribute('data-message-bubbles-expanded', expanded ? '0' : '1');
                button.setAttribute('aria-expanded', expanded ? 'false' : 'true');
                button.textContent = expanded ? '展开引用' : '收起引用';
            });
            quote.appendChild(button);
        });
    }

    function message_bubbles_init() {
        const root = message_bubbles_root();
        if (!root) return;
        message_bubbles_mark_groups(root);
        message_bubbles_prepare_reference_markers(root);
        message_bubbles_prepare_quotes(root);
        message_bubbles_draw_relations(root);
        window.addEventListener('resize', function () { message_bubbles_draw_relations(root); });
        window.addEventListener('load', function () { message_bubbles_draw_relations(root); }, {once: true});
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', message_bubbles_init, {once: true});
    else message_bubbles_init();
}());
/* mp3_player */
(function(){
var prefix='mp3_player_';
function formatTime(value){value=Math.max(0,Math.floor(value||0));var minutes=Math.floor(value/60),seconds=value%60;return String(minutes).padStart(2,'0')+':'+String(seconds).padStart(2,'0')}
function readState(key){try{var value=localStorage.getItem(prefix+key);return value?JSON.parse(value):{}}catch(e){return {}}}
function writeState(key,state){try{localStorage.setItem(prefix+key,JSON.stringify(state))}catch(e){}}
function saveRemote(card,item,audio,state){if(card.dataset.userId!=='1')return;var data=new URLSearchParams();data.set('_csrf',card.dataset.csrf||'');data.set('topic_id',card.dataset.topicId||'0');data.set('attachment_file',item.dataset.attachmentFile||'');data.set('filename',item.dataset.filename||'音频附件.mp3');data.set('position',String(state.position||0));data.set('duration',String(state.duration||0));data.set('rate',String(state.rate||1));fetch(card.dataset.historyUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest'},body:data.toString(),keepalive:true}).catch(function(){})}
function mp3PlayerSetup(card){if(card.dataset.mp3Ready==='1')return;card.dataset.mp3Ready='1';var audio=card.querySelector('[data-mp3-audio]'),position=card.querySelector('[data-mp3-position]'),status=card.querySelector('[data-mp3-status]'),rate=card.querySelector('[data-mp3-rate]'),currentName=card.querySelector('[data-mp3-current-name]'),items=Array.from(card.querySelectorAll('[data-mp3-track]'));if(!audio||!items.length)return;var current=null,state={},currentIndex=0,lastSave=0,pendingPlay=false;
function mp3PlayerLoadState(item){var local=readState(item.dataset.trackKey),saved={position:Number(item.dataset.positionMs||0)/1000,duration:Number(item.dataset.durationMs||0)/1000,rate:Number(item.dataset.rateMilli||1000)/1000,completed:item.dataset.completed==='1'};if(local&&typeof local==='object'){if(local.position!=null)saved.position=Math.max(0,Number(local.position)||0);if(local.duration!=null)saved.duration=Math.max(0,Number(local.duration)||0);if(local.rate!=null)saved.rate=Math.min(2,Math.max(.5,Number(local.rate)||1));if(local.completed!=null)saved.completed=local.completed===true}return saved}
function mp3PlayerUpdateItem(item,itemState){var total=itemState.duration||0,currentValue=itemState.completed?total:itemState.position||0,percent=total?Math.min(100,Math.round(currentValue*100/total)):0,summary=itemState.completed?'已听完':currentValue>0?'已听 '+formatTime(currentValue)+(total?' / '+formatTime(total):''):'未播放';item.classList.toggle('is-current',item===current);item.querySelector('[data-mp3-track-summary]').textContent=summary;item.querySelector('[data-mp3-track-percent]').textContent=percent+'%';item.querySelector('[data-mp3-track-fill]').style.width=percent+'%'}
function mp3PlayerUpdate(){if(!current)return;var total=audio.duration||state.duration||0,currentValue=audio.currentTime||0;if(!audio.paused||currentValue>0)state.position=currentValue;state.duration=total;position.textContent=total?'已听 '+formatTime(currentValue)+' / '+formatTime(total):'准备播放';status.textContent=state.completed?'已听完':audio.paused?(currentValue>0?'已暂停':'未播放'):'播放中';mp3PlayerUpdateItem(current,state)}
function persist(remote){if(!current)return;state.position=state.completed?(audio.duration||state.duration||0):(audio.currentTime||0);state.duration=audio.duration||state.duration||0;state.rate=audio.playbackRate||state.rate||1;writeState(current.dataset.trackKey,state);mp3PlayerUpdateItem(current,state);if(remote)saveRemote(card,current,audio,state)}
function mp3PlayerSelect(index,autoplay){var item=items[index];if(!item)return;if(current&&current!==item)persist(true);current=item;currentIndex=index;state=mp3PlayerLoadState(item);pendingPlay=autoplay;currentName.textContent=item.querySelector('.mp3-player-track-copy strong').textContent;rate.value=String(state.rate);audio.src=item.dataset.streamUrl;audio.load();items.forEach(function(entry){mp3PlayerUpdateItem(entry,entry===item?state:mp3PlayerLoadState(entry))});mp3PlayerUpdate();}
audio.addEventListener('loadedmetadata',function(){state.duration=audio.duration||state.duration||0;if(state.completed){state.position=0;state.completed=false}else if(state.position>0)try{audio.currentTime=Math.min(state.position,Math.max(0,audio.duration-1))}catch(e){}mp3PlayerUpdate();if(pendingPlay){pendingPlay=false;var result=audio.play();if(result&&result.catch)result.catch(function(){})}});audio.addEventListener('timeupdate',function(){mp3PlayerUpdate();if(Date.now()-lastSave>2000){lastSave=Date.now();persist(false)}});audio.addEventListener('play',function(){state.completed=false;status.textContent='播放中';mp3PlayerUpdate()});audio.addEventListener('pause',function(){persist(true);mp3PlayerUpdate()});audio.addEventListener('ended',function(){state.completed=true;state.position=audio.duration||state.duration;writeState(current.dataset.trackKey,state);mp3PlayerUpdate();saveRemote(card,current,audio,state);if(items[currentIndex+1])mp3PlayerSelect(currentIndex+1,true)});audio.addEventListener('error',function(){status.textContent='音频加载失败'});rate.addEventListener('change',function(){audio.playbackRate=Number(rate.value)||1;state.rate=audio.playbackRate;writeState(current.dataset.trackKey,state);if(!audio.paused)saveRemote(card,current,audio,state);mp3PlayerUpdate()});items.forEach(function(item,index){item.addEventListener('click',function(){mp3PlayerSelect(index,true)})});mp3PlayerSelect(0,false)}
function mp3PlayerInit(){document.querySelectorAll('[data-mp3-player]').forEach(mp3PlayerSetup);document.querySelectorAll('[data-mp3-mp3PlayerSelect-all]').forEach(function(button){if(button.dataset.ready==='1')return;button.dataset.ready='1';button.addEventListener('click',function(){var boxes=document.querySelectorAll('.mp3-player-forum-option input[type="checkbox"]'),all=Array.from(boxes).some(function(box){return !box.checked});boxes.forEach(function(box){box.checked=all})})})}
function persistVisible(){document.querySelectorAll('[data-mp3-player]').forEach(function(card){var audio=card.querySelector('[data-mp3-audio]');if(audio&&!audio.paused)audio.dispatchEvent(new Event('pause'))})}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mp3PlayerInit);else mp3PlayerInit();document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')persistVisible()});window.addEventListener('beforeunload',persistVisible);
})();(function(){
function format(value){value=Math.max(0,Math.floor(value||0));return String(Math.floor(value/60)).padStart(2,'0')+':'+String(value%60).padStart(2,'0')}
function mp3PlayerControlsSetup(card){if(card.dataset.mp3ControlsReady==='1')return;card.dataset.mp3ControlsReady='1';var audio=card.querySelector('[data-mp3-audio]'),toggle=card.querySelector('[data-mp3-toggle]'),icon=card.querySelector('[data-mp3-play-icon]'),seek=card.querySelector('[data-mp3-seek]'),elapsed=card.querySelector('[data-mp3-elapsed]'),duration=card.querySelector('[data-mp3-duration]'),volume=card.querySelector('[data-mp3-volume]'),volumeControl=card.querySelector('.mp3-player-volume'),volumeToggle=card.querySelector('[data-mp3-volume-toggle]'),volumePanel=card.querySelector('[data-mp3-volume-panel]');if(!audio||!toggle||!seek)return;function mp3PlayerControlsUpdate(){var total=audio.duration||0,current=audio.currentTime||0,percent=total?Math.min(100,current*100/total):0;seek.disabled=!total;seek.value=total?String(Math.round(Math.min(total,current)*1000/total)):'0';seek.style.setProperty('--mp3-progress',percent+'%');card.classList.toggle('is-playing',!audio.paused);if(elapsed)elapsed.textContent=format(current);if(duration)duration.textContent=total?format(total):'--:--';if(icon)icon.innerHTML=audio.paused?'<path d="M8 5.5v13l10-6.5L8 5.5z"/>':'<path d="M7 5h3v14H7V5zm7 0h3v14h-3V5z"/>';toggle.setAttribute('aria-label',audio.paused?'播放':'暂停')}toggle.addEventListener('click',function(){if(audio.paused){var result=audio.play();if(result&&result.catch)result.catch(function(){})}else audio.pause()});seek.addEventListener('input',function(){if(audio.duration)audio.currentTime=Number(seek.value||0)*audio.duration/1000});if(volume){audio.volume=Number(volume.value||1);volume.addEventListener('input',function(){audio.volume=Number(volume.value||1)})}if(volumeToggle&&volumePanel&&volumeControl){volumeToggle.addEventListener('click',function(event){event.stopPropagation();volumePanel.hidden=!volumePanel.hidden;volumeToggle.setAttribute('aria-expanded',volumePanel.hidden?'false':'true')});document.addEventListener('click',function(event){if(!volumeControl.contains(event.target)){volumePanel.hidden=true;volumeToggle.setAttribute('aria-expanded','false')}})}['loadedmetadata','timeupdate','play','pause','ended','emptied'].forEach(function(name){audio.addEventListener(name,mp3PlayerControlsUpdate)});mp3PlayerControlsUpdate()}
function mp3PlayerControlsInit(){document.querySelectorAll('[data-mp3-player]').forEach(mp3PlayerControlsSetup)}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mp3PlayerControlsInit);else mp3PlayerControlsInit();
})();
/* nb_editor */
(function () {
    'use strict';
    if (window.__nbEditorReady) return;
    window.__nbEditorReady = true;

    var PACKS = [
        {
            name: '表情',
            items: [
                '😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '🙃', '😉', '😊',
                '😇', '🥰', '😍', '🤩', '😘', '😗', '😚', '😋', '😛', '😜', '🤪', '😝',
                '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄',
                '😬', '😌', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧',
                '🥵', '🥶', '😵', '🤯', '🤠', '🥳', '😎', '🤓', '🧐', '😕', '🙁', '😮',
                '😯', '😲', '🥺', '😦', '😨', '😰', '😥', '😢', '😭', '😱', '😖', '😣',
                '😞', '😓', '😩', '😫', '🥱', '😤', '😡', '😠', '🤬', '😈', '💀', '💩',
                '🤡', '👻', '👽', '🤖', '😺', '😹', '😻', '😼', '😽', '🙀', '😿', '😾'
            ]
        },
        {
            name: '手势',
            items: [
                '👍', '👎', '👌', '🤌', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆',
                '👇', '☝️', '✋', '🤚', '🖐️', '🖖', '👋', '🤝', '🙏', '💪', '🦾', '✍️',
                '💅', '👏', '🙌', '👐', '🤲', '👀', '🫶', '❤️', '🧡', '💛', '💚', '💙',
                '💜', '🤎', '🖤', '🤍', '💔', '❤️‍🔥', '💕', '💞', '💖', '💘', '💌', '💯'
            ]
        },
        {
            name: '符号',
            items: [
                '✨', '⭐', '🌟', '💫', '🔥', '💥', '💢', '💦', '💨', '🎉', '🎊', '🎁',
                '🏆', '🥇', '🎯', '🎈', '🎂', '🍰', '🍺', '🍻', '☕', '🍵', '🍎', '🍉',
                '🌹', '🌸', '🌻', '🍀', '🌈', '☀️', '⛅', '🌧️', '❄️', '⚡', '🌙', '🐶',
                '🐱', '🐼', '🐰', '🦊', '🐷', '🐔', '✅', '❌', '❗', '❓', '⚠️', '🔔',
                '💡', '📌', '🔍', '📖', '💰', '🎵', '🚀', '⏰', '🔗', '📎', '🛠️', '💻'
            ]
        },
        {
            name: '颜文字',
            type: 'text',
            items: [
                ['OωO', 'OwO'], ['|´・ω・)ノ', 'Hi'], ['ヾ(≧∇≦*)ゝ', '开心'], ['(☆ω☆)', '星星眼'],
                ['（╯‵□′）╯︵┴─┴', '掀桌'], ['￣﹃￣', '流口水'], ['(/ω＼)', '捂脸'], ['∠( ᐛ 」∠)＿', '给跪'],
                ['(๑•̀ㅁ•́ฅ)', '打招呼'], ['→_→', '斜眼'], ['୧(๑•̀⌄•́๑)૭', '加油'], ['٩(ˊᗜˋ*)و', '有木有'],
                ['(ノ°ο°)ノ', '前方高能'], ['(´இ皿இ｀)', '厚颜无耻'], ['⌇●﹏●⌇', '吓死宝宝'], ['(ฅ´ω`ฅ)', '已阅留爪'],
                ['(╯°A°)╯︵○○○', '去吧大师球'], ['φ(￣∇￣o)', '太萌惹'], ['ヾ(´･ ･｀｡)ノ"', '咦咦咦'], ['( ง ᵒ̌皿ᵒ̌)ง⁼³₌₃', '气呼呼'],
                ['(ó﹏ò｡)', '受到惊吓'], ['Σ(っ °Д °;)っ', '什么鬼'], ['( ,,´･ω･)ﾉ"(´っω･｀｡)', '摸摸头'], ['╮(╯▽╰)╭', '无奈'],
                ['o(*////▽////*)q', '脸红'], ['＞﹏＜', '委屈'], ['( ๑´•ω•) "(ㆆᴗㆆ)', '安慰'], ['(｡•ˇ‸ˇ•｡)', '不高兴']
            ]
        }
    ];

    var textareaOf = function (root) {
        var form = root.closest('form');
        return form ? form.querySelector('textarea[name="body"]') : null;
    };

    var fieldOf = function (root) {
        return root.parentElement && root.parentElement.matches('.nb-editor-field') ? root.parentElement : null;
    };

    var mount = function (root) {
        if (!root || !root.isConnected) return;
        var textarea = textareaOf(root);
        var label = textarea ? textarea.closest('label') : null;
        if (!label) return;
        var field = label.parentElement && label.parentElement.matches('.nb-editor-field') ? label.parentElement : null;
        if (!field) {
            field = document.createElement('div');
            field.className = 'nb-editor-field';
            label.before(field);
            field.appendChild(label);
        }
        if (root.parentElement !== field) field.appendChild(root);
        if (root.dataset.nbEditorDraft) offerDraft(root);
    };

    var dispatchInput = function (textarea) {
        textarea.dispatchEvent(new Event('input', {bubbles: true}));
    };

    var replaceRange = function (textarea, value, start, end, selectionStart, selectionEnd) {
        textarea.value = textarea.value.slice(0, start) + value + textarea.value.slice(end);
        textarea.focus();
        textarea.setSelectionRange(start + selectionStart, start + selectionEnd);
        dispatchInput(textarea);
    };

    var replaceSelection = function (textarea, value, selectionStart, selectionEnd) {
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        replaceRange(textarea, value, start, end, selectionStart, selectionEnd);
    };

    var selectedText = function (textarea) {
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        return textarea.value.slice(start, end);
    };

    var template = function (textarea, before, after, placeholder) {
        var content = selectedText(textarea) || placeholder;
        replaceSelection(textarea, before + content + after, before.length, before.length + content.length);
    };

    var linePrefix = function (textarea, prefix, placeholder, numbered) {
        var text = textarea.value;
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        // 行首标记要作用在整行上，光标停在行中间也不会把标记插进句子里。
        var lineStart = text.lastIndexOf('\n', start - 1) + 1;
        var lineEnd = text.indexOf('\n', end);
        if (lineEnd < 0) lineEnd = text.length;
        var content = text.slice(lineStart, lineEnd);
        if (content.trim() === '') content = placeholder;
        var lines = content.split('\n').map(function (line, index) {
            return numbered ? (index + 1) + '. ' + line : prefix + line;
        });
        var value = lines.join('\n');
        var head = numbered ? 3 : prefix.length;
        replaceRange(textarea, value, lineStart, lineEnd, head, value.length);
    };

    var insertBlock = function (textarea, block, selectionStart, selectionEnd) {
        var start = textarea.selectionStart || 0;
        var head = start > 0 && textarea.value[start - 1] !== '\n' ? '\n' : '';
        var value = head + block;
        replaceSelection(textarea, value, head.length + selectionStart, head.length + selectionEnd);
    };

    var dialogFinish = null;
    // 打开弹层时记住它对应的正文框：弹层开着时（焦点在弹层输入框）粘贴图片也能直接落到正文里。
    var lastDialogTextarea = null;

    var closeDialog = function (value) {
        var finish = dialogFinish;
        dialogFinish = null;
        var dialog = document.getElementById('notify-modal');
        var body = document.getElementById('notify-modal-body');
        if (dialog) dialog.hidden = true;
        if (body) body.innerHTML = '';
        if (finish) finish(value);
    };

    // 复用「附件上传」插件已有的上传通道，不另建端点，站点后台配置的类型与大小限制自动生效。
    var attachmentTarget = function (textarea) {
        var form = textarea ? textarea.closest('form') : null;
        var uploader = form ? form.querySelector('.attachment-uploader[data-upload-url]') : null;
        var input = uploader ? uploader.querySelector('[data-attachment-input]') : null;
        if (!uploader || !input || input.disabled) return null;
        return {uploader: uploader, input: input};
    };

    var markdownResult = function (markdown) {
        var text = String(markdown || '');
        var match = /\]\(([^)\s]+)/.exec(text);
        return {url: match ? match[1] : '', markdown: text, isImage: text.indexOf('!') === 0};
    };

    var uploadThroughAttachment = function (target, file) {
        return new Promise(function (resolve, reject) {
            var stamp = Date.now();
            var named = new File([file], file.name || ('image-' + stamp + '.png'), {
                type: file.type || 'image/png',
                lastModified: stamp
            });
            var key = [named.name, named.size, named.lastModified].join('\u001f');
            var transfer = new DataTransfer();
            transfer.items.add(named);
            var settled = false;
            var observer = null;
            var timer = 0;
            var finish = function (fn, value) {
                if (settled) return;
                settled = true;
                if (observer) observer.disconnect();
                clearTimeout(timer);
                fn(value);
            };
            var inspect = function () {
                var items = target.uploader.querySelectorAll('.attachment-upload-item');
                for (var i = 0; i < items.length; i++) {
                    if ((items[i].dataset.attachmentKey || '') !== key) continue;
                    var state = items[i].dataset.state || '';
                    if (state === 'success') {
                        var parsed = markdownResult(items[i].dataset.markdown);
                        parsed.item = items[i];
                        if (parsed.url) finish(resolve, parsed);
                        else finish(reject, new Error('missing-url'));
                        return true;
                    }
                    if (state === 'error') { finish(reject, new Error('upload-failed')); return true; }
                }
                return false;
            };
            observer = new MutationObserver(function () { inspect(); });
            observer.observe(target.uploader, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['data-state', 'data-markdown']
            });
            timer = setTimeout(function () { finish(reject, new Error('timeout')); }, 60000);
            target.input.files = transfer.files;
            target.input.dispatchEvent(new Event('change', {bubbles: true}));
            inspect();
        });
    };

    var releaseAttachment = function (item) {
        if (!item || !item.isConnected) return;
        var remove = item.querySelector('[data-attachment-remove]');
        if (remove) remove.click();
    };

    var imageUploadRow = function (textarea, urlInput, box) {
        var target = attachmentTarget(textarea);
        // 没装或没权限用附件上传时，不显示这一行。
        if (!target) return null;
        // 只有这张编辑区开了「粘贴图片自动上传」时，才提示也可以直接粘贴。
        var field = textarea.closest('.nb-editor-field');
        var root = field ? field.querySelector('.nb-editor') : null;
        var paste = !!(root && root.dataset.nbEditorPaste === '1');
        var row = document.createElement('div');
        row.className = 'nb-editor-upload';
        // 整个加号区域就是一个 label，点哪里都会触发文件选择。
        var pick = document.createElement('label');
        pick.className = 'nb-editor-upload-pick';
        var plus = document.createElement('span');
        plus.className = 'nb-editor-upload-plus';
        plus.setAttribute('aria-hidden', 'true');
        plus.textContent = '+';
        var tip = document.createElement('span');
        tip.className = 'nb-editor-upload-tip';
        tip.textContent = paste ? '点击加号上传本地图片，也可以在内容中直接粘贴图片' : '点击加号上传本地图片';
        var file = document.createElement('input');
        file.type = 'file';
        file.accept = 'image/*';
        file.hidden = true;
        var status = document.createElement('span');
        status.className = 'nb-editor-upload-status';
        pick.append(plus, tip, file);
        file.addEventListener('change', function () {
            var picked = file.files && file.files[0];
            if (!picked) return;
            status.textContent = '正在上传……';
            pick.classList.add('is-busy');
            uploadThroughAttachment(target, picked).then(function (result) {
                if (!result.isImage) {
                    // 附件插件没把它当图片（常见于站点 PHP 未启用 fileinfo），此时给出的是文件下载地址，插进正文也显示不出来。
                    status.textContent = '这个文件没有被识别为图片，无法作为图片插入';
                    return;
                }
                urlInput.value = result.url;
                releaseAttachment(result.item);
                // 上传成功直接提交表单：地址已自动填好，按“确定”的逻辑插入正文并关闭弹层，不再等用户手动确认。
                if (box && box.requestSubmit) box.requestSubmit();
                else status.textContent = '上传完成，可直接确定插入';
            }).catch(function (error) {
                status.textContent = error && error.message === 'timeout' ? '上传超时，请重试' : '上传失败，请换张图片试试';
            }).then(function () {
                pick.classList.remove('is-busy');
                file.value = '';
            });
        });
        row.append(pick, status);
        return row;
    };

    var openDialog = function (title, fields, decorate) {
        return new Promise(function (resolve) {
            var dialog = document.getElementById('notify-modal');
            var titleElement = document.getElementById('notify-modal-title');
            var body = document.getElementById('notify-modal-body');
            if (!dialog || !body) { resolve(null); return; }
            dialogFinish = resolve;
            if (titleElement) titleElement.textContent = title;
            body.innerHTML = '';
            var box = document.createElement('form');
            box.className = 'confirm-box';
            var inputs = {};
            fields.forEach(function (field) {
                var label = document.createElement('label');
                label.className = 'nb-editor-dialog-field';
                var caption = document.createElement('span');
                caption.textContent = field.label;
                var input = document.createElement('input');
                input.className = 'prompt-input';
                input.type = field.type || 'text';
                if (field.inputmode) input.inputMode = field.inputmode;
                input.value = field.value || '';
                input.autocomplete = 'off';
                inputs[field.name] = input;
                label.append(caption, input);
                box.appendChild(label);
            });
            if (decorate) decorate(box, inputs);
            var actions = document.createElement('div');
            actions.className = 'confirm-actions';
            var cancel = document.createElement('button');
            cancel.type = 'button';
            cancel.className = 'btn alt';
            cancel.textContent = '取消';
            var confirm = document.createElement('button');
            confirm.type = 'submit';
            confirm.textContent = '确定';
            cancel.addEventListener('click', function () { closeDialog(null); });
            box.addEventListener('submit', function (event) {
                event.preventDefault();
                var values = {};
                Object.keys(inputs).forEach(function (name) { values[name] = inputs[name].value; });
                closeDialog(values);
            });
            actions.append(cancel, confirm);
            box.appendChild(actions);
            body.appendChild(box);
            dialog.hidden = false;
            var first = inputs[fields[0].name];
            if (first) { first.focus(); first.select(); }
        });
    };

    var insertLink = function (textarea) {
        lastDialogTextarea = textarea;
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        var label = textarea.value.slice(start, end) || '链接文字';
        return openDialog('插入链接', [{name: 'url', label: '链接地址', type: 'text', inputmode: 'url', value: 'https://'}]).then(function (values) {
            if (!values) return;
            var target = String(values.url || '').trim();
            if (!target) return;
            replaceRange(textarea, '[' + label + '](' + target + ')', start, end, 1, 1 + label.length);
        });
    };

    var insertImage = function (textarea) {
        lastDialogTextarea = textarea;
        var start = textarea.selectionStart || 0;
        var end = textarea.selectionEnd || start;
        var selected = textarea.value.slice(start, end);
        return openDialog('插入图片', [
            {name: 'url', label: '图片地址', type: 'text', inputmode: 'url', value: 'https://'},
            {name: 'alt', label: '图片描述', value: selected || '图片描述'}
        ], function (box, inputs) {
            var row = imageUploadRow(textarea, inputs.url, box);
            // 上传是主要入口，放在弹层最前面，选完图地址自动填好，再补描述。
            if (row) box.insertBefore(row, box.firstChild);
        }).then(function (values) {
            if (!values) return;
            var target = String(values.url || '').trim();
            if (!target) return;
            var alt = String(values.alt || '').trim() || '图片';
            replaceRange(textarea, '![' + alt + '](' + target + ')', start, end, 2, 2 + alt.length);
        });
    };

    var buildPanel = function (root) {
        var panel = root.querySelector('.nb-editor-panel');
        if (panel) return panel;
        panel = document.createElement('div');
        panel.className = 'nb-editor-panel';
        panel.hidden = true;
        var title = document.createElement('div');
        title.className = 'nb-editor-panel-title';
        title.textContent = '点一下插入到正文';
        panel.appendChild(title);
        var lists = [];
        PACKS.forEach(function (pack, index) {
            var text = pack.type === 'text';
            var list = document.createElement('ul');
            list.className = 'nb-editor-items' + (text ? '' : ' nb-editor-items-emoji');
            list.hidden = index !== 0;
            pack.items.forEach(function (item) {
                var icon = text ? item[0] : item;
                var li = document.createElement('li');
                li.textContent = icon;
                li.title = text ? item[1] : icon;
                li.dataset.nbEditorInsert = icon;
                list.appendChild(li);
            });
            panel.appendChild(list);
            lists.push(list);
        });
        var tabs = document.createElement('div');
        tabs.className = 'nb-editor-tabs';
        PACKS.forEach(function (pack, index) {
            var tab = document.createElement('button');
            tab.type = 'button';
            tab.className = 'nb-editor-tab' + (index === 0 ? ' nb-editor-tab-active' : '');
            tab.textContent = pack.name;
            tab.addEventListener('click', function () {
                lists.forEach(function (list, i) { list.hidden = i !== index; });
                tabs.querySelectorAll('.nb-editor-tab').forEach(function (item, i) {
                    item.classList.toggle('nb-editor-tab-active', i === index);
                });
            });
            tabs.appendChild(tab);
        });
        panel.appendChild(tabs);
        root.appendChild(panel);
        return panel;
    };

    var openPanel = null;

    // 优先在工具栏上方弹出，上方放不下才翻到下方；始终夹在视口内。
    var layoutPanel = function () {
        if (!openPanel) return;
        var panel = openPanel.panel;
        var bar = openPanel.root.querySelector('.nb-editor-bar');
        if (!bar) return;
        var barRect = bar.getBoundingClientRect();
        var anchor = openPanel.button.getBoundingClientRect();
        var width = Math.min(360, Math.max(220, barRect.width));
        panel.style.width = width + 'px';
        var height = panel.offsetHeight;
        var left = Math.min(anchor.right - width, barRect.right - width);
        left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
        var above = barRect.top - height - 6;
        var top = above >= 8 ? above : Math.min(barRect.bottom + 6, window.innerHeight - height - 8);
        panel.style.left = Math.round(left) + 'px';
        panel.style.top = Math.round(Math.max(8, top)) + 'px';
    };

    var closePanels = function () {
        document.querySelectorAll('.nb-editor-panel').forEach(function (panel) { panel.hidden = true; });
        document.querySelectorAll('[data-nb-editor-emoji]').forEach(function (button) {
            button.classList.remove('nb-editor-btn-active');
        });
        openPanel = null;
    };

    window.addEventListener('resize', layoutPanel);
    window.addEventListener('scroll', layoutPanel, true);

    var previewBox = function (field) {
        var box = field.querySelector('.nb-editor-preview');
        if (box) return box;
        box = document.createElement('div');
        box.className = 'nb-editor-preview post-content';
        box.hidden = true;
        field.appendChild(box);
        return box;
    };

    // 缩进、无序标记、序号、序号后的分隔符、正文
    var LIST_RE = /^([ \t]*)(?:([-*])[ \t]+|(\d{1,9})([.)])[ \t]+)(.*)$/;

    var insideCodeFence = function (text, position) {
        var lines = text.slice(0, position).split('\n');
        var fences = 0;
        for (var i = 0; i < lines.length - 1; i++) {
            if (/^\s*```/.test(lines[i])) fences++;
        }
        return fences % 2 === 1;
    };

    var lineOffsets = function (lines) {
        var offsets = [];
        var position = 0;
        for (var i = 0; i < lines.length; i++) {
            offsets.push(position);
            position += lines[i].length + 1;
        }
        return offsets;
    };

    // 让光标所在的这一段有序列表在源码里也保持连续编号。
    var renumberOrderedList = function (textarea, caret) {
        var lines = textarea.value.split('\n');
        var offsets = lineOffsets(lines);
        var index = 0;
        for (var i = 0; i < lines.length; i++) {
            if (offsets[i] <= caret) index = i;
        }
        var current = LIST_RE.exec(lines[index]);
        if (!current || !current[3]) return caret;
        var start = index;
        var end = index;
        while (start > 0) {
            var above = LIST_RE.exec(lines[start - 1]);
            if (!above || !above[3]) break;
            start--;
        }
        while (end < lines.length - 1) {
            var below = LIST_RE.exec(lines[end + 1]);
            if (!below || !below[3]) break;
            end++;
        }
        var first = parseInt(LIST_RE.exec(lines[start])[3], 10);
        var delta = 0;
        var changed = false;
        for (var j = start; j <= end; j++) {
            var item = LIST_RE.exec(lines[j]);
            var next = item[1] + (first + j - start) + item[4] + ' ' + item[5];
            if (next === lines[j]) continue;
            if (offsets[j] < caret) delta += next.length - lines[j].length;
            lines[j] = next;
            changed = true;
        }
        if (!changed) return caret;
        textarea.value = lines.join('\n');
        return caret + delta;
    };

    var handleListEnter = function (event, textarea) {
        var start = textarea.selectionStart || 0;
        if (start !== (textarea.selectionEnd || start)) return;
        var value = textarea.value;
        if (insideCodeFence(value, start)) return;
        var lineStart = value.lastIndexOf('\n', start - 1) + 1;
        var lineEnd = value.indexOf('\n', start);
        if (lineEnd < 0) lineEnd = value.length;
        var line = value.slice(lineStart, lineEnd);
        var match = LIST_RE.exec(line);
        if (!match) return;
        // 光标还在标记里面时按普通换行处理。
        if (start < lineStart + (line.length - match[5].length)) return;
        event.preventDefault();
        if (match[5].trim() === '') {
            // 空列表项上回车表示结束这个列表。
            replaceRange(textarea, '', lineStart, lineEnd, 0, 0);
            return;
        }
        var marker = match[2] ? match[2] + ' ' : (parseInt(match[3], 10) + 1) + match[4] + ' ';
        var insert = '\n' + match[1] + marker;
        replaceRange(textarea, insert, start, start, insert.length, insert.length);
        if (!match[3]) return;
        var caret = renumberOrderedList(textarea, textarea.selectionStart || 0);
        textarea.setSelectionRange(caret, caret);
        dispatchInput(textarea);
    };

    var DRAFT_PREFIX = 'nb_editor:draft:v1:';
    var DRAFT_MAX = 200000;
    var draftTimers = new WeakMap();

    var draftStore = function () {
        try {
            var store = window.localStorage;
            if (!store) return null;
            var probe = DRAFT_PREFIX + 'probe';
            store.setItem(probe, '1');
            store.removeItem(probe);
            return store;
        } catch (error) {
            return null;
        }
    };

    var draftKey = function (root) {
        var scope = root.dataset.nbEditorDraft || '';
        return scope === '' ? '' : DRAFT_PREFIX + scope;
    };

    var draftMaxAge = function (root) {
        return Math.max(1, parseInt(root.dataset.nbEditorDraftDays || '7', 10) || 7) * 86400000;
    };

    // 顺手清掉过期草稿，避免 localStorage 里越攒越多。
    var pruneDrafts = function (store, maxAge, now) {
        var stale = [];
        for (var i = 0; i < store.length; i++) {
            var key = store.key(i);
            if (!key || key.indexOf(DRAFT_PREFIX) !== 0) continue;
            try {
                var saved = JSON.parse(store.getItem(key) || '{}');
                if (!saved.at || now - saved.at > maxAge) stale.push(key);
            } catch (error) {
                stale.push(key);
            }
        }
        stale.forEach(function (key) { store.removeItem(key); });
    };

    var dropDraft = function (root) {
        var store = draftStore();
        var key = draftKey(root);
        if (store && key) store.removeItem(key);
    };

    var saveDraft = function (root) {
        var store = draftStore();
        var key = draftKey(root);
        var textarea = textareaOf(root);
        if (!store || !key || !textarea) return;
        var text = textarea.value;
        if (text.trim() === '') { store.removeItem(key); return; }
        if (text.length > DRAFT_MAX) text = text.slice(0, DRAFT_MAX);
        var record = JSON.stringify({text: text, at: Date.now()});
        try {
            store.setItem(key, record);
        } catch (error) {
            // 配额不足时先清过期草稿再试一次，仍失败就放弃，不打扰用户。
            try {
                pruneDrafts(store, draftMaxAge(root), Date.now());
                store.setItem(key, record);
            } catch (retryError) {}
        }
    };

    var scheduleDraft = function (root) {
        clearTimeout(draftTimers.get(root));
        draftTimers.set(root, setTimeout(function () { saveDraft(root); }, 500));
    };

    var draftAge = function (at) {
        var minutes = Math.floor((Date.now() - at) / 60000);
        if (minutes < 1) return '刚刚';
        if (minutes < 60) return minutes + ' 分钟前';
        var hours = Math.floor(minutes / 60);
        if (hours < 24) return hours + ' 小时前';
        return Math.floor(hours / 24) + ' 天前';
    };

    var offerDraft = function (root) {
        var store = draftStore();
        var key = draftKey(root);
        var textarea = textareaOf(root);
        var field = fieldOf(root);
        if (!store || !key || !textarea || !field) return;
        pruneDrafts(store, draftMaxAge(root), Date.now());
        var raw = store.getItem(key);
        if (!raw) return;
        var saved;
        try { saved = JSON.parse(raw); } catch (error) { store.removeItem(key); return; }
        var text = typeof saved.text === 'string' ? saved.text : '';
        if (text === '' || text === textarea.value) return;
        if (field.querySelector('.nb-editor-draft')) return;
        var bar = document.createElement('div');
        bar.className = 'nb-editor-draft';
        var label = document.createElement('span');
        label.className = 'nb-editor-draft-text';
        label.textContent = '发现' + draftAge(saved.at || Date.now()) + '未发布的草稿';
        var restore = document.createElement('button');
        restore.type = 'button';
        restore.className = 'nb-editor-draft-action';
        restore.textContent = '恢复';
        var discard = document.createElement('button');
        discard.type = 'button';
        discard.className = 'nb-editor-draft-action';
        discard.textContent = '丢弃';
        restore.addEventListener('click', function () {
            textarea.value = text;
            bar.remove();
            textarea.focus();
            dispatchInput(textarea);
        });
        discard.addEventListener('click', function () {
            store.removeItem(key);
            bar.remove();
        });
        bar.append(label, restore, discard);
        root.after(bar);
    };

    var previewTimers = new WeakMap();
    var previewState = new WeakMap();

    var previewMessage = function (box, text) {
        box.innerHTML = '';
        var line = document.createElement('p');
        line.className = 'nb-editor-preview-empty';
        line.textContent = text;
        box.appendChild(line);
    };

    // 预览一律由服务端渲染，保证所见即所得的那一栏和发布后的正文完全一致。
    var renderPreview = function (root) {
        var field = fieldOf(root);
        var textarea = textareaOf(root);
        var url = root.dataset.nbEditorPreviewUrl || '';
        if (!field || !textarea || !url) return;
        var box = previewBox(field);
        if (box.hidden) return;
        var text = textarea.value;
        var state = previewState.get(field) || {};
        if (state.text === text) return;
        state.text = text;
        if (state.controller) state.controller.abort();
        state.controller = null;
        previewState.set(field, state);
        if (text.trim() === '') {
            previewMessage(box, '还没有内容，写点什么就会显示在这里。');
            return;
        }
        var controller = window.AbortController ? new AbortController() : null;
        state.controller = controller;
        if (box.childElementCount === 0) previewMessage(box, '正在生成预览……');
        var form = root.closest('form');
        var token = form ? form.querySelector('input[name="_csrf"]') : null;
        var data = new FormData();
        data.append('body', text);
        data.append('topic_id', root.dataset.nbEditorTopic || '0');
        if (token) data.append('_csrf', token.value);
        var options = {method: 'POST', body: data, credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}};
        if (controller) options.signal = controller.signal;
        fetch(url, options)
            .then(function (response) { return response.json(); })
            .then(function (result) {
                if (box.hidden || previewState.get(field) !== state || state.controller !== controller) return;
                if (result && result.ok) box.innerHTML = result.html || '';
                else previewMessage(box, (result && result.message) || '预览失败，请稍后再试。');
            })
            .catch(function (error) {
                if (error && error.name === 'AbortError') return;
                if (!box.hidden) previewMessage(box, '预览失败，请稍后再试。');
            });
    };

    var schedulePreview = function (root) {
        var field = fieldOf(root);
        if (!field) return;
        clearTimeout(previewTimers.get(field));
        previewTimers.set(field, setTimeout(function () { renderPreview(root); }, 400));
    };

    var togglePreview = function (root, button) {
        var field = fieldOf(root);
        var textarea = textareaOf(root);
        if (!field || !textarea || !root.dataset.nbEditorPreviewUrl) return;
        var box = previewBox(field);
        var on = box.hidden;
        box.hidden = !on;
        field.classList.toggle('nb-editor-live', on);
        if (button) button.classList.toggle('nb-editor-btn-active', on);
        clearTimeout(previewTimers.get(field));
        if (on) {
            previewState.delete(field);
            renderPreview(root);
        }
        textarea.focus();
    };

    var toggleFullscreen = function (root, button) {
        var field = fieldOf(root);
        if (!field) return;
        var on = field.classList.toggle('nb-editor-full');
        if (button) button.classList.toggle('nb-editor-btn-active', on);
        var textarea = textareaOf(root);
        if (textarea) textarea.focus();
    };

    var applyAction = function (action, root, button) {
        var textarea = textareaOf(root);
        if (action === 'preview') { togglePreview(root, button); return; }
        if (action === 'fullscreen') { toggleFullscreen(root, button); return; }
        if (!textarea) return;
        switch (action) {
            case 'bold': template(textarea, '**', '**', '粗体文字'); break;
            case 'italic': template(textarea, '*', '*', '斜体文字'); break;
            case 'strike': template(textarea, '~~', '~~', '删除线文字'); break;
            case 'heading': linePrefix(textarea, '## ', '标题', false); break;
            case 'quote': linePrefix(textarea, '> ', '引用内容', false); break;
            case 'code': template(textarea, '`', '`', '代码'); break;
            case 'code_block': insertBlock(textarea, '```\n代码\n```\n', 4, 6); break;
            case 'ul': linePrefix(textarea, '- ', '列表项', false); break;
            case 'ol':
                linePrefix(textarea, '', '列表项', true);
                var olCaret = renumberOrderedList(textarea, textarea.selectionEnd || 0);
                if (olCaret !== (textarea.selectionEnd || 0)) { textarea.setSelectionRange(olCaret, olCaret); dispatchInput(textarea); }
                break;
            case 'link': insertLink(textarea); break;
            case 'image': insertImage(textarea); break;
            case 'table': insertBlock(textarea, '| 表头 | 表头 |\n| --- | --- |\n| 内容 | 内容 |\n', 2, 4); break;
            case 'hr': insertBlock(textarea, '\n---\n\n', 1, 4); break;
        }
    };

    document.addEventListener('click', function (event) {
        var target = event.target instanceof Element ? event.target : null;
        if (!target) return;
        if (dialogFinish) {
            var dialog = document.getElementById('notify-modal');
            if (target.closest('[data-modal-close]') || target === dialog) closeDialog(null);
        }
        var item = target.closest('[data-nb-editor-insert]');
        if (item) {
            var itemRoot = item.closest('.nb-editor');
            var itemTextarea = itemRoot ? textareaOf(itemRoot) : null;
            if (itemTextarea) {
                event.preventDefault();
                var value = item.dataset.nbEditorInsert || '';
                replaceSelection(itemTextarea, value, value.length, value.length);
                closePanels();
            }
            return;
        }
        var emoji = target.closest('[data-nb-editor-emoji]');
        if (emoji) {
            event.preventDefault();
            var emojiRoot = emoji.closest('.nb-editor');
            if (!emojiRoot) return;
            var panel = buildPanel(emojiRoot);
            var open = panel.hidden;
            closePanels();
            if (open) {
                panel.hidden = false;
                openPanel = {root: emojiRoot, panel: panel, button: emoji};
                layoutPanel();
                emoji.classList.add('nb-editor-btn-active');
            }
            return;
        }
        var button = target.closest('[data-nb-editor-action]');
        if (button) {
            var root = button.closest('.nb-editor');
            if (!root) return;
            event.preventDefault();
            applyAction(button.dataset.nbEditorAction || '', root, button);
            return;
        }
        if (!target.closest('.nb-editor-panel')) closePanels();
    });

    document.addEventListener('input', function (event) {
        var target = event.target instanceof Element ? event.target : null;
        var textarea = target ? target.closest('textarea[name="body"]') : null;
        if (!textarea) return;
        var host = textarea.closest('.nb-editor-field');
        var editor = host ? host.querySelector('.nb-editor') : null;
        if (!editor) return;
        if (editor.dataset.nbEditorDraft) scheduleDraft(editor);
        if (host.classList.contains('nb-editor-live')) schedulePreview(editor);
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            if (dialogFinish) { closeDialog(null); return; }
            var full = document.querySelector('.nb-editor-field.nb-editor-full');
            if (full) {
                var root = full.querySelector('.nb-editor');
                if (root) toggleFullscreen(root, root.querySelector('[data-nb-editor-action="fullscreen"]'));
                return;
            }
            closePanels();
            return;
        }
        if (event.key !== 'Enter') return;
        // 中文输入法回车是在选词，不能当成换行处理。
        if (event.isComposing || event.keyCode === 229) return;
        var textarea = event.target instanceof Element ? event.target.closest('textarea[name="body"]') : null;
        var field = textarea ? textarea.closest('.nb-editor-field') : null;
        if (!field) return;
        if (event.ctrlKey || event.metaKey) {
            if (!field.querySelector('.nb-editor[data-nb-editor-hotkey]')) return;
            var form = textarea.closest('form');
            if (!form) return;
            event.preventDefault();
            var submit = form.querySelector('button[type="submit"]');
            if (submit) form.requestSubmit(submit);
            else form.requestSubmit();
            return;
        }
        if (event.shiftKey || event.altKey) return;
        handleListEnter(event, textarea);
    });

    document.addEventListener('submit', function (event) {
        var form = event.target instanceof Element ? event.target : null;
        var textarea = form ? form.querySelector('textarea[name="body"]') : null;
        var field = textarea ? textarea.closest('.nb-editor-field') : null;
        var root = field ? field.querySelector('.nb-editor') : null;
        if (!root || !root.dataset.nbEditorDraft) return;
        clearTimeout(draftTimers.get(root));
        dropDraft(root);
    }, true);

    var statusTimers = new WeakMap();

    var editorStatus = function (field, text, sticky) {
        var bar = field.querySelector('.nb-editor-status');
        if (!bar) {
            bar = document.createElement('div');
            bar.className = 'nb-editor-status';
            var root = field.querySelector('.nb-editor');
            if (root) root.after(bar);
            else field.appendChild(bar);
        }
        bar.textContent = text;
        bar.hidden = false;
        clearTimeout(statusTimers.get(field));
        if (!sticky) statusTimers.set(field, setTimeout(function () { bar.hidden = true; }, 3000));
    };

    var pasteFileName = function (type, index, total) {
        var ext = ({'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp'})[String(type || '').toLowerCase()] || 'png';
        var now = new Date();
        var pad = function (value) { return String(value).length < 2 ? '0' + value : String(value); };
        var stamp = now.getFullYear() + pad(now.getMonth() + 1) + pad(now.getDate())
            + '-' + pad(now.getHours()) + pad(now.getMinutes()) + pad(now.getSeconds());
        return 'paste-' + stamp + (total > 1 ? '-' + (index + 1) : '') + '.' + ext;
    };

    // 逐张上传：附件插件的 input.files 每次都会被整体替换，并发会互相顶掉。
    var uploadPastedFiles = function (target, files, index, done, failed, items) {
        if (index >= files.length) return Promise.resolve({markdown: done.join('\n'), ok: done.length, failed: failed, items: items});
        var name = pasteFileName(files[index].type, index, files.length);
        var named = new File([files[index]], name, {type: files[index].type || 'image/png'});
        return uploadThroughAttachment(target, named).then(function (result) {
            done.push(result.markdown || ('![' + name + '](' + result.url + ')'));
            if (result.item) items.push(result.item);
        }).catch(function () {
            failed += 1;
        }).then(function () {
            return uploadPastedFiles(target, files, index + 1, done, failed, items);
        });
    };

    var replaceMarker = function (textarea, marker, markdown) {
        var index = textarea.value.indexOf(marker);
        if (index < 0) return;
        var before = textarea.value.slice(0, index);
        var after = textarea.value.slice(index + marker.length);
        var prefix = markdown !== '' && before !== '' && before.slice(-1) !== '\n' ? '\n' : '';
        var suffix = markdown !== '' && after !== '' && after.slice(0, 1) !== '\n' ? '\n' : '';
        var value = prefix + markdown + suffix;
        textarea.value = before + value + after;
        var caret = index + value.length;
        textarea.setSelectionRange(caret, caret);
        textarea.focus();
        dispatchInput(textarea);
    };

    document.addEventListener('paste', function (event) {
        var target = event.target instanceof Element ? event.target : null;
        var textarea = target ? target.closest('textarea[name="body"]') : null;
        var items = (event.clipboardData && event.clipboardData.items) || [];
        var files = [];
        for (var i = 0; i < items.length; i++) {
            if (items[i].kind !== 'file' || String(items[i].type || '').indexOf('image/') !== 0) continue;
            var blob = items[i].getAsFile();
            if (blob) files.push(blob);
        }
        // 粘的不是图片（比如往弹层的“图片地址”框里粘链接文本）就放行，交给输入框默认行为。
        if (!files.length) return;
        var field = textarea ? textarea.closest('.nb-editor-field') : null;
        var root = field ? field.querySelector('.nb-editor') : null;
        // 图片弹层开着时焦点在弹层输入框里，取不到正文框：识别到图片粘贴就关掉弹层，直接插进对应的正文。
        var dialog = document.getElementById('notify-modal');
        if ((!root || root.dataset.nbEditorPaste !== '1') && dialog && !dialog.hidden && dialog.contains(target) && lastDialogTextarea) {
            textarea = lastDialogTextarea;
            field = textarea.closest('.nb-editor-field');
            root = field ? field.querySelector('.nb-editor') : null;
            if (root && root.dataset.nbEditorPaste === '1') {
                if (dialogFinish) closeDialog(null);
            } else root = null;
        }
        if (!root || root.dataset.nbEditorPaste !== '1') return;
        // 独立的「粘贴图片上传」插件已经在处理时让给它，避免同一张图传两次。
        if (document.querySelector('[data-paste-image-upload-hint]')) return;
        var uploadTarget = attachmentTarget(textarea);
        if (!uploadTarget) return;
        event.preventDefault();
        var marker = '<!-- nb-editor-upload:' + Date.now().toString(36) + Math.random().toString(36).slice(2) + ' -->';
        replaceSelection(textarea, marker, marker.length, marker.length);
        editorStatus(field, files.length > 1 ? '正在上传 ' + files.length + ' 张粘贴的图片……' : '正在上传粘贴的图片……', true);
        uploadPastedFiles(uploadTarget, files, 0, [], 0, []).then(function (result) {
            replaceMarker(textarea, marker, result.markdown);
            (result.items || []).forEach(releaseAttachment);
            // 粘贴的图片都成功插入后，顺手关掉还开着的弹层（含插入图片弹层）。
            if (!result.failed && result.ok && dialogFinish) closeDialog(null);
            if (result.failed && !result.ok) editorStatus(field, '粘贴的图片上传失败', false);
            else if (result.failed) editorStatus(field, '已插入 ' + result.ok + ' 张，' + result.failed + ' 张上传失败', false);
            else editorStatus(field, '已插入 ' + result.ok + ' 张图片', false);
        });
    });

    var scan = function (node) {
        if (node.matches && node.matches('[data-nb-editor]')) mount(node);
        if (node.querySelectorAll) node.querySelectorAll('[data-nb-editor]').forEach(mount);
    };

    scan(document);
    if (document.body && window.MutationObserver) {
        new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1) scan(node);
                });
            });
        }).observe(document.body, {childList: true, subtree: true});
    }
}());
/* next_admin */
(function next_admin_init(){
    var root=document.querySelector('[data-next-admin-app]');
    if(!root)return;
    var key='next_admin_theme';
    var stored='';
    try{stored=localStorage.getItem(key)||'';}catch(e){}
    var dark=stored?stored==='dark':window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;
    root.classList.toggle('is-dark',dark);
    var menuButton=root.querySelector('[data-next-admin-open]');
    function next_admin_set_menu(open){root.classList.toggle('is-menu-open',open);if(menuButton)menuButton.setAttribute('aria-expanded',open?'true':'false');}
    if(menuButton)menuButton.addEventListener('click',function(){next_admin_set_menu(true);});
    root.querySelectorAll('[data-next-admin-close]').forEach(function(button){button.addEventListener('click',function(){next_admin_set_menu(false);});});
    var theme=root.querySelector('[data-next-admin-theme]');
    if(theme)theme.addEventListener('click',function(){var next=!root.classList.contains('is-dark');root.classList.toggle('is-dark',next);try{localStorage.setItem(key,next?'dark':'light');}catch(e){}});
    document.querySelectorAll('[data-next-admin-confirm]').forEach(function(form){form.addEventListener('submit',function(event){if(!window.confirm(form.getAttribute('data-next-admin-confirm')||'确定执行此操作？'))event.preventDefault();});});
    var selectAll=document.querySelector('[data-next-admin-select-all]');
    if(selectAll)selectAll.addEventListener('change',function(){document.querySelectorAll('input[name="ids[]"]').forEach(function(box){box.checked=selectAll.checked;});});
    var bulkAction=document.querySelector('[data-next-admin-bulk-action]');
    var bulkForum=document.querySelector('[data-next-admin-bulk-forum]');
    function next_admin_bulk_state(){if(bulkForum)bulkForum.hidden=!bulkAction||bulkAction.value!=='move';}
    if(bulkAction){bulkAction.addEventListener('change',next_admin_bulk_state);next_admin_bulk_state();}
    var toast=document.querySelector('[data-next-admin-toast]');
    if(toast)window.setTimeout(function(){toast.classList.add('is-leaving');window.setTimeout(function(){toast.remove();},220);},3200);
    document.addEventListener('keydown',function(event){
        if(event.key==='Escape')next_admin_set_menu(false);
        if(event.key==='/'&&!/input|textarea|select/i.test(document.activeElement.tagName)){event.preventDefault();var input=root.querySelector('.next-admin-global-search input');if(input)input.focus();}
    });
})();
/* notice */
(function () {
    'use strict';

    var notice_js_route = "/index.php?a=notifications";
    var notice_js_labels = ["😍通知中心","😮通知中心"];
    var notice_js_rotation = true;
    var notice_js_interval = 0.4;
    var notice_js_font_size = "inherit";
    var notice_js_color = "inherit";

    function notice_js_is_route(link) {
        if (!link) return false;
        var href = link.getAttribute('href') || '';
        return href === notice_js_route || (notice_js_route && href.indexOf(notice_js_route + '?') === 0);
    }

    function notice_js_parse_labels(value) {
        try {
            var labels = JSON.parse(value || '[]');
            if (!Array.isArray(labels)) return [];
            return labels.filter(function (label) {
                return typeof label === 'string' && label.trim() !== '';
            });
        } catch (error) {
            return [];
        }
    }

    function notice_js_apply(link, label) {
        if (!link) return;
        link.textContent = label;
        if (notice_js_font_size !== 'inherit') link.style.fontSize = notice_js_font_size;
        else link.style.removeProperty('font-size');
        if (notice_js_color !== 'inherit') link.style.color = notice_js_color;
        else link.style.removeProperty('color');
    }

    function notice_js_collect_links(root) {
        if (!root || !root.querySelectorAll) return [];
        var nodes = root.querySelectorAll(
            '[data-slot~="top.menu_links"] a, .mobile-forum-strip a, .mobile-menu-links a'
        );
        var out = [];
        for (var i = 0; i < nodes.length; i++) {
            if (notice_js_is_route(nodes[i])) out.push(nodes[i]);
        }
        return out;
    }

    function notice_js_scan(root, state) {
        var links = notice_js_collect_links(root);
        for (var i = 0; i < links.length; i++) {
            var link = links[i];
            if (link.getAttribute('data-notice-js-ready') === '1') continue;
            notice_js_apply(link, notice_js_labels[0] || '通知中心');
            link.setAttribute('data-notice-js-ready', '1');
            state.links.push(link);
        }
    }

    function notice_js_init() {
        var state = {links: []};
        notice_js_scan(document, state);

        if (notice_js_rotation && notice_js_labels.length > 1) {
            window.setInterval(function () {
                state.links = state.links.filter(function (link) {
                    return link && link.isConnected;
                });
                if (!state.links.length) return;
                state.index = (typeof state.index === 'number' ? state.index + 1 : 1) % notice_js_labels.length;
                state.links.forEach(function (link) {
                    notice_js_apply(link, notice_js_labels[state.index]);
                });
            }, Math.max(100, Math.min(60000, notice_js_interval * 1000)));
        }

        if (window.MutationObserver && document.body) {
            var observer = new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    for (var i = 0; i < mutation.addedNodes.length; i++) {
                        var node = mutation.addedNodes[i];
                        if (node.nodeType === 1) notice_js_scan(node, state);
                    }
                });
            });
            observer.observe(document.body, {childList: true, subtree: true});
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', notice_js_init);
    else notice_js_init();
}());
/* today_hot */
document.addEventListener('click', function (e) {
    var root = e.target.closest('[data-today-hot]');
    var tab = e.target.closest('.today-hot-tab');
    if (root && tab) {
        e.preventDefault();
        if (root.dataset.todayHotLoading) return;
        root.dataset.todayHotLoading = '1';
        root.style.opacity = '.5';
        var base = root.dataset.refreshBase || '';
        var url = base.replace('__CAT__', encodeURIComponent(tab.dataset.cat));
        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok) throw new Error(d.message || '加载失败');
                applyHot(root, d.html, tab.dataset.cat);
            })
            .catch(function () { window.location.href = tab.href; })
            .finally(function () { root.style.opacity = ''; delete root.dataset.todayHotLoading; });
        return;
    }
    var btn = e.target.closest('[data-today-hot-refresh]');
    if (btn && root) {
        e.preventDefault();
        btn.disabled = true;
        var base = root.dataset.refreshBase || '';
        var cat = root.dataset.cat || 'all';
        var url = base.replace('__CAT__', encodeURIComponent(cat));
        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok) throw new Error(d.message || '加载失败');
                var list = document.querySelector('[data-today-hot] .today-hot-grid');
                if (list) list.outerHTML = d.html;
                var up = document.querySelector('[data-today-hot-updated]');
                if (up) up.textContent = '更新于 ' + new Date().toTimeString().slice(0, 8);
            })
            .catch(function () {})
            .finally(function () { btn.disabled = false; });
    }
});
function applyHot(root, html, cat) {
    var grid = root.querySelector('.today-hot-grid');
    if (grid) grid.outerHTML = html;
    root.dataset.cat = cat;
    var tabs = root.querySelectorAll('.today-hot-tab');
    tabs.forEach(function (t) {
        if (t.dataset.cat === cat) t.classList.add('active');
        else t.classList.remove('active');
    });
    root.style.opacity = '';
}
(function poll(ms){
    var root = document.querySelector('[data-today-hot]');
    if (root) {
        var rms = parseInt(root.dataset.refreshMs || '0', 10);
        if (rms > 0 && !root._todayHotTimer) {
            root._todayHotTimer = setInterval(function () {
                var btn = root.querySelector('[data-today-hot-refresh]');
                if (btn) btn.click();
            }, rms);
        }
    }
})();
/* user_files */
(() => {
    const copyText = async (text, button) => {
        let ok = false;
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
                ok = true;
            }
        } catch (e) {}
        if (!ok) {
            const area = document.createElement('textarea');
            area.value = text;
            area.setAttribute('readonly', '');
            area.style.position = 'fixed';
            area.style.opacity = '0';
            document.body.appendChild(area);
            area.select();
            try { ok = document.execCommand('copy'); } catch (e) {}
            area.remove();
        }
        if (button) {
            const old = button.textContent;
            button.textContent = ok ? '已复制' : '复制失败';
            setTimeout(() => { button.textContent = old; }, 1400);
        }
        return ok;
    };

    const userFilesUploadMessage = async (response) => {
        const text = await response.text();
        if (!text.trim()) return { ok: false, message: `服务器返回空响应（HTTP ${response.status}）` };

        try {
            const json = JSON.parse(text);
            if (json && typeof json === 'object') return json;
        } catch (e) {}

        const holder = document.createElement('div');
        holder.innerHTML = text;
        const plain = (holder.textContent || text).replace(/\s+/g, ' ').trim();
        return {
            ok: false,
            message: plain ? plain.slice(0, 240) : `服务器返回异常（HTTP ${response.status}）`,
        };
    };

    document.addEventListener('click', (event) => {
        const button = event.target.closest('[data-copy-user-files-path]');
        if (!button) return;
        const direct = button.getAttribute('data-copy-text');
        if (direct !== null) {
            copyText(direct, button);
            return;
        }
        const holder = button.closest('.user-files-path-row, .user-files-admin-stored, .user-files-path-panel');
        const code = holder ? holder.querySelector('[data-user-files-path]') : null;
        if (code) copyText(code.textContent.trim(), button);
    });

    const uploadDirectFiles = async (picker) => {
        const button = picker.closest('.user-files-head-actions')?.querySelector('[data-user-files-pick-files]');
        const result = picker.closest('.user-files-head-actions')?.querySelector('[data-user-files-direct-upload-result]');
        if (!button || !result) return;
        const files = picker.files ? Array.from(picker.files) : [];
        if (!files.length) return;

        const csrf = picker.closest('.user-files-head-actions')?.querySelector('input[name="_csrf"]');
        const uploadUrl = button.getAttribute('data-user-files-upload-url') || '';
        const folderId = button.getAttribute('data-user-files-folder-id') || '0';
        if (!uploadUrl || !csrf) {
            result.hidden = false;
            result.textContent = '上传初始化失败，请刷新页面后重试。';
            return;
        }

        button.disabled = true;
        result.hidden = false;
        result.innerHTML = '';

        const title = document.createElement('div');
        title.className = 'user-files-direct-upload-title';
        result.appendChild(title);

        let success = 0;
        for (let index = 0; index < files.length; index++) {
            const file = files[index];
            title.textContent = `正在上传 ${index + 1}/${files.length}：${file.name}`;
            const line = document.createElement('div');
            line.className = 'user-files-upload-result-item';
            const label = document.createElement('strong');
            label.textContent = `… ${file.name}`;
            line.appendChild(label);
            result.appendChild(line);

            const data = new FormData();
            data.append('_csrf', csrf.value);
            data.append('folder_id', folderId);
            data.append('attachment', file, file.name);

            try {
                const response = await fetch(uploadUrl, {
                    method: 'POST',
                    body: data,
                    credentials: 'same-origin',
                    headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
                });
                const json = await userFilesUploadMessage(response);
                const items = Array.isArray(json.results) ? json.results : [];
                const item = items.find((row) => row && row.name === file.name) || items[0] || json;
                if (!response.ok || !json.ok || !item || !item.ok) {
                    throw new Error((item && item.message) || json.message || `上传失败（HTTP ${response.status}）`);
                }

                success++;
                label.textContent = item.already_exists
                    ? `✓ ${file.name}（文件已存在，已更新到文件管理）`
                    : `✓ ${file.name}`;
                if (item.markdown) {
                    const copy = document.createElement('button');
                    copy.type = 'button';
                    copy.setAttribute('data-copy-user-files-path', '');
                    copy.setAttribute('data-copy-text', item.markdown);
                    copy.textContent = '复制插入链接';
                    line.appendChild(copy);
                }
            } catch (error) {
                label.textContent = `× ${file.name}：${error && error.message ? error.message : '上传失败'}`;
                line.classList.add('user-files-upload-result-error');
            }
        }

        picker.value = '';
        button.disabled = false;
        if (success > 0) {
            title.textContent = `上传完成：${success}/${files.length} 个文件成功，正在刷新文件列表…`;
            window.setTimeout(() => window.location.reload(), 1200);
        } else {
            title.textContent = `上传完成：${success}/${files.length} 个文件成功`;
        }
    };

    document.addEventListener('click', (event) => {
        const button = event.target.closest('[data-user-files-pick-files]');
        if (!button) return;
        const input = button.closest('.user-files-head-actions')?.querySelector('[data-user-files-picker-input]');
        if (!input) return;
        event.preventDefault();
        input.click();
    });

    document.addEventListener('change', (event) => {
        const picker = event.target.closest('[data-user-files-picker-input]');
        if (picker) {
            uploadDirectFiles(picker);
            return;
        }
        const input = event.target.closest('[data-user-files-upload-input]');
        if (!input) return;
        const form = input.closest('[data-user-files-upload-form]');
        if (!form) return;
        const status = form.querySelector('[data-user-files-upload-status]');
        const count = input.files ? input.files.length : 0;
        if (status) status.textContent = count ? `已选择 ${count} 个文件，点击“开始上传”` : '';
    });

    document.addEventListener('submit', async (event) => {
        const form = event.target.closest('[data-user-files-upload-form]');
        if (!form) return;
        event.preventDefault();

        const input = form.querySelector('[data-user-files-upload-input]');
        const status = form.querySelector('[data-user-files-upload-status]');
        const result = form.parentElement.querySelector('[data-user-files-upload-result]');
        const submit = form.querySelector('button[type="submit"]');
        const files = input && input.files ? Array.from(input.files) : [];

        if (!files.length) {
            if (status) status.textContent = '请先选择文件';
            return;
        }

        if (submit) submit.disabled = true;
        if (result) {
            result.hidden = false;
            result.innerHTML = '';
        }

        let success = 0;
        const total = files.length;

        for (let index = 0; index < total; index++) {
            const file = files[index];
            if (status) status.textContent = `正在上传 ${index + 1}/${total}：${file.name}`;

            const data = new FormData();
            for (const element of form.querySelectorAll('input[type="hidden"]')) {
                if (element.name) data.append(element.name, element.value);
            }
            const folder = form.querySelector('[name="folder_id"]');
            if (folder) data.set('folder_id', folder.value);
            data.set('attachment', file, file.name);

            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    body: data,
                    credentials: 'same-origin',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json',
                    },
                });
                const json = await userFilesUploadMessage(response);
                const items = Array.isArray(json.results) ? json.results : [];
                const item = items.find((row) => row && row.name === file.name) || items[0] || json;

                if (json.ok && item && item.ok) {
                    success++;
                    const line = document.createElement('div');
                    line.className = 'user-files-upload-result-item';

                    const label = document.createElement('strong');
                    label.textContent = `✓ ${file.name}`;
                    line.appendChild(label);

                    if (item.markdown) {
                        const copy = document.createElement('button');
                        copy.type = 'button';
                        copy.setAttribute('data-copy-user-files-path', '');
                        copy.setAttribute('data-copy-text', item.markdown);
                        copy.textContent = '复制插入链接';
                        line.appendChild(copy);
                    }
                    result.appendChild(line);
                } else {
                    const message = item && item.message ? item.message : (json.message || '上传失败');
                    throw new Error(message);
                }
            } catch (error) {
                const line = document.createElement('div');
                line.className = 'user-files-upload-result-item user-files-upload-result-error';
                line.textContent = `× ${file.name}：${error && error.message ? error.message : '上传失败'}`;
                result.appendChild(line);
            }
        }

        input.value = '';
        if (submit) submit.disabled = false;
        if (status) status.textContent = `上传完成：${success}/${total} 个文件成功`;

        const back = form.closest('.user-files-upload-page')?.querySelector('a[href*="user_files"]');
        if (back && result && success > 0) {
            const link = document.createElement('a');
            link.href = back.href;
            link.textContent = '返回文件管理';
            link.className = 'user-files-upload-result-back';
            result.appendChild(link);
        }
    });

    const user_files_recent_url = "/index.php?a=user_files_recent";
    const loadRecentFilesIntoNotifyModal = async () => {
        const modalBody = document.querySelector('#notify-modal-body');
        if (!modalBody || modalBody.querySelector('.user-files-recent-notify')) return;
        try {
            const url = new URL(user_files_recent_url, window.location.href);
            url.searchParams.set('_', String(Date.now()));
            const response = await fetch(url.toString(), {
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'text/html' },
            });
            if (!response.ok) return;
            const html = await response.text();
            if (!html.trim()) return;
            const wrap = document.createElement('div');
            wrap.className = 'user-files-recent-notify';
            wrap.innerHTML = html;
            modalBody.appendChild(wrap);
        } catch (e) {}
    };

    if (typeof window.openNotify === 'function' && !window.__userFilesOpenNotifyWrapped) {
        const originalOpenNotify = window.openNotify;
        window.openNotify = async function (url) {
            const result = await originalOpenNotify(url);
            await loadRecentFilesIntoNotifyModal();
            return result;
        };
        window.__userFilesOpenNotifyWrapped = true;
    }
})();
